<?php
namespace Bookly\Backend\Components\Notices\Proxy;

use Bookly\Lib;

/**
 * @method static void renderWelcome()
 */
abstract class Pro extends Lib\Base\Proxy
{

}