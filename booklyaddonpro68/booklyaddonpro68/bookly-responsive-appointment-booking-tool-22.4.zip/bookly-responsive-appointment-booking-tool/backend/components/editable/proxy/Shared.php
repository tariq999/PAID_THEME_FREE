<?php
namespace Bookly\Backend\Components\Editable\Proxy;

use Bookly\Lib;

/**
 * @method static void renderModals()
 */
abstract class Shared extends Lib\Base\Proxy
{

}