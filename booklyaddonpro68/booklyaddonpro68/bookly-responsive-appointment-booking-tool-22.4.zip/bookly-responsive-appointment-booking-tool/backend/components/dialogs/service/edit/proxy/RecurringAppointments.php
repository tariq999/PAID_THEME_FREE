<?php
namespace Bookly\Backend\Components\Dialogs\Service\Edit\Proxy;

use Bookly\Lib;

/**
 * @method static void renderSubForm( array $service ) Render repeat sub form.
 */
abstract class RecurringAppointments extends Lib\Base\Proxy
{

}