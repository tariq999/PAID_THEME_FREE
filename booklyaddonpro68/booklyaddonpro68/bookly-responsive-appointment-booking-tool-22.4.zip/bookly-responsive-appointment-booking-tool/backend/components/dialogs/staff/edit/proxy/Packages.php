<?php
namespace Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;

use Bookly\Lib;

/**
 * @method static void renderStaffServicesTip()
 */
abstract class Packages extends Lib\Base\Proxy
{

}