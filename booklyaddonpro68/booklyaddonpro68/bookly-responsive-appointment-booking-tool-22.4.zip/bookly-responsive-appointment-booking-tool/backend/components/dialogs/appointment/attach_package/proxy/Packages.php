<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\AttachPackage\Proxy;

use Bookly\Lib;

/**
 * @method static void renderAttachPackageDialog() Render attach package dialog.
 */
abstract class Packages extends Lib\Base\Proxy
{

}