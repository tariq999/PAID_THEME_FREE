<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\Edit\Proxy;

use Bookly\Lib;

/**
 * @method static array addCustomService( array $services ) Add custom service to given array of services.
 */
abstract class Pro extends Lib\Base\Proxy
{

}