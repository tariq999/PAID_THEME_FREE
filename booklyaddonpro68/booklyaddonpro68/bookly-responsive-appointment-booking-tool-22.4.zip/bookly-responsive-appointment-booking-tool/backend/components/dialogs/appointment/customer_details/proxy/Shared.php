<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\CustomerDetails\Proxy;

use Bookly\Lib;

/**
 * @method static array prepareL10n( array $localize )
 */
abstract class Shared extends Lib\Base\Proxy
{

}