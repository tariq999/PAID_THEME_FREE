<?php
namespace Bookly\Backend\Components\Settings\Proxy;

use Bookly\Lib;

/**
 * @method static void renderHelpMessage() Render tax help message.
 */
abstract class Taxes extends Lib\Base\Proxy
{

}