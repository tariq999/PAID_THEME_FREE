<?php
namespace Bookly\Backend\Modules\Calendar\Proxy;

use Bookly\Lib;

/**
 * @method static void renderSyncButton( array $staff_members ) Render Google Calendar sync button.
 */
abstract class AdvancedGoogleCalendar extends Lib\Base\Proxy
{

}