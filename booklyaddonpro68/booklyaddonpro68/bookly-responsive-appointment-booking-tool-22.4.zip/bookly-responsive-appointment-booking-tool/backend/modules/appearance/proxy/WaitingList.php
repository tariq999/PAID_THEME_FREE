<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * @method static void renderInfoText() Render WL info text in Time step.
 */
abstract class WaitingList extends Lib\Base\Proxy
{

}