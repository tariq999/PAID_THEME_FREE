<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * @method static void renderLocation() Render location select in Service step.
 */
abstract class Locations extends Lib\Base\Proxy
{

}