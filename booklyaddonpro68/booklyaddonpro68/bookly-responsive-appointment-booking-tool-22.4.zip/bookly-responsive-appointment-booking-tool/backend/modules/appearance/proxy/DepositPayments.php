<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * @method static void renderAppearance() Render editable selector for deposit/full payment
 */
abstract class DepositPayments extends Lib\Base\Proxy
{

}