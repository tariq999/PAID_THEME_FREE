<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * @method static void renderHighlightSpecialHours() Render 'Highlight special hours' on Time step.
 */
abstract class SpecialHours extends Lib\Base\Proxy
{

}