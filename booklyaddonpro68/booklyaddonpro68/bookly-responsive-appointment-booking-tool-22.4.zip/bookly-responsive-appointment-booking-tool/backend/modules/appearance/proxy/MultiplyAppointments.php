<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * @method static void renderQuantity() Render Multiply (quantity) control in Service step.
 */
abstract class MultiplyAppointments extends Lib\Base\Proxy
{

}