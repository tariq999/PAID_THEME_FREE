<?php
namespace Bookly\Backend\Modules\Settings\Proxy;

use Bookly\Lib;

/**
 * @method static void renderTab() Render custom statuses settings tab.
 */
abstract class CustomStatuses extends Lib\Base\Proxy
{

}