<?php
namespace Bookly\Backend\Modules\Appointments\Proxy;

use Bookly\Lib;

/**
 * @method static void renderAddOnsComponents() Render components on appointments list page.
 */
abstract class Shared extends Lib\Base\Proxy
{

}