<?php
namespace Bookly\Backend\Modules\Payments\Proxy;

use Bookly\Lib;

/**
 * @method static void renderDownloadButton() Render button for downloading invoice(s).
 */
abstract class Invoices extends Lib\Base\Proxy
{

}