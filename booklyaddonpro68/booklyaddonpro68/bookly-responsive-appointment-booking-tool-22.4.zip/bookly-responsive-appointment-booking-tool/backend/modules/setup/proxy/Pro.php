<?php
namespace Bookly\Backend\Modules\Setup\Proxy;

use Bookly\Lib;

/**
 * @method static array prepareOptions( array $options ) Prepare options.
 */
abstract class Pro extends Lib\Base\Proxy
{

}