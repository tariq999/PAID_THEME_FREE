<?php defined( 'ABSPATH' ) || exit; // Exit if accessed directly ?>
<div id="bookly-tbs" class="wrap">
    <div class="form-row align-items-center mb-3">
        <h4 class="col m-0"><?php esc_html_e( 'Initial setup', 'bookly' ) ?></h4>
    </div>
    <div id="bookly-setup-form"></div>
</div>