var bacolaThemeModule = {};
/* global bacola_settings */

(function($) {

	bacolaThemeModule.$window = $(window);

	bacolaThemeModule.$document = $(document);

	bacolaThemeModule.$body = $('body');


	
})(jQuery);