jQuery(document).ready(function ($) {
	("use strict");

	mapInit();

	// init function
	function mapInit() {
		borobazarStoreMap();
	}

	// Google map load for contact us
	function borobazarStoreMap() {
		if ($(".borobazarStoreMap").length) {
			var lat = $(".borobazarStoreMap").data("latitude");
			var lng = $(".borobazarStoreMap").data("longitude");
			var theme = $(".borobazarStoreMap").data("theme");
			var markerIcon = $(".borobazarStoreMap").data("marker");
			var mapStyle = [
				{
					elementType: "geometry",
					stylers: [
						{
							color: "#e7f2f0",
						},
					],
				},
				{
					elementType: "labels.icon",
					stylers: [
						{
							visibility: "off",
						},
					],
				},
				{
					elementType: "labels.text.fill",
					stylers: [
						{
							color: "#616161",
						},
					],
				},
				{
					elementType: "labels.text.stroke",
					stylers: [
						{
							color: "#e7f2f0",
						},
					],
				},
				{
					featureType: "administrative.land_parcel",
					elementType: "labels.text.fill",
					stylers: [
						{
							color: "#bdbdbd",
						},
					],
				},
				{
					featureType: "poi",
					elementType: "geometry",
					stylers: [
						{
							color: "#eeeeee",
						},
					],
				},
				{
					featureType: "poi",
					elementType: "labels.text.fill",
					stylers: [
						{
							color: "#757575",
						},
					],
				},
				{
					featureType: "poi.park",
					elementType: "geometry",
					stylers: [
						{
							color: "#e5e5e5",
						},
					],
				},
				{
					featureType: "poi.park",
					elementType: "labels.text.fill",
					stylers: [
						{
							color: "#9e9e9e",
						},
					],
				},
				{
					featureType: "road",
					elementType: "geometry",
					stylers: [
						{
							color: "#ffffff",
						},
					],
				},
				{
					featureType: "road.arterial",
					elementType: "labels.text.fill",
					stylers: [
						{
							color: "#757575",
						},
					],
				},
				{
					featureType: "road.highway",
					elementType: "geometry",
					stylers: [
						{
							color: "#dadada",
						},
					],
				},
				{
					featureType: "road.highway",
					elementType: "labels.text.fill",
					stylers: [
						{
							color: "#616161",
						},
					],
				},
				{
					featureType: "road.local",
					elementType: "labels.text.fill",
					stylers: [
						{
							color: "#9e9e9e",
						},
					],
				},
				{
					featureType: "transit.line",
					elementType: "geometry",
					stylers: [
						{
							color: "#e5e5e5",
						},
					],
				},
				{
					featureType: "transit.station",
					elementType: "geometry",
					stylers: [
						{
							color: "#eeeeee",
						},
					],
				},
				{
					featureType: "water",
					elementType: "geometry",
					stylers: [
						{
							color: "#c9c9c9",
						},
					],
				},
				{
					featureType: "water",
					elementType: "labels.text.fill",
					stylers: [
						{
							color: "#9e9e9e",
						},
					],
				},
			];

			// custom marker
			CustomMarker.prototype = new google.maps.OverlayView();
			function CustomMarker(opts) {
				this.setValues(opts);
			}
			CustomMarker.prototype.draw = function () {
				var self = this;
				var div = this.div;
				if (!div) {
					div = this.div = $(
						"" +
							"<div>" +
							'<div class="pin-wrap">' +
							'<div class="pin relative flex flex-col items-center">' +
							'<img class="borobazar-marker-img w-12 h-14 object-contain absolute -top-14 -left-6" src="' +
							markerIcon +
							'" alt="Marker"/>' +
							'<span class="borobazar-marker-animation flex items-center justify-center h-10 w-10 relative -left-5 bottom-5 -z-1">' +
							'<span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand opacity-20"></span>' +
							'<span class="relative inline-flex rounded-full h-8 w-8 bg-brand opacity-40"></span>' +
							"</span>" +
							"</div>" +
							"</div>" +
							"</div>" +
							""
					)[0];
					this.pinWrap = this.div.getElementsByClassName("pin-wrap");
					this.pin = this.div.getElementsByClassName("pin");
					div.style.position = "absolute";
					div.style.cursor = "pointer";
					var panes = this.getPanes();
					panes.overlayImage.appendChild(div);
					google.maps.event.addDomListener(div, "click", function (event) {
						google.maps.event.trigger(self, "click", event);
					});
				}
				var point = this.getProjection().fromLatLngToDivPixel(this.position);
				if (point) {
					div.style.left = point.x + "px";
					div.style.top = point.y + "px";
				}
			};

			// map options
			var mapCenter = new google.maps.LatLng(lat, lng);
			var mapOption = {
				zoom: 13,
				center: mapCenter,
				zoomControl: false,
				disableDefaultUI: true,
				keyboardShortcuts: false,
				styles: theme === "silver" ? mapStyle : [],
			};
			var map = new google.maps.Map(
				document.getElementById("borobazarStoreMap"),
				mapOption
			);
			var marker = new CustomMarker({
				position: mapCenter,
				map: map,
			});
		}
	}
});
