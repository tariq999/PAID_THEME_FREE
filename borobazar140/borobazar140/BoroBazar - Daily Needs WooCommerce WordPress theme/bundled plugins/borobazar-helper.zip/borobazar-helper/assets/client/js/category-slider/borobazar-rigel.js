// eslint-disable-next-line no-unused-vars
jQuery(document).ready(function ($) {
	'use strict';

	// eslint-disable-next-line no-undef
	new Swiper('#product-category-slider-rigel', {
		slidesPerView: 2,
		spaceBetween: 15,
		speed: 500,
		// responsive breakpoints
		breakpoints: {
			700: {
				slidesPerView: 3,
				spaceBetween: 15,
			},
			1000: {
				slidesPerView: 5,
				spaceBetween: 15,
			},
			1200: {
				slidesPerView: 6,
				spaceBetween: 15,
			},
			1440: {
				slidesPerView: 7,
				spaceBetween: 20,
			},
			1700: {
				slidesPerView: 8,
				spaceBetween: 25,
			},
		},

		// Navigation arrows
		navigation: {
			nextEl: '.borobazar-slider-next-button',
			prevEl: '.borobazar-slider-prev-button',
		},

		// And if we need scrollbar
		scrollbar: {
			el: '#product-category-slider-rigel .swiper-scrollbar',
			draggable: true,
		},
	});
});
