jQuery(document).ready(function ($) {
	('use strict');

	//global variables
	const menuAreaHeight = $('header.site-header').length
		? $('header.site-header').outerHeight()
		: 0;
	const adminBarHeight = $('body.admin-bar').length ? 32 : 0;

	init();
	//globally define customSelect
	var customSelect = customSelect();

	/**
	 * initializing main function.
	 */
	function init() {
		// initialize search functionalities
		if (typeof BoroBazarSearch !== 'undefined') {
			const formParams = $('#borobazar-product-filter-form')
				.find(":input[value][value!='']")
				.serialize();

			if (window.location.search) {
				const urlParams = decodeURIComponent(
					window.location.href.split('?')[1]
				);
				params = formParams + '&' + urlParams;
				const searchParams = urlParams.split('&');

				$.each(searchParams, function (index, value) {
					const attribute = decodeURIComponent(value);
					const splitAttrs = attribute.split('=');
					if (splitAttrs[0] === 'text-search' && splitAttrs[1]) {
						$('.product-text-search').val(splitAttrs[1]);
					}
					if (splitAttrs[0] === 'text-search' && splitAttrs[1]) {
						$('.borobazar-product-search-form-input').val(splitAttrs[1]);
					}
					$('form#borobazar-product-filter-form')
						.find(`:input[value="${splitAttrs[1]}"]`)
						.attr('checked', 'checked')
						.attr('previousValue', 'checked')
						.parent()
						.addClass('selected');

					//active custom select
					if (splitAttrs[0] === 'order_by' && splitAttrs[1]) {
						setTimeout(() => {
							const select = $('.borobazar-custom-select');
							const currentSelect = select.find(
								`span[data-value=${splitAttrs[1]}]`
							);

							currentSelect.addClass(
								'bg-white sm:bg-base text-brand sm:text-main font-medium sm:font-normal'
							);

							const text = select.find('.text-brand').text();
							select.find('.borobazar-custom-select-replace').text(text);
						}, 100);
					}
				});
				BoroBazarSearch.initSearch();
			} else {
				BoroBazarSearch.initSearch();
			}

			// search form text input field clear function on click.
			if ($('.borobazar-header-search-clear').length) {
				$('.borobazar-header-search-clear').on('click', function () {
					clearTextSearchForm();
				});
			}

			// calling functions
			handleForm();
			clearHeaderSearchForm();
			handleTextSearch();
			// handleMobileFilter();
			activeDropdown();
		}

		if (typeof BoroBazarGlobalSearch !== 'undefined') {
			handleTextSearch();
		}
		handleTextSearchUI();

		//BoroBazar Slider Block
		borobazarSlider();
		//Category dropdown
		categoryDropdown();
		//accordion
		accordion();
		searchParameterLoadMore();
		searchFilterDrawer();
		collectionSlider();
		bannerSlider();

		// Initializing Scroll to content
		if ($('.borobazar-scroll-to-content').length) {
			scrollToContent();
		}
	}

	//selected/active dropdown items
	function activeDropdown() {
		const dropdown = $('.borobazar-search-dropdown');
		$(dropdown).each(function () {
			const selected = $(this).find('.selected');

			if (selected.length > 0) {
				$(this)
					.children('.borobazar-search-dropdown-label')
					.addClass('bg-base');
			} else {
				$(this)
					.children('.borobazar-search-dropdown-label')
					.removeClass('bg-base');
			}
		});
	}

	//show fixed number of parameter in sidebar
	function searchParameterLoadMore() {
		$('.borobazar-parameter-list').each(function () {
			const item = $(this).children('*:not(.borobazar-parameter-load-more)');
			const button = $(this).children('.borobazar-parameter-load-more');
			const limit = $(this).data('limit') ? parseInt($(this).data('limit')) : 5;
			let display_count = 0;
			const totalCount = item.length;

			function show(start, end, selector) {
				for (let i = start; i < end; i++) {
					selector.eq(i).show();
				}
			}

			item.hide();
			button
				.on('click', function () {
					show(display_count, display_count + limit, item);
					display_count += limit;
					totalCount <= display_count && $(this).remove();
				})
				.trigger('click');
		});
	}

	//Search filters drawer
	function searchFilterDrawer() {
		const open = $('.borobazar-filters-open');
		const close = $('.borobazar-filters-close');
		const sidebar = $('.borobazar-product-search-sidebar');
		const overlay = $('.borobazar-filters-overlay');
		const classes = 'invisible -translate-x-full';

		open.on('click', function () {
			sidebar.removeClass(classes);
			overlay.removeClass('invisible opacity-0');
		});

		close.on('click', function () {
			sidebar.addClass(classes);
			overlay.addClass('invisible opacity-0');
		});
	}

	//Category dropdown
	function categoryDropdown() {
		$('.borobazar-search-dropdown-label').on('click', function () {
			$(this)
				.parent()
				.siblings()
				.find('.borobazar-search-dropdown-children.active')
				.slideToggle(300)
				.removeClass('active');
			$(this)
				.parent()
				.siblings()
				.find('.rotate-90')
				.addClass('rotate-0')
				.removeClass('rotate-90');

			$(this)
				.siblings('.borobazar-search-dropdown-children')
				.slideToggle(300)
				.toggleClass('active');
			$(this)
				.find('.rotate-0')
				.toggleClass('rotate-90')
				.removeClass('.rotate-0');
		});
	}

	//Custom SelectBox
	function customSelect() {
		$('.borobazar-custom-select').each(function () {
			$(this).children('select').css('display', 'none');

			const $current = $(this);

			$current.prepend(
				$('<div>', {
					class: $current
						.attr('class')
						.replace(
							/borobazar-custom-select/g,
							'borobazar-custom-select-box bg-white absolute top-full right-0 invisible opacity-0 z-30 shadow-dropdown rounded-md translate-y-5 duration-300'
						),
				})
			);

			const placeholder = $current.find('option:first-child').text();

			$current.prepend(
				$('<span>', {
					class: $current
						.attr('class')
						.replace(
							/borobazar-custom-select/g,
							'borobazar-custom-select-placeholder flex items-center cursor-pointer'
						),
				})
					.append(
						'<svg class="text-lightest ml-2" width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.99997 7.42017C5.7849 7.42017 5.56987 7.33805 5.4059 7.17417L0.24617 2.01439C-0.0820566 1.68616 -0.0820566 1.154 0.24617 0.825904C0.574263 0.497811 1.10632 0.497811 1.43457 0.825904L5.99997 5.39156L10.5654 0.826063C10.8936 0.49797 11.4256 0.49797 11.7537 0.826063C12.0821 1.15416 12.0821 1.68632 11.7537 2.01455L6.59404 7.17433C6.42999 7.33824 6.21495 7.42017 5.99997 7.42017Z" fill="currentColor" /></svg>'
					)
					.prepend(
						$('<span>', {
							class: $current
								.attr('class')
								.replace(
									/borobazar-custom-select/g,
									'borobazar-custom-select-replace font-semibold text-main'
								),
							text: placeholder,
						})
					)
			);

			$(this)
				.find('option')
				.each(function () {
					$current.children('div').append(
						$('<span>', {
							class: $current
								.attr('class')
								.replace(
									/borobazar-custom-select/g,
									'borobazar-custom-select-options block text-main text-sm px-5 py-2.5 whitespace-nowrap cursor-pointer hover:bg-base transition-all'
								),
							text: $(this).text(),
							'data-value': $(this).val(),
						})
					);
				});
		});

		$(document).mouseup((e) => {
			if (!$('.borobazar-custom-select *').is(e.target)) {
				$('.borobazar-custom-select').removeClass('active');
			}
		});

		$('.borobazar-custom-select').click(function () {
			$(this).toggleClass('active');
		});

		$('.borobazar-custom-select-options').click(function () {
			const txt = $(this).text();
			const index = $(this).index();
			const value = $(this).data('value');

			$(this)
				.siblings('.borobazar-custom-select-options')
				.removeClass(
					'bg-white sm:bg-base text-brand sm:text-main font-medium sm:font-normal'
				);
			$(this).addClass(
				'bg-white sm:bg-base text-brand sm:text-main font-medium sm:font-normal'
			);

			const $currentSel = $(this).closest('.borobazar-custom-select');
			$currentSel.find('.borobazar-custom-select-replace').text(txt);
			$currentSel.children('select').prop('selectedIndex', index);
			$currentSel.children('select').val(value).trigger('change');
		});

		function reset() {
			$('.borobazar-custom-select')
				.find('.borobazar-custom-select-replace')
				.text($('.borobazar-custom-select').find('option:first-child').text());
			$('.borobazar-custom-select').children('select').prop('selectedIndex', 0);
			$('.borobazar-custom-select-options').removeClass(
				'bg-white sm:bg-base text-brand sm:text-main font-medium sm:font-normal'
			);
			removeSpecificParamsfromURLParameter(window.location.search, 'order_by');
		}

		return {
			reset: reset,
		};
	}

	/**
	 * function for accordion
	 */
	function accordion() {
		const accordionTitle = $('.borobazar-accordion-title');
		const accordionDescription = $('.borobazar-accordion-description');

		accordionDescription.slideUp();

		accordionTitle.on('click', function () {
			$(this).parent().siblings().find('.active').removeClass('active');
			$(this).toggleClass('active');
			$(this)
				.parent()
				.siblings()
				.find('.active-description')
				.slideToggle()
				.removeClass('active-description');
			$(this)
				.next(accordionDescription)
				.slideToggle()
				.toggleClass('active-description');
		});
	}

	/*---------------------------------------------------------
  # Search functions area 
  ---------------------------------------------------------*/

	function handleTextSearch() {
		$('.borobazar-product-search-form-input').on('keyup', function (e) {
			// handle esc event
			if (e.which === 27) {
				return false;
			}
			const value = $(this).val();
			$('.borobazar-product-search-form-input').val(value);
			// sync with search banner (if exists)
			if ($('.borobazar-banner-text-search-input').length) {
				$('.borobazar-banner-text-search-input').val(value);
			}

			if (value === '') {
				$('.borobazar-header-search').removeClass('has-value');
			} else {
				$('.borobazar-header-search').addClass('has-value');
				if (value.length > 2) {
					// useScrollToTheElement($('.borobazar-product-search'));
				}
			}
		});

		// handle global search clear
		if ($('.borobazar-global-search-container').length) {
			$('.native-search-clear, .borobazar-global-search-overlay').on(
				'click',
				function () {
					$('.borobazar-global-search-input').val('');
					$('.borobazar-global-search-results').hide();
					$('.borobazar-global-search-container').removeClass(
						'result-found is-searching has-value'
					);
					useFreezeBodyScroll(false);
				}
			);
		}

		// handle global search
		$('.borobazar-global-search-input').on(
			'keyup',
			_.debounce(function () {
				const searchQuery = $(this).val();

				if (searchQuery === '') {
					$('.borobazar-global-search-results').hide();
					$('.borobazar-global-search-container').removeClass('has-value');
					return;
				}

				$('.borobazar-global-search-results').show();
				$('.borobazar-global-search-container').addClass(
					'is-searching has-value'
				);
				useFreezeBodyScroll(true);

				BoroBazarGlobalSearch.search({
					type: 'text',
					value: encodeURIComponent(searchQuery),
				});

				const siteSlug = BOROBAZAR_HELPER_DATA.siteSlug;
				const siteURL = BOROBAZAR_HELPER_DATA.siteUrl;
				const searchPageSlug = BOROBAZAR_HELPER_DATA.searchPageSlug;
				const loadMoreAnchor = $('.borobazar-more-result');

				if (BOROBAZAR_HELPER_DATA && BOROBAZAR_HELPER_DATA.isMultiSite) {
					if (siteSlug) {
						loadMoreAnchor.attr(
							'href',
							`${searchPageSlug}?text-search${encodeURIComponent(
								'=' + searchQuery
							)}`
						);
					} else {
						loadMoreAnchor.attr(
							'href',
							`${searchPageSlug}?text-search${encodeURIComponent(
								'=' + searchQuery
							)}`
						);
					}
				} else {
					loadMoreAnchor.attr(
						'href',
						`${searchPageSlug}?text-search${encodeURIComponent(
							'=' + searchQuery
						)}`
					);
				}
			}, 500)
		);
		// End;
	}

	function handleForm() {
		$('.borobazar-product-search-form-input').on('keyup paste', function (e) {
			// handle esc event
			if (e.which === 27) {
				return false;
			}
			$('.product-text-search').val($(this).val());
			// sync with search banner (if exists)
			if ($('.borobazar-banner-text-search-input').length) {
				$('.borobazar-banner-text-search-input').val($(this).val());
			}
			if ($(this).val().length > 2) {
				$('#borobazar-product-filter-form').trigger('change');
			}
		});

		// handle filter form on change
		$('#borobazar-product-filter-form').on('change', function () {
			// const params = $(this).serialize();
			const params = $(this).find(":input[value][value!='']").serialize();
			// Start
			const urlParams = $(this)
				.find(
					":input[value][value!=''][name!='action_type'][name!='action'][name!='product_taxonomy_by']"
				)
				.serialize();
			history.pushState(null, null, `?${encodeURIComponent(urlParams)}`);
			BoroBazarSearch.search(params);
			//End
		});

		// prevent default behaviour of filter form
		$('#borobazar-product-filter-form').submit(function (e) {
			e.preventDefault();
		});

		// handle universal radio & checkbox filter
		if ($('.radio-search').length) {
			const customNameField = $(
				'#borobazar-product-filter-form input[name="product_taxonomy_by"]'
			).val();
			searchInputItemRadio('product-category[]');
			searchInputItemRadio('product-price[]');
			searchInputItemRadio('product-brand[]');
			searchInputItemRadio('product-genre[]');
			searchInputItemRadio('product-tag[]');
			searchInputItemRadio(customNameField + '[]');
		} else {
			const customNameField = $(
				'#borobazar-product-filter-form input[name="product_taxonomy_by"]'
			).val();
			searchInputItemCheckbox('product-category[]');
			searchInputItemCheckbox('product-brand[]');
			searchInputItemCheckbox('product-price[]');
			searchInputItemCheckbox('product-genre[]');
			searchInputItemCheckbox('product-tag[]');
			searchInputItemCheckbox(customNameField + '[]');
		}

		// handle products sorting
		$('.borobazar-products-sorting').on(
			'change',
			'.product-sorting',
			function () {
				const sortBy = $(this).val();
				$('.product-order-by').val(sortBy);
				const hasSortBy = $('.product-order-by').val();

				if (hasSortBy) {
					$('body #borobazar-product-filter-form').trigger('change');
				}
			}
		);

		// borobazar filter widgets
		$('.borobazar-filter-widgets').on(
			'click',
			'.clear-all-filter',
			function () {
				$('input:checkbox.form-checkbox:checked').each(function () {
					$(this).removeAttr('checked');
					$('#borobazar-product-filter-form').trigger('change');
				});
			}
		);

		// remove search params or tags
		$('body').on('click', '.remove-search-tag', function () {
			const parent = $(this).parent();
			const tag = parent.data('tag');

			const textField = $('.product-text-search');

			//remove animation
			parent.css({ animation: 'scale-out 1s cubic-bezier(0, 0, 0.2, 1)' });
			parent.on(
				'animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd',
				function () {
					$(this).css({ display: 'none' });
				}
			);

			if (tag === textField.val()) {
				textField.val('');
				$('.borobazar-product-search-form-input').val('');
				$('#borobazar-product-filter-form').trigger('change');
				removeSpecificParamsfromURLParameter(
					window.location.search,
					'text-search'
				);
			}

			$('input:checkbox.form-checkbox:checked').each(function () {
				if ($(this).val() === tag) {
					$(this).removeAttr('checked');
					$(this).attr('previousValue', false);
					$(this).parent().removeClass('selected');
					$('#borobazar-product-filter-form').trigger('change');
				}
			});
			activeDropdown();
		});

		// reset search page
		$('.reset-search-page').on('click', '.reset-form', function (e) {
			e.preventDefault();

			$('.product-text-search').val('');
			$('.borobazar-product-search-form-input').val('');

			$('#sortBy option').prop('selected', function () {
				return this.defaultSelected;
			});

			//Clear checkbox
			$("#borobazar-product-filter-form input[type='checkbox']")
				.removeAttr('checked')
				.attr('previousValue', false)
				.parent()
				.removeClass('selected');

			//clear selected dropdown
			activeDropdown();

			customSelect.reset();
			clearSearchParamsFromURL();
			BoroBazarSearch.search();
		});
	}

	function searchInputItemRadio(itemName) {
		$("input[name='" + itemName + "']").on('click', function () {
			$(this)
				.closest('.borobazar-product-search-filters')
				.find('.selected')
				.removeClass('selected');
			const previousValue = $(this).attr('previousValue');
			if (previousValue == 'checked') {
				$(this).removeAttr('checked');
				$(this).parent().removeClass('selected');
				$(this).attr('previousValue', false);
				$(this).siblings('.borobazar-checkbox-icon').removeClass('animate');
				const searchParams = new URLSearchParams(
					decodeURIComponent(window.location.search)
				);
				if (searchParams.has(itemName)) {
					searchParams.delete(itemName);
					window.history.replaceState(null, null, `${location.pathname}`);
				}
				BoroBazarSearch.search(searchParams);
			} else {
				$("input[name='" + itemName + "']:radio").attr('previousValue', false);
				$(this).attr('previousValue', 'checked');
				$(this).siblings('.borobazar-checkbox-icon').addClass('animate');
				$(this).attr('checked', 'checked');
				$(this).parent().addClass('selected');
			}

			activeDropdown();

			//Close drawer on category click
			$('.quick-search .borobazar-product-search-sidebar').addClass(
				'invisible -translate-x-full'
			);
			$('.borobazar-filters-overlay').addClass('invisible opacity-0');
		});
	}

	function searchInputItemCheckbox(itemName) {
		$("input[name='" + itemName + "']").on('click', function () {
			const previousValue = $(this).attr('previousValue');
			if (previousValue == 'checked') {
				$(this).removeAttr('checked');
				$(this).attr('previousValue', false);
				$(this).parent().removeClass('selected');
				$(this).siblings('.borobazar-checkbox-icon').removeClass('animate');
				// Fire Search
				$('#borobazar-product-filter-form').trigger('change');
				// BoroBazarSearch.search();
				// clearSearchParamsFromURL();
			} else {
				$(this).attr('checked', 'checked');
				$(this).attr('previousValue', 'checked');
				$(this).parent().addClass('selected');
				$(this).siblings('.borobazar-checkbox-icon').addClass('animate');
			}

			activeDropdown();
		});
	}

	/**
	 * search form text input field clear function on click.
	 */
	function clearHeaderSearchForm() {
		if ($('.borobazar-header-search-clear').length) {
			$('.borobazar-header-search-clear').on('click', function () {
				clearTextSearchForm();
			});
		}
	}

	/**
	 * search form text input field clear function.
	 */
	function clearTextSearchForm() {
		if ($('.borobazar-product-search-form-input').length) {
			const inputValue = $('.borobazar-product-search-form-input').val();
			if (inputValue !== '') {
				$('.borobazar-product-search-form-input').val('');

				if ($('.borobazar-banner-text-search-input').length) {
					$('.borobazar-banner-text-search-input').val('');
				}

				$('.product-text-search').val('');
				$('#borobazar-product-filter-form').trigger('change');
				removeSpecificParamsfromURLParameter(
					window.location.search,
					'text-search'
				);
			}
		}
	}

	function removeSpecificParamsfromURLParameter(url, parameter) {
		//prefer to use l.search if you have a location/link object
		const urlparts = url.split('?');
		if (urlparts.length >= 2) {
			const prefix = encodeURIComponent(parameter) + '=';
			const pars = urlparts[1].split(/[&;]/g);
			//reverse iteration as may be destructive
			for (let i = pars.length; i-- > 0; ) {
				//idiom for string.startsWith
				if (pars[i].lastIndexOf(prefix, 0) !== -1) {
					pars.splice(i, 1);
				}
			}
			return urlparts[0] + (pars.length > 0 ? '?' + pars.join('&') : '');
		}
		return url;
	}

	/**
	 * search URL clear function.
	 */
	function clearSearchParamsFromURL() {
		const url = window.location.toString();
		if (url.indexOf('?') > 0) {
			const clean_url = url.substring(0, url.indexOf('?'));
			window.history.replaceState({}, document.title, clean_url);
		}
		$('body .extend-search-filters-top').addClass('lg:hidden');
		$('body .reset-search-page').addClass('hidden');
	}

	/**
	 * handling header input text search ui.
	 */
	function handleTextSearchUI() {
		let body = $('body'),
			headerSearch = $('.borobazar-header-search'),
			headerGlobalSearch = $('.borobazar-global-search-container');

		if (headerSearch.length) {
			const searchHandler = $('.borobazar-header-search-handler');
			const searchField = $('.borobazar-header-search-field');
			const searchClear = $('.borobazar-header-search-clear');
			const mainMenu = $('.borobazar-main-navigation');
			const searchInput = searchField.find('input');

			// show search form
			searchHandler.on('click', function (e) {
				e.stopPropagation();
				searchHandler.addClass('hidden');
				headerSearch.removeClass('hidden');
				headerSearch.addClass('search-is-open');
				body.addClass('header-search-is-open');
				searchField.removeClass('opacity-0');
				mainMenu.removeClass('xl:flex');
				searchInput.focus();
				// run for global search
				if (headerGlobalSearch.length) {
					useFreezeBodyScroll(true);
					$('.borobazar-global-search-overlay').removeClass(
						'opacity-0 invisible'
					);
				}
			});

			// hide search form
			searchClear.on('click', function () {
				hideAndClearSearch();
			});

			// hide search form on outside click
			$(document).on('click', function (e) {
				if (
					$(e.target).closest(headerSearch).length == 0 &&
					headerSearch.is(':visible')
				) {
					headerSearch.addClass('hidden');
					searchHandler.removeClass('hidden');
					headerSearch.removeClass('search-is-open has-value');
					body.removeClass('header-search-is-open');
					mainMenu.addClass('xl:flex');
					searchField.addClass('opacity-0');
				}
			});

			// hide search from on esc press
			$(document).on('keydown', function (e) {
				if (e.which === 27) {
					hideAndClearSearch();
				}
			});

			// hide & clear search form
			function hideAndClearSearch() {
				headerSearch.addClass('hidden');
				searchHandler.removeClass('hidden');
				headerSearch.removeClass('search-is-open has-value');
				body.removeClass('header-search-is-open');
				mainMenu.addClass('xl:flex');
				searchField.addClass('opacity-0');
				clearTextSearchForm();
				// run for global search
				if (headerGlobalSearch.length) {
					useFreezeBodyScroll(false);
					$('.borobazar-global-search-overlay').addClass('opacity-0 invisible');
				}
			}
		}
	}

	function useScrollToTheElement(targetElement) {
		if (targetElement.length) {
			const header = $('#masthead>div');
			const headerBoundingClientRect = header[0].getBoundingClientRect();
			$('html, body')
				.stop()
				.animate(
					{
						scrollTop:
							targetElement.offset().top - headerBoundingClientRect.bottom,
					},
					700
				);
		}
	}

	function useFreezeBodyScroll(freezeState) {
		if (typeof freezeState !== 'boolean') {
			console.error(
				'useFreezeBodyScroll param should be a boolean type value.'
			);
			return false;
		}
		const body = $('body');
		if (freezeState) {
			body.addClass('overflow-hidden');
			body.removeClass('overflow-x-hidden');
		} else {
			body.removeClass('overflow-hidden');
			body.addClass('overflow-x-hidden');
		}
	}

	//borobazar Slider Block
	function borobazarSlider() {
		$('.borobazar-slider').each(function () {
			const slider = $(this).find('.borobazar-slider-settings');
			const selector = $(this).find('.swiper').attr('id');
			const template = slider.data('template');

			const slidesPerViewDesktop = slider.data('slides-per-view-desktop');
			const slidesPerViewLaptop = slider.data('slides-per-view-laptop');
			const slidesPerViewTab = slider.data('slides-per-view-tab');
			const slidesPerViewMobile = slider.data('slides-per-view-mobile');
			const spaceBetweenDesktop = slider.data('space-between-desktop');
			const spaceBetweenLaptop = slider.data('space-between-laptop');
			const spaceBetweenTab = slider.data('space-between-tab');
			const spaceBetweenMobile = slider.data('space-between-mobile');
			const autoPlay = slider.data('autoplay');
			const loop = slider.data('loop');
			const speed = slider.data('speed');
			const centeredSlides = slider.data('centered-slides');
			const grabCursor = slider.data('grab-cursor');

			let pagination = false;
			if (template == 'hero') {
				pagination = {
					el: `#${selector} .swiper-pagination`,
					type: 'bullets',
					clickable: true,
				};
			}

			new Swiper('#' + selector, {
				slidesPerView: slidesPerViewMobile,
				spaceBetween: spaceBetweenMobile,
				autoplay: autoPlay,
				loop: loop,
				speed: speed,
				centeredSlides: centeredSlides,
				grabCursor: grabCursor,
				navigation: {
					nextEl: '.borobazar-slider-next-button',
					prevEl: '.borobazar-slider-prev-button',
				},
				scrollbar: {
					el: '#' + selector + ' .swiper-scrollbar',
					draggable: true,
				},
				pagination: pagination,
				breakpoints: {
					767: {
						slidesPerView: slidesPerViewTab,
						spaceBetween: spaceBetweenTab,
					},
					1200: {
						slidesPerView: slidesPerViewLaptop,
						spaceBetween: spaceBetweenLaptop,
					},
					1400: {
						slidesPerView: slidesPerViewDesktop,
						spaceBetween: spaceBetweenDesktop,
					},
				},
			});
		});
	}

	//borobazar collection block slider
	function collectionSlider() {
		$('.borobazar-collection-block').each(function () {
			const slider = $(this).find('.borobazar-collection-slider');
			const selector = slider.attr('id');
			const template = slider.data('template');

			new Swiper('#' + selector, {
				slidesPerView: 1.15,
				spaceBetween: 15,
				speed: 500,
				navigation: {
					nextEl: '.borobazar-slider-next-button',
					prevEl: '.borobazar-slider-prev-button',
				},
				scrollbar: {
					el: '#' + selector + ' .swiper-scrollbar',
					draggable: true,
				},
				breakpoints: {
					767: {
						slidesPerView: template == 'modern' ? 2 : 2,
						spaceBetween: 25,
					},
					990: {
						slidesPerView: template == 'modern' ? 2 : 3,
						spaceBetween: 25,
					},
					1400: {
						slidesPerView: template == 'modern' ? 3 : 4,
						spaceBetween: 25,
					},
				},
			});
		});
	}

	//Banner Slider
	function bannerSlider() {
		new Swiper('.borobazar-search-banner .swiper', {
			slidesPerView: 1,
			spaceBetween: 0,
			loop: true,
			speed: 800,
			navigation: false,
			pagination: {
				el: '.borobazar-search-banner .swiper-pagination',
				type: 'bullets',
				clickable: true,
			},
			autoplay: { delay: 6500, disableOnInteraction: false },
		});
	}

	//mousemove animation
	setTimeout(function () {
		const animeEl = $('.mouse-move-effect');

		animeEl.on('mousemove', function (e) {
			const r = this.getBoundingClientRect();

			$(this).css({
				'--x': e.clientX - (r.left + Math.floor(r.width / 2)),
				'--y': e.clientY - (r.top + Math.floor(r.height / 2)),
			});
		});

		animeEl.on('mouseleave', function () {
			$(this).css({
				'--x': 0,
				'--y': 0,
			});
		});
	}, 500);

	//scrollSpy
	function scrollSpy() {
		let offset = 0;
		$(window).width() < 600
			? (offset = menuAreaHeight + 35)
			: (offset = adminBarHeight + menuAreaHeight + 35);
		const scrollPosition = $(window).scrollTop();
		const elems = $('.borobazar-scroll-to-content-single');
		elems.each(function () {
			const elemTop = $(this).offset().top - offset;
			const elemBottom = elemTop + $(this).height();
			if (scrollPosition >= elemTop && scrollPosition <= elemBottom) {
				const id = $(this).attr('id');
				const navElem = $('a[href="#' + id + '"]');
				navElem
					.addClass('text-brand before:bg-brand')
					.siblings()
					.removeClass('text-brand before:bg-brand');
			}
		});
	}

	//Scroll to content
	function scrollToContent() {
		let offset = 0;
		$(window).width() < 600
			? (offset = menuAreaHeight + 30)
			: (offset = adminBarHeight + menuAreaHeight + 30);

		$('.borobazar-scroll-to-content-list').css({ top: offset });

		$('.borobazar-scroll-to-content-list a').on('click', function (event) {
			event.preventDefault();
			const $anchor = $(this);
			$('html, body')
				.stop()
				.animate(
					{
						scrollTop: $($anchor.attr('href')).offset().top - offset,
					},
					700
				);
			setTimeout(function () {
				$anchor.siblings().removeClass('text-brand before:bg-brand');
				$anchor.addClass('text-brand before:bg-brand');
			}, 700);
		});
	}

	/**
	 * checking search input value
	 */
	function checkProductSearchValue() {
		if ($('.borobazar-product-search-form-input').length) {
			const inputValue = $('.borobazar-product-search-form-input').val();
			if (inputValue !== '') {
				$('.borobazar-header-search').addClass('has-value');
			} else {
				$('.borobazar-header-search').removeClass('has-value');
			}
		}
	}

	/*---------------------------------------------------------
  # Window on load functions
  ---------------------------------------------------------*/
	$(window).on('load', function () {
		checkProductSearchValue();
	});

	/*---------------------------------------------------------
  # Window on scroll functions
  ---------------------------------------------------------*/
	$(window).on('scroll', function () {
		//Initializing scrollspy on scroll
		if ($('.borobazar-scroll-to-content').length) {
			scrollSpy();
		}
	});

	/*---------------------------------------------------------
  # AjaxComplete functions
  ---------------------------------------------------------*/
	$(document).ajaxComplete(function () {
		checkProductSearchValue();
	});
});
