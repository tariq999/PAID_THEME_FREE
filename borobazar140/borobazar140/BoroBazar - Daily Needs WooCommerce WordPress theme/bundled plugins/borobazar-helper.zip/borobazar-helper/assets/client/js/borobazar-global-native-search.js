var BoroBazarGlobalSearch;
var helper;
var params = getParameters(document.location.search);
var listing = [];
var page = 0;
var globalAjaxFlag = true;
var cartItems = BOROBAZAR_GLOBAL_SEARCH.cartItems;
var lang = BOROBAZAR_GLOBAL_SEARCH.lang;
var currentCurrency = BOROBAZAR_GLOBAL_SEARCH.currentCurrency;

jQuery(document).ready(function ($) {
	/**
	 * Native Search Object
	 */
	BoroBazarGlobalSearch = {
		model: {
			text: "",
		},

		block: (selector) => {
			$(selector).block({
				message: null,
				overlayCSS: {
					background: "#fff",
					opacity: 0.6,
				},
			});
		},

		unblock: (selector) => {
			$(selector).unblock();
		},

		initSearch: () => {},

		search: (data) => {
			if (data.type == "text") {
				BoroBazarGlobalSearch.model.text = decodeURIComponent(data.value);
			}

			const url = $.param(BoroBazarGlobalSearch.model);
			params = getParameters(`?${url}`);
			BoroBazarGlobalSearch.fireAjax(params);
		},

		fireAjax: (params) => {
			BoroBazarGlobalSearch.block("#borobazar-product-block");
			handleSearchLoadingUI(true);
			globalAjaxFlag = true;
			$.ajax({
				type: "post",
				dataType: "json",
				url: BOROBAZAR_GLOBAL_SEARCH.ajax_url,
				data: {
					params,
					search_type: "global",
					action: BOROBAZAR_GLOBAL_SEARCH.action,
					nonce: BOROBAZAR_GLOBAL_SEARCH.nonce,
					action_type: "search",
				},
				success: function (response) {
					$(this).removeClass("loading");
					const responseData = response.data;
					listing = responseData.listing;
					count = responseData.count;
					BoroBazarGlobalSearch.renderResults();
					BoroBazarGlobalSearch.unblock("#borobazar-product-block");
					globalAjaxFlag = false;
					handleSearchLoadingUI(false);
					$("#borobazar-product-block").css({ opacity: "1" });
				},
				error: function (res) {
					console.log(res, "error response");
				},
			});
		},

		renderResults: (event) => {
			const container = $(".borobazar-global-search-results .products");
			container.html("");
			const template = _.template($("#borobazarGlobalSearchTemplate").html())({
				listing,
				count,
				cartItems,
				lang,
				currentCurrency,
			});
			container.html(template);
			// handing load more based on searched data
			if (listing.length > 0) {
				$(".borobazar-global-search-container").addClass("result-found");
				$(".borobazar-more-result").show();
			} else {
				$(".borobazar-global-search-container").removeClass("result-found");
				$(".borobazar-more-result").hide();
			}

			$(".borobazar-qty-button").hide();
			_.mapObject(cartItems, function (val, key) {
				$(`.borobazar-add-to-cart-${key}`).hide();
				$(`.borobazar-qty-button-${key}`).show();
				$(`.borobazar-cart-product-${key} span.cart-quantity`).html(val);
			});
		},
	};

	/**
	 * handle search loading ui.
	 * @param  {} isLoading: boolean
	 */
	function handleSearchLoadingUI(isLoading) {
		if (isLoading) {
			$(".borobazar-global-search-results").addClass(
				"is-loading flex items-center justify-center"
			);
			$(".borobazar-global-search-results .products").hide();
			$(".borobazar-more-result").hide();
			$(".borobazar-global-search-results .borobazar-loader").addClass(
				"is-active"
			);
		} else {
			$(".borobazar-global-search-results").removeClass(
				"is-loading flex items-center justify-center"
			);
			$(".borobazar-global-search-results .products").show();
			$(".borobazar-global-search-results .borobazar-loader").removeClass(
				"is-active"
			);
		}
	}
});

/**
 * Helper functionality
 * @param  {} url
 */
function getParameters(url) {
	var splitParametersFromUrl = url.split("?");
	if (!splitParametersFromUrl[1]) return [];
	var splitParameters = splitParametersFromUrl[1].split("&");
	var param = function (name, value) {
		(this.name = name), (this.value = value);
	};
	var result = new Array();
	for (var i = 0; i < splitParameters.length; i++) {
		var item = splitParameters[i].split("=");
		var itemParam = new param(
			decodeURIComponent(item[0]),
			decodeURIComponent(item[1]).split("+").join(" ")
		);
		result.push(itemParam);
	}
	return result;
}
