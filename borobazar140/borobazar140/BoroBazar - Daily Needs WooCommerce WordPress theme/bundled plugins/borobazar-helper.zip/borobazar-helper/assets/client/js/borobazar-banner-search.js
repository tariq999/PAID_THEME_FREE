jQuery(document).ready(function ($) {
	('use strict');

	bannerSearchInit();

	/*---------------------------------------------------------
	# init function
  ---------------------------------------------------------*/
	function bannerSearchInit() {
		if ($('.borobazar-search-banner').length) {
			bannerSearchObserver();

			if (BOROBAZAR_BANNER_SEARCH && BOROBAZAR_BANNER_SEARCH.hasQuickSearch) {
				handleBannerSearchWithQuickSearch();
			} else {
				handleBannerSearchWithOutQuickSearch();
			}
		}
	}

	/*---------------------------------------------------------
  # show hide header search based on banner search
	# intersection visibility
  ---------------------------------------------------------*/
	function bannerSearchObserver() {
		var bannerSearch = document.querySelectorAll('.borobazar-search-banner');
		var config = {
			threshold: 0.2,
		};
		observer = new IntersectionObserver((entries) => {
			entries.forEach((entry) => {
				if (entry.isIntersecting) {
					$('body').addClass('borobazar-banner-search-is-visible');
					$('body').removeClass('borobazar-banner-search-not-visible');
				} else {
					$('body').removeClass('borobazar-banner-search-is-visible');
					$('body').addClass('borobazar-banner-search-not-visible');
				}
			});
		}, config);
		bannerSearch.forEach((div) => {
			observer.observe(div);
		});
	}

	/*---------------------------------------------------------
  # search banner function with  Quick search on page
  ---------------------------------------------------------*/
	// change keyup paste
	function handleBannerSearchWithQuickSearch() {
		$('.borobazar-banner-text-search-input').on(
			'keyup',
			_.debounce(function (e) {
				// handle esc event
				if (e.which === 27) {
					// handleSearchClearing();
					return false;
				}

				$('.product-text-search').val($(this).val());
				$('.borobazar-product-search-form-input').val($(this).val());
				$('#borobazar-product-filter-form').trigger('change');
				useScrollToTheElement($('.borobazar-product-search'));
			}, 800)
		);

		// handle filter form on change
		$('#borobazar-product-filter-form').on('change', function () {
			const params = $(this).find(":input[value][value!='']").serialize();
			let urlParams = $(this)
				.find(":input[value][value!=''][name!='action_type'][name!='action']")
				.serialize();
			history.pushState(null, null, `?${encodeURIComponent(urlParams)}`);
			BoroBazarSearch.search(params);
		});

		// prevent default behaviour of filter form
		$('#borobazar-product-filter-form').submit(function (e) {
			e.preventDefault();
		});
	}

	/*---------------------------------------------------------
  # function for handling search result scroll position
  ---------------------------------------------------------*/
	function useScrollToTheElement(targetElement) {
		if (targetElement.length) {
			var header = $('#masthead>div');
			var storeNoticeHeight = 0;
			var headerBoundingClientRect = header[0].getBoundingClientRect();
			if ($('.borobazar-store-notice').length) {
				storeNoticeHeight = $('.borobazar-store-notice').outerHeight();
			}
			$('html, body')
				.stop()
				.animate(
					{
						scrollTop:
							targetElement.offset().top -
							headerBoundingClientRect.bottom +
							storeNoticeHeight,
					},
					700
				);
		}
	}

	/*---------------------------------------------------------
  # search banner function without Quick search on page
  ---------------------------------------------------------*/
	function handleBannerSearchWithOutQuickSearch() {
		$('.borobazar-banner-text-search-input').bind(
			'keyup paste',
			function (event) {
				// handle esc event
				if (event.which === 27) {
					return false;
				}
			}
		);

		$('.borobazar-banner-text-search-input').on('keypress', function (e) {
			let searchQuery = $(this).val();
			var redirectSearchPage = $('.borobazar-search-banner-redirect');

			BoroBazarGlobalSearch.search({
				type: 'text',
				value: searchQuery,
			});

			if (e.keyCode == 13) {
				window.location.href = redirectSearchURLOnBannerSearch(searchQuery);
			} else {
				redirectSearchPage.on('click', function (e) {
					window.location.href = redirectSearchURLOnBannerSearch(searchQuery);
				});
			}
		});
	}

	/*---------------------------------------------------------
  # search banner function redirect on search page
  ---------------------------------------------------------*/
	function redirectSearchURLOnBannerSearch(searchQuery) {
		var redirectSearchURL = '';
		var siteSlug = BOROBAZAR_BANNER_SEARCH.siteSlug;
		var siteURL = BOROBAZAR_BANNER_SEARCH.siteUrl;
		var searchPageSlug = BOROBAZAR_BANNER_SEARCH.searchPageSlug;

		// there was an search URL issue.
		// if (BOROBAZAR_BANNER_SEARCH && BOROBAZAR_BANNER_SEARCH.isMultiSite) {
		// 	if (siteSlug) {
		// 		redirectSearchURL = `/${siteSlug}/${searchPageSlug}?text-search=${searchQuery}`;
		// 	} else {
		// 		redirectSearchURL = `${siteURL}/${searchPageSlug}?text-search=${searchQuery}`;
		// 	}
		// } else {
		// 	redirectSearchURL = `${siteURL}/${searchPageSlug}?text-search=${searchQuery}`;
		// }

		if (BOROBAZAR_BANNER_SEARCH && BOROBAZAR_BANNER_SEARCH.isMultiSite) {
			if (siteSlug) {
				redirectSearchURL = `${searchPageSlug}?text-search=${searchQuery}`;
			} else {
				redirectSearchURL = `${searchPageSlug}?text-search=${searchQuery}`;
			}
		} else {
			redirectSearchURL = `${searchPageSlug}?text-search=${searchQuery}`;
		}

		return redirectSearchURL;
	}
});
