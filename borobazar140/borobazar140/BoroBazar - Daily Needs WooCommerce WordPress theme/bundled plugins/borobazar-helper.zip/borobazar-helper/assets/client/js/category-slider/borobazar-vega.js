jQuery(document).ready(function ($) {
	'use strict';

	const slider = $('#product-category-slider-vega');

	// eslint-disable-next-line no-undef
	new Swiper('#product-category-slider-vega', {
		slidesPerView: 1.3,
		grid: {
			rows: 3,
			fill: 'row',
		},
		spaceBetween: 14,
		speed: 500,
		// responsive breakpoints
		breakpoints: {
			550: {
				slidesPerView: 2,
				spaceBetween: 14,
				grid: {
					rows: 3,
					fill: 'row',
				},
			},
			700: {
				slidesPerView: 2,
				spaceBetween: 15,
				grid: {
					rows: 3,
					fill: 'row',
				},
			},
			1000: {
				slidesPerView: 3,
				spaceBetween: 14,
				grid: {
					rows: 3,
					fill: 'row',
				},
			},
			1200: {
				slidesPerView: 4,
				spaceBetween: 14,
				grid: {
					rows: 3,
					fill: 'row',
				},
			},
			1500: {
				slidesPerView: 5,
				spaceBetween: 14,
				grid: {
					rows: 3,
					fill: 'row',
				},
			},
			1700: {
				slidesPerView: 6,
				spaceBetween: 14,
				grid: {
					rows: 3,
					fill: 'row',
				},
			},
		},

		// Navigation arrows
		navigation: {
			nextEl: '.borobazar-slider-next-button',
			prevEl: '.borobazar-slider-prev-button',
		},

		// And if we need scrollbar
		scrollbar: {
			el: '#product-category-slider-vega .swiper-scrollbar',
			draggable: true,
		},

		on: {
			init: function () {
				if (this.isEnd) {
					slider.find('.swiper-wrapper').css({ justifyContent: 'center' });
				}
			},
			resize: function () {
				if (!this.isEnd) {
					slider.find('.swiper-wrapper').css({ justifyContent: '' });
				}
				for (const val of this.slides) {
					if (val.offsetTop > 10) {
						val.className += ' not-in-first-row';
					} else {
						val.className = 'swiper-slide';
					}
				}
			},
		},
	});
});
