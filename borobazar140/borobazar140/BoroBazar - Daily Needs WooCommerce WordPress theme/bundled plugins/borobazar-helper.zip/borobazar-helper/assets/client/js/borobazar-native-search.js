let BoroBazarSearch;

let helper;
let params = getParameters(document.location.search);
var cartItems = BOROBAZAR_SEARCH.cartItems;
let listing = [];
let count = 0;
let countText = '';
let searchTags = [];
let page = 1;
let isLoadMore = false;
var lang = BOROBAZAR_SEARCH.lang;
var loadMoreProductBy = BOROBAZAR_SEARCH.loadMoreProductBy;
var ajaxFlag = true;
var scrollExtraHeight = BOROBAZAR_SEARCH.scrollExtraHeight
	? parseInt(BOROBAZAR_SEARCH.scrollExtraHeight)
	: 100;
var isLoadMoreClicked = false;

jQuery(document).ready(function ($) {
	/**
	 * infiniteScroll
	 *
	 */
	function infiniteScroll() {
		if (
			ajaxFlag === false &&
			listing.length < count &&
			$(window).scrollTop() + scrollExtraHeight >=
				$(document).height() - $(window).height()
		) {
			$('.borobazar-product-infinity-loadmore').removeClass('hidden');
			page = page + 1;
			params = params + '&page=' + page;
			BoroBazarSearch.fireAjax(params);
			isLoadMoreClicked = true;
		}
	}

	/**
	 * BoroBazar Search Object
	 */
	BoroBazarSearch = {
		model: {
			category: '',
			text: '',
		},

		block: (selector) => {
			$(selector).block({
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0,
				},
			});
		},

		unblock: (selector) => {
			$(selector).unblock();
		},

		initSearch: (params) => {
			params = BoroBazarSearch.managePagination(page);
			BoroBazarSearch.renderSearchTagsDom(params);
			BoroBazarSearch.fireAjax(params);
		},

		search: (data) => {
			params = data + '&page=' + page;
			BoroBazarSearch.renderSearchTagsDom(params);
			BoroBazarSearch.fireAjax(params);
		},

		sorting: (sortBy) => {
			if (!count) {
				return;
			}

			const reverseOrder = ['priceHigh', 'popularityHigh', 'titleHigh'];

			switch (sortBy) {
				case 'popularityHigh':
				case 'popularityLow':
					sortKey = '_wc_average_rating';
					break;

				case 'priceHigh':
				case 'priceLow':
					sortKey = '_price';
					break;

				default:
					sortKey = 'title';
					break;
			}

			listing = _.sortBy(listing, function (list) {
				return list[sortKey];
			});

			if (reverseOrder.includes(sortBy)) {
				listing = listing.reverse();
			}

			BoroBazarSearch.renderResults();
		},

		fireAjax: (params) => {
			$('.borobazar-product-search-results').css('opacity', '.5');
			BoroBazarSearch.block('#borobazar-products-grid');
			ajaxFlag = true;
			let search_taxonomy_name,
				block_type = '';

			if ($('body .quick-search').length) {
				search_taxonomy_name = $(
					'#borobazar-product-filter-form input[name="product_taxonomy_by"]'
				).val();
				block_type = 'quick_search';
			} else {
				search_taxonomy_name = search_taxonomy_name = $(
					'#borobazar-product-filter-form input[name="product_taxonomy_by"]'
				).val();
				block_type = 'extended_search';
			}

			$.ajax({
				type: 'post',
				// dataType: "json",
				url: BOROBAZAR_SEARCH.ajax_url,
				data: {
					params,
					action: BOROBAZAR_SEARCH.action,
					nonce: BOROBAZAR_SEARCH.nonce,
					action_type: 'search',
					search_type: 'local',
					search_taxonomy_name: search_taxonomy_name,
					block_type: block_type,
				},
				success: function (response) {
					const responseData = response.data;
					listing = responseData.listing;
					count = responseData.count;
					searchTags = responseData.searchTags;
					searchTagsType = responseData.searchTagsType;
					countText = responseData.countText;
					BoroBazarSearch.renderSearchTags();
					BoroBazarSearch.renderResults();
					BoroBazarSearch.unblock('#borobazar-products-grid');
					ajaxFlag = false;
					$('#borobazar-product-grid').css({ opacity: '1' });
					$('.borobazar-product-search-results').css('opacity', '1');

					//Scroll to search results
					if (
						$('.borobazar-search-trigger-scroll').length &&
						isLoadMoreClicked == false
					) {
						var menuAreaHeight = $('header.site-header').length
							? $('header.site-header>div').outerHeight()
							: 0;
						var adminBarHeight = $('body.admin-bar').length ? 32 : 0;
						$('html, body').animate(
							{
								scrollTop:
									$('.borobazar-search-trigger-scroll').offset().top -
									(menuAreaHeight + adminBarHeight + 30),
							},
							600
						);
					}

					isLoadMoreClicked = false;
				},
				error: function (res) {
					console.log(res, 'error response');
				},
			});
		},

		renderResults: (event) => {
			if (!$('#borobazarGridTemplate').length) {
				return;
			}
		
			$('.products-count').html(countText);


			const container = $('.borobazar-product-search-results');
			const template = _.template($('#borobazarGridTemplate').html())({
				listing,
				count,
				cartItems,
				lang,
				// currentCurrency,
				loadMoreProductBy,
			});
			// console.log(template);
			container.html(template);
			if (listing.length < count) {
				BoroBazarSearch.loadMore();
			}
			BoroBazarSearch.ImageLazy();

			// $(".borobazar-qty-button").hide(); [prev code]
			$('.borobazar-qty-button').addClass('hidden');

			_.mapObject(cartItems, function (val, key) {
				// $(`.borobazar-add-to-cart-${key}`).hide(); [prev code]
				$(`.borobazar-add-to-cart-${key}`).removeClass('flex');
				$(`.borobazar-add-to-cart-${key}`).addClass('hidden');

				// $(`.borobazar-qty-button-${key}`).show(); [prev code]
				$(`.borobazar-qty-button-${key}`).removeClass('hidden');
				$(`.borobazar-qty-button-${key}`).addClass('flex');
				$(`.borobazar-cart-product-${key} span.cart-quantity`).html('x'+val);
				
			});
		},

		renderSearchTags: (event) => {
			if (!$('#borobazarSearchTags').length) {
				return;
			}
			const container = $('#borobazar-product-search-param');
			const template = _.template($('#borobazarSearchTags').html())({
				searchTags,
				searchTagsType,
				count,
			});
			container.html(template);
		},

		ImageLazy: () => {
			var lazyImage = $('.borobazar-lazy-image');
			$(document).on('lazyloaded', function () {
				lazyImage.on('error', function () {
					$(this).addClass('image-is-broken');
					$(this).parent().addClass('broken-image-icon');
				});
				lazyImage.each(function () {
					if ($(this).hasClass('lazyloaded')) {
						$(this).parent().removeClass('borobazar-content-loading');
						$(this).siblings('.borobazar-image-loader').remove();
					}
				});
			});
		},

		loadMore: () => {
			if (loadMoreProductBy === 'scroll') {
				$(window).on('scroll', infiniteScroll);
				$(window).on('touchmove', infiniteScroll);
			} else {
				$('.borobazar-product-search-loadmore button').on('click', function () {
					$(this).addClass('loading');
					page = page + 1;
					params = params + '&page=' + page;
					BoroBazarSearch.fireAjax(params);
					isLoadMoreClicked = true;
				});
			}
		},

		managePagination: (page) => {
			params = $('#borobazar-product-filter-form')
				.find(":input[value][value!='']")
				.serialize();
			params = params + '&page=' + page;
			return params;
		},

		renderSearchTagsDom: (params) => {
			if (document.location.search.length > 0) {
				const customNameField = $(
					'#borobazar-product-filter-form input[name="product_taxonomy_by"]'
				).val();
				if (
					params.includes('product-category') ||
					params.includes('product-brand') ||
					params.includes('product-price') ||
					params.includes('product-genre') ||
					params.includes(customNameField) ||
					params.includes('text-search')
				) {
					$('.extend-search-filters-top').removeClass('lg:hidden');
					$('.reset-search-page').removeClass('hidden');
				} else {
					$('.extend-search-filters-top').addClass('lg:hidden');
					$('.reset-search-page').addClass('hidden');
				}
			} else {
				$('.extend-search-filters-top').addClass('lg:hidden');
				$('.reset-search-page').addClass('hidden');
			}
		},
	};
});

/**
 * Helper functionality
 */
function getParameters(url) {
	let splitParametersFromUrl = url.split('?');
	if (!splitParametersFromUrl[1]) return [];
	let splitParameters = splitParametersFromUrl[1].split('&');
	let param = function (name, value) {
		(this.name = name), (this.value = value);
	};
	let result = new Array();
	for (let i = 0; i < splitParameters.length; i++) {
		let item = splitParameters[i].split('=');
		let itemParam = new param(
			decodeURIComponent(item[0]),
			decodeURIComponent(item[1]).split('+').join(' ')
		);
		result.push(itemParam);
	}
	return result;
}
