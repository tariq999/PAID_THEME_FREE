(function ($) {
	// const cartItems = IF_WOOCOMMERCE ? IF_WOOCOMMERCE.cartItems : [];
	const addToCartTimer = IF_WOOCOMMERCE
		? parseInt(IF_WOOCOMMERCE.addToCartTimer)
		: 3500;

	const loading = (selector) => {
		$(selector).block({
			message: null,
			overlayCSS: {
				background: "#fff",
				opacity: 0.6,
				zIndex: 1,
			},
		});
	};

	const unLoading = (selector) => {
		$(selector).unblock();
	};

	$("body").on("click", ".borobazar-update-qty", function (e) {
		e.preventDefault();
		const product_id = $(this).data("product_id");
		const type = $(this).data("type");
		const source = $(this).data("source");
		const loaderSelector = `.borobazar-product-${product_id}`;

		const data = {
			action: "borobazar_woocommerce_update_qty",
			product_id,
			type,
		};

		loading(loaderSelector);

		$.post(IF_WOOCOMMERCE.ajax_url, data, function (response) {
			const responseData = response.data;
			const header = $("#masthead>div");

			if (response.success === false) {
				$.toast({
					text: responseData.message,
					showHideTransition: "fade",
					hideAfter: addToCartTimer,
					position: {
						right: 10,
						top: 10 + header[0].getBoundingClientRect().bottom,
					},
					stack: false,
					bgColor: "#fff",
				});
			}

			if (response.success) {
				$(document.body).trigger("wc_fragment_refresh");
				$(document.body).trigger("wc_fragments_loaded");
				$(`.borobazar-cart-product-${product_id}`).html(responseData.notation+responseData.quantity);
				if (responseData.quantity) {
					// hide + btn
					$(`.borobazar-add-to-cart-${product_id}`).removeClass("flex");
					$(`.borobazar-add-to-cart-${product_id}`).addClass("hidden");
					// show quantity
					$(`.borobazar-qty-button-${product_id}`).removeClass("hidden");
					$(`.borobazar-qty-button-${product_id}`).addClass("flex");
				} else {
					// show + btn
					$(`.borobazar-add-to-cart-${product_id}`).removeClass("hidden");
					$(`.borobazar-add-to-cart-${product_id}`).addClass("flex");
					// hide quantity
					$(`.borobazar-qty-button-${product_id}`).removeClass("flex");
					$(`.borobazar-qty-button-${product_id}`).addClass("hidden");
				}

				//Toast message
				if (source !== "mini_cart") {
					$.toast({
						text: responseData.details.markup,
						showHideTransition: "fade",
						hideAfter: addToCartTimer,
						position: {
							right: 10,
							top: 10 + header[0].getBoundingClientRect().bottom,
						},
						stack: false,
						bgColor: "#fff",
					});
				}
			}
			unLoading(loaderSelector);
		}).fail(function () {
			console.log(IF_WOOCOMMERCE.message);
		});
	});

	// start mini cart remove ajax
	$("body").on("click", ".remove_from_cart_button", function (e) {
		e.preventDefault();

		const product_id = $(this).data("product_id");
		const type = $(this).data("type");
		const source = $(this).data("source");

		const data = {
			action: "borobazar_woocommerce_clean_mini_cart",
			product_id,
			type,
		};

		const loaderSelector = `.borobazar-product-${product_id}`;
		loading(loaderSelector);

		$.post(IF_WOOCOMMERCE.ajax_url, data, function (response) {
			if (response.success) {
				const responseData = response.data;

				$(document.body).trigger("wc_fragment_refresh");
				$(document.body).trigger("wc_fragments_loaded");
				$(`.borobazar-cart-product-${product_id}`).html(responseData.notation+responseData.quantity);
				// show
				$(`.borobazar-add-to-cart-${product_id}`).removeClass("hidden");
				$(`.borobazar-add-to-cart-${product_id}`).addClass("flex");

				// hide
				$(`.borobazar-qty-button-${product_id}`).removeClass("flex");
				$(`.borobazar-qty-button-${product_id}`).addClass("hidden");

				const header = $("#masthead>div");
				// Toast message
				if (responseData.source !== "mini_cart_remove") {
					$.toast({
						text: responseData.details.markup,
						showHideTransition: "fade",
						hideAfter: addToCartTimer,
						position: {
							right: 10,
							top: 10 + header[0].getBoundingClientRect().bottom,
						},
						stack: false,
						bgColor: "#fff",
					});
				}
			}
			unLoading(loaderSelector);
		}).fail(function () {
			console.log(IF_WOOCOMMERCE.message);
		});
	});
})(jQuery);
