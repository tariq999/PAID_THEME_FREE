/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
jQuery(document).ready(function ($) {
	'use strict';

	const slider = $('#product-category-slider-sirius');

	const swiper = new Swiper('#product-category-slider-sirius', {
		slidesPerView: 3,
		grid: {
			rows: 1,
			fill: 'row',
		},
		spaceBetween: 15,
		speed: 500,
		breakpoints: {
			550: {
				slidesPerView: 4,
				spaceBetween: 15,
				grid: {
					rows: 2,
					fill: 'row',
				},
			},
			700: {
				slidesPerView: 5,
				spaceBetween: 15,
				grid: {
					rows: 2,
					fill: 'row',
				},
			},
			1000: {
				slidesPerView: 6,
				spaceBetween: 20,
				grid: {
					rows: 2,
					fill: 'row',
				},
			},
			1200: {
				slidesPerView: 7,
				spaceBetween: 30,
				grid: {
					rows: 2,
					fill: 'row',
				},
			},
			1500: {
				slidesPerView: 8,
				spaceBetween: 30,
				grid: {
					rows: 2,
					fill: 'row',
				},
			},
			1700: {
				slidesPerView: 9,
				spaceBetween: 30,
				grid: {
					rows: 2,
					fill: 'row',
				},
			},
		},

		// Navigation arrows
		navigation: {
			nextEl: '.borobazar-slider-next-button',
			prevEl: '.borobazar-slider-prev-button',
		},

		// And if we need scrollbar
		scrollbar: {
			el: '#product-category-slider-sirius .swiper-scrollbar',
			draggable: true,
		},

		on: {
			init: function () {
				if (this.isEnd) {
					slider.find('.swiper-wrapper').css({ justifyContent: 'center' });
				}
			},
			resize: function () {
				if (!this.isEnd) {
					slider.find('.swiper-wrapper').css({ justifyContent: '' });
				}
				for (const val of this.slides) {
					if (val.offsetTop > 10) {
						val.className += ' not-in-first-row';
					} else {
						val.className = 'swiper-slide';
					}
				}
			},
		},
	});
});
