(function ($) {
	'use strict';

	$(document).ready(function () {
		//Mutation Observer
		function onElementInserted(containerSelector, elementSelector, callback) {
			const onMutationsObserved = function (mutations) {
				mutations.forEach(function (mutation) {
					if (mutation.addedNodes.length) {
						const elements = $(mutation.addedNodes).find(elementSelector);
						for (let i = 0, len = elements.length; i < len; i++) {
							callback(elements[i]);
						}
					}
				});
			};

			const target = $(containerSelector)[0];
			const config = { childList: true, subtree: true };
			const MutationObserver =
				window.MutationObserver || window.WebKitMutationObserver;
			const observer = new MutationObserver(onMutationsObserved);
			observer.observe(target, config);
		}

		onElementInserted(
			'body',
			'.borobazar-product-category-slider',
			function () {
				borobazarCategorySliderSirius();
				borobazarCategorySliderVega();
				borobazarCategorySliderRigel();
			}
		);

		// Remove image loading effect in admin
		function removeImageFadeIn() {
			if ($('.borobazar-image-fade-in').length) {
				$('.borobazar-image-fade-in img').removeClass('opacity-0');
				$('.borobazar-image-fade-in').removeClass('borobazar-image-fade-in');
			}
		}
		onElementInserted('body', '.borobazar-image-fade-in', function () {
			removeImageFadeIn();
		});

		function borobazarCategorySliderSirius() {
			// eslint-disable-next-line no-undef
			const siriusSlider = new Swiper('#product-category-slider-sirius', {
				slidesPerView: 3,
				grid: {
					rows: 1,
					fill: 'row',
				},
				spaceBetween: 15,
				speed: 500,
				breakpoints: {
					550: {
						slidesPerView: 4,
						spaceBetween: 15,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					700: {
						slidesPerView: 5,
						spaceBetween: 15,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1000: {
						slidesPerView: 6,
						spaceBetween: 20,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1200: {
						slidesPerView: 7,
						spaceBetween: 30,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1500: {
						slidesPerView: 8,
						spaceBetween: 30,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1700: {
						slidesPerView: 9,
						spaceBetween: 30,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
				},

				// Navigation arrows
				navigation: {
					nextEl: '.borobazar-slider-next-button',
					prevEl: '.borobazar-slider-prev-button',
				},

				// And if we need scrollbar
				scrollbar: {
					el: '#product-category-slider-sirius .swiper-scrollbar',
					draggable: true,
				},
			});
		}

		function borobazarCategorySliderVega() {
			// eslint-disable-next-line no-undef
			const vegaSlider = new Swiper('#product-category-slider-vega', {
				slidesPerView: 1.3,
				grid: {
					rows: 3,
					fill: 'row',
				},
				spaceBetween: 14,
				speed: 500,
				// responsive breakpoints
				breakpoints: {
					550: {
						slidesPerView: 2,
						spaceBetween: 14,
						grid: {
							rows: 3,
							fill: 'row',
						},
					},
					700: {
						slidesPerView: 2,
						spaceBetween: 15,
						grid: {
							rows: 3,
							fill: 'row',
						},
					},
					1000: {
						slidesPerView: 3,
						spaceBetween: 14,
						grid: {
							rows: 3,
							fill: 'row',
						},
					},
					1200: {
						slidesPerView: 4,
						spaceBetween: 14,
						grid: {
							rows: 3,
							fill: 'row',
						},
					},
					1500: {
						slidesPerView: 5,
						spaceBetween: 14,
						grid: {
							rows: 3,
							fill: 'row',
						},
					},
					1700: {
						slidesPerView: 6,
						spaceBetween: 14,
						grid: {
							rows: 3,
							fill: 'row',
						},
					},
				},

				// Navigation arrows
				navigation: {
					nextEl: '.borobazar-slider-next-button',
					prevEl: '.borobazar-slider-prev-button',
				},

				// And if we need scrollbar
				scrollbar: {
					el: '#product-category-slider-vega .swiper-scrollbar',
					draggable: true,
				},
			});
		}

		function borobazarCategorySliderRigel() {
			// eslint-disable-next-line no-undef
			new Swiper('#product-category-slider-rigel', {
				slidesPerView: 2,
				spaceBetween: 15,
				speed: 500,
				// responsive breakpoints
				breakpoints: {
					550: {},
					700: {
						slidesPerView: 4,
						spaceBetween: 15,
					},
					1000: {
						slidesPerView: 5,
						spaceBetween: 15,
					},
					1200: {
						slidesPerView: 6,
						spaceBetween: 15,
					},
					1500: {
						slidesPerView: 7,
						spaceBetween: 20,
					},
					1700: {
						slidesPerView: 8,
						spaceBetween: 25,
					},
				},

				// Navigation arrows
				navigation: {
					nextEl: '.borobazar-slider-next-button',
					prevEl: '.borobazar-slider-prev-button',
				},

				// And if we need scrollbar
				scrollbar: {
					el: '#product-category-slider-rigel .swiper-scrollbar',
					draggable: true,
				},
			});
		}
	});
})(jQuery);
