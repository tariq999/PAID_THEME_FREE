<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class WooProdSingleSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initWooProdSingleSettings();
        $this->WooProdSingleSettings();
    }

    /**
     * initWooProdSingleSettings.
     *
     * @return void
     */
    public function initWooProdSingleSettings()
    {
        Kirki::add_section('borobazar_woo_prod_section', [
            'title'       => esc_html__('WooCommerce Product Single', 'borobazar-helper'),
            'description' => esc_html__('Global settings for woocommerce product single page located here', 'borobazar-helper'),
            'panel'       => 'borobazar_config_panel',
            'priority'    => 160,
        ]);
    }

    /**
     * Generate layout based on conditions.
     *
     * @return array
     */
    public function generateLayoutChoices()
    {
        $choices = [
            'default'    => esc_html__('Layout (Default)', 'borobazar-helper'),
        ];
        return $choices;
    }

    /**
     * WooProdSingleSettings.
     *
     * @return void
     */
    public function WooProdSingleSettings()
    {
        // section choosing key : borobazar_woo_prod_section
        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'woo_single_layout_switch',
            'label'       => esc_html__('Product Single Layout', 'borobazar-helper'),
            'description' => esc_html__('Choose product single page layout for display', 'borobazar-helper'),
            'section'     => 'borobazar_woo_prod_section',
            'default'     => 'default',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => $this->generateLayoutChoices(),
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'select',
            'settings'         => 'woo_single_breadcrumb_switch',
            'label'            => esc_html__('Product single page breadcrumb switch', 'borobazar-helper'),
            'description'      => esc_html__('Choose either breadcrumb section is On/Off', 'borobazar-helper'),
            'section'          => 'borobazar_woo_prod_section',
            'default'          => 'off',
            'priority'         => 10,
            'multiple'         => 1,
            'choices'          => [
                'on'           => esc_html__('On', 'borobazar-helper'),
                'off'          => esc_html__('Off', 'borobazar-helper'),
            ],
            'active_callback'  => [
                [
                    'setting'  => 'woo_single_layout_switch',
                    'operator' => 'contains',
                    'value'    => ['layout_one', 'layout_rnb_one'],
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'woo_single_sidebar_switch',
            'label'       => esc_html__('Product Sidebar', 'borobazar-helper'),
            'description' => esc_html__('Choose either sidebar is On/Off (Not recommended)', 'borobazar-helper'),
            'section'     => 'borobazar_woo_prod_section',
            'default'     => 'off',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'select',
            'settings'         => 'woo_single_sidebar_position',
            'label'            => esc_html__('Product single page layout', 'borobazar-helper'),
            'description'      => esc_html__('Choose layout for display on shop', 'borobazar-helper'),
            'section'          => 'borobazar_woo_prod_section',
            'default'          => 'right',
            'priority'         => 10,
            'multiple'         => 1,
            'choices'          => [
                'right'        => esc_html__('Right Sidebar', 'borobazar-helper'),
                'left'         => esc_html__('Left Sidebar', 'borobazar-helper'),
            ],
            'active_callback'  => [
                [
                    'setting'  => 'woo_single_sidebar_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'woo_single_tabs_switch',
            'label'       => esc_html__('Product Single Tabs', 'borobazar-helper'),
            'description' => esc_html__('Choose to display tabs on product single page', 'borobazar-helper'),
            'section'     => 'borobazar_woo_prod_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'woo_single_upsell_products_switch',
            'label'       => esc_html__('Upsell products grid', 'borobazar-helper'),
            'description' => esc_html__('Choose upsell product to display on product single', 'borobazar-helper'),
            'section'     => 'borobazar_woo_prod_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'woo_single_related_products_switch',
            'label'       => esc_html__('Related products grid', 'borobazar-helper'),
            'description' => esc_html__('Choose related product to display on product single', 'borobazar-helper'),
            'section'     => 'borobazar_woo_prod_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);
    }
}
