<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class FooterSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initFooterSettings();
        $this->FooterSettings();
    }

    /**
     * initFooterSettings.
     *
     * @return void
     */
    public function initFooterSettings()
    {
        Kirki::add_section('borobazar_footer_section', [
            'title'       => esc_html__('Footer', 'borobazar-helper'),
            'description' => esc_html__('Global settings for footer located here', 'borobazar-helper'),
            'panel'       => 'borobazar_config_panel',
            'priority'    => 160,
        ]);
    }

    /**
     * FooterSettings.
     *
     * @return void
     */
    public function FooterSettings()
    {
        $listed_footer = [];
        $get_footer = get_posts([
            'post_type'   => 'footer',
            'order'       => 'ASC',
            'post_status' => 'publish',
        ]);

        foreach ($get_footer as $post) {
            $listed_footer[$post->ID] = $post->post_title;
        }

        // section choosing key : borobazar_footer_section
        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'footer_widget_switch',
            'label'       => esc_html__('Footer Widgets', 'borobazar-helper'),
            'description' => esc_html__('Choose either On/Off', 'borobazar-helper'),
            'section'     => 'borobazar_footer_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'select',
            'settings'         => 'custom_footer_layout',
            'label'            => esc_html__('Custom', 'borobazar-helper'),
            'description'      => esc_html__('Build your custom widgets layout footer from wp-admin->footer->add new footer', 'borobazar-helper'),
            'section'          => 'borobazar_footer_section',
            'default'          => '#',
            'placeholder'      => esc_attr__('Select Footer', 'borobazar-helper'),
            'priority'         => 10,
            'multiple'         => 1,
            'choices'          => $listed_footer,
            'active_callback'  => [
                [
                    'setting'  => 'footer_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        // borobazar copyright settings
        Kirki::add_field('borobazar_config', [
            'type'             => 'textarea',
            'settings'         => 'copyright_texts',
            'label'            => esc_html__('Copyright Text', 'borobazar-helper'),
            'description'      => esc_html__('enter copyright text to display', 'borobazar-helper'),
            'section'          => 'borobazar_footer_section',
            'default'          => esc_html__('RedQ, Inc. All rights reserved', 'borobazar-helper'),
            'priority'         => 10,
            'active_callback'  => [
                [
                    'setting'  => 'footer_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'repeater',
            'label'       => esc_html__('Payment Method', 'borobazar-helper'),
            'description' => esc_html__('Add supported payment method', 'borobazar-helper'),
            'section'     => 'borobazar_footer_section',
            'priority'    => 10,
            'row_label' => [
                'type'  => 'text',
                'value' => esc_html__('Payment Method:', 'borobazar-helper'),
            ],
            'button_label' => esc_html__('Add new method', 'borobazar-helper'),
            'settings'     => 'copyright_payment_support',
            'default'      => [
                [
                    'payment_method_logo' => BOROBAZAR_HELPER_ASSETS . 'client/images/payment-method/mastercard.svg',
                ],
                [
                    'payment_method_logo' => BOROBAZAR_HELPER_ASSETS . 'client/images/payment-method/visa.svg',
                ],
                [
                    'payment_method_logo' => BOROBAZAR_HELPER_ASSETS . 'client/images/payment-method/pay-pal.svg',
                ],
                [
                    'payment_method_logo' => BOROBAZAR_HELPER_ASSETS . 'client/images/payment-method/discover.svg',
                ],
                [
                    'payment_method_logo' => BOROBAZAR_HELPER_ASSETS . 'client/images/payment-method/jcb.svg',
                ],
                [
                    'payment_method_logo' => BOROBAZAR_HELPER_ASSETS . 'client/images/payment-method/skrill.svg',
                ],
            ],
            'fields' => [
                'payment_method_logo' => [
                    'type'        => 'image',
                    'label'       => esc_html__('Logo', 'borobazar-helper'),
                    'description' => esc_html__('Add payment method\'s logo', 'borobazar-helper'),
                    'default'     => '',
                ],
            ]
        ]);


        if (class_exists('SitePress')) {
            //  WPML settings
            Kirki::add_field('borobazar_config', [
                'type'        => 'select',
                'settings'    => 'borobazar_lang_switcher',
                'label'       => esc_html__('Language Switcher', 'borobazar-helper'),
                'description' => esc_html__('Set WPML language switcher On/Off ', 'borobazar-helper'),
                'section'     => 'borobazar_footer_section',
                'default'     => 'off',
                'priority'    => 10,
                'multiple'    => 1,
                'choices'     => [
                    'on'   => esc_html__('On', 'borobazar-helper'),
                    'off'  => esc_html__('Off', 'borobazar-helper'),
                ],
            ]);

            Kirki::add_field('borobazar_config', [
                'type'        => 'select',
                'settings'    => 'borobazar_lang_switcher_as',
                'label'       => esc_html__('Show Switcher As', 'borobazar-helper'),
                'description' => esc_html__('Set WPML language as Name | Code | Flag', 'borobazar-helper'),
                'section'     => 'borobazar_footer_section',
                'default'     => 'translated_name',
                'priority'    => 10,
                'multiple'    => 1,
                'choices'     => [
                    'translated_name'  => esc_html__('Language Name', 'borobazar-helper'),
                    'code'             => esc_html__('Language Code', 'borobazar-helper'),
                    'country_flag_url' => esc_html__('Language Flag', 'borobazar-helper'),
                ],
                'active_callback' => [
                    [
                        'setting'  => 'borobazar_lang_switcher',
                        'operator' => ' === ',
                        'value'    => 'on',
                    ],
                ],
            ]);
        }


        // color settings
        Kirki::add_field('borobazar_config', [
            'type'             => 'color',
            'settings'         => 'footer_text_color',
            'label'            => esc_html__('Text Color', 'borobazar-helper'),
            'description'      => esc_html__('Choose footer text color', 'borobazar-helper'),
            'section'          => 'borobazar_footer_section',
            'default'          => '#212121',
            'active_callback'  => [
                [
                    'setting'  => 'footer_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'color',
            'settings'         => 'footer_bg_color',
            'label'            => esc_html__('Background Color', 'borobazar-helper'),
            'description'      => esc_html__('Choose footer background color', 'borobazar-helper'),
            'section'          => 'borobazar_footer_section',
            'default'          => '#ffffff',
            'active_callback'  => [
                [
                    'setting'  => 'footer_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);
    }
}
