<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class ColorSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initColorSettings();
        $this->ColorSettings();
    }

    /**
     * initColorSettings.
     *
     * @return void
     */
    public function initColorSettings()
    {
        Kirki::add_section('borobazar_color_section', [
            'title'       => esc_html__('Colors', 'borobazar-helper'),
            'description' => esc_html__('Global settings for theme colors located here', 'borobazar-helper'),
            'panel'       => 'borobazar_config_panel',
            'priority'    => 160,
        ]);
    }

    /**
     * ColorSettings.
     *
     * @return void
     */
    public function ColorSettings()
    {
        // section choosing key : borobazar_color_section
        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_brand_color',
            'label'    => esc_html__('Brand Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#02b290',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_brand_hover_color',
            'label'    => esc_html__('Brand Hover Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#01A585',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_main_text_color',
            'label'    => esc_html__('Main Text Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#000000',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_dark_text_color',
            'label'    => esc_html__('Dark Text Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#595959',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_light_text_color',
            'label'    => esc_html__('Light Text Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#666666',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_lighter_text_color',
            'label'    => esc_html__('Lighter Text Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#808080',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_lightest_text_color',
            'label'    => esc_html__('Lightest Text Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#8C969F',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_main_border_color',
            'label'    => esc_html__('Main Border Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#E2E8F0',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_light_border_color',
            'label'    => esc_html__('Light Border Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#DBDEE5',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_lighter_border_color',
            'label'    => esc_html__('Lighter Border Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#E7ECF0',
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_bg_color',
            'label'    => esc_html__('Background Color', 'borobazar-helper'),
            'section'  => 'borobazar_color_section',
            'default'  => '#F3F5F9',
        ]);
    }
}
