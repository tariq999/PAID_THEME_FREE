<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class BlogSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initBlogSettings();
        $this->BlogSettings();
    }

    /**
     * initBlogSettings.
     *
     * @return void
     */
    public function initBlogSettings()
    {
        Kirki::add_section('borobazar_blog_section', [
            'title' => esc_html__('Blog General', 'borobazar-helper'),
            'description' => esc_html__('Global settings for blog located here', 'borobazar-helper'),
            'panel' => 'borobazar_config_panel',
            'priority' => 160,
        ]);
    }

    /**
     * BlogSettings.
     *
     * @return void
     */
    public function BlogSettings()
    {
        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'blog_sidebar_switch',
            'label'       => esc_html__('Sidebar Switch', 'borobazar-helper'),
            'description' => esc_html__('Choose either blog sidebar is On/Off', 'borobazar-helper'),
            'section'     => 'borobazar_blog_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'blog_sidebar_position',
            'label'       => esc_html__('Sidebar Position', 'borobazar-helper'),
            'description' => esc_html__('Choose either blog sidebar position on Left/Right', 'borobazar-helper'),
            'section'     => 'borobazar_blog_section',
            'default'     => 'right',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'left'      => esc_html__('Left', 'borobazar-helper'),
                'right'     => esc_html__('Right', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'blog_banner_switch',
            'label'       => esc_html__('Banner Switch', 'borobazar-helper'),
            'description' => esc_html__('Choose either blog page banner is On/Off', 'borobazar-helper'),
            'section'     => 'borobazar_blog_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'background',
            'settings'         => 'blog_banner_image',
            'label'            => esc_html__('Banner Background', 'borobazar-helper'),
            'description'      => esc_html__('Upload blog banner image or set a background color', 'borobazar-helper'),
            'section'          => 'borobazar_blog_section',
            'priority'         => 10,
            'default'          => [
                'background-color'      => 'rgba(231, 242, 240, 1)',
                'background-image'      => '',
                'background-repeat'     => 'repeat',
                'background-position'   => 'center center',
                'background-size'       => 'cover',
                'background-attachment' => 'scroll',
            ],
            'transport'        => 'auto',
            'output'           => [
                [
                    'element' => '.borobazar-blog-page-banner',
                ],
            ],
            'active_callback' => [
                [
                    'setting'  => 'blog_banner_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'color',
            'settings'    => 'blog_banner_text_color',
            'label'       => esc_html__('Banner Text Color', 'borobazar-helper'),
            'description' => esc_html__('Select blog banner text color', 'borobazar-helper'),
            'section'     => 'borobazar_blog_section',
            'default'     => '#000000',
            'priority'    => 10,
            'active_callback' => [
                [
                    'setting' => 'blog_banner_switch',
                    'operator' => '!==',
                    'value' => 'off',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'blog_breadcrumb_switch',
            'label'       => esc_html__('Breadcrumb Switch', 'borobazar-helper'),
            'description' => esc_html__('Choose either blog breadcrumb section is On/Off', 'borobazar-helper'),
            'section'     => 'borobazar_blog_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices' => [
                'on'  => esc_html__('On', 'borobazar-helper'),
                'off' => esc_html__('Off', 'borobazar-helper'),
            ],
            'active_callback' => [
                [
                    'setting' => 'blog_banner_switch',
                    'operator' => '===',
                    'value' => 'on',
                ],
            ],
        ]);
    }
}
