<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class MiscellaneousSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initMiscellaneousSettings();
        $this->MiscellaneousSettings();
    }

    /**
     * initMiscellaneousSettings.
     *
     * @return void
     */
    public function initMiscellaneousSettings()
    {
        Kirki::add_section('borobazar_miscellaneous_section', [
            'title'       => esc_html__('Miscellaneous', 'borobazar-helper'),
            'description' => esc_html__('Global settings for miscellaneous', 'borobazar-helper'),
            'panel'       => 'borobazar_config_panel',
            'priority'    => 160,
        ]);
    }

    /**
     * MiscellaneousSettings.
     *
     * @return void
     */
    public function MiscellaneousSettings()
    {
        // section choosing key : borobazar_miscellaneous_section
        Kirki::add_field('borobazar_config', [
            'type'     => 'image',
            'settings' => 'borobazar_auth_cover_image',
            'label'    => esc_html__('Auth Cover Image', 'borobazar-helper'),
            'description' => esc_html__('Set beautiful cover images for WooCommerce my-account login/registration pages', 'borobazar-helper'),
            'section'  => 'borobazar_miscellaneous_section',
            'default'  => '',
            'priority' => 10,
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'image',
            'settings' => 'borobazar_not_found_cover_image',
            'label'    => esc_html__('404 Cover Image', 'borobazar-helper'),
            'description' => esc_html__('Set beautiful cover images for WordPress 404 page.', 'borobazar-helper'),
            'section'  => 'borobazar_miscellaneous_section',
            'default'  => '',
            'priority' => 10,
        ]);
    }
}
