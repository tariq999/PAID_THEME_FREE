<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
  exit;
}

class WooGeneralSettings
{
  /**
   * __construct.
   *
   * @return void
   */
  public function __construct()
  {
    $this->initWooGeneralSettings();
    $this->WooGeneralSettings();
  }

  /**
   * initWooGeneralSettings.
   *
   * @return void
   */
  public function initWooGeneralSettings()
  {
    Kirki::add_section('borobazar_woo_section', [
      'title'       => esc_html__('WooCommerce General', 'borobazar-helper'),
      'description' => esc_html__('Global settings for woocommerce located here', 'borobazar-helper'),
      'panel'       => 'borobazar_config_panel',
      'priority'    => 160,
    ]);
  }

  /**
   * WooGeneralSettings.
   *
   * @return void
   */
  public function WooGeneralSettings()
  {
    // section choosing key : borobazar_woo_section
    Kirki::add_field('borobazar_config', [
      'type'            => 'select',
      'settings'        => 'woo_grid_switch',
      'label'           => esc_html__('Product Card', 'borobazar-helper'),
      'description'     => esc_html__('Choose product grid card for display', 'borobazar-helper'),
      'section'         => 'borobazar_woo_section',
      'default'         => 'grid_alpine',
      'priority'        => 10,
      'multiple'        => 1,
      'choices'         => [
        'grid_alpine' => esc_html__('Alpine', 'borobazar-helper'),
        'grid_maple' => esc_html__('Maple', 'borobazar-helper'),
        'grid_oak' => esc_html__('Oak', 'borobazar-helper'),
        'grid_sweetgum' => esc_html__('Sweetgum', 'borobazar-helper'),
        'grid_broomstick' => esc_html__('Broomstick', 'borobazar-helper'),
        'grid_obsidian' => esc_html__('Obsidian', 'borobazar-helper'),
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type'        => 'text',
      'settings'    => 'woo_product_limit_on_shop',
      'label'       => esc_html__('Product Limit on shop page', 'borobazar-helper'),
      'description' => esc_html__('Set no. of product show on shop page', 'borobazar-helper'),
      'section'     => 'borobazar_woo_section',
      'default'     => 24,
      'priority'    => 10,
    ]);

    Kirki::add_field('borobazar_config', [
      'type'        => 'text',
      'settings'    => 'woo_product_limit',
      'label'       => esc_html__('Product Limit on search page', 'borobazar-helper'),
      'description' => esc_html__('Set no. of product show initial on search page', 'borobazar-helper'),
      'section'     => 'borobazar_woo_section',
      'default'     => 12,
      'priority'    => 10,
    ]);

    Kirki::add_field('borobazar_config', [
      'type'             => 'select',
      'settings'         => 'woo_preview_pop_switch',
      'label'            => esc_html__('Quick View', 'borobazar-helper'),
      'description'      => esc_html__('Note: please install/activate "RedQ WooCommerce Quick View" plugin first.', 'borobazar-helper'),
      'section'          => 'borobazar_woo_section',
      'default'          => 'on',
      'priority'         => 10,
      'multiple'         => 1,
      'choices'          => [
        'off'          => esc_html__('Disable', 'borobazar-helper'),
        'on'           => esc_html__('Enable', 'borobazar-helper'),
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type'        => 'select',
      'settings'    => 'woo_hidden_product_switch',
      'label'       => esc_html__(
        'Hide "Hidden" Products',
        'borobazar-helper'
      ),
      'description' => esc_html__('Hide "hidden" products on search page', 'borobazar-helper'),
      'section'     => 'borobazar_woo_section',
      'default'     => 'off',
      'priority'    => 10,
      'multiple'    => 1,
      'choices'     => [
        'on'      => esc_html__('On', 'borobazar-helper'),
        'off'     => esc_html__('Off', 'borobazar-helper'),
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type'        => 'select',
      'settings'    => 'remove_out_of_stock_from_search',
      'label'       => esc_html__('Remove out of stock product from search page?', 'cartsy-helper'),
      'section'     => 'borobazar_woo_section',
      'default'     => 'no',
      'priority'    => 10,
      'multiple'    => false,
      'choices'     => [
        'no' => esc_html__('No', 'cartsy-helper'),
        'yes' => esc_html__('Yes', 'cartsy-helper'),
      ],
    ]);


    Kirki::add_field('borobazar_config', [
      'type'        => 'number',
      'settings'    => 'woo_mini_cart_timer',
      'label'       => esc_html__('Toast Hide Timer', 'borobazar-helper'),
      'description' => esc_html__('Set toast timer (in seconds) for product add to cart', 'borobazar-helper'),
      'section'     => 'borobazar_woo_section',
      'default'     => 3500,
      'choices'     => [
        'min'     => 500,
        'max'     => 20000,
        'step'    => 500,
      ],
      'priority'    => 10,
    ]);

    Kirki::add_field('borobazar_config', [
      'type'        => 'select',
      'settings'    => 'woo_crosssell_product_switch',
      'label'       => esc_html__(
        'Crossell Products',
        'borobazar-helper'
      ),
      'description' => esc_html__('Choose cross-sell product to display on cart', 'borobazar-helper'),
      'section'     => 'borobazar_woo_section',
      'default'     => 'on',
      'priority'    => 10,
      'multiple'    => 1,
      'choices'     => [
        'on'      => esc_html__('On', 'borobazar-helper'),
        'off'     => esc_html__('Off', 'borobazar-helper'),
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type'             => 'number',
      'settings'         => 'woo_crosssell_product_grid_count',
      'label'            => esc_html__('Crossell Products Grid', 'borobazar-helper'),
      'description'      => esc_html__('Choose cross-sell product grid number to display on cart', 'borobazar-helper'),
      'section'          => 'borobazar_woo_section',
      'priority'         => 10,
      'default'          => 4,
      'choices'          => [
        'min'          => 1,
        'max'          => 6,
        'step'         => 1,
      ],
      'active_callback'  => [
        [
          'setting'  => 'woo_crosssell_product_switch',
          'operator' => '===',
          'value'    => 'on',
        ],
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type'        => 'select',
      'settings'    => 'woo_shop_sidebar_switch',
      'label'       => esc_html__('WooCommerce Shop Sidebar', 'borobazar-helper'),
      'description' => esc_html__('Choose either woo shop sidebar is On/Off', 'borobazar-helper'),
      'section'     => 'borobazar_woo_section',
      'default'     => 'off',
      'priority'    => 10,
      'multiple'    => 1,
      'choices' => [
        'on' => esc_html__('On', 'borobazar-helper'),
        'off' => esc_html__('Off', 'borobazar-helper'),
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type'        => 'select',
      'settings'    => 'woo_sidebar_switch',
      'label'       => esc_html__('WooCommerce Page Sidebar', 'borobazar-helper'),
      'description' => esc_html__('Choose either woo page sidebar is On/Off', 'borobazar-helper'),
      'section'     => 'borobazar_woo_section',
      'default'     => 'off',
      'priority'    => 10,
      'multiple'    => 1,
      'choices' => [
        'on' => esc_html__('On', 'borobazar-helper'),
        'off' => esc_html__('Off', 'borobazar-helper'),
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type'             => 'select',
      'settings'         => 'woo_sidebar_position',
      'label'            => esc_html__('WooCommerce Sidebar Position', 'borobazar-helper'),
      'description'      => esc_html__('Choose woo sidebar position on left/right', 'borobazar-helper'),
      'section'          => 'borobazar_woo_section',
      'default'          => 'right',
      'priority'         => 10,
      'multiple'         => 1,
      'choices'          => [
        'right'        => esc_html__('Right Sidebar', 'borobazar-helper'),
        'left'         => esc_html__('Left Sidebar', 'borobazar-helper'),
      ],
      'active_callback' => function () {
        $shop_widget = get_theme_mod('woo_shop_sidebar_switch', 'off');
        $woo_page_widget    = get_theme_mod('woo_sidebar_switch', 'off');

        if ('on' === $shop_widget || 'on' === $woo_page_widget) {
          return true;
        }
        return false;
      },
    ]);

    Kirki::add_field('borobazar_config', [
      'type'        => 'select',
      'settings'    => 'woo_banner_switch',
      'label'       => esc_html__('Woo Page Banner', 'borobazar-helper'),
      'description' => esc_html__('Choose either page banner section is On/Off', 'borobazar-helper'),
      'section'     => 'borobazar_woo_section',
      'default'     => 'on',
      'priority'    => 10,
      'multiple'    => 1,
      'choices'     => [
        'on'      => esc_html__('On', 'borobazar-helper'),
        'off'     => esc_html__('Off', 'borobazar-helper'),
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type'             => 'background',
      'settings'         => 'woo_banner_image',
      'label'            => esc_html__('Woo Banner Background', 'borobazar-helper'),
      'description'      => esc_html__('Upload page banner image or set a background color', 'borobazar-helper'),
      'section'          => 'borobazar_woo_section',
      'priority'         => 10,
      'default'          => [
        'background-color'      => 'rgba(231, 242, 240, 1)',
        'background-image'      => '',
        'background-repeat'     => 'repeat',
        'background-position'   => 'center center',
        'background-size'       => 'cover',
        'background-attachment' => 'scroll',
      ],
      'transport'        => 'auto',
      'output'           => [
        [
          'element' => '.borobazar-woo-page-banner',
        ],
      ],
      'active_callback' => [
        [
          'setting'  => 'woo_banner_switch',
          'operator' => '!==',
          'value'    => 'off',
        ],
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type' => 'color',
      'settings' => 'woo_banner_text_color',
      'label' => esc_html__('Woo Banner Text Color', 'borobazar-helper'),
      'description' => esc_html__('Select shop page banner text color', 'borobazar-helper'),
      'section' => 'borobazar_woo_section',
      'default' => '#000000',
      'priority' => 10,
      'active_callback' => [
        [
          'setting' => 'woo_banner_switch',
          'operator' => '===',
          'value' => 'on',
        ],
      ],
    ]);

    Kirki::add_field('borobazar_config', [
      'type' => 'select',
      'settings' => 'woo_page_breadcrumb_switch',
      'label' => esc_html__('Woo Breadcrumb', 'borobazar-helper'),
      'description' => esc_html__('Choose either woocommerce page\'s breadcrumb is On/Off', 'borobazar-helper'),
      'section' => 'borobazar_woo_section',
      'default' => 'on',
      'priority' => 10,
      'multiple' => 1,
      'choices' => [
        'on' => esc_html__('On', 'borobazar-helper'),
        'off' => esc_html__('Off', 'borobazar-helper'),
      ],
      'active_callback' => [
        [
          'setting' => 'woo_banner_switch',
          'operator' => '===',
          'value' => 'on',
        ],
      ],
    ]);
  }
}
