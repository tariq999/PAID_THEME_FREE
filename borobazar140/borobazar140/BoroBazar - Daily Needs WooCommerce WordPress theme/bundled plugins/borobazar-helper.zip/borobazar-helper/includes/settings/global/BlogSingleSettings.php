<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class BlogSingleSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initBlogSingleSettings();
        $this->BlogSingleSettings();
    }

    /**
     * initBlogSingleSettings.
     *
     * @return void
     */
    public function initBlogSingleSettings()
    {
        Kirki::add_section('borobazar_blog_single_section', [
            'title' => esc_html__('Blog Post Single', 'borobazar-helper'),
            'description' => esc_html__('Global settings for blog post single', 'borobazar-helper'),
            'panel' => 'borobazar_config_panel',
            'priority' => 160,
        ]);
    }

    /**
     * BlogSingleSettings.
     *
     * @return void
     */
    public function BlogSingleSettings()
    {
        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'blog_single_sidebar_switch',
            'label'       => esc_html__('Sidebar Switch', 'borobazar-helper'),
            'description' => esc_html__('Choose either post single sidebar is On/Off', 'borobazar-helper'),
            'section'     => 'borobazar_blog_single_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'blog_single_sidebar_position',
            'label'       => esc_html__('Sidebar Position', 'borobazar-helper'),
            'description' => esc_html__('Choose either post single sidebar position on Left/Right', 'borobazar-helper'),
            'section'     => 'borobazar_blog_single_section',
            'default'     => 'right',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'left'      => esc_html__('Left', 'borobazar-helper'),
                'right'     => esc_html__('Right', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'blog_single_banner_switch',
            'label'       => esc_html__('Banner Switch', 'borobazar-helper'),
            'description' => esc_html__('Choose either post single page banner is On/Off', 'borobazar-helper'),
            'section'     => 'borobazar_blog_single_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'background',
            'settings'         => 'blog_single_banner_image',
            'label'            => esc_html__('Banner Background', 'borobazar-helper'),
            'description'      => esc_html__('Upload post single banner image or set a background color', 'borobazar-helper'),
            'section'          => 'borobazar_blog_single_section',
            'priority'         => 10,
            'default'          => [
                'background-color'      => 'rgba(231, 242, 240, 1)',
                'background-image'      => '',
                'background-repeat'     => 'repeat',
                'background-position'   => 'center center',
                'background-size'       => 'cover',
                'background-attachment' => 'scroll',
            ],
            'transport'        => 'auto',
            'output'           => [
                [
                    'element' => '.borobazar-blog-single-page-banner',
                ],
            ],
            'active_callback' => [
                [
                    'setting'  => 'blog_single_banner_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type' => 'color',
            'settings' => 'blog_single_banner_text_color',
            'label' => esc_html__('Banner Text Color', 'borobazar-helper'),
            'description' => esc_html__('Select post single banner text color', 'borobazar-helper'),
            'section' => 'borobazar_blog_single_section',
            'default' => '#000000',
            'priority' => 10,
            'active_callback' => [
                [
                    'setting' => 'blog_single_banner_switch',
                    'operator' => '!==',
                    'value' => 'off',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type' => 'select',
            'settings' => 'blog_single_breadcrumb_switch',
            'label' => esc_html__('Breadcrumb Switch', 'borobazar-helper'),
            'description' => esc_html__('Choose either post single breadcrumb section is On/Off', 'borobazar-helper'),
            'section' => 'borobazar_blog_single_section',
            'default' => 'on',
            'priority' => 10,
            'multiple' => 1,
            'choices' => [
                'on' => esc_html__('On', 'borobazar-helper'),
                'off' => esc_html__('Off', 'borobazar-helper'),
            ],
            'active_callback' => [
                [
                    'setting' => 'blog_single_banner_switch',
                    'operator' => '===',
                    'value' => 'on',
                ],
            ],
        ]);
    }
}
