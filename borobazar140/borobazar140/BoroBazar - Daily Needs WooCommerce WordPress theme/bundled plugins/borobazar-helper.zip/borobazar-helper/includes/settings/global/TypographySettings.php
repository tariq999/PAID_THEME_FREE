<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class TypographySettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initTypographySettings();
        $this->TypographySettings();
    }

    /**
     * initTypographySettings.
     *
     * @return void
     */
    public function initTypographySettings()
    {
        Kirki::add_section('borobazar_typography_section', [
            'title'       => esc_html__('Typography', 'borobazar-helper'),
            'description' => esc_html__('Global settings for typography located here', 'borobazar-helper'),
            'panel'       => 'borobazar_config_panel',
            'priority'    => 160,
        ]);
    }

    /**
     * TypographySettings.
     *
     * @return void
     */
    public function TypographySettings()
    {
        // section choosing key : borobazar_typography_section
        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'borobazar_typography_switch',
            'label'       => esc_html__('Typography Switch', 'borobazar-helper'),
            'section'     => 'borobazar_typography_section',
            'default'     => 'off',
            'priority'    => 10,
            'choices'     => [
                'on'  => esc_html__('On', 'borobazar-helper'),
                'off' => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'typography',
            'settings'         => 'body_typography_setting',
            'label'            => esc_html__('Body tag Typography Control', 'borobazar-helper'),
            'section'          => 'borobazar_typography_section',
            'default'          => [
                'font-family'  => 'Inter',
                'variant'      => 'regular',
                'font-size'    => '15px',
                'line-height'  => '1.8',
            ],
            'priority'         => 10,
            'transport'        => 'auto',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_typography_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'typography',
            'settings'         => 'heading1_typography_setting',
            'label'            => esc_html__('Heading1', 'borobazar-helper'),
            'section'          => 'borobazar_typography_section',
            'default'          => [
                'font-family'  => 'Manrope',
                'variant'      => '700',
                'font-size'    => '40px',
                'line-height'  => '1.5',
                'color'        => '#000000',
            ],
            'priority'         => 10,
            'transport'        => 'auto',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_typography_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'typography',
            'settings'         => 'heading2_typography_setting',
            'label'            => esc_html__('Heading2', 'borobazar-helper'),
            'section'          => 'borobazar_typography_section',
            'default'          => [
                'font-family'  => 'Manrope',
                'variant'      => '700',
                'font-size'    => '24px',
                'line-height'  => '1.5',
                'color'        => '#000000',
            ],
            'priority'         => 10,
            'transport'        => 'auto',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_typography_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'typography',
            'settings'         => 'heading3_typography_setting',
            'label'            => esc_html__('Heading3', 'borobazar-helper'),
            'section'          => 'borobazar_typography_section',
            'default'          => [
                'font-family'  => 'Manrope',
                'variant'      => '700',
                'font-size'    => '22px',
                'line-height'  => '1.5',
                'color'        => '#000000',
            ],
            'priority'         => 10,
            'transport'        => 'auto',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_typography_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'typography',
            'settings'         => 'heading4_typography_setting',
            'label'            => esc_html__('Heading4', 'borobazar-helper'),
            'section'          => 'borobazar_typography_section',
            'default'          => [
                'font-family'  => 'Manrope',
                'variant'      => '700',
                'font-size'    => '18px',
                'line-height'  => '1.5',
                'color'        => '#000000',
            ],
            'priority'         => 10,
            'transport'        => 'auto',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_typography_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'typography',
            'settings'         => 'heading5_typography_setting',
            'label'            => esc_html__('Heading5', 'borobazar-helper'),
            'section'          => 'borobazar_typography_section',
            'default'          => [
                'font-family'  => 'Manrope',
                'variant'      => '700',
                'font-size'    => '16px',
                'line-height'  => '1.5',
                'color'        => '#000000',
            ],
            'priority'         => 10,
            'transport'        => 'auto',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_typography_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'typography',
            'settings'         => 'heading6_typography_setting',
            'label'            => esc_html__('Heading6', 'borobazar-helper'),
            'section'          => 'borobazar_typography_section',
            'default'          => [
                'font-family'  => 'Manrope',
                'variant'      => '700',
                'font-size'    => '15px',
                'line-height'  => '1.5',
                'color'        => '#000000',
            ],
            'priority'         => 10,
            'transport'        => 'auto',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_typography_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'typography',
            'settings'         => 'special_typography_setting',
            'label'            => esc_html__('Special Typography Control', 'borobazar-helper'),
            'description'      => esc_html__('Set banner special title font family & variant', 'borobazar-helper'),
            'section'          => 'borobazar_typography_section',
            'default'          => [
                'font-family'  => 'Caveat',
                'variant'      => '700',
                'font-size'    => '30px',
                'line-height'  => '1.26',
            ],
            'priority'         => 10,
            'transport'        => 'auto',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_typography_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);
    }
}
