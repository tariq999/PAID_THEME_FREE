<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class HeaderSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initHeaderSettings();
        $this->HeaderSettings();
    }

    /**
     * initHeaderSettings.
     *
     * @return void
     */
    public function initHeaderSettings()
    {
        Kirki::add_section('borobazar_header_section', [
            'title'       => esc_html__('Header', 'borobazar-helper'),
            'description' => esc_html__('Global settings for header located here', 'borobazar-helper'),
            'panel'       => 'borobazar_config_panel',
            'priority'    => 160,
        ]);
    }

    /**
     * HeaderSettings.
     *
     * @return void
     */
    public function HeaderSettings()
    {
        // section choosing key : borobazar_header_section
        Kirki::add_field('borobazar_config', [
            'type'          => 'select',
            'settings'      => 'borobazar_header_layout',
            'label'         => esc_html__('Header Layout', 'borobazar-helper'),
            'description'   => esc_html__('Choose header layout, Bogota is only designed for transparent header. It looks great on white background banner.', 'borobazar-helper'),
            'section'       => 'borobazar_header_section',
            'default'       => 'default',
            'priority'      => 10,
            'multiple'      => 1,
            'choices'       => [
                'default'   => esc_html__('Default', 'borobazar-helper'),
                'berlin'    => esc_html__('Berlin', 'borobazar-helper'),
                'bogota'    => esc_html__('Bogota', 'borobazar-helper'),
                'denver'    => esc_html__('Denver', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_topbar_bg_color',
            'label'    => esc_html__('Topbar Background Color', 'borobazar-helper'),
            'section'  => 'borobazar_header_section',
            'default'  => '#f2f5f9',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_header_layout',
                    'operator' => '===',
                    'value'    => 'berlin',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_topbar_search_text_color',
            'label'    => esc_html__('Search Box Colors', 'borobazar-helper'),
            'section'  => 'borobazar_header_section',
            'default'  => '#595959',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_header_layout',
                    'operator' => '===',
                    'value'    => 'berlin',
                ]
            ],
        ]);
        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_topbar_content_color',
            'label'    => esc_html__('Topbar Content Colors', 'borobazar-helper'),
            'section'  => 'borobazar_header_section',
            'default'  => '#8C969F',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_header_layout',
                    'operator' => '===',
                    'value'    => 'berlin',
                ]
            ],
        ]);
        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_topbar_counter_color',
            'label'    => esc_html__('Cart Counter Color', 'borobazar-helper'),
            'section'  => 'borobazar_header_section',
            'default'  => '#FFFFFF',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_header_layout',
                    'operator' => '===',
                    'value'    => 'berlin',
                ]
            ],
        ]);
        Kirki::add_field('borobazar_config', [
            'type'     => 'color',
            'settings' => 'borobazar_topbar_counter_bg_color',
            'label'    => esc_html__('Cart Counter Background Color', 'borobazar-helper'),
            'section'  => 'borobazar_header_section',
            'default'  => '#02b290',
            'active_callback' => [
                [
                    'setting'  => 'borobazar_header_layout',
                    'operator' => '===',
                    'value'    => 'berlin',
                ]
            ],
        ]);
    }
}
