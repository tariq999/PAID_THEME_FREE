<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class CustomizerSettings
{
    public function __construct()
    {
        $this->SettingsPanelInit();
        new GeneralSettings();
        new StoreNoticeSettings();
        new HeaderSettings();
        new BottomNavigationSettings();
        new BlogSettings();
        new BlogSingleSettings();
        if (class_exists('WooCommerce')) {
            new WooGeneralSettings();
            new WooProdSingleSettings();
        }
        new ColorSettings();
        new TypographySettings();
        new MiscellaneousSettings();
        new FooterSettings();
    }

    public function SettingsPanelInit()
    {
        Kirki::add_config('borobazar_config', [
            'capability'  => 'edit_theme_options',
            'option_type' => 'theme_mod',
        ]);

        Kirki::add_panel('borobazar_config_panel', [
            'priority'    => 10,
            'title'       => esc_html__('BoroBazar Theme Panel', 'borobazar-helper'),
            'description' => esc_html__('BoroBazar theme panel description', 'borobazar-helper'),
        ]);
    }
}
