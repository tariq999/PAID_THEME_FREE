<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class BottomNavigationSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initBottomNavigationSettings();
        $this->BottomNavigationSettings();
    }

    /**
     * initBottomNavigationSettings.
     *
     * @return void
     */
    public function initBottomNavigationSettings()
    {
        Kirki::add_section('borobazar_bottom_navigation_section', [
            'title'       => esc_html__('Mobile Bottom Navigation', 'borobazar-helper'),
            'description' => esc_html__('Global settings for Mobile Bottom Navigation', 'borobazar-helper'),
            'panel'       => 'borobazar_config_panel',
            'priority'    => 160,
        ]);
    }

    /**
     * BottomNavigationSettings.
     *
     * @return void
     */
    public function BottomNavigationSettings()
    { // section choosing key : borobazar_bottom_navigation_section
        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'bottom_nav_switch',
            'label'       => esc_html__('Bottom Navigation', 'borobazar-helper'),
            'description' => esc_html__('Choose either bottom navigation is On/Off', 'borobazar-helper'),
            'section'     => 'borobazar_bottom_navigation_section',
            'default'     => 'off',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'color',
            'settings'         => 'bottom_nav_bg_color',
            'label'            => esc_html__('Background Color', 'borobazar-helper'),
            'description'      => esc_html__('Choose background color', 'borobazar-helper'),
            'section'          => 'borobazar_bottom_navigation_section',
            'default'          => '#ffffff',
            'active_callback'  => [
                [
                    'setting'  => 'bottom_nav_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'color',
            'settings'         => 'bottom_nav_font_color',
            'label'            => esc_html__('Icon Color', 'borobazar-helper'),
            'description'      => esc_html__('Choose icon color', 'borobazar-helper'),
            'section'          => 'borobazar_bottom_navigation_section',
            'default'          => '#8C969F',
            'active_callback'  => [
                [
                    'setting'  => 'bottom_nav_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);
    }
}
