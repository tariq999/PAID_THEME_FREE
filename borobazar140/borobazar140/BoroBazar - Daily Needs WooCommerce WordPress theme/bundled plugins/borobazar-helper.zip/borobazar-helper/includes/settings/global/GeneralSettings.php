<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class GeneralSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initGeneralSettings();
        $this->GeneralSettings();
    }

    /**
     * initGeneralSettings.
     *
     * @return void
     */
    public function initGeneralSettings()
    {
        Kirki::add_section('borobazar_general_section', [
            'title'       => esc_html__('General', 'borobazar-helper'),
            'description' => esc_html__('General theme settings', 'borobazar-helper'),
            'panel'       => 'borobazar_config_panel',
            'priority'    => 160,
        ]);
    }

    /**
     * GeneralSettings.
     *
     * @return void
     */
    public function GeneralSettings()
    {
        // section choosing key : borobazar_general_section
        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'site_loader',
            'label'       => esc_html__('Site loader', 'borobazar-helper'),
            'description' => esc_html__('Choose either site loader is On/Off thorugh out the site', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => 'off',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'radio-buttonset',
            'settings'    => 'site_loader_type',
            'label'       => esc_html__('Site Loader Type', 'borobazar-helper'),
            'description' => esc_html__('Choose default loader OR use your custom gif loader', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => 'gif',
            'priority'    => 10,
            'choices'     => [
                'default'   => esc_html__('Default', 'borobazar-helper'),
                'gif' => esc_html__('Gif', 'borobazar-helper'),
            ],
            'active_callback'  => [
                [
                    'setting'  => 'site_loader',
                    'operator' => '===',
                    'value'    => 'on',
                ],
            ]
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'image',
            'settings'    => 'site_loader_gif',
            'label'       => esc_html__('Loader Gif', 'borobazar-helper'),
            'description' => esc_html__('You can upload your own gif loader, by default we provide our theme gif loader', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => '',
            'active_callback'  => [
                [
                    'setting'  => 'site_loader_type',
                    'operator' => '===',
                    'value'    => 'gif',
                ],
            ]
        ]);

        Kirki::add_field('borobazar_config', [
            'type'       => 'select',
            'settings'   => 'borobazar_load_more_product_by',
            'label'      => esc_html__('Load more Product', 'borobazar-helper'),
            'section'    => 'borobazar_general_section',
            'default'    => 'off',
            'priority'   => 10,
            'multiple'   => 1,
            'choices'    => [
                'click'  => esc_html__('By Clicking Load More Button', 'borobazar-helper'),
                'scroll' => esc_html__('by Infinity scroll', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'number',
            'settings' => 'borobazar_scroll_extra_height',
            'label'    => esc_html__('Scroll Extra Height', 'borobazar-helper'),
            'section'  => 'borobazar_general_section',
            'default'  => 100,
            'choices'  => [
                'min'  => 0,
                'max'  => 200,
                'step' => 10,
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'borobazar_limit_search_to_post_title',
            'label'       => esc_html__('Limit search functionality to post_title only?', 'borobazar-helper'),
            'description' => esc_html__('Do you want to limit search in post title only? then enable this.', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => 'off',
            'priority'    => 10,
            'choices'     => [
                'on'  => esc_html__('Enable', 'borobazar-helper'),
                'off' => esc_html__('Disable', 'borobazar-helper'),
            ],
        ]);


        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'borobazar_enable_global_search',
            'label'       => esc_html__('Enable Global Search', 'borobazar-helper'),
            'description' => esc_html__('Use Global search for products.', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => 'off',
            'priority'    => 10,
            'choices'     => [
                'on'      => esc_html__('Enable', 'borobazar-helper'),
                'off'     => esc_html__('Disable', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'select',
            'settings' => 'borobazar_search_page',
            'label'    => esc_html__('Set Search Page', 'borobazar-helper'),
            'section'  => 'borobazar_general_section',
            'default'  => 0,
            'priority' => 10,
            'multiple' => 1,
            'choices'  => borobazarGetPages(),
            'active_callback'  => [
                [
                    'setting'  => 'borobazar_enable_global_search',
                    'operator' => '===',
                    'value'    => 'on',
                ],
            ]
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'text',
            'settings'         => 'borobazar_site_slug',
            'label'            => esc_html__('Search Page Slug [multisite settings]', 'borobazar-helper'),
            'description'      => esc_html__('Set Search page slug when multi-site is enabled. Input the multi-site sub-directory name. Otherwise you can ignore it.', 'borobazar-helper'),
            'section'          => 'borobazar_general_section',
            'default'          => '',
            'priority'         => 10,
            'active_callback'  => [
                [
                    'setting'  => 'borobazar_enable_global_search',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'text',
            'settings'    => 'borobazar_global_search_placeholder',
            'label'       => esc_html__('Global Search Placeholder', 'borobazar-helper'),
            'description' => esc_html__('Set Global Search Placeholder', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => 'What are you looking for..',
            'priority'    => 10,
            'active_callback'  => [
                [
                    'setting'  => 'borobazar_enable_global_search',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        // Kirki::add_field('borobazar_config', [
        //     'type'        => 'text',
        //     'settings'    => 'borobazar_view_details_button_text',
        //     'label'       => esc_html__('View Details Button', 'borobazar-helper'),
        //     'description' => esc_html__('Set View Details Button', 'borobazar-helper'),
        //     'section'     => 'borobazar_general_section',
        //     'default'     => 'View Details',
        //     'priority'    => 10,
        //     'active_callback'  => [
        //         [
        //             'setting'  => 'borobazar_enable_global_search',
        //             'operator' => ' === ',
        //             'value'    => 'on',
        //         ],
        //     ],
        // ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'text',
            'settings'    => 'borobazar_global_search_load_more_label',
            'label'       => esc_html__('Search Page redirect link text', 'borobazar-helper'),
            'description' => esc_html__('Set search page redirect link text for user.', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => esc_html__('Explore search page.', 'borobazar-helper'),
            'priority'    => 10,
            'active_callback'  => [
                [
                    'setting'  => 'borobazar_enable_global_search',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'page_sidebar',
            'label'       => esc_html__('Page Sidebar', 'borobazar-helper'),
            'description' => esc_html__('Choose either page sidebar is On/Off', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => 'off',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'page_sidebar_position',
            'label'       => esc_html__('Sidebar Position', 'borobazar-helper'),
            'description' => esc_html__('Choose either page sidebar on Left/Right', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => 'right',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'left'    => esc_html__('Left', 'borobazar-helper'),
                'right'   => esc_html__('Right', 'borobazar-helper'),
            ],
            'active_callback' => [
                [
                    'setting'  => 'page_sidebar',
                    'operator' => '!==',
                    'value'    => 'off',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'page_banner_switch',
            'label'       => esc_html__('Page Banner', 'borobazar-helper'),
            'description' => esc_html__('Choose either page banner section is On/Off', 'borobazar-helper'),
            'section'     => 'borobazar_general_section',
            'default'     => 'on',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'on'      => esc_html__('On', 'borobazar-helper'),
                'off'     => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'background',
            'settings'         => 'page_banner_image',
            'label'            => esc_html__('Banner Background', 'borobazar-helper'),
            'description'      => esc_html__('Upload post single banner image or set a background color', 'borobazar-helper'),
            'section'          => 'borobazar_general_section',
            'priority'         => 10,
            'default'          => [
                'background-color'      => 'rgba(231, 242, 240, 1)',
                'background-image'      => '',
                'background-repeat'     => 'repeat',
                'background-position'   => 'center center',
                'background-size'       => 'cover',
                'background-attachment' => 'scroll',
            ],
            'transport'        => 'auto',
            'output'           => [
                [
                    'element' => '.borobazar-site-page-banner',
                ],
            ],
            'active_callback' => [
                [
                    'setting'  => 'page_banner_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'color',
            'settings'         => 'page_banner_text_color',
            'label'            => esc_html__('Page banner text color', 'borobazar-helper'),
            'description'      => esc_html__('Select page banner text color', 'borobazar-helper'),
            'section'          => 'borobazar_general_section',
            'default'          => '#000000',
            'priority'         => 10,
            'active_callback'  => [
                [
                    'setting'  => 'page_banner_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'select',
            'settings'         => 'page_breadcrumb_switch',
            'label'            => esc_html__('Page breadcrumb switch', 'borobazar-helper'),
            'description'      => esc_html__('Choose either page breadcrumb section is On/Off', 'borobazar-helper'),
            'section'          => 'borobazar_general_section',
            'default'          => 'on',
            'priority'         => 10,
            'multiple'         => 1,
            'choices'          => [
                'on'           => esc_html__('On', 'borobazar-helper'),
                'off'          => esc_html__('Off', 'borobazar-helper'),
            ],
            'active_callback'  => [
                [
                    'setting'  => 'page_banner_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);
    }
}
