<?php

namespace BoroBazarHelper\Settings;

use Kirki;

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

class StoreNoticeSettings
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->initStoreNoticeSettings();
        $this->StoreNoticeSettings();
    }

    /**
     * initStoreNoticeSettings.
     *
     * @return void
     */
    public function initStoreNoticeSettings()
    {
        Kirki::add_section('borobazar_notice_section', [
            'title'       => esc_html__('Store Notice', 'borobazar-helper'),
            'description' => esc_html__('Global settings for store notice here', 'borobazar-helper'),
            'panel'       => 'borobazar_config_panel',
            'priority'    => 160,
        ]);
    }

    /**
     * StoreNoticeSettings.
     *
     * @return void
     */
    public function StoreNoticeSettings()
    {
        // section choosing key : borobazar_notice_section
        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'borobazar_store_notice_switch',
            'label'       => esc_html__('Store Notice Switch', 'borobazar-helper'),
            'section'     => 'borobazar_notice_section',
            'default'     => 'off',
            'priority'    => 10,
            'choices'     => [
                'on'  => esc_html__('On', 'borobazar-helper'),
                'off' => esc_html__('Off', 'borobazar-helper'),
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'textarea',
            'settings'    => 'borobazar_store_notice_text',
            'label'       => esc_html__('Set Message', 'borobazar-helper'),
            'description' => esc_html__('Set store notice message', 'borobazar-helper'),
            'section'     => 'borobazar_notice_section',
            'default'     => esc_html__('35% exclusive discount plus free next day delivery location, excludes sale', 'borobazar-helper'),
            'priority'    => 10,
            'active_callback' => [
                [
                    'setting'  => 'borobazar_store_notice_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'borobazar_store_notice_link_switch',
            'label'       => esc_html__('Add Link Switch', 'borobazar-helper'),
            'section'     => 'borobazar_notice_section',
            'default'     => 'on',
            'priority'    => 10,
            'choices'     => [
                'on'  => esc_html__('On', 'borobazar-helper'),
                'off' => esc_html__('Off', 'borobazar-helper'),
            ],
            'active_callback' => [
                [
                    'setting'  => 'borobazar_store_notice_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'link',
            'settings' => 'borobazar_store_notice_link',
            'label'    => esc_html__('Set Link', 'borobazar-helper'),
            'section'  => 'borobazar_notice_section',
            'default'  => '',
            'priority' => 10,
            'active_callback' => [
                [
                    'setting'  => 'borobazar_store_notice_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ],
                [
                    'setting'  => 'borobazar_store_notice_link_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'     => 'text',
            'settings' => 'borobazar_store_notice_link_text',
            'label'    => esc_html__('Set Link Text', 'borobazar-helper'),
            'section'  => 'borobazar_notice_section',
            'default'  => 'Learn More',
            'priority' => 10,
            'active_callback' => [
                [
                    'setting'  => 'borobazar_store_notice_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ],
                [
                    'setting'  => 'borobazar_store_notice_link_switch',
                    'operator' => '!==',
                    'value'    => 'off',
                ]
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'color',
            'settings'         => 'borobazar_store_notice_bg_color',
            'label'            => esc_html__('Background Color', 'borobazar-helper'),
            'description'      => esc_html__('Choose background color', 'borobazar-helper'),
            'section'          => 'borobazar_notice_section',
            'default'          => '#02b290',
            'active_callback'  => [
                [
                    'setting'  => 'borobazar_store_notice_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'             => 'color',
            'settings'         => 'borobazar_store_notice_text_color',
            'label'            => esc_html__('Text Color', 'borobazar-helper'),
            'description'      => esc_html__('Choose text color', 'borobazar-helper'),
            'section'          => 'borobazar_notice_section',
            'default'          => '#ffffff',
            'active_callback'  => [
                [
                    'setting'  => 'borobazar_store_notice_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);

        Kirki::add_field('borobazar_config', [
            'type'        => 'select',
            'settings'    => 'borobazar_countdown_switch',
            'label'       => esc_html__('Display Countdown?', 'borobazar-helper'),
            'section'     => 'borobazar_notice_section',
            'default'     => 'off',
            'priority'    => 10,
            'choices'     => [
                'on'  => esc_html__('On', 'borobazar-helper'),
                'off' => esc_html__('Off', 'borobazar-helper'),
            ],
            'active_callback'  => [
                [
                    'setting'  => 'borobazar_store_notice_switch',
                    'operator' => ' === ',
                    'value'    => 'on',
                ],
            ],
        ]);


        new \Kirki\Field\Date(
            [
                'settings'    => 'date_setting',
                'label'       => esc_html__('Date Control', 'borobazar-helper'),
                'description' => esc_html__('Selected date must be greater than today.', 'borobazar-helper'),
                'section'     => 'borobazar_notice_section',
                'default'     => '',
                'active_callback'  => [
                    [
                        'setting'  => 'borobazar_store_notice_switch',
                        'operator' => ' === ',
                        'value'    => 'on',
                    ],
                    [
                        'setting'  => 'borobazar_countdown_switch',
                        'operator' => ' === ',
                        'value'    => 'on',
                    ],
                ],
            ],

        );
    }
}
