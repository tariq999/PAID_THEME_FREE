<?php

namespace BoroBazarHelper\Traits;

defined('ABSPATH') || exit;

trait BlockPostData
{
    use ImageResizer;

    public static function getTaxonomiesByProducts($attributes, $taxonomy)
    {
        $process_terms = get_transient('transient_borobazar_' . $taxonomy);

        BlockPostData::setTransientTracking('transient_borobazar_' . $taxonomy);

        if (false === $process_terms) {
            $process_terms = [];
            $termImage = '';

            $predefinedTaxonomy = [
                'product_cat',
                'product_tag',
                'borobazar_product_brands',
                'borobazar_product_price_ranges',
                'borobazar_product_genre',
            ];

            $args =  [
                'taxonomy'   => $taxonomy,
                'hide_empty' => $attributes['showEmptyCategory'],
                'orderby'    => $attributes['categoryOrderBy'],
                'order'      => $attributes['categoryOrder'],
                'show_count'       => 0,
                'pad_counts'       => 0,
                'title_li'         => '',
                'suppress_filters' => false,
                'parent'   => 0,
            ];

            if (!empty($limit)) {
                $args['number'] = $limit;
            }
            if (!empty($orderby)) {
                $args['orderby'] = $orderby;
            }
            if (!empty($order)) {
                $args['order'] = $order;
            }

            $taxonomyObjects = get_terms($args);

            if (empty($taxonomyObjects)) {
                return $process_terms;
            } else {
                foreach ($taxonomyObjects as $key => $taxonomyObject) {
                    $process_terms[$taxonomyObject->term_id]['ID'] = $taxonomyObject->term_id;
                    $process_terms[$taxonomyObject->term_id]['name'] = $taxonomyObject->name;
                    $process_terms[$taxonomyObject->term_id]['taxonomy_name'] = $taxonomy;
                    $process_terms[$taxonomyObject->term_id]['thumbnail_id'] = get_term_meta($taxonomyObject->term_id, 'thumbnail_id', true);
                    $process_terms[$taxonomyObject->term_id]['image_url'] = wp_get_attachment_image_src($process_terms[$taxonomyObject->term_id]['thumbnail_id'], 'thumbnail');
                    if ($taxonomy !== 'product_cat') {
                        $process_terms[$taxonomyObject->term_id]['custom_thumb_term_meta'] = get_term_meta($taxonomyObject->term_id, '_borobazar_term_meta_data', true);
                    }
                    $process_terms[$taxonomyObject->term_id]['full'] = $taxonomyObject;
                    $process_terms[$taxonomyObject->term_id]['child'] = get_terms(
                        [
                            'taxonomy'   => $taxonomy,
                            'parent'     => $taxonomyObject->term_id,
                            'hide_empty' => $attributes['showEmptyCategory'],
                            'orderby'    => $attributes['categoryOrderBy'],
                            'order'      => $attributes['categoryOrder'],
                            'show_count'   => 0,
                            'pad_counts'   => 0,
                            'hierarchical' => 1,
                            'title_li'     => '',
                            'hide_empty'   => 0,
                            'child_of'     => 0,
                        ],
                    );
                }
            }

            set_transient('transient_borobazar_' . $taxonomy, $process_terms, MONTH_IN_SECONDS);
        }

        return $process_terms;
    }

    /**
     * setTransientTracking
     *
     * @param  string $transient_name
     * @return array
     */
    public static function setTransientTracking($transient_name)
    {
        $currentTransientLists = $transientNameLists = [];

        if (empty($transient_name)) {
            return;
        }

        $currentTransientLists = get_option('borobazar_transient_names', []);

        if (!empty($currentTransientLists)) {
            if (!in_array($transient_name, $currentTransientLists)) {
                array_push($currentTransientLists, $transient_name);
                update_option('borobazar_transient_names', $currentTransientLists);
            }
        } else {
            array_push($currentTransientLists, $transient_name);
            update_option('borobazar_transient_names', $currentTransientLists);
        }

        return $currentTransientLists;
    }

    /**
     * getCategoriesWPML
     *
     * @param  array $attributes
     * @return void
     */
    public static function getCategoriesWPML($attributes)
    {
        $exclude_ids = [];

        $exclude_names = ['Uncategorized'];
        if (!empty($exclude_names)) {
            foreach ($exclude_names as $name) {
                if (!empty($name)) {
                    $excluded_term = get_term_by('name', $name, 'product_cat');
                    if (!empty($excluded_term)) {
                        $exclude_ids[] = (int) $excluded_term->term_id;
                    }
                }
            }
        }

        $args = [
            'taxonomy'         => 'product_cat',
            'show_count'       => 0,
            'pad_counts'       => 0,
            'title_li'         => '',
            'exclude'          => $exclude_ids,
            'suppress_filters' => false,
            'hide_empty'       => $attributes['showEmptyCategory'],
        ];

        if (!$attributes['enableSubcategory']) {
            $args['parent']       = 0;
            $args['hierarchical'] = 1;
            $args['orderby']      = $attributes['categoryOrderBy'];
            if ($attributes['categoryOrderBy'] !== "menu_order") {
                $args['order'] = $attributes['categoryOrder'];
            }
        } else {
            // $args['parent']       = 0;
            $args['hierarchical'] = true;
            $args['orderby']      = $attributes['categoryOrderBy'];
            if ($attributes['categoryOrderBy'] !== "menu_order") {
                $args['order'] = $attributes['categoryOrder'];
            }
        }

        $results = get_categories($args);
        $process_categories = [];

        foreach ($results as $key => $category) {
            $process_categories[$category->term_id]['ID'] = $category->term_id;
            $process_categories[$category->term_id]['thumbnail_id'] = get_term_meta($category->term_id, 'thumbnail_id', true);
            $process_categories[$category->term_id]['image_url'] = wp_get_attachment_image_src($process_categories[$category->term_id]['thumbnail_id'], 'thumbnail');
            $process_categories[$category->term_id]['term_url'] = get_category_link($category->term_id);
            $process_categories[$category->term_id]['parent'] = $category->parent;
            $process_categories[$category->term_id]['full'] = $category;
            $process_categories[$category->term_id]['child'] = get_categories(
                [
                    'taxonomy'     => 'product_cat',
                    'child_of'     => 0,
                    'parent'       => $category->term_id,
                    'orderby'      => $attributes['categoryOrderBy'],
                    'show_count'   => 0,
                    'pad_counts'   => 0,
                    'hierarchical' => 1,
                    'title_li'     => '',
                    'hide_empty'   => 0,
                ]
            );
        }

        return $process_categories;
    }

    public static function getCategoriesByProducts($attributes)
    {

        if (class_exists('SitePress')) {
            $process_categories = BlockPostData::getCategoriesWPML($attributes);
            return $process_categories;
        }

        $process_categories = get_transient('transient_borobazar_product_categories');

        if (false === $process_categories) {
            $exclude_ids = [];

            $exclude_names = ['Uncategorized'];
            if (!empty($exclude_names)) {
                foreach ($exclude_names as $name) {
                    if (!empty($name)) {
                        $excluded_term = get_term_by('name', $name, 'product_cat');
                        if (!empty($excluded_term)) {
                            $exclude_ids[] = (int) $excluded_term->term_id;
                        }
                    }
                }
            }

            $args = [
                'taxonomy'         => 'product_cat',
                'show_count'       => 0,
                'pad_counts'       => 0,
                'title_li'         => '',
                'exclude'          => $exclude_ids,
                'suppress_filters' => false,
                'hide_empty'       => $attributes['showEmptyCategory'],
            ];

            if (!$attributes['enableSubcategory']) {
                $args['parent']       = 0;
                $args['hierarchical'] = 1;
                $args['orderby']      = $attributes['categoryOrderBy'];
                if ($attributes['categoryOrderBy'] !== "menu_order") {
                    $args['order'] = $attributes['categoryOrder'];
                }
            } else {
                // $args['parent']       = 0;
                $args['hierarchical'] = true;
                $args['orderby']      = $attributes['categoryOrderBy'];
                if ($attributes['categoryOrderBy'] !== "menu_order") {
                    $args['order'] = $attributes['categoryOrder'];
                }
            }

            $results = get_categories($args);
            $process_categories = [];

            foreach ($results as $key => $category) {
                $process_categories[$category->term_id]['ID'] = $category->term_id;
                $process_categories[$category->term_id]['thumbnail_id'] = get_term_meta($category->term_id, 'thumbnail_id', true);
                $process_categories[$category->term_id]['image_url'] = wp_get_attachment_image_src($process_categories[$category->term_id]['thumbnail_id'], 'thumbnail');
                $process_categories[$category->term_id]['term_url'] = get_category_link($category->term_id);
                $process_categories[$category->term_id]['parent'] = $category->parent;
                $process_categories[$category->term_id]['full'] = $category;
                $process_categories[$category->term_id]['child'] = get_categories(
                    [
                        'taxonomy'     => 'product_cat',
                        'child_of'     => 0,
                        'parent'       => $category->term_id,
                        'orderby'      => $attributes['categoryOrderBy'],
                        'show_count'   => 0,
                        'pad_counts'   => 0,
                        'hierarchical' => 1,
                        'title_li'     => '',
                        'hide_empty'   => 0,
                    ]
                );
            }

            set_transient('transient_borobazar_product_categories', $process_categories, MONTH_IN_SECONDS);
        }

        return $process_categories;
    }

    /**
     * checkIFProductInCart.
     *
     * @return void
     */
    public static function checkIFProductInCart()
    {
        $result = [];

        if (class_exists('WooCommerce') && !empty(WC()->cart)) {
            $cart_items = WC()->cart->get_cart();
            if (!count($cart_items)) {
                return $result;
            }
            foreach ($cart_items as $cart_item_key => $cart_item) {
                $result[$cart_item['product_id']] = $cart_item['quantity'];
            }
        }

        return $result;
    }

    /**
     * ifTransientTime.
     *
     * @return void
     */
    public static function ifTransientTime()
    {
        $setTransientTime = 60;
        $borobazarhelperSettings = get_option('borobazarhelper_settings', true);
        $transientSwitch = isset($borobazarhelperSettings['if_transient_switch']) ? $borobazarhelperSettings['if_transient_switch'] : 'false';
        if ($transientSwitch === 'true') {
            $transientTime = isset($borobazarhelperSettings['if_transient_expiration_time']) ? $borobazarhelperSettings['if_transient_expiration_time'] : '';
            if ($transientTime === 'MINUTE_IN_SECONDS') {
                $setTransientTime = 60;
            } elseif ($transientTime === 'HOUR_IN_SECONDS') {
                $setTransientTime = 3600;
            } elseif ($transientTime === 'DAY_IN_SECONDS') {
                $setTransientTime = 86400;
            } elseif ($transientTime === 'WEEK_IN_SECONDS') {
                $setTransientTime = 604800;
            } elseif ($transientTime === 'MONTH_IN_SECONDS') {
                $setTransientTime = 2592000;
            } elseif ($transientTime === 'YEAR_IN_SECONDS') {
                $setTransientTime = 31536000;
            } else {
                $setTransientTime = 60;
            }
        }

        return [
            'transientSwitch' => $transientSwitch,
            'transientTime' => $setTransientTime,
        ];
    }

    /**
     * orderByClause.
     *
     * @param string $tableName
     * @param string $orderBy
     *
     * @return void
     */
    public static function orderByClause($tableName = null, $orderBy = null)
    {
        $orderby_clause = '';
        switch ($orderBy) {
            case 'post_name':
            case 'post_author':
            case 'post_date':
            case 'post_title':
            case 'post_modified':
            case 'post_parent':
            case 'post_type':
            case 'ID':
            case 'menu_order':
            case 'comment_count':
                $orderby_clause = "{$tableName}.{$orderBy}";
                break;
            case 'rand':
                $orderby_clause = 'RAND()';
                break;
            default:
                $orderby_clause = "{$tableName}.ID";
                break;
        }

        return $orderby_clause;
    }
}
