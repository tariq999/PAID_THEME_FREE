<?php

namespace BoroBazarHelper\Traits;

trait LangTrait
{
    /**
     * Get translated ids of activate langs of a post
     *
     * @param int $product_id
     * @return array
     */
    public function get_translated_ids($product_id)
    {
        global $sitepress;
        $translated_ids = array();

        if (!isset($sitepress)) return;

        $trid = $sitepress->get_element_trid($product_id, 'post_product');
        $translations = $sitepress->get_element_translations($trid, 'product');

        foreach ($translations as $lang => $translation) {
            $translated_ids[$lang] = $translation->element_id;
        }

        return $translated_ids;
    }

    /**
     * Translated titles of posts
     *
     * @param array $translated_ids
     * @return array
     */
    public function get_translated_titles($translated_ids)
    {
        $titles = array_map(function ($id) {
            return get_the_title($id);
        }, $translated_ids);

        return $titles;
    }

    /**
     * Translated thumbnails of posts
     *
     * @param array $translated_ids
     * @return array
     */
    public function get_translated_thumbnails($translated_ids)
    {
        $thumbnails = array_map(function ($id) {
            return get_the_post_thumbnail_url($id, 'borobazar-grid-thumb');
        }, $translated_ids);

        return $thumbnails;
    }

    /**
     * Translated thumbnails sizes of posts
     *
     * @param array $translated_ids
     * @return array
     */
    public function get_translated_thumbnails_size($translated_ids)
    {
        $thumbnail_sizes = array_map(function ($id) {
            $size_array = [];
            $size_data = wp_get_attachment_image_src(get_post_thumbnail_id($id), 'borobazar-grid-thumb');

            if (!empty($size_data)) {
                $size_array = [
                    'width' => $size_data[1],
                    'height' => $size_data[2],
                ];
            }

            return $size_array;
        }, $translated_ids);

        return $thumbnail_sizes;
    }

    /**
     * Translated permalink of posts
     *
     * @param int $post_id
     * @param array $translated_ids
     * @return array
     */
    public function get_translated_permalink($post_id, $translated_ids)
    {
        $default_permalink = get_permalink($post_id);
        $languages = array_keys($translated_ids);

        $permalink = array_combine(
            $languages,
            array_map(function ($key) use ($default_permalink) {
                return apply_filters('wpml_permalink', $default_permalink, $key);
            }, $languages)
        );

        return $permalink;
    }

    /**
     * Get translated terms of post
     *
     * @param int $product_id
     * @param array $translated_ids
     * @param string $taxonomy
     * @return array
     */
    public function get_translated_post_terms($product_id, $translated_ids, $taxonomy = 'product_cat')
    {
        global $sitepress;
        $terms = [];

        if (!isset($sitepress)) return;

        $terms_id = array_map(function (\WP_Term $term) {
            return $term->term_id;
        }, wp_get_post_terms($product_id, $taxonomy));

        $languages = array_keys($translated_ids);

        if (empty($terms_id)) {
            return $terms;
        }

        foreach ($terms_id as $key => $term_id) {
            foreach ($languages as $lang_key => $language) {
                $translated_term = icl_object_id($term_id, $taxonomy, true, $language);

                remove_filter('get_term', array($sitepress, 'get_term_adjust_id'), 1);

                $term_object = get_term_by('id', $translated_term, $taxonomy);

                $terms[$language][] = [
                    'name' => $term_object->name,
                    'slug' => $term_object->slug,
                    'url'  => get_term_link($term_object->term_id),
                ];

                add_filter('get_term', array($sitepress, 'get_term_adjust_id'), 1, 1);
            }
        }

        return $terms;
    }

    /**
     * Slugs for taxonomies
     *
     * @param array $categories
     * @return void
     */
    public function get_formatted_slugs($categories)
    {
        $results = [];

        if (empty($categories)) {
            return $results;
        }

        foreach ($categories as $key => $category) {

            if (empty($category)) {
                continue;
            }

            foreach ($category as $key => $value) {
                $results[] = $value['slug'];
            }
        }

        return $results;
    }
}
