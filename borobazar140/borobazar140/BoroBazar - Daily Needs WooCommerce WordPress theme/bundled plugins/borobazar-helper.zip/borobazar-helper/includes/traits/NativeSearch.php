<?php

namespace BoroBazarHelper\Traits;

trait NativeSearchTrait
{
    protected $post_type = 'product';
    protected $limit = 12;

    /**
     * search through wordpress post types
     *
     * @return array
     */
    public function search($args = [])
    {
        $args = array_merge(
            [
                'post_type'   => apply_filters('search_post_type', $this->post_type),
                'post_status' => 'publish',
            ],
            $args
        );

        $args = apply_filters('search_args', $args);

        if (get_theme_mod('borobazar_limit_search_to_post_title', 'off') !== "on") {
            $query = new \WP_Query($args);
        } else {
            add_filter('posts_where', [$this, 'search_product_title_only'], 10, 2);
            $query = new \WP_Query($args);
            remove_filter('posts_where', [$this, 'search_product_title_only'], 10, 2);
        }



        $posts = $this->processPostData($query->posts);
        return apply_filters('search_results', ['posts' => $posts, 'count' => $query->found_posts]);
    }

    /**
     * search_product_title_only
     *
     * @param  mixed $where
     * @param  mixed $wp_query
     * @return void
     */
    public function search_product_title_only($where, $wp_query)
    {
        global $wpdb;
        if ($search_term = $wp_query->get('search_product_title')) {
            $where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'%' . esc_sql($wpdb->esc_like($search_term)) . '%\'';
        }
        return $where;
    }


    /**
     * Process post data
     *
     * @param array $posts
     * @return array
     */
    public function processPostData($posts)
    {
        $all_processed_posts = [];

        foreach ($posts as $key => $post) {
            $all_processed_posts[] = apply_filters('borobazar_process_grid_data', $post);
        }

        return apply_filters('processed_results', $all_processed_posts);
    }

    /**
     * Get product limit
     *
     * @return int
     */
    public function getProductLimit()
    {
        $product_limit = (int) get_theme_mod('woo_product_limit', 12);

        if ($product_limit) {
            return $product_limit;
        }

        return $this->limit;
    }
}
