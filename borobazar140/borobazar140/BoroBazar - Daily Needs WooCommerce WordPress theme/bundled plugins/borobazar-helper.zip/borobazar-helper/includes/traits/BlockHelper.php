<?php

namespace BoroBazarHelper\Traits;

defined('ABSPATH') || exit;
trait BlockHelper
{
    /**
     * getIFBGStyles.
     *
     * @param mixed $attributes
     *
     * @return string
     */
    public static function getIFBGStyles($attributes)
    {
        extract($attributes);
        $styles = '';
        $styles .= 'background-color:' . $backgroundColor . ';';
        if ($backgroundImage) {
            $styles .= 'background-image:' . 'url(' . $backgroundImage . ');';
            $styles .= 'background-size:' . $backgroundSize . ';';
            $styles .= 'background-attachment:' . $backgroundAttachment . ';';
            $styles .= 'background-repeat:' . $backgroundRepeat . ';';
            $styles .= 'background-position-x:' . $backgroundPositionX . ';';
            $styles .= 'background-position-y:' . $backgroundPositionY . ';';
        }

        return apply_filters('get_if_background_styles', $styles);
    }

    /**
     * getIFPaddingStyles.
     *
     * @param mixed $attributes
     *
     * @return string
     */
    public static function getIFPaddingStyles($attributes)
    {
        extract($attributes);
        $styles = '';
        $styles .= '--desktop-padding-top:' . $paddingTop['desktop'] . 'px;';
        $styles .= '--laptop-padding-top:' . $paddingTop['laptop'] . 'px;';
        $styles .= '--tab-padding-top:' . $paddingTop['tab'] . 'px;';
        $styles .= '--mobile-padding-top:' . $paddingTop['mobile'] . 'px;';
        $styles .= '--desktop-padding-right:' . $paddingRight['desktop'] . 'px;';
        $styles .= '--laptop-padding-right:' . $paddingRight['laptop'] . 'px;';
        $styles .= '--tab-padding-right:' . $paddingRight['tab'] . 'px;';
        $styles .= '--mobile-padding-right:' . $paddingRight['mobile'] . 'px;';
        $styles .= '--desktop-padding-bottom:' . $paddingBottom['desktop'] . 'px;';
        $styles .= '--laptop-padding-bottom:' . $paddingBottom['laptop'] . 'px;';
        $styles .= '--tab-padding-bottom:' . $paddingBottom['tab'] . 'px;';
        $styles .= '--mobile-padding-bottom:' . $paddingBottom['mobile'] . 'px;';
        $styles .= '--desktop-padding-left:' . $paddingLeft['desktop'] . 'px;';
        $styles .= '--laptop-padding-left:' . $paddingLeft['laptop'] . 'px;';
        $styles .= '--tab-padding-left:' . $paddingLeft['tab'] . 'px;';
        $styles .= '--mobile-padding-left:' . $paddingLeft['mobile'] . 'px;';

        return apply_filters('get_if_padding_styles', $styles);
    }

    /**
     * getIFStylesAttributes.
     *
     * @param mixed $attributes
     *
     * @return string
     */
    public static function getIFStylesAttributes($attributes, $selector = 'font-size')
    {
        extract($attributes);
        $styles = '';

        if (is_array($attributes) && !empty($attributes)) {
            foreach ($attributes as $key => $value) {
                $styles .= '--' . $key . '-' . $selector . ':' . $value . 'px;';
            }
        }

        return apply_filters('get_if_style_attributes', $styles);
    }

    /**
     * getIFBackgroundAttributes.
     *
     * @param mixed $attributes
     *
     * @return string
     */
    public static function getIFBackgroundAttributes($attributes)
    {
        extract($attributes);
        $styles = '';

        $styles .= '--backgroundImage:' . $attributes['backgroundImage'] . ';';
        $styles .= '--backgroundSize:' . $attributes['backgroundSize'] . ';';
        $styles .= '--backgroundAttachment:' . $attributes['backgroundAttachment'] . ';';
        $styles .= '--backgroundPositionX:' . $attributes['backgroundPositionX'] . ';';
        $styles .= '--backgroundPositionY:' . $attributes['backgroundPositionY'] . ';';
        $styles .= '--backgroundRepeat:' . $attributes['backgroundRepeat'] . ';';
        $styles .= '--mobileBackgroundImage:' . $attributes['mobileBackgroundImage'] . ';';
        $styles .= '--mobileBackgroundSize:' . $attributes['mobileBackgroundSize'] . ';';
        $styles .= '--mobileBackgroundAttachment:' . $attributes['mobileBackgroundAttachment'] . ';';
        $styles .= '--mobileBackgroundPositionX:' . $attributes['mobileBackgroundPositionX'] . ';';
        $styles .= '--mobileBackgroundPositionY:' . $attributes['mobileBackgroundPositionY'] . ';';
        $styles .= '--mobileBackgroundRepeat:' . $attributes['mobileBackgroundRepeat'] . ';';

        return apply_filters('get_if_background_attributes', $styles);
    }

    /**
     * ifGridLoopItemClasses.
     *
     * @param string $gridTemplate
     *
     * @return string
     */
    public static function ifGridLoopItemClasses($gridTemplate)
    {
        $gridClass = '';

        switch ($gridTemplate) {
            case 'grid_alpine':
                $gridClass  = 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 3xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
                break;
            default:
                $gridClass  = 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 3xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
                break;
        }

        return apply_filters('if_grid_loop_item_classes', $gridClass);
    }

    /**
     * wp_is_only_mobile.
     *
     * @return string
     */
    public static function wp_is_only_mobile()
    {
        static $is_mobile;

        if (isset($is_mobile)) {
            return $is_mobile;
        }

        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            $is_mobile = false;
        } elseif (
            strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Silk/') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Kindle') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'BlackBerry') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== false
        ) {
            $is_mobile = true;
        } elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false && strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') == false) {
            $is_mobile = true;
        } elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'iPad') !== false) {
            $is_mobile = false;
        } else {
            $is_mobile = false;
        }

        return $is_mobile;
    }
}
