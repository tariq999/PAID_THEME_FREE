<?php

namespace BoroBazarHelper\Front;

defined('ABSPATH') || exit;

use BoroBazarHelper\Traits\StyleScriptLoader;

/**
 * Styles.
 */
class Styles
{
    use StyleScriptLoader;

    /**
     * __construct.
     */
    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'loadStyles']);
    }

    /**
     * registerStyles.
     */
    private static function registerStyles()
    {
        $register_styles = apply_filters('borobazar_frontend_styles_array', [
            'jquery.toast.min' => [
                'src'          => BOROBAZAR_HELPER_ASSETS . 'client/library/jquery.toast.min.css',
                'deps'         => [],
                'version'      => BOROBAZAR_HELPER_VERSION,
                'has_rtl'      => false,
            ],
            'if-gutenberg-front-css' => [
                'src'     => BOROBAZAR_HELPER_DIST . 'blocks.style.build.css',
                'deps'    => is_admin() ? ['wp-editor'] : [],
                'version' => BOROBAZAR_HELPER_VERSION,
                'has_rtl' => true,
            ],
        ]);

        foreach ($register_styles as $name => $props) {
            self::registerStyle($name, $props['src'], $props['deps'], $props['version'], 'all', $props['has_rtl']);
        }
    }

    /**
     * loadStyles.
     */
    public function loadStyles()
    {
        self::registerStyles();
        self::enqueueStyle('if-gutenberg-front-css');
        self::enqueueStyle('jquery.toast.min');

        if (is_rtl()) {
            wp_enqueue_style('borobazar-helper-custom-rtl', BOROBAZAR_HELPER_ASSETS . 'client/css/borobazar-helper-custom-rtl.css', [], BOROBAZAR_HELPER_VERSION);
        }
    }
}
