<?php

/**
 * ShortCodes For Contact Info Block
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazar_team_block');


function borobazar_team_block()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/borobazar-team-block',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazar_team_block_callback',
                'attributes'   => array(
                    'teamMembers' => array(
                        'type' => "array",
                        'default' => [],
                    ),
                    'columnSize' => [
                        'type' => "number",
                        'default' => 4,
                    ],
                    'nameColor' => [
                        'type' => "string",
                        'default' => "#000000",
                    ],
                    'designationColor' => [
                        'type' => "string",
                        'default' => "#595959",
                    ],
                    'paddingTop'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingRight'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingBottom'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingLeft'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                )
            )
        );
    }
}

function borobazar_team_block_callback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $width = $height = '';
    $allowedHTML = wp_kses_allowed_html('post');
    $padding = getBoroBazarPaddingStyles($attributes);

    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    // set team column
    $columnClass = '';
    switch ($columnSize) {
        case 6:
            $columnClass =
                "grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6";
            break;

        case 5:
            $columnClass = "grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5";
            break;

        case 4:
            $columnClass = "grid-cols-2 md:grid-cols-3 lg:grid-cols-4";
            break;

        case 3:
            $columnClass = "grid-cols-2 md:grid-cols-3";
            break;

        default:
            $columnClass = "grid-cols-2";
            break;
    }
?>

    <div class="borobazar-block-spacing-wrapper borobazar-team-block <?php echo esc_attr($customClass) ?>" style="<?php echo esc_attr($padding) ?>">
        <?php if (!empty($attributes['teamMembers'])) { ?>
            <div class="grid gap-4 sm:gap-6 lg:gap-8 <?php echo esc_attr($columnClass); ?>">
                <?php foreach ($attributes['teamMembers'] as $member) {
                    $thumb = isset($member['thumb']) ? $member['thumb'] : '';
                    $name = isset($member['name']) ? $member['name'] : '';
                    $designation = isset($member['designation']) ? $member['designation'] : '';

                    if (!empty($thumb)) {
                        if (attachment_url_to_postid($thumb) === 0) {
                            $width = 355;
                            $height = 355;
                        } else {
                            $image_id = attachment_url_to_postid($thumb);
                            $image_attributes = wp_get_attachment_image_src($image_id, "large");
                            $width = !empty($image_attributes) ? $image_attributes['1'] : 355;
                            $height = !empty($image_attributes) ? $image_attributes['2'] : 355;
                        }
                    }


                ?>
                    <div class="borobazar-team-member mouse-move-effect">
                        <div class="overflow-hidden mb-2 sm:mb-4">
                            <div class="borobazar-image-fade-in member-image flex items-center mouse-move-effect-scale">
                                <img class="w-full aspect-square object-cover mouse-move-effect-el block opacity-0" width="<?php echo esc_attr($width); ?>" height="<?php echo esc_attr($height); ?>" src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr__('member-image', 'borobazar-helper'); ?>" style="--d: 22" />
                            </div>
                        </div>
                        <div class="member-info">
                            <h5 class="mt-0 mb-0.5 text-sm sm:text-md sm:mb-1.5 md:mb-2" style="--name-color: <?php echo esc_attr($nameColor) ?>">
                                <?php echo wp_kses($name, $allowedHTML); ?>
                            </h5>
                            <div class="content text-xs sm:text-md" style="--designation-color: <?php echo esc_attr($designationColor) ?>">
                                <?php echo wp_kses($designation, $allowedHTML); ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        <?php } ?>
    </div>

    <?php return apply_filters('borobazar_team_block', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>