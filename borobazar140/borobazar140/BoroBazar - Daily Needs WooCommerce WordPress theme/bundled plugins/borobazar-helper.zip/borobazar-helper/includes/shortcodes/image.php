<?php

/**
 * ShortCodes For rnbBanner
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazarImage');


function borobazarImage()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/image-block',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazarImageCallback',
                'attributes'   => array(
                    'image'    => array(
                        'type'      => 'string',
                        'default'   =>  ''
                    ),
                    'alt'    => array(
                        'type'      => 'string',
                        'default'   =>  ''
                    ),
                )
            )
        );
    }
}

function borobazarImageCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

?>

    <div class="borobazar-image-block <?php echo esc_attr($customClass) ?>">
        <?php if ($image) { ?>
            <img src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr($alt ? $alt : 'image') ?>" />
        <?php } ?>
    </div>


    <?php return apply_filters('borobazar_image', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>