<?php

/**
 * ShortCodes For rnbBanner
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazarCounter');


function borobazarCounter()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/counter-block',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazarCounterCallback',
                'attributes'   => array(
                    'columnSize'    => array(
                        'type'      => 'number',
                        'default'   =>  2
                    ),
                    'verticalAlign'    => array(
                        'type'      => 'string',
                        'default'   =>  'center'
                    ),
                    'counterItems'    => array(
                        'type' => 'array',
                        'default' => [
                            [
                                'title' => "",
                                'description' => "",
                                'count' => "",
                                'symbol' => "",
                            ],
                        ],
                        'items' => [
                            'type' => 'object',
                        ],
                    ),
                    'backgroundColor'    => array(
                        'type'      => 'string',
                        'default'   =>  '#fff'
                    ),
                    'titleColor'    => array(
                        'type'      => 'string',
                        'default'   =>  '#595959'
                    ),
                    'descriptionColor'    => array(
                        'type'      => 'string',
                        'default'   =>  '#666666'
                    ),
                    'countColor'    => array(
                        'type'      => 'string',
                        'default'   =>  '#02B290'
                    ),
                    'symbolColor'    => array(
                        'type'      => 'string',
                        'default'   =>  '#02B290'
                    ),
                )
            )
        );
    }
}

function borobazarCounterCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    $columnClassName = "";
    switch ($columnSize) {
        case 1:
            $columnClassName = "grid-cols-1";
            break;
        case 2:
            $columnClassName = "sm:grid-cols-2";
            break;
        case 3:
            $columnClassName = "sm:grid-cols-2 2xl:grid-cols-3";
            break;

        default:
            $columnClassName = "sm:grid-cols-2";
            break;
    }

?>

    <div class="borobazar-counter-block <?php echo esc_attr($customClass) ?>">
        <div class="borobazar-counters-wrapper grid gap-5 sm:gap-7 xl:gap-8 <?php echo esc_attr($columnClassName) ?>">
            <?php foreach ($counterItems as $key => $item) {
                $title = isset($item['title']) ? $item['title'] : '';
                $description = isset($item['description']) ? $item['description'] : '';
                $count = isset($item['count']) ? $item['count'] : '';
                $symbol = isset($item['symbol']) ? $item['symbol'] : '';
            ?>
                <div class="relative bg-white rounded-xl px-8 sm:px-9 xl:px-14 py-6 sm:py-9 xl:py-11 transition-all shadow-countdown hover:shadow-countdown-hover" style="background-color: <?php echo esc_attr($backgroundColor) ?>">

                    <div class="text-md sm:text-lg font-semibold mb-2" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></div>
                    <div class="flex items-center">
                        <div class="text-4xl sm:text-6xl xl:text-gx font-semibold leading-none" style="color: <?php echo esc_attr($countColor) ?>"><?php echo wp_kses($count, $allowedHTML); ?></div>
                        <div class="text-2xl sm:text-4xl xl:text-5xl font-semibold leading-none" style="color: <?php echo esc_attr($symbolColor) ?>"><?php echo wp_kses($symbol, $allowedHTML); ?></div>
                    </div>
                    <div class="text-sm sm:text-base mt-4" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?></div>
                </div>

            <?php } ?>
        </div>
    </div>


    <?php return apply_filters('borobazar_counter', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>