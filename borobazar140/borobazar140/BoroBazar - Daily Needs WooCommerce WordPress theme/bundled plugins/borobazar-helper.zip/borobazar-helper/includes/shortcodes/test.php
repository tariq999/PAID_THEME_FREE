<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

add_action('init', 'gsBestSellingGrid');

function gsBestSellingGrid()
{
    if (function_exists('register_block_type')) {
        register_block_type('cgb/block-borobazar-helper', [
            'editor_script' => 'if-gutenberg-block-scripts',
            'render_callback' => 'gsTestBlock',
            'attributes' => [
            ],
        ]);
    }
}

function gsTestBlock($attributes, $content)
{
    ob_start();

    return apply_filters('if_test_block', ob_get_clean(), $attributes, $content);
}