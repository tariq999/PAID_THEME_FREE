<?php

/**
 * ShortCodes For App block
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazar_about_block');


function borobazar_about_block()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/borobazar-about-info-block',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazar_about_block_callback',
                'attributes'   => array(
                    'image'  => array(
                        'type'    => 'string',
                        'default' => BOROBAZAR_HELPER_ASSETS . 'global/images/logo.svg'
                    ),
                    'content' => array(
                        'type'    => "string",
                        'default' => esc_html__("We offers high-quality films and the best documentary selection, and the ability to browse alphabetically", 'borobazar-helper'),
                    ),
                    'socialLinks' => array(
                        'type' => "array",
                        'default' => [
                            [
                                'icon' => BOROBAZAR_HELPER_ASSETS . 'global/images/facebook.svg',
                                'link' => [
                                    'url' => "",
                                    'opensInNewTab' => false,
                                ],
                            ],
                            [
                                'icon' => BOROBAZAR_HELPER_ASSETS . 'global/images/twitter.svg',
                                'link' => [
                                    'url' => "",
                                    'opensInNewTab' => false,
                                ],
                            ],
                            [
                                'icon' => BOROBAZAR_HELPER_ASSETS . 'global/images/youtube.svg',
                                'link' => [
                                    'url' => "",
                                    'opensInNewTab' => false,
                                ],
                            ],
                            [
                                'icon' => BOROBAZAR_HELPER_ASSETS . 'global/images/instagram.svg',
                                'link' => [
                                    'url' => "",
                                    'opensInNewTab' => false,
                                ],
                            ],
                        ],
                    ),
                )
            )
        );
    }
}

function borobazar_about_block_callback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }
?>

    <div class="borobazar-about-block 3xl:max-w-xs <?php echo esc_attr($customClass) ?>">
        <a class="-mt-1.5 no-underline inline-flex items-center transition-opacity duration-200 hover:opacity-90 focus:opacity-90" href="<?php echo esc_url(home_url('/')); ?>" rel="<?php echo esc_attr__('home', 'borobazar-helper'); ?>">
            <img class="max-w-[120px] sm:max-w-[auto]" src="<?php echo esc_attr($image); ?>" alt="<?php bloginfo('name'); ?>" />
        </a>
        <div class="borobazar-about-block-content mt-2 sm:mt-3 md:mt-4 mb-5 sm:mb-6 leading-loose">
            <?php echo wp_kses($content, $allowedHTML); ?>
        </div>

        <?php if (!empty($socialLinks)) { ?>
            <div class="flex flex-wrap items-center gap-4 sm:gap-5 mb-1 sm:mb-2">
                <?php foreach ($socialLinks as $socialLink) {
                    $icon = isset($socialLink['icon']) ? $socialLink['icon'] : '';
                    $url = isset($socialLink['link']['url']) ? $socialLink['link']['url'] : '';
                    $newTab = isset($socialLink['link']['opensInNewTab']) ? $socialLink['link']['opensInNewTab'] : '';
                ?>
                    <a class="no-underline inline-flex items-center transition-opacity duration-200 hover:opacity-70 focus:opacity-70" href="<?php echo esc_url($url) ?>" target="<?php echo esc_attr($newTab ? '_blank' : '_self'); ?>" rel="noopener noreferrer">
                        <img class="w-4 sm:w-5 h-4 sm:h-5" src="<?php echo esc_attr($icon); ?>" alt="<?php echo esc_attr__('Social profile', 'borobazar-helper'); ?>" />
                    </a>
                <?php } ?>
            </div>
        <?php } ?>
    </div>

    <?php return apply_filters('borobazar_about_block', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>