<?php

/**
 * ShortCodes For Contact Info Block
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazar_contact_info_block');


function borobazar_contact_info_block()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/borobazar-contact-info-block',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazar_contact_info_block_callback',
                'attributes'   => array(
                    'title'  => array(
                        'type'    => 'string',
                        'default' => esc_html__("Support is our main priority", "borobazar-helper")
                    ),
                    'description' => array(
                        'type'    => "string",
                        'default' => esc_html__("We created reusable react components, and modern mono repo so you can build multiple apps with common components.", 'borobazar-helper'),
                    ),
                    'contactInfo' => array(
                        'type' => "array",
                        'default' => [
                            [
                                'icon' => BOROBAZAR_HELPER_ASSETS . 'global/images/contact/location.svg',
                                'title' => esc_html__("Office Location", "borobazar-helper"),
                                'description' => esc_html__("2756 Quiet Valley Lane, Reseda, California, United Stats", "borobazar-helper")
                            ],
                            [
                                'icon' => BOROBAZAR_HELPER_ASSETS . 'global/images/contact/phone.svg',
                                'title' => esc_html__("Call us anytime", "borobazar-helper"),
                                'description' => esc_html__("Change the design through a range<br />+89 5631 564  +88 5321 036", "borobazar-helper")
                            ],
                            [
                                'icon' => BOROBAZAR_HELPER_ASSETS . 'global/images/contact/at.svg',
                                'title' => esc_html__("Send Mail", "borobazar-helper"),
                                'description' => esc_html__("support@redqagency.com<br />hire.us@redqteam.io", "borobazar-helper")
                            ],
                        ],
                    ),
                    'titleColor' => [
                        'type' => "string",
                        'default' => "#000000",
                    ],
                    'descriptionColor' => [
                        'type' => "string",
                        'default' => "#595959",
                    ],
                )
            )
        );
    }
}

function borobazar_contact_info_block_callback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = '';

    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

?>

    <div class="borobazar-contact-block <?php echo esc_attr($customClass) ?>">
        <h3 class="mt-0 mb-3 sm:mb-5" style="--title-color: <?php echo esc_attr($titleColor) ?>">
            <?php echo wp_kses($title, $allowedHTML); ?>
        </h3>
        <div class="content leading-loose mb-8 sm:mb-10" style="--description-color: <?php echo esc_attr($descriptionColor) ?>">
            <?php echo wp_kses($description, $allowedHTML); ?>
        </div>
        <?php if (!empty($contactInfo)) { ?>
            <div class="grid gap-8">
                <?php foreach ($contactInfo as $item) {
                    $icon = isset($item['icon']) ? $item['icon'] : '';
                    $title = isset($item['title']) ? $item['title'] : '';
                    $description = isset($item['description']) ? $item['description'] : '';
                ?>
                    <div class="flex items-center">
                        <div class="w-14 sm:w-[68px] shrink-0 grid place-content-start">
                            <img class="w-10 sm:w-[50px] h-10 sm:h-[50px] object-scale-down" src="<?php echo esc_attr($icon); ?>" alt="<?php echo esc_attr($title); ?>" />
                        </div>
                        <div class="flex-1">
                            <h6 class="mt-0 mb-2" style="--title-color: <?php echo esc_attr($titleColor) ?>">
                                <?php echo wp_kses($title, $allowedHTML); ?>
                            </h6>
                            <div class="content" style="--description-color: <?php echo esc_attr($descriptionColor) ?>">
                                <?php echo wp_kses($description, $allowedHTML); ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        <?php } ?>
    </div>

    <?php return apply_filters('borobazar_contact_info_block', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>