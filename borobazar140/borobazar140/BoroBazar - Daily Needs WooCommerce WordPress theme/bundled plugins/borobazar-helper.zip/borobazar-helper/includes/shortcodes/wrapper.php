<?php

/**
 *
 * ShortCodes For Store Map
 *
 * @since   1.0.0
 *
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazar_wrapper');

function borobazar_wrapper()
{
    if (function_exists('register_block_type')) {
        register_block_type('borobazar-blocks/borobazar-wrapper', [
            'editor_script' => 'borobazar_blocks-cgb-block-js',
            'render_callback' => 'borobazar_wrapper_callback',
            'attributes' => [
                'paddingTop'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0
                    ],
                ),
                'paddingRight'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0
                    ],
                ),
                'paddingBottom'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0
                    ],
                ),
                'paddingLeft'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0
                    ],
                ),
                'marginTop'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0
                    ],
                ),
                'marginRight'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0
                    ],
                ),
                'marginBottom'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0
                    ],
                ),
                'marginLeft'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0
                    ],
                ),
                'boxShadow'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'horizontal' => 0,
                        'vertical'   => 0,
                        'blur'       => 0,
                        'spread'     => 0,
                        'color'      => ''
                    ],
                ),
                'backgroundColor' => array(
                    "type" => "string",
                    'default' => "#ffffff",
                ),
                'borderRadius' => array(
                    "type" => "number",
                    'default' => 0,
                ),
            ],
        ]);
    }
}

function borobazar_wrapper_callback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $paddingStyle = getBoroBazarPaddingStyles($attributes);
    $marginStyle = getBoroBazarMarginStyles($attributes);
    $shadowStyle = getBoroBazarShadowStyles($attributes);
    $blockStyle = '';
    $blockStyle .= $paddingStyle;
    $blockStyle .= $marginStyle;
    $blockStyle .= $shadowStyle;
    $blockStyle .= ';';
    $blockStyle .= '--background-color:' . $backgroundColor . ';';
    $blockStyle .= '--border-radius:' . $borderRadius . 'px';
?>

    <div class="wp-block-borobazar-blocks-borobazar-wrapper borobazar-block-spacing-wrapper borobazar-block-spacing-margin-wrapper borobazar-block-shadow" style="<?php echo esc_attr($blockStyle); ?>">
        <?php echo $content; ?>
    </div>

    <?php return apply_filters('borobazar_wrapper', ob_get_clean(), $attributes, $content); ?>

<?php
} ?>