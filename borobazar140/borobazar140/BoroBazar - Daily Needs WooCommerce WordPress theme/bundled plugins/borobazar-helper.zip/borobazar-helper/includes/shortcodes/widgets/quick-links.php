<?php

/**
 * ShortCodes For App block
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazar_quick_links');


function borobazar_quick_links()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/borobazar-quick-link',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazar_quick_links_callback', 'attributes'  => array(
                    'title'    => array(
                        'type'      => 'string',
                        'default'   => '',
                    ),
                    'links' => array(
                        'type' => "array",
                        'default' => [],
                    ),
                )
            )
        );
    }
}

function borobazar_quick_links_callback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

?>

    <div class="borobazar-quick-links flex flex-col <?php echo esc_attr($customClass) ?>">
        <?php if (!empty($title)) { ?>
            <h3 class="borobazar-quick-links-title text-[15px] sm:text-base 3xl:text-[17px] mt-0 mb-2 sm:mb-2.5 md:mb-4"><?php esc_html_e($title, 'borobazar-helper'); ?></h3>
        <?php } ?>

        <?php if (!empty($links)) { ?>
            <?php foreach ($links as $link) {
                $text = isset($link['text']) ? $link['text'] : '';
                $url = isset($link['link']['url']) ? $link['link']['url'] : '';
                $newTab = isset($link['link']['opensInNewTab']) ? $link['link']['opensInNewTab'] : '';
            ?>
                <a class="borobazar-quick-links-item self-start my-1.5 sm:my-2 sm:first:mt-1.5 last:mb-0 no-underline transition-colors duration-200 text-dark hover:text-brand focus:text-brand" href="<?php echo esc_url($url) ?>" target="<?php echo esc_attr($newTab ? '_blank' : '_self'); ?>" rel="noopener noreferrer">
                    <?php esc_html_e($text, 'borobazar-helper'); ?>
                </a>
            <?php } ?>
        <?php } ?>
    </div>

    <?php return ob_get_clean(); ?>

<?php } ?>