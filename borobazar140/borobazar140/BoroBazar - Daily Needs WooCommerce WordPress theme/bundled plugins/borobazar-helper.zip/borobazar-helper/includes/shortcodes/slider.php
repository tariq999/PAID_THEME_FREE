<?php

/**
 * ShortCodes For rnbBanner
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

use BoroBazarHelper\Classes;

add_action('init', 'borobazarSlider');


function borobazarSlider()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/slider',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazarSliderCallback',
                'attributes'   => array(
                    'paddingTop'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingRight'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingBottom'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingLeft'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'slideItems'    => array(
                        'type' => 'array',
                        'default' => [
                            [
                                'slogan'             => '',
                                'title'              => '',
                                'description'        => '',
                                'button'             => 'Button',
                                'image'              => "",
                                'url'                => "",
                                'opensInNewTab'      => false,
                                'contentPosition'    => "top left",
                                'textAlign'          => "left",
                                'backgroundPosition' => "50% 50%",
                                'backgroundRepeat'   => false,
                                'fixedBackground'    => false,
                                'backgroundSize'     => "cover",
                                'backgroundColor'    => "#f9f9f9",
                                'overlayOpacity'     => 0,
                                'overlay'            => "#000000",
                                'sloganColor'        => "#000000",
                                'titleColor'         => "#000000",
                                'descriptionColor'   => "#4A5568",
                                'buttonColor'        => "#02B290",
                                'buttonTextColor'    => "#ffffff",
                                'buttonHoverColor'   => "#01A585",
                                'buttonHoverTextColor' => "#ffffff",
                                'height' => ['desktop' => 300, 'laptop' => 300, 'tab' => 200, 'mobile' => 120],
                                'paddingTop' => ['desktop' => 0, 'laptop' => 0, 'tab' => 0, 'mobile' => 0],
                                'paddingRight' => ['desktop' => 0, 'laptop' => 0, 'tab' => 0, 'mobile' => 0],
                                'paddingBottom' => ['desktop' => 0, 'laptop' => 0, 'tab' => 0, 'mobile' => 0],
                                'paddingLeft' => ['desktop' => 0, 'laptop' => 0, 'tab' => 0, 'mobile' => 0],
                            ],
                        ],
                        'items' => [
                            'type' => 'object',
                        ],
                    ),
                    'template' => array(
                        'type'      => 'string',
                        'default'   => 'image',
                    ),
                    'slidesPerView'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 1,
                            'laptop'  => 1,
                            'tab'     => 1,
                            'mobile'  => 1
                        ],
                    ),
                    'spaceBetween'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'speed' => array(
                        'type'      => 'number',
                        'default'   => 300,
                    ),
                    'centeredSlides' => array(
                        'type'      => 'boolean',
                        'default'   => false,
                    ),
                    'grabCursor' => array(
                        'type'      => 'boolean',
                        'default'   => false,
                    ),
                    'loop' => array(
                        'type'      => 'boolean',
                        'default'   => false,
                    ),
                    'autoplay' => array(
                        'type'      => 'boolean',
                        'default'   => false,
                    ),
                )
            )
        );
    }
}

function borobazarSliderCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $padding = getBoroBazarPaddingStyles($attributes);
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    $transfer_data = new Classes();
    $unique_id = uniqid();

?>

    <div class="borobazar-block-spacing-wrapper borobazar-slider box-border <?php echo esc_attr($customClass) ?>  <?php echo esc_attr($template) ?>-slider" style="<?php echo esc_attr($padding) ?>">
        <div class="swiper borobazar-slider-selector" id="borobazar-slider-<?php echo esc_attr($unique_id); ?>">
            <div class="swiper-wrapper">
                <?php foreach ($slideItems as $key => $slide) { ?>
                    <div class="swiper-slide">
                        <?php
                        $transfer_data->borobazar_get_template_part('slider/' . $template . '.php', ['slide' => $slide, 'allowedHTML' => $allowedHTML,]);
                        ?>
                    </div>
                <?php } ?>
            </div>
            <div class='borobazar-slider-next-button absolute top-1/2 right-1.5 md:right-9 bg-white w-9 md:w-11 4xl:w-13 h-9 md:h-11 4xl:h-13 rounded-full z-1 hidden md:flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white'>
                <svg class="w-2 4xl:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M110.841,12.005l-8.978-8.979a1.316,1.316,0,0,1,0-1.856l.787-.786a1.315,1.315,0,0,1,1.857,0l10.69,10.69a1.325,1.325,0,0,1,0,1.863l-10.68,10.68a1.315,1.315,0,0,1-1.857,0l-.787-.786a1.314,1.314,0,0,1,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>
            <div class='borobazar-slider-prev-button absolute top-1/2 left-1.5 md:left-9 bg-white w-9 md:w-11 4xl:w-13 h-9 md:h-11 4xl:h-13 rounded-full z-1 hidden md:flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white'>
                <svg class="w-2 4xl:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M106.218,12.005,115.2,3.026a1.316,1.316,0,0,0,0-1.856l-.787-.786a1.315,1.315,0,0,0-1.857,0l-10.69,10.69a1.325,1.325,0,0,0,0,1.863l10.68,10.68a1.315,1.315,0,0,0,1.857,0l.787-.786a1.314,1.314,0,0,0,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>
            <div class="swiper-scrollbar slider-mobile-scrollbar"></div>

            <?php if ($template == 'hero') { ?>
                <div class="swiper-pagination"></div>
            <?php } ?>
        </div>

        <input type="hidden" class="borobazar-slider-settings" data-template="<?php echo esc_attr($template) ?>" data-slides-per-view-desktop="<?php echo esc_attr($slidesPerView['desktop']) ?>" data-slides-per-view-laptop="<?php echo esc_attr($slidesPerView['laptop']) ?>" data-slides-per-view-tab="<?php echo esc_attr($slidesPerView['tab']) ?>" data-slides-per-view-mobile="<?php echo esc_attr($slidesPerView['mobile']) ?>" data-space-between-desktop="<?php echo esc_attr($spaceBetween['desktop']) ?>" data-space-between-laptop="<?php echo esc_attr($spaceBetween['laptop']) ?>" data-space-between-tab="<?php echo esc_attr($spaceBetween['tab']) ?>" data-space-between-mobile="<?php echo esc_attr($spaceBetween['mobile']) ?>" data-centered-slides="<?php echo esc_attr($centeredSlides ? 'true' : 'false') ?>" data-grab-cursor="<?php echo esc_attr($grabCursor ? 'true' : 'false') ?>" data-loop="<?php echo esc_attr($loop ? 'true' : 'false') ?>" data-autoplay="<?php echo esc_attr($autoplay ? 'true' : 'false') ?>" data-speed="<?php echo esc_attr($speed) ?>" />
    </div>


    <?php return apply_filters('borobazar_slider', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>