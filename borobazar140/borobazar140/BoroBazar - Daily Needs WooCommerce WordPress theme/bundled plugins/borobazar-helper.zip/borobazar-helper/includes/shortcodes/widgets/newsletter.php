<?php

/**
 * ShortCodes For NewsLetter
 *
 *
 * @since   1.0.0
 * @package CGB
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}


add_action('init', 'borobazar_newsletter');

function borobazar_newsletter()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/borobazar-newsletter',
            array(
                'editor_script'     => 'borobazar_blocks-cgb-block-js',
                'render_callback'   => 'borobazar_newsletter_callback',
                'attributes'        => array(
                    'title'         => array(
                        'type'      => 'string',
                        'default'   => esc_html__('Our Newsletter', 'borobazar-helper'),
                    ),
                    'content'       => array(
                        'type'      => 'string',
                        'default'   => esc_html__('Subscribe to our newsletter and we will inform you about newest directory and promotions', 'borobazar-helper'),
                    ),
                    'newsLetterLink'    => array(
                        'type'      => 'string',
                        'default'   => '#',
                    ),
                )
            )
        );
    }
}

function borobazar_newsletter_callback($attributes, $content)
{
    ob_start();
    $output = $title = $content = $newsLetterLink = '';
    $title = !empty($attributes['title']) ? $attributes['title'] : '';
    $content = !empty($attributes['content']) ? $attributes['content'] : '';
    $newsLetterLink = !empty($attributes['newsLetterLink']) ? $attributes['newsLetterLink'] : '';
    $allowedHTML = wp_kses_allowed_html('post');
?>
    <div class="borobazar-footer-newsletter">
        <?php if (empty($title) && empty($content) && empty($newsLetterLink)) {  ?>
            <div class="borobazar-footer-newsletter-default">
                <?php echo esc_html__('Newsletter Block is loaded...configure the data from inspector panel', 'borobazar-helper'); ?>
            </div>
        <?php  } ?>
        <?php if (!empty($title)) { ?>
            <h3 class="borobazar-footer-newsletter-title text-[15px] sm:text-base 3xl:text-[17px] mt-0 mb-3 sm:mb-4 md:mb-5 3xl:mb-6"><?php echo esc_attr($title); ?></h3>
        <?php  } ?>
        <?php if (!empty($content)) { ?>
            <div class="borobazar-footer-newsletter-content leading-loose mb-5 sm:mb-6">
                <?php echo wp_kses($content, $allowedHTML); ?>
            </div>
        <?php  } ?>
        <?php if (!empty($newsLetterLink)) { ?>
            <form action="<?php echo esc_url($newsLetterLink) ?>" method="post" id="borobazar-footer-newsletter-form-id" name="borobazar-footer-newsletter-form-name" class="borobazar-footer-newsletter-form relative" target="_blank">
                <input type="email" value="" name="EMAIL" placeholder="<?php echo esc_html__('Email Address', 'borobazar-helper') ?>" class="borobazar-footer-newsletter-form w-full" required>
                <button type="submit" class="borobazar-footer-newsletter-btn absolute top-0 right-0 h-full flex items-center justify-center w-12 bg-transparent text-brand" aria-label="<?php echo esc_attr__('Send', 'borobazar-helper'); ?>">
                    <svg class="borobazar-rtl-rotate" width="18" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18.809 7.21623L2.67252 0.520529C1.99272 0.23842 1.22471 0.362521 0.668264 0.84424C0.111818 1.32604 -0.120916 2.06838 0.0609589 2.78154L1.49725 8.41404H8.52951C8.85311 8.41404 9.11549 8.67639 9.11549 9.00002C9.11549 9.32362 8.85315 9.586 8.52951 9.586H1.49725L0.0609589 15.2185C-0.120916 15.9317 0.111779 16.674 0.668264 17.1558C1.22584 17.6385 1.99393 17.761 2.67256 17.4795L18.809 10.7838C19.5437 10.479 20.0001 9.79545 20.0001 9.00002C20.0001 8.20459 19.5437 7.52104 18.809 7.21623Z" fill="currentColor" />
                    </svg>
                </button>
            </form>
        <?php  } ?>
    </div>
    <?php return apply_filters('borobazar_newsletter', ob_get_clean(), $attributes, $content); ?>
<?php } ?>