<?php

/**
 * ShortCodes For App block.
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazarCallToActionBlock');

function borobazarCallToActionBlock()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/call-to-action-block',
            [
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazarCallToActionBlockCallback',
                'attributes' => [
                    'paddingTop' => [
                        'type' => 'object',
                        'default' => [
                            'desktop' => 0,
                            'laptop' => 0,
                            'tab' => 0,
                            'mobile' => 0,
                        ],
                    ],
                    'paddingRight' => [
                        'type' => 'object',
                        'default' => [
                            'desktop' => 0,
                            'laptop' => 0,
                            'tab' => 0,
                            'mobile' => 0,
                        ],
                    ],
                    'paddingBottom' => [
                        'type' => 'object',
                        'default' => [
                            'desktop' => 0,
                            'laptop' => 0,
                            'tab' => 0,
                            'mobile' => 0,
                        ],
                    ],
                    'paddingLeft' => [
                        'type' => 'object',
                        'default' => [
                            'desktop' => 0,
                            'laptop' => 0,
                            'tab' => 0,
                            'mobile' => 0,
                        ],
                    ],
                    'title' => [
                        'type' => 'string',
                        'default' => 'Make your online shop easier with our mobile app',
                    ],
                    'description' => [
                        'type' => 'string',
                        'default' => 'We offers high-quality films and the best documentary selection, and the ability to browse alphabetically and by genre',
                    ],
                    'ctaButton' => [
                        'type' => 'object',
                        'default' => [
                            'url' => '',
                            'opensInNewTab' => false,
                        ],
                    ],
                    'ctaButtonText' => [
                        'type' => 'string',
                        'default' => 'Order More',
                    ],
                    'titleColor' => [
                        'type' => 'string',
                        'default' => '#000',
                    ],
                    'descriptionColor' => [
                        'type' => 'string',
                        'default' => '#808080',
                    ],
                    'backgroundColor' => [
                        'type' => 'string',
                        'default' => '#f2f2f2',
                    ],
                    'backgroundImage' => [
                        'type' => 'string',
                        'default' => '',
                    ],
                    'backgroundPosition' => [
                        'type' => 'string',
                        'default' => 'right top',
                    ],
                    'backgroundRepeat' => [
                        'type' => 'boolean',
                        'default' => false,
                    ],
                    'fixedBackground' => [
                        'type' => 'boolean',
                        'default' => false,
                    ],
                    'backgroundSize' => [
                        'type' => 'string',
                        'default' => 'contain',
                    ],
                    'fullWidth' => [
                        'type' => 'boolean',
                        'default' => false,
                    ],
                ],
            ]
        );
    }
}

function borobazarCallToActionBlockCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $padding = getBoroBazarPaddingStyles($attributes);
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    $backgroundStyles = '';
    $backgroundStyles .= 'background-color:' . $backgroundColor . ';';
    // if ($backgroundImage) {
    //     $backgroundStyles .= 'background-image:' . 'url(' . $backgroundImage . ');';
    //     $backgroundStyles .= 'background-size:' . $backgroundSize . ';';
    //     $fixedBackground ? $backgroundStyles .= 'background-attachment: fixed;' : '';
    //     $backgroundRepeat ? $backgroundStyles .= 'background-repeat: repeat;' : $backgroundStyles .= 'background-repeat: no-repeat;';
    //     $backgroundStyles .= 'background-position:' . $backgroundPosition . ';';
    // } 
?>

    <div class="borobazar-block-spacing-wrapper borobazar-cta-block <?php echo esc_attr($fullWidth ? 'borobazar-full-width-block' : ''); ?> <?php echo esc_attr($customClass); ?>" style="<?php echo esc_attr($padding); ?>">
        <div class="flex flex-col-reverse md:flex-row lg:grid lg:grid-cols-2 relative rounded-[30px]" style="<?php echo esc_attr($backgroundStyles); ?>">
            <div class="relative text-center md:text-left px-4 sm:px-12 md:px-8 lg:px-12 xl:px-20 3xl:px-28 4xl:pr-36 4xl:pl-40 py-10 sm:py-12 md:py-8 lg:py-12 xl:py-18 4xl:py-20">
                <h2 class="text-xl sm:text-2xl lg:text-3xl xl:text-[35px] 2xl:text-[40px] 4xl:text-[42px] font-bold mt-0 mb-4 xl:mb-5 leading-snug sm:leading-snug lg:leading-snug xl:leading-snug -tracking-[0.2px]" style="color: <?php echo esc_attr($titleColor); ?>"><?php echo wp_kses($title, $allowedHTML); ?></h2>
                <div class="text-md lg:text-base leading-loose lg:leading-loose hide-br-mobile max-w-sm 2xl:max-w-lg" style="color: <?php echo esc_attr($descriptionColor); ?>">
                    <?php echo wp_kses($description, $allowedHTML); ?>
                </div>

                <?php if ($ctaButton['url']) { ?>
                    <div class="flex justify-center md:justify-start items-center mt-5 lg:mt-8">
                        <!-- App store button -->
                        <?php if ($ctaButton['url']) { ?>
                            <?php if ($ctaButton['opensInNewTab']) { ?>
                                <a class="grid grid-cols-[repeat(2,max-content)] gap-2.5 items-center justify-center transition-all bg-brand text-white text-base font-semibold px-8 py-4 lg:py-5 rounded-full no-underline -translate-y-0 hover:-translate-y-1 hover:text-white focus:text-white" href="" target="_blank" rel="noopener noreferrer">
                                    <?php echo esc_attr($ctaButtonText); ?>
                                    <svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg" class="inline-flex borobazar-rtl-rotate">
                                        <path d="M9.03003 1.62305L15.7681 8.36109L9.03003 15.0991" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M14.8322 8.36133H1.16895" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            <?php } else { ?>
                                <a class="grid grid-cols-[repeat(2,max-content)] gap-2.5 items-center justify-center transition-all bg-brand text-white text-base font-semibold px-8 py-4 lg:py-5 rounded-full no-underline -translate-y-0 hover:-translate-y-1 hover:text-white focus:text-white" href="<?php echo esc_url($ctaButton['url']); ?>">
                                    <?php echo esc_attr($ctaButtonText); ?>
                                    <svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg" class="inline-flex borobazar-rtl-rotate">
                                        <path d="M9.03003 1.62305L15.7681 8.36109L9.03003 15.0991" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        <path d="M14.8322 8.36133H1.16895" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            <?php } ?>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
            <figure class="my-0 flex items-start ml-auto -mt-14 md:-mt-7 lg:-mt-20 xl:-mt-18 4xl:-mt-18 max-w-xl 4xl:mr-48">
                <img src="<?php echo $backgroundImage; ?>" alt="">
            </figure>
        </div>
    </div>


    <?php return apply_filters('borobazar_call_to_action_block', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>