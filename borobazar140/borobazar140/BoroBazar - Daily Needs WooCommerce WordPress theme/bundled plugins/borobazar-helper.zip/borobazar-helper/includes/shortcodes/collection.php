<?php

/**
 * ShortCodes For rnbBanner
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazarCollection');


function borobazarCollection()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/collections-block',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazarCollectionCallback',
                'attributes'   => array(
                    'paddingTop'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingRight'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingBottom'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingLeft'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'template'    => array(
                        'type'      => 'string',
                        'default'   =>  'default'
                    ),
                    'collectionItems'    => array(
                        'type' => 'array',
                        'default' => [
                            [
                                'image'              => "",
                                'url'                => "",
                                'opensInNewTab'      => false,
                                'title'              => esc_html__("Title", "borobazar-helper"),
                                'description'        => esc_html__("Description", "borobazar-helper"),
                                'button'             => esc_html__("Explore", "borobazar-helper"),
                                'overlayOpacity'     => 0,
                                'overlay'            => "#000000",
                                'backgroundPosition' => "50% 50%",
                                'bgColor'            => "#fff",
                                'titleColor'         => "#000",
                                'descriptionColor'   => "#808080",
                                'buttonColor'        => "#02b290",
                                'buttonHoverColor'   => "#01a585",
                            ],
                        ],
                        'items' => [
                            'type' => 'object',
                        ],
                    ),
                )
            )
        );
    }
}

function borobazarCollectionCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $width = $height = '';
    $allowedHTML = wp_kses_allowed_html('post');
    $padding = getBoroBazarPaddingStyles($attributes);
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }
    $unique_id = uniqid();

?>

    <div class="borobazar-block-spacing-wrapper borobazar-collection-block <?php echo esc_attr($customClass) ?>" style="<?php echo esc_attr($padding) ?>">
        <div class="swiper borobazar-collection-slider" data-template="<?php echo esc_attr($template) ?>" id="collection-slider-<?php echo esc_attr($unique_id); ?>">
            <div class="swiper-wrapper -mb-1 md:-mb-0">
                <?php foreach ($collectionItems as $key => $item) {

                    $image              = isset($item['image']) ? $item['image']                      : '';
                    $url                = isset($item['url']) ? $item['url']                          : '';
                    $newTab             = isset($item['opensInNewTab']) ? $item['opensInNewTab']      : '';
                    $title              = isset($item['title']) ? $item['title']                      : '';
                    $description        = isset($item['description']) ? $item['description']          : '';
                    $button             = isset($item['button']) ? $item['button']                    : '';
                    $bgColor            = isset($item['bgColor']) ? $item['bgColor']                  : '';
                    $titleColor         = isset($item['titleColor']) ? $item['titleColor']            : '';
                    $descriptionColor   = isset($item['descriptionColor']) ? $item['descriptionColor'] : '';
                    $buttonColor        = isset($item['buttonColor']) ? $item['buttonColor']          : '';
                    $buttonHoverColor   = isset($item['buttonHoverColor']) ? $item['buttonHoverColor'] : '';
                    $overlay            = isset($item['overlay']) ? $item['overlay']                  : '';
                    $overlayOpacity     = isset($item['overlayOpacity']) ? $item['overlayOpacity']    : '';
                    $backgroundPosition = isset($item['backgroundPosition']) ? $item['backgroundPosition'] : '';

                    if (!empty($image)) {
                        if (attachment_url_to_postid($image) === 0) {
                            $width = 442;
                            $height = 288;
                        } else {
                            $image_id = attachment_url_to_postid($image);
                            $image_attributes = wp_get_attachment_image_src($image_id, "large");
                            $width = !empty($image_attributes) ? $image_attributes['1'] : 442;
                            $height = !empty($image_attributes) ? $image_attributes['2'] : 288;
                        }
                    }

                ?>
                    <div class="swiper-slide py-1 h-auto">
                        <?php if ($template == 'default') { ?>
                            <div class="borobazar-collection-item relative rounded shadow-product h-full overflow-hidden mouse-move-effect" style="background: <?php echo esc_attr($bgColor) ?>">
                                <?php if ($newTab) { ?>
                                    <a class="no-underline" href="<?php echo esc_url($url) ?>" target="_blank" rel="noopener noreferrer">
                                        <div class="borobazar-image-fade-in h-52 lg:h-48 xl:h-56 4xl:h-72 overflow-hidden mouse-move-effect-scale">
                                            <img class="w-full h-full object-cover rounded-none opacity-0 mouse-move-effect-el" width="<?php echo esc_attr($width); ?>" height="<?php echo esc_attr($height); ?>" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("collection image", "borobazar-helper") ?>" style="--d: 18; border-radius: 0; object-position: <?php echo esc_attr($backgroundPosition) ?>">
                                        </div>
                                        <div class="p-5 4xl:p-6">
                                            <div class="m-0 text-base 4xl:text-lg font-semibold" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></div>
                                            <div class="text-sm 4xl:text-base mt-2 4xl:mt-2.5" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?></div>
                                        </div>
                                    </a>
                                <?php } else { ?>
                                    <a class="no-underline" href="<?php echo esc_url($url) ?>">
                                        <div class="borobazar-image-fade-in h-52 lg:h-48 xl:h-56 4xl:h-72 overflow-hidden mouse-move-effect-scale">
                                            <img class="w-full h-full object-cover rounded-none opacity-0 mouse-move-effect-el" src="<?php echo esc_url($image) ?>" width="<?php echo esc_attr($width); ?>" height="<?php echo esc_attr($height); ?>" alt="<?php echo esc_attr__("collection image", "borobazar-helper") ?>" style="--d: 18; border-radius: 0; object-position: <?php echo esc_attr($backgroundPosition) ?>">
                                        </div>
                                        <div class="p-5 4xl:p-6">
                                            <div class="m-0 text-base 4xl:text-lg font-semibold" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></div>
                                            <div class="text-sm 4xl:text-base mt-2 4xl:mt-2.5" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?></div>
                                        </div>
                                    </a>
                                <?php } ?>
                            </div>
                        <?php } else { ?>
                            <div class="borobazar-collection-item relative rounded shadow-product h-full overflow-hidden flex items-center mouse-move-effect" style="background: <?php echo esc_attr($bgColor) ?>">
                                <div class="borobazar-image-fade-in absolute w-full h-full inset-0 mouse-move-effect-scale">
                                    <img class="w-full h-full object-cover rounded-none opacity-0 mouse-move-effect-el" src="<?php echo esc_url($image) ?>" width="<?php echo esc_attr($width); ?>" height="<?php echo esc_attr($height); ?>" alt="<?php echo esc_attr__("collection image", "borobazar-helper") ?>" style="--d: 25; border-radius: 0; object-position: <?php echo esc_attr($backgroundPosition) ?>">
                                </div>
                                <div class="absolute w-full h-full inset-0" style="background: <?php echo esc_attr($overlay) ?>; opacity: <?php echo esc_attr($overlayOpacity / 100) ?>"></div>
                                <div class="relative px-6 sm:px-8 py-10 sm:py-16">
                                    <h3 class="m-0 text-xl sm:text-3xl font-bold leading-snug sm:leading-snug" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h3>
                                    <div class="mt-2.5 sm:mt-4 leading-relaxed" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?></div>
                                    <?php if ($newTab) { ?>
                                        <a class="collection-button inline-flex text-xs sm:text-sm text-white font-semibold sm:min-h-11 py-3 px-5 rounded mt-4 sm:mt-6 box-border no-underline transition-all hover:text-white" href="<?php echo esc_url($url) ?>" style="--bg-color: <?php echo esc_attr($buttonColor) ?>; --hover-color: <?php echo esc_attr($buttonHoverColor) ?>;" target="_blank" rel="noopener noreferrer"><?php echo wp_kses($button, $allowedHTML); ?></a>
                                    <?php } else { ?>
                                        <a class="collection-button inline-flex text-xs sm:text-sm text-white font-semibold sm:min-h-11 py-3 px-5 rounded mt-4 sm:mt-6 box-border no-underline transition-all hover:text-white" href="<?php echo esc_url($url) ?>" style="--bg-color: <?php echo esc_attr($buttonColor) ?>; --hover-color: <?php echo esc_attr($buttonHoverColor) ?>;"><?php echo wp_kses($button, $allowedHTML); ?></a>
                                    <?php } ?>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
            <div class='borobazar-slider-next-button absolute top-1/2 right-1.5 md:right-9 bg-white w-9 md:w-13 h-9 md:h-13 rounded-full z-1 hidden md:flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white'>
                <svg class="w-2 md:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M110.841,12.005l-8.978-8.979a1.316,1.316,0,0,1,0-1.856l.787-.786a1.315,1.315,0,0,1,1.857,0l10.69,10.69a1.325,1.325,0,0,1,0,1.863l-10.68,10.68a1.315,1.315,0,0,1-1.857,0l-.787-.786a1.314,1.314,0,0,1,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>
            <div class='borobazar-slider-prev-button absolute top-1/2 left-1.5 md:left-9 bg-white w-9 md:w-13 h-9 md:h-13 rounded-full z-1 hidden md:flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white'>
                <svg class="w-2 md:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M106.218,12.005,115.2,3.026a1.316,1.316,0,0,0,0-1.856l-.787-.786a1.315,1.315,0,0,0-1.857,0l-10.69,10.69a1.325,1.325,0,0,0,0,1.863l10.68,10.68a1.315,1.315,0,0,0,1.857,0l.787-.786a1.314,1.314,0,0,0,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>

            <div class="swiper-scrollbar slider-mobile-scrollbar"></div>
        </div>
    </div>


    <?php return apply_filters('borobazar_collection', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>