<?php

/**
 *
 * ShortCodes For Store Map
 *
 * @since   1.0.0
 *
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazar_store_map');

function borobazar_store_map()
{
    if (function_exists('register_block_type')) {
        register_block_type('borobazar-blocks/borobazar-store-map', [
            'editor_script' => 'borobazar_blocks-cgb-block-js',
            'render_callback' => 'borobazar_store_map_callback',
            'attributes' => [
                'theme' => [
                    'type'    => "string",
                    'default' => "silver",
                ],
                'marker' => [
                    'type'    => "string",
                    'default' => BOROBAZAR_HELPER_ASSETS . 'global/images/map-marker.svg',
                ],
                'markerAnimation' => [
                    'type'    => "boolean",
                    'default' => true,
                ],
                'height'    => array(
                    'type'      => 'object',
                    'default'     =>  [
                        'desktop' => 420,
                        'laptop'  => 320,
                        'tab'     => 260,
                        'mobile'  => 180
                    ],
                ),
                'locationData' => [
                    'type' => 'object',
                    'default' => [
                        'address' => '',
                        'coordinate' => ['lat' => '40.7127753', 'lng' => '-74.0059728'],
                    ],
                ],
                'fullWidth' => [
                    'type'    => "boolean",
                    'default' => false,
                ],
            ],
        ]);
    }
}

function borobazar_store_map_callback($attributes, $content)
{
    ob_start();
    extract($attributes);

    $coordinate = isset($attributes['locationData']) ? $attributes['locationData'] : '';
    $latitude   = isset($coordinate['coordinate']['lat']) ? $coordinate['coordinate']['lat'] : '';
    $longitude  = isset($coordinate['coordinate']['lng']) ? $coordinate['coordinate']['lng'] : '';
    $mapHeight  = getBoroBazarHeightStyles($attributes);
    // merge custom & alignment class
    $customClass = isset($className) ? $className . ' ' : ' ';
    $customClass .= isset($markerAnimation) && $markerAnimation ? 'borobazar-enable-marker-animation ' : 'borobazar-disable-marker-animation ';

    // $googleMapSettings = 'false';
    $googleMap = false;
    if (class_exists('Load_Google_Map')) {
        $googleMapSettings = get_option('googlemap_settings', true);
        if (isset($googleMapSettings)) {
            if (isset($googleMapSettings['googlemap_enable']) && $googleMapSettings['googlemap_enable'] === 'enable' && isset($googleMapSettings['googlemap_api_key']) && $googleMapSettings['googlemap_api_key'] !== '') {
                $googleMap = true;
            }
        }
    }
?>

    <?php if ($googleMap === true) { ?>
        <div class="borobazar-store-map <?php echo esc_attr($fullWidth ? 'borobazar-full-width-block' : '') ?> <?php echo esc_attr($customClass); ?> ">
            <div class="borobazar-store-map-wrapper">
                <div id="borobazarStoreMap" class="borobazarStoreMap borobazar-block-height-wrapper bg-base <?php echo esc_attr($markerAnimation ? 'borobazar-marker-animation-off' : ''); ?>" data-theme="<?php echo esc_attr($theme); ?>" data-latitude="<?php echo esc_attr($latitude); ?>" data-longitude="<?php echo esc_attr($longitude); ?>" data-marker="<?php echo esc_attr($marker) ?>" style="<?php echo esc_attr($mapHeight); ?>">
                </div>
            </div>
        </div>
    <?php } else { ?>
        <div class="h-28 grid place-content-center m-4 p-4 rounded-md md:text-base border border-red-500">
            <?php echo esc_html__('Please install and activate our Google Map Loader plugin, and configure it.', 'borobazar-helper'); ?>
        </div>
    <?php } ?>

    <?php return apply_filters('borobazar_store_map', ob_get_clean(), $attributes, $content); ?>

<?php
} ?>