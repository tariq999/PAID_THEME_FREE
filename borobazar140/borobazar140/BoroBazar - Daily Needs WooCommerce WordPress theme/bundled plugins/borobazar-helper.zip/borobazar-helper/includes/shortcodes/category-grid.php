<?php

/**
 * ShortCodes For Category Grid.
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

use BoroBazarHelper\Classes;
use BoroBazarHelper\Front\Shortcodes;
use BoroBazarHelper\Traits\BlockPostData;

add_action('init', 'borobazarProductCategoryGrid');

function borobazarProductCategoryGrid()
{
    if (function_exists('register_block_type')) {
        register_block_type('borobazar-blocks/category-grid', [
            'editor_script' => 'if-gutenberg-block-scripts',
            'render_callback' => 'borobazarProductCategoryGridCallback',
            'attributes' => [
                'categoryOrderBy' => [
                    'type' => 'string',
                    'default' => 'menu_order',
                ],
                'categoryOrder' => [
                    'type' => 'string',
                    'default' => 'ASC',
                ],
                'categoryTemplate' => [
                    'type' => 'string',
                    'default' => 'sirius',
                ],
                'enableSubcategory' => [
                    'type' => 'boolean',
                    'default' => false,
                ],
                'showEmptyCategory' => [
                    'type' => 'boolean',
                    'default' => false,
                ],
                'marginTop' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'marginRight' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'marginBottom' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'marginLeft' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingTop' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingRight' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingBottom' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingLeft' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
            ],
        ]);
    }
}

function borobazarProductCategoryGridCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }
    $padding = Shortcodes::getIFPaddingStyles($attributes);
    $margin = getBoroBazarMarginStyles($attributes);

    $showEmptyCategory = false;
    if ($attributes['showEmptyCategory'] === false) {
        $showEmptyCategory = false;
    } else {
        $showEmptyCategory = true;
    }

    $transfer_data = new Classes();
    $product_terms = BlockPostData::getCategoriesByProducts($attributes);
    // $product_terms = ProductTrait::getCategoriesByProducts($attributes);

    $unique_id = uniqid();

?>

    <div class="borobazar-block-spacing-wrapper borobazar-block-spacing-margin-wrapper borobazar-category-block <?php echo esc_attr($customClass); ?>" style="<?php echo esc_attr($padding); ?> <?php echo esc_attr($margin); ?>">
        <?php if (class_exists('WooCommerce')) { ?>
            <div class="borobazar-product-category-slider-wrapper <?php echo esc_attr($categoryTemplate); ?>">
                <div id="product-category-slider-<?php echo esc_attr($categoryTemplate) ?>" class="swiper borobazar-product-category-slider" data-template="<?php echo esc_attr($categoryTemplate) ?>">
                    <div class="swiper-wrapper">
                        <?php if (!empty($product_terms)) {
                            foreach ($product_terms as $terms) {
                                $args = [
                                    'blockArgs' => $attributes,
                                    'category' => $terms['full'],
                                    'image_url' => $terms['image_url'],
                                    'term_url' => $terms['term_url'],
                                    'placeholderImage' => BOROBAZAR_HELPER_ASSETS . '/client/images/placeholder-icon.svg',
                                ]; ?>
                                <div class="swiper-slide">
                                    <?php switch ($categoryTemplate) {
                                        case 'sirius':
                                            $transfer_data->borobazar_get_template_part('category-grid/' . $categoryTemplate . '.php', $args);
                                            break;

                                        case 'vega':
                                            $transfer_data->borobazar_get_template_part('category-grid/' . $categoryTemplate . '.php', $args);
                                            break;

                                        case 'rigel':
                                            $transfer_data->borobazar_get_template_part('category-grid/' . $categoryTemplate . '.php', $args);
                                            break;

                                        default:
                                            $transfer_data->borobazar_get_template_part('category-grid/sirius.php', $args);
                                            break;
                                    } ?>
                                </div>
                        <?php   }
                        } ?>
                    </div>
                    <div class='borobazar-slider-next-button absolute top-1/2 right-1.5 md:right-9 bg-white w-9 md:w-13 h-9 md:h-13 rounded-full z-1 hidden md:flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white'>
                        <svg class="w-2 md:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                            <path d="M110.841,12.005l-8.978-8.979a1.316,1.316,0,0,1,0-1.856l.787-.786a1.315,1.315,0,0,1,1.857,0l10.69,10.69a1.325,1.325,0,0,1,0,1.863l-10.68,10.68a1.315,1.315,0,0,1-1.857,0l-.787-.786a1.314,1.314,0,0,1,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                        </svg>
                    </div>
                    <div class='borobazar-slider-prev-button absolute top-1/2 left-1.5 md:left-9 bg-white w-9 md:w-13 h-9 md:h-13 rounded-full z-1 hidden md:flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white'>
                        <svg class="w-2 md:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                            <path d="M106.218,12.005,115.2,3.026a1.316,1.316,0,0,0,0-1.856l-.787-.786a1.315,1.315,0,0,0-1.857,0l-10.69,10.69a1.325,1.325,0,0,0,0,1.863l10.68,10.68a1.315,1.315,0,0,0,1.857,0l.787-.786a1.314,1.314,0,0,0,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                        </svg>
                    </div>

                    <div class="swiper-scrollbar slider-mobile-scrollbar"></div>
                </div>
            </div>
        <?php } else { ?>
            <p class="borobazar-woo-not-found">
                <?php echo esc_html__('Please install WooCommerce plugin first.', 'borobazar-helper'); ?>
            </p>
        <?php } ?>
    </div>

    <?php return apply_filters('borobazar_category_grid', ob_get_clean(), $attributes, $content); ?>

<?php
} ?>