<?php

/**
 * ShortCodes For Products.
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

use BoroBazarHelper\Classes;
use BoroBazarHelper\Traits\BlockPostData;

add_action('init', 'borobazarSearch');

function borobazarSearch()
{
    if (function_exists('register_block_type')) {
        register_block_type('borobazar-blocks/borobazar-search-block', [
            'editor_script'         => 'if-gutenberg-block-scripts',
            'render_callback'       => 'borobazarSearchCallback',
            'attributes'            => [
                'paddingTop'        => [
                    'type'          => 'object',
                    'default'       => [
                        'desktop'   => 0,
                        'laptop'    => 0,
                        'tab'       => 0,
                        'mobile'    => 0,
                    ],
                ],
                'paddingRight'      => [
                    'type'          => 'object',
                    'default'       => [
                        'desktop'   => 0,
                        'laptop'    => 0,
                        'tab'       => 0,
                        'mobile'    => 0,
                    ],
                ],
                'paddingBottom'     => [
                    'type'          => 'object',
                    'default'       => [
                        'desktop'   => 0,
                        'laptop'    => 0,
                        'tab'       => 0,
                        'mobile'    => 0,
                    ],
                ],
                'paddingLeft'       => [
                    'type'          => 'object',
                    'default'       => [
                        'desktop'   => 0,
                        'laptop'    => 0,
                        'tab'       => 0,
                        'mobile'    => 0,
                    ],
                ],
                'categoryOrderBy'   => [
                    'type'          => 'string',
                    'default'       => 'menu_order',
                ],
                'categoryOrder'     => [
                    'type'          => 'string',
                    'default'       => 'ASC',
                ],
                'showEmptyCategory' => [
                    'type'          => 'boolean',
                    'default'       => false,
                ],
                'enableSubcategory' => [
                    'type'          => 'boolean',
                    'default'       => false,
                ],
                'searchedTaxonomoy' => [
                    'type'          => 'string',
                    'default'       => 'product_cat',
                ],
            ],
        ]);
    }
}

function borobazarSearchCallback($attributes, $content)
{
    ob_start();
    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = $layoutClass = $padding = $search_field_params_name = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }
    $padding = getBoroBazarPaddingStyles($attributes);

    $defaultSortBy = '';
    if (isset($_GET['order_by']) && !empty($_GET['order_by'])) {
        $defaultSortBy = $_GET['order_by'];
    }

    $transfer_data = new Classes();
    if (!empty($attributes['searchedTaxonomoy']) && $attributes['searchedTaxonomoy'] !== 'product_cat') {
        $product_taxonomies = BlockPostData::getTaxonomiesByProducts($attributes, $attributes['searchedTaxonomoy']);
        switch ($attributes['searchedTaxonomoy']) {
            case 'borobazar_product_brands':
                $search_field_params_name = 'product-brand[]';
                break;

            case 'borobazar_product_price_ranges':
                $search_field_params_name = 'product-price[]';
                break;

            case 'borobazar_product_genre':
                $search_field_params_name = 'product-genre[]';
                break;

            case 'product_tag':
                $search_field_params_name = 'product-tag[]';
                break;

            default:
                $search_field_params_name = $attributes['searchedTaxonomoy'] . '[]';
                break;
        }
    } else {
        $product_taxonomies = BlockPostData::getCategoriesByProducts($attributes);
        $search_field_params_name = 'product-category[]';
    }

?>


    <?php if (class_exists('WooCommerce')) { ?>


        <div class="borobazar-product-search quick-search borobazar-block-spacing-wrapper relative flex <?php echo esc_attr($customClass); ?>" style="<?php echo esc_attr($padding); ?>">
            <!-- Overlay -->
            <div class="borobazar-filters-close borobazar-filters-overlay fixed invisible opacity-0 w-full h-full inset-0 bg-black bg-opacity-40 z-50 duration-400 ease-linear">
            </div>
            <div class="borobazar-product-search-sidebar fixed lg:position-sticky h-full top-0 left-0 bg-white shrink-0 w-98 lg:w-80 2xl:w-88 max-w-full py-4 md:py-7 lg:py-0 px-4 md:px-7 lg:pl-0 lg:pr-8 z-50 lg:z-auto overflow-x-hidden lg:overflow-auto -translate-x-full lg:translate-x-0 invisible lg:visible duration-500 ease-out-quart">
                <!-- Filter header (only for mobile) -->
                <div class="relative flex items-center text-center text-lg text-main font-semibold lg:hidden mb-8">
                    <span class="borobazar-filters-close mr-3.5 cursor-pointer">
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" class="block" width="21" height="21" viewBox="0 0 31.494 31.494">
                            <path style="fill:#1E201D;" d="M10.273,5.009c0.444-0.444,1.143-0.444,1.587,0c0.429,0.429,0.429,1.143,0,1.571l-8.047,8.047h26.554
	c0.619,0,1.127,0.492,1.127,1.111c0,0.619-0.508,1.127-1.127,1.127H3.813l8.047,8.032c0.429,0.444,0.429,1.159,0,1.587
	c-0.444,0.444-1.143,0.444-1.587,0l-9.952-9.952c-0.429-0.429-0.429-1.143,0-1.571L10.273,5.009z" />
                        </svg>
                    </span>
                    <span><?php echo esc_html__('Categories', 'borobazar-helper'); ?></span>
                </div>

                <form id="borobazar-product-filter-form" action="#">
                    <input type="hidden" class="hidden" name="action" value="borobazar_helper_ajax" />
                    <input type="hidden" class="hidden" name="action_type" value="search" />
                    <input type="hidden" class="hidden product-order-by" name="order_by" value="<?php echo esc_attr($defaultSortBy); ?>" />
                    <input type="hidden" name="product_taxonomy_by" value="<?php echo esc_attr($attributes['searchedTaxonomoy']); ?>" />
                    <input type="hidden" name="text-search" class="border-0 bg-transparent text-gray-300 mr-5 product-text-search" id="text-search-hidden">

                    <div class="borobazar-product-search-filters quick-search-scrollbar radio-search">
                        <?php
                        if (!empty($product_taxonomies)) { ?>
                            <div class="borobazar-parameter-list border border-lighter border-solid rounded-md mb-9" data-limit="15">
                                <?php
                                foreach ($product_taxonomies as $taxonomy) {
                                    $transfer_data->borobazar_get_template_part(
                                        'search/dropdown-radio.php',
                                        [
                                            'attributes'             => $attributes,
                                            'taxonomy_all_data'      => $taxonomy,
                                            'category'               => $taxonomy['full'],
                                            'product_sub_categories' => $taxonomy['child'],
                                            'category_thumb'         => $taxonomy['image_url'],
                                            'allowedHTML'            => $allowedHTML,
                                            'search_field_name'      => $search_field_params_name,
                                            'taxonomy_name'          => $attributes['searchedTaxonomoy'],
                                        ]
                                    );
                                } ?>
                                <span class="borobazar-parameter-load-more cursor-pointer flex items-center justify-center py-4 text-center text-brand text-sm font-medium transition-all hover:text-brand-hover hover:underline">
                                    <?php echo esc_html__('Show more', 'borobazar-helper'); ?>
                                    <svg class="text-lightest ml-1 " width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5.99997 7.42017C5.7849 7.42017 5.56987 7.33805 5.4059 7.17417L0.24617 2.01439C-0.0820566 1.68616 -0.0820566 1.154 0.24617 0.825904C0.574263 0.497811 1.10632 0.497811 1.43457 0.825904L5.99997 5.39156L10.5654 0.826063C10.8936 0.49797 11.4256 0.49797 11.7537 0.826063C12.0821 1.15416 12.0821 1.68632 11.7537 2.01455L6.59404 7.17433C6.42999 7.33824 6.21495 7.42017 5.99997 7.42017Z" fill="currentColor" />
                                    </svg>
                                </span>
                            </div>
                        <?php  }
                        ?>

                    </div>
                </form>

            </div>

            <div class="borobazar-product-search-main relative grow md:h-full w-full lg:w-calc-full-80 2xl:w-calc-full-88">
                <?php echo $content; ?>
            </div>

        </div>
    <?php } ?>

<?php
    return apply_filters('borobazar_search_block', ob_get_clean(), $attributes, $content);
}
