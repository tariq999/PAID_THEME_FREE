<?php

/**
 * ShortCodes For rnbBanner
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazarAccordion');


function borobazarAccordion()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/borobazar-accordion',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazarAccordionCallback',
                'attributes'   => array(
                    'paddingTop'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingRight'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingBottom'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingLeft'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'accordionItems'    => array(
                        'type' => 'array',
                        'default' => [
                            [
                                'title' => "",
                                'description' => "",
                            ],
                        ],
                        'items' => [
                            'type' => 'object',
                        ],
                    ),
                )
            )
        );
    }
}

function borobazarAccordionCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $padding = getBoroBazarPaddingStyles($attributes);
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

?>

    <div class="borobazar-block-spacing-wrapper borobazar-accordion-block <?php echo esc_attr($customClass) ?>" style="<?php echo esc_attr($padding) ?>">
        <?php foreach ($accordionItems as $key => $accordion) {
            $title = isset($accordion['title']) ? $accordion['title'] : '';
            $description = isset($accordion['description']) ? $accordion['description'] : '';
        ?>
            <div class="relative shadow-faq mb-4 last:mb-0 rounded bg-white">
                <div class="borobazar-accordion-title flex items-center justify-between text-sm sm:text-base text-main font-medium p-5 sm:p-6 cursor-pointer">
                    <?php echo wp_kses($title, $allowedHTML) ?>
                    <span class="text-lightest shrink-0 ml-4 duration-300 ease-out-quart">
                        <svg class="w-2 sm:w-auto block" width="9" height="15" viewBox="0 0 9 15" xmlns="http://www.w3.org/2000/svg">
                            <path opacity="0.7" d="M1.02791 0.149879L0.276513 0.901328C0.176172 1.00146 0.12616 1.1168 0.12616 1.2472C0.12616 1.37729 0.176172 1.49258 0.276513 1.59271L6.18341 7.49992L0.276671 13.4069C0.17633 13.507 0.126318 13.6223 0.126318 13.7526C0.126318 13.8829 0.17633 13.9982 0.276671 14.0983L1.02812 14.8496C1.12825 14.95 1.24354 15 1.37384 15C1.50403 15 1.61932 14.9498 1.71945 14.8496L8.72362 7.84564C8.8238 7.74551 8.87387 7.63016 8.87387 7.49992C8.87387 7.36968 8.8238 7.25454 8.72362 7.15447L1.71945 0.149879C1.61927 0.0497484 1.50398 0 1.37384 0C1.24354 0 1.12825 0.0497484 1.02791 0.149879Z" fill="currentColor" />
                        </svg>
                    </span>
                </div>
                <div class="borobazar-accordion-description hidden px-5 sm:px-6 pb-5 sm:pb-6 text-light text-sm sm:text-md leading-relaxed sm:leading-loose"><?php echo wp_kses($description, $allowedHTML); ?></div>
            </div>
        <?php } ?>
    </div>


    <?php return apply_filters('borobazar_accordion', ob_get_clean(), $attributes, $content); ?>
<?php

} ?>