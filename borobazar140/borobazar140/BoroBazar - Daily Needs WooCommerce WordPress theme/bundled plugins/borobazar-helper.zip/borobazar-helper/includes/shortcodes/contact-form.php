<?php

/**
 *
 * ShortCodes For Fetching Contact Form 7 Post
 *
 * @since   1.0.0
 *
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'borobazar_helper_contact_form');

function borobazar_helper_contact_form()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/borobazar-contact-form',
            array(
                'editor_script' => 'if-gutenberg-block-scripts',
                'render_callback' => 'borobazar_helper_contact_form_callback',
                'attributes'      => array(
                    'selectedContactForm' => array(
                        'type'      => 'string',
                        'default'   => '',
                    ),
                )
            )
        );
    }
}

function borobazar_helper_contact_form_callback($attributes, $content)
{
    ob_start();
    $contactFormID = !empty($attributes['selectedContactForm']) ? $attributes['selectedContactForm'] : '';

    if (empty($contactFormID) || $contactFormID === 'none') {
        return ''; // no id = no fun
    }

    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }
?>

    <div class="borobazar-contact-form-wrapper <?php echo esc_attr($customClass) ?>">
        <?php echo do_shortcode('[contact-form-7 id="' . $contactFormID . '"]'); ?>
    </div>

<?php
    return apply_filters('borobazar_contact_form', ob_get_clean(), $attributes, $content);
}
