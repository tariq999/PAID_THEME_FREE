<?php

/**
 * ShortCodes For search banner
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

use BoroBazarHelper\Classes;
use BoroBazarHelper\Front\Shortcodes;

add_action('init', 'borobazarSearchBanner');

function borobazarSearchBanner()
{
    if (function_exists('register_block_type')) {
        register_block_type('borobazar-blocks/search-banner', [
            'editor_script' => 'borobazar_blocks-cgb-block-js',
            'render_callback' => 'borobazarSearchBannerCallback',
            'attributes' => [
                'paddingTop' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingRight' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingBottom' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingLeft' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'title' => [
                    'type' => 'string',
                    'default' => esc_html__("Products Delivered in 90 Minutes", "borobazar-helper"),
                ],
                'description' => [
                    'type' => 'string',
                    'default' =>  esc_html__(
                        "Get your products delivered at your doorsteps all day everyday",
                        "borobazar-helper"
                    ),
                ],
                'searchSuggestions' => [
                    'type' => 'string',
                    'default' => esc_html__("", "borobazar-helper"),
                ],
                'placeholder' => [
                    'type' => 'string',
                    'default' => esc_html__("Search...", "borobazar-helper"),
                ],
                'backgroundType' => [
                    'type' => 'string',
                    'default' => 'image',
                ],
                'sliderImages' => [
                    'type' => 'array',
                    'default' => [
                        [
                            'url' => ''
                        ],
                    ],
                    'items' => [
                        'type' => 'object',
                    ],
                ],
                'backgroundImage' => [
                    'type' => 'string',
                    'default' => '',
                ],
                'searchLayout' => [
                    'type' => 'string',
                    'default' => 'lily',
                ],
                'backgroundColor' => [
                    'type' => 'string',
                    'default' => '#ffffff',
                ],
                'titleColor' => [
                    'type' => 'string',
                    'default' => '#212121',
                ],
                'descriptionColor' => [
                    'type' => 'string',
                    'default' => '#5A5A5A',
                ],
                'searchSuggestionColor' => [
                    'type' => 'string',
                    'default' => '#5a5a5a',
                ],
                'overlay' => [
                    'type' => 'string',
                    'default' => '#000',
                ],
                'overlayOpacity' => [
                    'type' => 'number',
                    'default' => 0,
                ],
                'minHeight' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 400,
                        'laptop' => 400,
                        'tab' => 400,
                        'mobile' => 400,
                    ],
                ],
            ],
        ]);
    }
}


function borobazarSearchBannerCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }
    $padding = Shortcodes::getIFPaddingStyles($attributes);
    $transfer_data = new Classes();

    $templateSlug = isset($attributes) ? $attributes['searchLayout'] : 'lily';
    $templateName = $templateSlug . '.php';

    $styles = '';
    $styles .= 'background-color:' . $backgroundColor . ';';
    $styles .= '--desktop-min-height:' . $minHeight['desktop'] . 'px;';
    $styles .= '--laptop-min-height:' . $minHeight['laptop'] . 'px;';
    $styles .= '--tab-min-height:' . $minHeight['tab'] . 'px;';
    $styles .= '--mobile-min-height:' . $minHeight['mobile'] . 'px;';
    if ($backgroundImage && $backgroundType == 'image') {
        $styles .= 'background-image:' . 'url(' . $backgroundImage . ');';
    }
?>
    <div class="borobazar-block-spacing-wrapper" style="<?php echo esc_attr($padding); ?>">
        <div class="borobazar-search-banner borobazar-min-height-wrapper relative flex items-center justify-center py-14 px-4 overflow-hidden bg-cover bg-center bg-no-repeat <?php echo esc_attr($customClass) ?>" style="<?php echo esc_attr($styles); ?>">
            <?php if ($backgroundType == 'slider') { ?>
                <div class="absolute w-full h-full">
                    <div class="swiper w-full h-full">
                        <div class="swiper-wrapper">
                            <?php foreach ($sliderImages as $key => $value) { ?>
                                <?php $bgImage = isset($value['url']) ? $value['url'] : ''; ?>
                                <div class="swiper-slide">
                                    <div class="borobazar-search-banner-slide w-full h-full bg-cover bg-center bg-no-repeat" style="background-image: url(<?php echo esc_url($bgImage); ?>)"></div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <div class="swiper-pagination"></div>
            <?php } ?>

            <div class="absolute w-full h-full inset-0 z-1" style="background: <?php echo esc_attr($overlay) ?>; opacity: <?php echo esc_attr($overlayOpacity / 100) ?>"></div>

            <div class="text-center relative z-1 max-w-full search-banner-content">
                <h2 class="text-3xl sm:text-4xl xl:text-5xl leading-snug sm:leading-snug xl:leading-snug font-extrabold mt-0 mb-3" style="color: <?php echo esc_attr($titleColor) ?>;"><?php echo wp_kses($title, $allowedHTML); ?></h2>
                <div class="text-md sm:text-base xl:text-lg leading-loose sm:leading-loose xl:leading-loose" style="color: <?php echo esc_attr($descriptionColor) ?>;">
                    <?php echo wp_kses($description, $allowedHTML); ?>
                </div>

                <?php
                $transfer_data->borobazar_get_template_part(
                    'search-banner/' . $templateName,
                    [
                        'attributes'   => $attributes,
                        'allowedHTML'  => $allowedHTML,
                        'templateName' => $templateSlug,
                    ]
                );
                ?>

                <?php if ($attributes['searchSuggestions']) : ?>
                    <p class="mb-0 mt-7 font-medium leading-tight">
                        <?php echo wp_kses($attributes['searchSuggestions'], $allowedHTML) ?>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php return apply_filters('borobazar_search_banner', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>