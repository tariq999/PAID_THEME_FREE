<?php

/**
 * ShortCodes For App block
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazarAppBlock');


function borobazarAppBlock()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/app-block',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazarAppBlockCallback',
                'attributes'   => array(
                    'paddingTop'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingRight'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingBottom'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingLeft'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'title'    => array(
                        'type'      => 'string',
                        'default'   =>  ''
                    ),
                    'description'    => array(
                        'type'      => 'string',
                        'default'   =>  ''
                    ),
                    'appStore'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'url' => "",
                            'opensInNewTab' => false,
                        ],
                    ),
                    'playStore'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'url' => "",
                            'opensInNewTab' => false,
                        ],
                    ),
                    'titleColor' => array(
                        "type" => "string",
                        'default' => "#000",
                    ),
                    'descriptionColor' => array(
                        "type" => "string",
                        'default' => "#808080",
                    ),
                    'backgroundColor' => array(
                        "type" => "string",
                        'default' => "#f2f2f2",
                    ),
                    'backgroundImage' => array(
                        "type" => "string",
                        'default' => "",
                    ),
                    'backgroundPosition' => array(
                        "type" => "string",
                        'default' => "50% 50%",
                    ),
                    'backgroundRepeat' => array(
                        "type" => "boolean",
                        'default' => false,
                    ),
                    'fixedBackground' => array(
                        "type" => "boolean",
                        'default' => false,
                    ),
                    'backgroundSize' => array(
                        "type" => "string",
                        'default' => "cover",
                    ),
                    'overlay' => array(
                        "type" => "string",
                        'default' => "#000",
                    ),
                    'overlayOpacity' => array(
                        "type" => "string",
                        'default' => 0,
                    ),
                    'fullWidth' => array(
                        "type" => "boolean",
                        'default' => false,
                    ),
                )
            )
        );
    }
}

function borobazarAppBlockCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $padding = getBoroBazarPaddingStyles($attributes);
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    $backgroundStyles = '';
    $backgroundStyles .= 'background-color:' . $backgroundColor . ';';
    if ($backgroundImage) {
        $backgroundStyles .= 'background-image:' . 'url(' . $backgroundImage . ');';
        $backgroundStyles .= 'background-size:' . $backgroundSize . ';';
        $fixedBackground ? $backgroundStyles .= 'background-attachment: fixed;' : '';
        $backgroundRepeat ? $backgroundStyles .= 'background-repeat: repeat;' : $backgroundStyles .= 'background-repeat: no-repeat;';
        $backgroundStyles .= 'background-position:' . $backgroundPosition . ';';
    }

?>

    <div class="borobazar-block-spacing-wrapper borobazar-app-block <?php echo esc_attr($fullWidth ? 'borobazar-full-width-block' : '') ?> <?php echo esc_attr($customClass) ?>" style="<?php echo esc_attr($padding) ?>">
        <div class="relative px-4 sm:px-12 md:px-14 lg:px-20 xl:px-28 4xl:px-48 py-10 sm:py-12 md:py-13 lg:py-14 xl:py-18 4xl:py-24" style="<?php echo esc_attr($backgroundStyles) ?>">
            <div class="absolute w-full h-full inset-0" style="background: <?php echo esc_attr($overlay) ?>; opacity: <?php echo esc_attr($overlayOpacity / 100) ?>"></div>
            <div class="relative text-center sm:text-justify">
                <h2 class="text-xl sm:text-2xl lg:text-3xl xl:text-4xl font-bold mt-0 mb-4 xl:mb-5 leading-snug sm:leading-snug lg:leading-snug xl:leading-snug" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h2>
                <div class="text-md lg:text-base leading-loose lg:leading-loose hide-br-mobile" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?></div>

                <?php if ($appStore['url'] || $playStore['url']) { ?>
                    <div class="flex justify-center sm:justify-start items-center mt-7 lg:mt-8">
                        <!-- App store button -->
                        <?php if ($appStore['url']) { ?>
                            <?php if ($appStore['opensInNewTab']) { ?>
                                <a class="mr-4 lg:mr-5 transition-all hover:-translate-y-1" href="<?php echo esc_url($appStore['url']) ?>" target="_blank" rel="noopener noreferrer">
                                    <img class="w-auto h-9 sm:h-11 lg:h-auto block" src="<?php echo esc_url(BOROBAZAR_HELPER_ASSETS . 'global/images/app-store-btn.svg'); ?>" alt="<?php echo esc_html__('App store', 'borobazar-helper') ?>">
                                </a>
                            <?php } else { ?>
                                <a class="mr-4 lg:mr-5 transition-all hover:-translate-y-1" href="<?php echo esc_url($appStore['url']) ?>">
                                    <img class="w-auto h-9 sm:h-11 lg:h-auto block" src="<?php echo esc_url(BOROBAZAR_HELPER_ASSETS . 'global/images/app-store-btn.svg'); ?>" alt="<?php echo esc_html__('App store', 'borobazar-helper') ?>">
                                </a>
                            <?php } ?>
                        <?php } ?>
                        <!-- Play store button -->
                        <?php if ($playStore['url']) { ?>
                            <?php if ($playStore['opensInNewTab']) { ?>
                                <a class="transition-all hover:-translate-y-1" href="<?php echo esc_url($playStore['url']) ?>" target="_blank" rel="noopener noreferrer">
                                    <img class="w-auto h-9 sm:h-11 lg:h-auto block" src="<?php echo esc_url(BOROBAZAR_HELPER_ASSETS . 'global/images/play-store-btn.svg'); ?>" alt="<?php echo esc_html__('Play store', 'borobazar-helper') ?>">
                                </a>
                            <?php } else { ?>
                                <a class="transition-all hover:-translate-y-1" href="<?php echo esc_url($playStore['url']) ?>">
                                    <img class="w-auto h-9 sm:h-11 lg:h-auto block" src="<?php echo esc_url(BOROBAZAR_HELPER_ASSETS . 'global/images/play-store-btn.svg'); ?>" alt="<?php echo esc_html__('Play store', 'borobazar-helper') ?>">
                                </a>
                            <?php } ?>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>


    <?php return apply_filters('borobazar_app_block', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>