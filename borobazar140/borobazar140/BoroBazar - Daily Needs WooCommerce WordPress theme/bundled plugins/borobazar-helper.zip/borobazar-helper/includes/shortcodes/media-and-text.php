<?php

/**
 * ShortCodes For rnbBanner
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazarMediaText');


function borobazarMediaText()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/media-and-text',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazarMediaTextCallback',
                'attributes'   => array(
                    'paddingTop'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingRight'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingBottom'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingLeft'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'title'    => array(
                        'type'      => 'string',
                        'default'   =>  ''
                    ),
                    'description'    => array(
                        'type'      => 'string',
                        'default'   =>  ''
                    ),
                    'slogan'    => array(
                        'type'      => 'string',
                        'default'   =>  ''
                    ),
                    'titleColor'    => array(
                        'type'      => 'string',
                        'default'   =>  '#000'
                    ),
                    'descriptionColor'    => array(
                        'type'      => 'string',
                        'default'   =>  '#4d4d4d'
                    ),
                    'sloganColor'    => array(
                        'type'      => 'string',
                        'default'   =>  '#000'
                    ),
                    'width'    => array(
                        'type'      => 'number',
                        'default'   =>  50
                    ),
                    'verticalAlign'    => array(
                        'type'      => 'string',
                        'default'   =>  'center'
                    ),
                    'textAreaPosition'    => array(
                        'type'      => 'string',
                        'default'   =>  'left'
                    ),
                )
            )
        );
    }
}

function borobazarMediaTextCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $padding = getBoroBazarPaddingStyles($attributes);
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    $alignItems = "";
    $textAreaPadding = "";
    $counterAreaPadding = "";

    //vertical align classNames
    switch ($verticalAlign) {
        case "top":
            $alignItems = "flex-start";
            break;
        case "center":
            $alignItems = "center";
            break;
        case "bottom":
            $alignItems = "flex-end";
            break;

        default:
            $alignItems = "center";
            break;
    }

    //padding classNames
    if ($textAreaPosition == 'left') {
        $textAreaPadding = 'lg:pr-9 xl:pr-11 pb-10 lg:pb-0';
        $counterAreaPadding = 'lg:pl-9 xl:pl-11';
    } else {
        $textAreaPadding = 'lg:pl-9 xl:pl-11';
        $counterAreaPadding = 'lg:pr-9 xl:pr-11 pb-10 lg:pb-0';
    }

?>

    <div class="borobazar-block-spacing-wrapper borobazar-media-and-text <?php echo esc_attr($customClass) ?>" style="<?php echo esc_attr($padding) ?>">

        <div class="flex flex-wrap lg:flex-nowrap" style="align-items: <?php echo esc_attr($alignItems) ?>;">
            <div class="borobazar-mt-text-area <?php echo esc_attr($textAreaPadding) ?>" style="--desktop-width: <?php echo esc_attr($width) ?>%; order: <?php echo esc_attr($textAreaPosition == 'left' ? "0" : "1") ?>">
                <h4 class="text-sm font-bold tracking-wider relative pl-8 mt-0 mb-2 sm:mb-4 before:w-4 before:h-0.5 before:absolute before:top-1/2 before:-translate-y-2/4 before:left-0 before:bg-black before:block" style="color: <?php echo esc_attr($sloganColor) ?>"><?php echo wp_kses($slogan, $allowedHTML); ?></h4>
                <h2 class="text-lg md:text-2xl xl:text-3xl font-extrabold mt-0 mb-4 sm:mb-6 md:leading-normal xl:leading-normal" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h2>
                <div class="text-sm sm:text-md xl:text-base leading-loose" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?></div>
            </div>
            <div class="grow <?php echo esc_attr($counterAreaPadding) ?>">
                <?php echo $content ?>
            </div>
        </div>

    </div>


    <?php return apply_filters('borobazar_media-and-text', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>