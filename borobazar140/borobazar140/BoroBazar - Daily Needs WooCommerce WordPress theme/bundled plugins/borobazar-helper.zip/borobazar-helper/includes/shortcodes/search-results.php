<?php

/**
 * ShortCodes For Products.
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

use BoroBazarHelper\Classes;
use BoroBazarHelper\Front\Shortcodes;

add_action('init', 'borobazarSearchResults');

function borobazarSearchResults()
{
    if (function_exists('register_block_type')) {
        register_block_type('borobazar-blocks/borobazar-search-result', [
            'editor_script'       => 'if-gutenberg-block-scripts',
            'render_callback'     => 'borobazarSearchResultsCallback',
            'attributes'          => [
                'gridTemplate'    => [
                    'type'        => 'string',
                    'default'     => 'grid_alpine',
                ],
                'paddingTop'      => [
                    'type'        => 'object',
                    'default'     => [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0,
                    ],
                ],
                'paddingRight'    => [
                    'type'        => 'object',
                    'default'     => [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0,
                    ],
                ],
                'paddingBottom'   => [
                    'type'        => 'object',
                    'default'     => [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0,
                    ],
                ],
                'paddingLeft'     => [
                    'type'        => 'object',
                    'default'     => [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0,
                    ],
                ],
                'scrollToTop'     => [
                    'type'        => 'boolean',
                    'default'     => false
                ],
            ],
        ]);
    }
}

function borobazarSearchResultsCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = $padding = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    $padding = Shortcodes::getIFPaddingStyles($attributes);

    $gridName = isset($attributes) ? $attributes['gridTemplate'] : 'grid_alpine';
    $templateSlug = !class_exists('SitePress') ? $gridName : $gridName . '_wpml';
    $templateName = $templateSlug . '.php';

    $transfer_data = new Classes();
    $isActiveRedQWooCommerceQuickView = 'false';
    $showQuickView = borobazar_global_option_data('woo_preview_pop_switch', 'on');

    if (class_exists('RedQWooCommerceQuickView')) {
        $isActiveRedQWooCommerceQuickView = 'true';
    }

?>

    <div class="borobazar-products-wrapper borobazar-block-spacing-wrapper  <?php echo esc_attr($scrollToTop ? "borobazar-search-trigger-scroll" : '') ?>" style="<?php echo esc_attr($padding); ?>">
        <div class="flex items-center justify-between mb-5">
            <div class="hidden lg:block products-count text-main font-medium"></div>
            <span class="borobazar-filters-open flex items-center lg:hidden text-main font-medium mr-1.5 cursor-pointer">
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" class="mr-2 block" fill="currentColor" width="14" height="14" viewBox="0 0 512 512">
                    <path d="M490.667,405.333h-56.811C424.619,374.592,396.373,352,362.667,352s-61.931,22.592-71.189,53.333H21.333
			C9.557,405.333,0,414.891,0,426.667S9.557,448,21.333,448h270.144c9.237,30.741,37.483,53.333,71.189,53.333
			s61.931-22.592,71.189-53.333h56.811c11.797,0,21.333-9.557,21.333-21.333S502.464,405.333,490.667,405.333z M362.667,458.667
			c-17.643,0-32-14.357-32-32s14.357-32,32-32s32,14.357,32,32S380.309,458.667,362.667,458.667z" />
                    <path d="M490.667,64h-56.811c-9.259-30.741-37.483-53.333-71.189-53.333S300.736,33.259,291.477,64H21.333
			C9.557,64,0,73.557,0,85.333s9.557,21.333,21.333,21.333h270.144C300.736,137.408,328.96,160,362.667,160
			s61.931-22.592,71.189-53.333h56.811c11.797,0,21.333-9.557,21.333-21.333S502.464,64,490.667,64z M362.667,117.333
			c-17.643,0-32-14.357-32-32c0-17.643,14.357-32,32-32s32,14.357,32,32C394.667,102.976,380.309,117.333,362.667,117.333z" />
                    <path d="M490.667,234.667H220.523c-9.259-30.741-37.483-53.333-71.189-53.333s-61.931,22.592-71.189,53.333H21.333
			C9.557,234.667,0,244.224,0,256c0,11.776,9.557,21.333,21.333,21.333h56.811c9.259,30.741,37.483,53.333,71.189,53.333
			s61.931-22.592,71.189-53.333h270.144c11.797,0,21.333-9.557,21.333-21.333C512,244.224,502.464,234.667,490.667,234.667z
			 M149.333,288c-17.643,0-32-14.357-32-32s14.357-32,32-32c17.643,0,32,14.357,32,32S166.976,288,149.333,288z" />
                </svg>

                <?php echo esc_html__('Filters', 'borobazar-helper'); ?>
            </span>

            <div class="borobazar-products-sorting flex items-center">
                <span class="text-light mr-1.5"><?php echo esc_html__('Sort by:', 'borobazar-helper'); ?></span>


                <div class="borobazar-custom-select">
                    <select name="sortBy" id="sortBy" class="product-sorting">
                        <option value="" selected="selected"><?php echo esc_html__('Sorting Options', 'borobazar-helper'); ?></option>
                        <option value="title"><?php echo esc_html__('Title (A - Z)', 'borobazar-helper'); ?></option>
                        <option value="title-desc"><?php echo esc_html__('Title (Z - A)', 'borobazar-helper'); ?></option>
                        <option value="date-desc"><?php echo esc_html__('Sort by Newest', 'borobazar-helper'); ?></option>
                        <option value="date"><?php echo esc_html__('Sort by Oldest', 'borobazar-helper'); ?></option>
                        <option value="_wc_average_rating-desc"><?php echo esc_html__('Popularity (High to Low)', 'borobazar-helper'); ?></option>
                        <option value="_wc_average_rating"><?php echo esc_html__('Popularity (Low to High)', 'borobazar-helper'); ?></option>
                        <option value="_price-desc"><?php echo esc_html__('Price (High to Low)', 'borobazar-helper'); ?></option>
                        <option value="_price"><?php echo esc_html__('Price (Low to High)', 'borobazar-helper'); ?></option>
                    </select>
                </div>
            </div>
        </div>

        <div id="borobazar-products-grid" class="borobazar-products-grid <?php echo esc_attr($customClass); ?>" style="<?php echo esc_attr($padding); ?>">
            <div class="borobazar-product-search-results transition duration-200">
                <div class="borobazar-product-search-loader w-full h-64 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-16 md:w-20" style="margin: auto;background: rgba(255, 255, 255, 0);" width="80" height="80" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                        <circle cx="50" cy="50" r="34" stroke="#cccccc" stroke-width="2" fill="none"></circle>
                        <circle cx="50" cy="50" r="34" stroke="#212121" stroke-width="4" stroke-linecap="round" fill="none" transform="rotate(55.3041 50 50)">
                            <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1.5384615384615383s" values="0 50 50;180 50 50;720 50 50" keyTimes="0;0.5;1">
                            </animateTransform>
                            <animate attributeName="stroke-dasharray" repeatCount="indefinite" dur="1.5384615384615383s" values="21.362830044410593 192.26547039969535;106.81415022205297 106.81415022205297;21.362830044410593 192.26547039969535" keyTimes="0;0.5;1"></animate>
                        </circle>
                    </svg>
                </div>
            </div>

            <?php
            $transfer_data->borobazar_get_template_part(
                'grid/' . $templateName,
                [
                    'attributes'        => $attributes,
                    'allowedHTML'       => $allowedHTML,
                    'showHiddenProduct' => get_theme_mod('woo_hidden_product_switch', 'off'),
                    'showQuickView'     => $showQuickView,
                    'isActiveRedQWooCommerceQuickView' => $isActiveRedQWooCommerceQuickView,
                ]
            );
            ?>
        </div>
    </div>

<?php
    return apply_filters('borobazar_search_result_block', ob_get_clean(), $attributes, $content);
}
