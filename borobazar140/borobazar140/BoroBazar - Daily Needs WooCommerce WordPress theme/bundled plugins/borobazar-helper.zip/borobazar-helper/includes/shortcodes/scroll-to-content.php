<?php

/**
 * ShortCodes For rnbBanner
 *
 *
 * @since   1.0.0
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit();
}

add_action('init', 'borobazarScrollToContent');


function borobazarScrollToContent()
{
    if (function_exists('register_block_type')) {
        register_block_type(
            'borobazar-blocks/borobazar-scroll-to-content',
            array(
                'editor_script' => 'borobazar_blocks-cgb-block-js',
                'render_callback' => 'borobazarScrollToContentCallback',
                'attributes'   => array(
                    'paddingTop'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingRight'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingBottom'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'paddingLeft'    => array(
                        'type'      => 'object',
                        'default'     =>  [
                            'desktop' => 0,
                            'laptop'  => 0,
                            'tab'     => 0,
                            'mobile'  => 0
                        ],
                    ),
                    'scrollItems'    => array(
                        'type' => 'array',
                        'default' => [
                            [
                                'id' => "",
                                'title' => "",
                                'content' => "",
                            ],
                        ],
                        'items' => [
                            'type' => 'object',
                        ],
                    ),
                )
            )
        );
    }
}

function borobazarScrollToContentCallback($attributes, $content)
{
    ob_start();
    extract($attributes);
    $allowedHTML = wp_kses_allowed_html('post');
    $padding = getBoroBazarPaddingStyles($attributes);
    $customClass = '';
    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }
?>

    <div class="borobazar-block-spacing-wrapper borobazar-scroll-to-content flex-wrap md:flex-nowrap flex <?php echo esc_attr($customClass) ?>" style="<?php echo esc_attr($padding) ?>">
        <div class="borobazar-scroll-to-content-nav hidden md:block md:w-60 lg:w-72 xl:w-80 shrink-0">
            <div class="borobazar-scroll-to-content-list sticky">
                <?php foreach ($scrollItems as $key => $item) {
                    $id = isset($item['id']) ? $item['id'] : '';
                    $title = isset($item['title']) ? $item['title'] : '';
                ?>

                    <a class="relative flex px-4 mb-6 last:mb-0 text-main no-underline leading-snug before:absolute before:h-full before:w-0.5 before:bg-transparent before:top-0 before:left-0 <?php echo esc_attr($key == 0 ? 'text-brand before:bg-brand' : '') ?>" href="#id-<?php echo esc_attr($id) ?>"><?php echo wp_kses($title, $allowedHTML) ?></a>

                <?php } ?>
            </div>
        </div>
        <div class="borobazar-scroll-to-content-content grow md:pl-11 lg:pl-16 xl:pl-20">
            <?php foreach ($scrollItems as $key => $item) {
                $id = isset($item['id']) ? $item['id'] : '';
                $title = isset($item['title']) ? $item['title'] : '';
                $itemContent = isset($item['content']) ? $item['content'] : '';
            ?>

                <div id="id-<?php echo esc_attr($id) ?>" class="borobazar-scroll-to-content-single mb-10 md:mb-14 last:mb-0">
                    <h2 class="text-base md:text-lg font-semibold mt-0 mb-4 md:mb-6 font-body"><?php echo wp_kses($title, $allowedHTML) ?></h2>
                    <div class="leading-loose text-dark"><?php echo wp_kses($itemContent, $allowedHTML); ?></div>
                </div>

            <?php } ?>
        </div>
    </div>


    <?php return apply_filters('borobazar_scroll_to_content', ob_get_clean(), $attributes, $content); ?>
<?php
} ?>