<?php

/**
 * Generate MetaBox.
 */

namespace BoroBazarHelper\Builder;

class GenerateMetaBox
{
    public function __construct($args)
    {
        $this->generateMetabox($args);
    }

    public function generateMetabox($args)
    {
        if (is_array($args) && !empty($args)) {
            foreach ($args as $key => $arg) {
                add_meta_box(
                    $arg['id'],
                    __($arg['name'], 'borobazar-helper'),
                    [$this, 'borobazarRenderMetaBox'],
                    $arg['postType'],
                    'normal',
                    $arg['position'],
                    ['path' => $arg['templatePath']]
                );
            }
        }
    }

    public function borobazarRenderMetaBox($post, $template)
    {
        include_once BOROBAZAR_HELPER_LOCAL_SETTINGS_TEMPLATE_PATH.$template['args']['path'];
    }

    public function borobazarRenderDynamicMetaBox($post, $template)
    {
        require BOROBAZAR_HELPER_LOCAL_SETTINGS_TEMPLATE_PATH.$template['args']['path'];
    }
}
