<?php

/**
 *  MetaBox Saver.
 */

namespace BoroBazarHelper\Builder;

class SaveMetaBox
{
    public function __construct($args)
    {
        $this->generateMetaboxSaver($args);
    }

    public function generateMetaboxSaver($args)
    {
        if (isset($args) && is_array($args)) {
            foreach ($args as $metaArgs) {
                $postType = get_post_type($metaArgs['postId']);
                if ($postType === $metaArgs['postType']) {
                    if (isset($metaArgs['metaFields']) && is_array($metaArgs['metaFields'])) {
                        foreach ($metaArgs['metaFields'] as $key => $metaField) {
                            if (isset($_POST[$metaField])) {
                                $metaValue = $_POST[$metaField];
                                update_post_meta($metaArgs['postId'], $metaField, $metaValue);
                                if (isset($metaArgs['hasIndividual']) && $metaArgs['hasIndividual']) {
                                    if (isset($metaValue) && $metaValue) {
                                        $metaObjectData = json_decode(stripslashes_deep($metaValue), true);
                                        if (isset($metaObjectData) && is_array($metaObjectData)) {
                                            foreach ($metaObjectData as $key => $value) {
                                                update_post_meta($metaArgs['postId'], $key, $value);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}