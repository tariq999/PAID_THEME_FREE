<?php

/**
 * Generate custom post type on request.
 */

namespace BoroBazarHelper\Builder;

use Doctrine\Common\Inflector\Inflector;

class GeneratePostType
{
    protected $config = [
        'name'              => 'custom',
        'postPublic'        => true,
        'publiclyQueryable' => true,
        'showUi'            => true,
        'showInMenu'        => true,
        'showInRest'        => true,
        'rewrite'           => true,
        'hasArchive'        => true,
        'hierarchical'      => true,
        'menuPosition'      => 25,
        'supports'          => [],
        'menuIcon'          => 'dashicons-plus',
    ];

    protected $supports = [
        'title'          => true,
        'editor'         => true,
        'author'         => true,
        'thumbnail'      => true,
        'excerpt'        => false,
        'trackbacks'     => false,
        'customFields'   => false,
        'comments'       => true,
        'revisions'      => true,
        'pageAttributes' => true,
        'postFormats'    =>  true,
    ];

    public function __construct($postTypes)
    {
        $this->generateCustomPost($postTypes);
        add_filter('enter_title_here', [$this, 'borobazarChangeDefaultTitle']);
    }

    public function borobazarChangeDefaultTitle($title)
    {
        $screen = get_current_screen();
        if ('borobazar_post_type' == $screen->post_type || 'borobazar_taxonomy' == $screen->post_type || 'borobazar_term_metabox' == $screen->post_type || 'borobazar_metabox' == $screen->post_type) { // Replace 'post' with the name of the post type you want to use with the new title
            $title .= ' (Required)';
        }

        return $title;
    }

    /**
     * Generate Custom post type.
     *
     * @param array $postTypes
     *
     * @return void
     */
    public function generateCustomPost($postTypes)
    {
        // $inflector = new Inflector();
        $postTypeSupports = [];
        if (!empty($postTypes)) {
            foreach ($postTypes as $postType) {
                $postType = array_merge($this->config, $postType);
                $support = array_merge($this->supports, $postType['supports']);

                $postTypeSupports[] = ($support['title'] ? 'title' : '');
                $postTypeSupports[] = ($support['editor'] ? 'editor' : '');
                $postTypeSupports[] = ($support['author'] ? 'author' : '');
                $postTypeSupports[] = ($support['thumbnail'] ? 'thumbnail' : '');
                $postTypeSupports[] = ($support['excerpt'] ? 'excerpt' : '');
                $postTypeSupports[] = ($support['trackbacks'] ? 'trackbacks' : '');
                $postTypeSupports[] = ($support['customFields'] ? 'custom-fields' : '');
                $postTypeSupports[] = ($support['comments'] ? 'comments' : '');
                $postTypeSupports[] = ($support['revisions'] ? 'revisions' : '');
                $postTypeSupports[] = ($support['pageAttributes'] ? 'page-attributes' : '');
                $postTypeSupports[] = ($support['postFormats'] ? 'post-formats' : '');
                $pluralName = Inflector::pluralize($postType['showName']);
                $singularName = Inflector::singularize($postType['showName']);
                // Post type labels
                $labels = array_merge([
                    'name'               => _x($pluralName, 'post type general name'),
                    'singular_name'      => _x($singularName, 'post type singular name'),
                    'add_new'            => _x('Add New ' . $singularName, $singularName),
                    'add_new_item'       => __('Add New ' . $singularName),
                    'edit_item'          => __('Edit ' . $singularName),
                    'new_item'           => __('New ' . $singularName),
                    'all_items'          => __('All ' . $singularName),
                    'view_item'          => __('View ' . $singularName),
                    'search_items'       => __('Search ' . $singularName),
                    'not_found'          => __('No ' . $singularName . ' found'),
                    'not_found_in_trash' => __('No ' . $singularName . ' found in Trash'),
                    'parent_item_colon'  => '',
                    'menu_name'          => __($pluralName),
                ], isset($postType['label']) ? $postType['label'] : []);

                $args = [
                    'labels'             => $labels,
                    'public'             => (bool) $postType['postPublic'],
                    'publicly_queryable' => (bool) $postType['publiclyQueryable'],
                    'show_ui'            => (bool) $postType['showUi'],
                    'show_in_menu'       => $postType['showInMenu'],
                    'query_var'          => true,
                    'show_in_rest'       => isset($postType['showInRest']) ? $postType['showInRest'] : false,
                    'map_meta_cap'       => true,
                    'rewrite'            => (bool) $postType['rewrite'],
                    'has_archive'        => (bool) $postType['hasArchive'],
                    'hierarchical'       => (bool) $postType['hierarchical'],
                    'menu_position'      => $postType['menuPosition'],
                    'supports'           => $postTypeSupports,
                    'menu_icon'          => $postType['menuIcon'],
                ];

                $postTypeName = str_replace(' ', '_', strtolower($postType['name']));

                // Register post type
                register_post_type($postTypeName, $args);

                $postTypeSupports = [];
            }
        }
    }
}
