<?php

/**
 * Generate custom taxonomy on request.
 */

namespace BoroBazarHelper\Builder;

use Doctrine\Common\Inflector\Inflector;

class GenerateTaxonomy
{
    public function __construct($taxonomies)
    {
        $this->generateCustomTaxonomy($taxonomies);
    }

    /**
     * Generate Custom taxonomy.
     *
     * @param array $taxonomies
     *
     * @return void
     */
    public function generateCustomTaxonomy($taxonomies)
    {
        if (!empty($taxonomies)) {
            foreach ($taxonomies as $taxonomy) {
                $pluralName = Inflector::pluralize($taxonomy['showName']);
                $singularName = Inflector::singularize($taxonomy['showName']);

                $labels = [
                    'name'              => _x($pluralName, 'taxonomy general name'),
                    'singular_name'     => _x($singularName, 'taxonomy singular name'),
                    'search_items'      => __('Search ' . $pluralName),
                    'all_items'         => __('All ' . $pluralName),
                    'parent_item'       => __('Parent ' . $singularName),
                    'parent_item_colon' => __('Parent ' . $singularName . ': '),
                    'edit_item'         => __('Edit ' . $singularName),
                    'update_item'       => __('Update ' . $singularName),
                    'add_new_item'      => __('Add New ' . $singularName),
                    'new_item_name'     => __('New ' . $singularName . 'Name'),
                    'menu_name'         => __($singularName),
                ];

                $args = [
                    'hierarchical'      => isset($taxonomy['hierarchy']) ? $taxonomy['hierarchy']      : false,
                    'labels'            => $labels,
                    'show_ui'           => true,
                    'show_admin_column' => true,
                    'query_var'         => true,
                    'show_in_rest'      => isset($taxonomy['show_in_rest']) ? $taxonomy['show_in_rest'] : true,
                    'rewrite' => [
                        'slug' => $taxonomy['name']
                    ],
                ];

                register_taxonomy($taxonomy['name'], [$taxonomy['postType']], $args);
            }
        }
    }
}
