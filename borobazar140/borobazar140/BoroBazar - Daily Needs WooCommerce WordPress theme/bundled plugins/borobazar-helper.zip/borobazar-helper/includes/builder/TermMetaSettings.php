<?php

/**
 * Generate Page Settings.
 */

namespace BoroBazarHelper\Builder;

class TermMetaSettings
{
    public $borobazar_predefined_taxonomy_fields = [];

    public function __construct()
    {
        /**
         * Example
         * keep the 'taxonomy_name' inside the array of $taxonomies.
         *
         * 'taxonomy_name',
         */
        add_action('init', [$this, 'addTermMetaToTaxonomies'], 10);
        add_action('init', [$this, 'registerTermMetaRestFields'], 10);
    }

    public function addTermMetaToTaxonomies()
    {
        $taxonomies = apply_filters('borobazar_add_term_meta_to_taxonomies', $this->borobazar_predefined_taxonomy_fields);
        new GenerateTermMeta($taxonomies);
    }

    public function registerTermMetaRestFields()
    {
        /**
         * Example
         * keep the 'taxonomy_name' inside the array of $restSupportedTaxonomies.
         *
         * 'taxonomy_name',
         */
        $restSupportedTaxonomies = apply_filters(
            'borobazar_rest_supported_taxonomies',
            $this->borobazar_predefined_taxonomy_fields
        );
        foreach ($restSupportedTaxonomies as $key => $taxonomy) {
            register_rest_field(
                $taxonomy,
                'meta',
                [
                    'get_callback' => function ($object, $fieldName, $request) {
                        $termMeta = get_term_meta($object['id'], '', true);
                        $processed_data = [];
                        foreach ($termMeta as $key => $value) {
                            $processed_data[$key] = maybe_unserialize($value[0]);
                        }

                        return $processed_data;
                    },
                    'update_callback' => null,
                    'schema' => null,
                ]
            );
        }
        // register_rest_field(
        // 	'borobazar_location',
        // 	'thumbnail_url',
        // 	array(
        // 		'get_callback' => function ($object, $fieldName, $request) {
        // 			$thumbnail_url = get_the_post_thumbnail_url($object['id'], 'post-thumbnail');
        // 			return $thumbnail_url;
        // 		},
        // 		'update_callback' => null,
        // 		'schema' => null,
        // 	)
        // );
    }

    public function getTermMetaSettingsFields()
    {
        /**
         * Example for imageupload field.
         *
         * array(
         *		'id' 		 	=> 'term_meta_settings_field_id',
         *		'type' 		 	=> 'imageupload',
         *		'multiple'		=> 'false',
         *		'label' 	  	=> esc_html__('Label', 'borobazar-helper'),
         *		'subtitle' 	  	=> esc_html__('subtitle description, [image size 270x210]', 'borobazar-helper'),
         *	),
         *
         * Example for color picker field
         *
         * array(
         *		'id' 		 	=> 'term_meta_settings_field_id',
         *		'type' 		 	=> 'colorpicker',
         *		'multiple'		=> 'false',
         *		'defaultColor' 	=> '#ffffff',
         *		'value' 		=> '#ffffff',
         *		'label' 	  	=> esc_html__('Label', 'borobazar-helper'),
         *		'subtitle' 	  	=> esc_html__('subtitle description','borobazar-helper'),
         *	),
         */
        $fields = [
            [
                'id'       => 'term_meta_settings_field_id',
                'type'     => 'imageupload',
                'multiple' => 'false',
                'label'    => esc_html__('Select thumbnail image', 'borobazar-helper'),
                'subtitle' => esc_html__('Thumbnail image for term. Image size 270x210 is preferable', 'borobazar-helper'),
            ]
        ];

        return apply_filters('term_meta_settings_fields', $fields);
    }
}
