<div id="borobazarTermMetabox"></div>

<?php
/**
 * Localize the updated data from database
 */




use BoroBazarHelper\Builder\TermMetaSettings;

$termMetaSettings = new TermMetaSettings();
$fields = $termMetaSettings->getTermMetaSettingsFields();
// $relating_taxonomy = apply_filters('category_relating_taxonomy', 'borobazar_product_brands');
// $terms = get_terms('borobazar_product_brands', array(
// 	'hide_empty' => false,
// ));
// $related_terms = [];
// foreach ($terms as $key => $term) {
// 	$related_terms[$term->term_id] =  $term->name;
// }
// if ($taxonomy === 'borobazar_product_brands') {
// 	$fields[] = array(
// 		'id' 		 	=> 'related_features',
// 		'param' 		=> 'related_features',
// 		'type' 		 	=> 'select',
// 		'placeholder'	=> esc_html__('Related Feature', 'borobazar-helper'),
// 		'label' 	  	=> esc_html__('Related Feature', 'borobazar-helper'),
// 		'options'		=> $related_terms,
// 		'multiple' 		=> 'true',
// 	);
// }
wp_localize_script(
	'if-gutenberg-block-scripts',
	'TERM_META_SETTINGS',
	array(
		'fields' => $fields,
	)
);
?>
<input type="hidden" id="_borobazar_term_meta_data" name="_borobazar_term_meta_data">