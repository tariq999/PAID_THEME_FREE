<?php

/**
 * Generate custom term meta on request.
 */

namespace BoroBazarHelper\Builder;

class GenerateTermMeta
{
    public function __construct($taxonomies)
    {
        foreach ($taxonomies as $taxonomy) {
            // create new fields
            add_action($taxonomy . '_add_form_fields', [$this, 'addTermMetaField'], 10, 2);
            // save created fields data
            add_action('created_' . $taxonomy, [$this, 'saveTermFieldsMeta'], 10, 2);
            // edit saved fields
            add_action($taxonomy . '_edit_form_fields', [$this, 'editSavedTermField'], 10, 2);
            // update edited fields
            add_action('edited_' . $taxonomy, [$this, 'updateEditedMeta'], 10, 2);
        }
    }

    public function editSavedTermField($term, $taxonomy)
    {
?>
        <tr class="form-field term-custom-wrap">
            <th scope="row"><label for="custom-group"><?php esc_html_e('Custom Fields', 'borobazar-helper'); ?></label></th>
            <td>
                <?php $termMetaData = get_term_meta($term->term_id, '_borobazar_term_meta_data', true); ?>
                <?php include_once BOROBAZAR_HELPER_SETTINGS_TEMPLATE_PATH . 'editTermMeta.php'; ?>
            </td>
        </tr>
<?php
    }

    public function addTermMetaField($taxonomy)
    {
        include_once BOROBAZAR_HELPER_SETTINGS_TEMPLATE_PATH . 'addTermMeta.php';
    }

    public function saveTermFieldsMeta($termId, $termTaxonomyId)
    {
        if (isset($_POST['_borobazar_term_meta_data']) && '' !== $_POST['_borobazar_term_meta_data']) {
            $termMetaData = json_decode(stripslashes_deep($_POST['_borobazar_term_meta_data']), true);
            add_term_meta($termId, '_borobazar_term_meta_data', $_POST['_borobazar_term_meta_data'], true);
            foreach ($termMetaData as $key => $value) {
                add_term_meta($termId, $key, $value, true);
            }
        }
    }

    public function updateEditedMeta($termId, $termTaxonomyId)
    {
        if (isset($_POST['_borobazar_term_meta_data']) && '' !== $_POST['_borobazar_term_meta_data']) {
            $termMetaData = json_decode(stripslashes_deep($_POST['_borobazar_term_meta_data']), true);
            update_term_meta($termId, '_borobazar_term_meta_data', $_POST['_borobazar_term_meta_data']);
            foreach ($termMetaData as $key => $value) {
                update_term_meta($termId, $key, $value);
            }
        }
    }
}
