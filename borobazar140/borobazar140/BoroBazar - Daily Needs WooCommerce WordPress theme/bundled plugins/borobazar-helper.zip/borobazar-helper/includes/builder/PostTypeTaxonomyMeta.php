<?php

/**
 * Create BoroBazar Related Posttype and Taxonomy.
 */

namespace BoroBazarHelper\Builder;

class PostTypeTaxonomyMeta
{
    public function __construct()
    {
        add_action('init', [$this, 'registerPostType']);
        add_action('init', [$this, 'registerTaxonomy']);
        add_action('add_meta_boxes', [$this, 'addMetabox']);
    }

    public function addMetabox()
    {
        /**
         * Example of metabox creation.
         * keep that similar type array inside the array of $args variable.
         *
         * create a php file inside the admin-templates folder with the same name as templatePath argument
         *
         * array(
         *		'id' 			=> 'borobazar_metabox',
         *		'name' 			=> esc_html__('Metabox Name', 'borobazar-helper'),
         *		'postType' 		=> 'posttype name',
         *		'position' 		=> 'high',
         *		'templatePath' 	=> 'xxxMetabox.php',
         *	),
         */
        $args = [];
        new GenerateMetaBox(apply_filters('borobazar_metabox', $args));
    }

    public function registerTaxonomy()
    {
        /**
         * Example of taxonomy creation.
         * keep that similar type array inside the array() of $taxonomy_lists variable.
         *
         * array(
         *		'name' 		          => 'taxonomy_name',
         *		'showName' 	          => 'Taxonomy Name',
         *		'postType' 	          => 'post_type name',
         *		'hierarchy'           => false,
         *	),
         */
        $taxonomy_lists = apply_filters(
            'borobazar_custom_taxonomy_list',
            [
                [
                    'name'      => 'borobazar_product_brands',
                    'showName'  => esc_html__('Product Brands', 'borobazar-helper'),
                    'postType'  => 'product',
                    'hierarchy' => true
                ],
                [
                    'name'      => 'borobazar_product_price_ranges',
                    'showName'  => esc_html__('Price Range', 'borobazar-helper'),
                    'postType'  => 'product',
                    'hierarchy' => true
                ],
                [
                    'name'      => 'borobazar_product_genre',
                    'showName'  => esc_html__('Product Genre', 'borobazar-helper'),
                    'postType'  => 'product',
                    'hierarchy' => true
                ],
            ]
        );

        new GenerateTaxonomy($taxonomy_lists);
    }

    public function registerPostType()
    {
        new GeneratePostType([
            [
                'name' => 'footer',
                'showName' => esc_html__('Footer', 'borobazar-helper'),
                'label' => [
                    'all_items' => esc_html__('All Footer', 'borobazar-helper'),
                ],
                'supports' => [
                    'title' => true,
                    'editor' => true,
                    'thumbnail' => true,
                ],
                'publiclyQueryable' => true,
                'hasArchive' => true,
                'hierarchical' => false,
                'showInRest' => true,
            ],
        ]);
    }
}
