<?php

/**
 * BoroBazar Helper Template Hooks.
 */
defined('ABSPATH') || exit;

/*
 * Grid Loop No Items.
 *
 * @see ifGridLoopItemsEmptyFunc()
 */
add_action('if_grid_loop_empty', 'ifGridLoopItemsEmptyFunc', 10);

/*
 * Render before search block.
 *
 * @see ifSearchBlockRenderBefore()
 */
// add_action('if_search_block_template_render_before', 'ifSearchBlockRenderBefore', 10, 3);

/*
 * Render after search block.
 *
 * @see ifSearchBlockRenderAfter()
 */
// add_action('if_search_block_template_render_after', 'ifSearchBlockRenderAfter', 10);

/*
 * Render before grid template.
 *
 * @see ifTemplateRenderBeforeWrap()
 */
add_action('if_grid_template_render_before', 'ifTemplateRenderBeforeWrap', 10, 2);

/*
 * Render after grid template.
 *
 * @see ifTemplateRenderAfterWrap()
 */
add_action('if_grid_template_render_after', 'ifTemplateRenderAfterWrap', 10);

/*
 * Grid Loop Thumbnails or Gallery or Lazyloading.
 *
 * @see ifGridLoopItemThumbnailsFunc()
 */
add_action('if_grid_loop_item_thumbnails', 'ifGridLoopItemThumbnailsFunc', 10, 5);

/*
 * Gutenberg Blocks Heading area.
 *
 * @see ifShortCodeHeading()
 */
add_action('if_grid_block_heading', 'ifShortCodeHeading', 10, 1);

// add_action('if_grid_loop_items_before_wrap', 'ifGridSliderStart', 10, 1);
// add_action('if_grid_loop_items_after_wrap', 'ifGridSliderEnd', 10, 1);