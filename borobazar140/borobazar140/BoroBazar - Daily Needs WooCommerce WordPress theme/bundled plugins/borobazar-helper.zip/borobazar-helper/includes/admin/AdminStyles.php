<?php

namespace BoroBazarHelper\Admin;

// Exit if accessed directly.
defined('ABSPATH') || exit;

use BoroBazarHelper\Traits\StyleScriptLoader;

/**
 * AdminStyles.
 */
class AdminStyles
{
    use StyleScriptLoader;

    private static $styles = [];

    /**
     * __construct.
     */
    public function __construct()
    {
        add_action('admin_enqueue_scripts', [$this, 'loadStyles']);
    }

    /**
     * registerStyles.
     */
    private static function registerStyles()
    {
        $register_styles = apply_filters('borobazar_admin_styles_array', [
            'if-admin-page-settings-css' => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'admin/css/admin-style.css',
                'deps'    => [],
                'version' => BOROBAZAR_HELPER_VERSION,
                'has_rtl' => false,
            ],
            'swiper-css' => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'admin/css/swiper-bundle.min.css',
                'deps'    => [],
                'version' => BOROBAZAR_HELPER_VERSION,
                'has_rtl' => false,
            ],
            'tailwind-css' => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'admin/css/borobazar-tailwind-backend.css',
                'deps'    => [],
                'version' => BOROBAZAR_HELPER_VERSION,
                'has_rtl' => true,
            ],
            'if-gutenberg-editor-css' => [
                'src'     => BOROBAZAR_HELPER_DIST . 'blocks.editor.build.css',
                'deps'    => ['wp-edit-blocks'],
                'version' => BOROBAZAR_HELPER_VERSION,
                'has_rtl' => true,
            ],
        ]);

        foreach ($register_styles as $name => $props) {
            self::registerStyle($name, $props['src'], $props['deps'], $props['version'], 'all', $props['has_rtl']);
        }
    }

    /**
     * loadStyles.
     */
    public function loadStyles()
    {
        self::registerStyles();
        wp_enqueue_style('wp-color-picker');
        self::enqueueStyle('if-admin-page-settings-css');
        self::enqueueStyle('if-gutenberg-editor-css');
        self::enqueueStyle('swiper-css');
        self::enqueueStyle('tailwind-css');

        if (is_rtl()) {
            wp_enqueue_style('borobazar-helper-admin-custom-rtl', BOROBAZAR_HELPER_ASSETS . 'admin/css/borobazar-helper-custom-admin-rtl.css', [], BOROBAZAR_HELPER_VERSION);
        }
    }
}
