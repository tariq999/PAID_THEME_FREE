<?php

namespace BoroBazarHelper\Admin;

// Exit if accessed directly.
defined('ABSPATH') || exit;

use BoroBazarHelper\Traits\StyleScriptLoader;

/**
 * Scripts.
 */
class AdminScripts
{
    use StyleScriptLoader;

    /**
     * __construct.
     */
    public function __construct()
    {
        add_action('admin_enqueue_scripts', [$this, 'loadScripts']);
    }

    /**
     * registerScripts.
     */
    private static function registerScripts()
    {
        $register_scripts = apply_filters('borobazar_admin_scripts_array', [
            'borobazar-admin' => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'admin/js/borobazar-helper-admin.js',
                'deps'    => [],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'if-gutenberg-block-scripts' => [
                'src'     => BOROBAZAR_HELPER_DIST . 'blocks.build.js',
                'deps'    => ['wp-api', 'wp-blocks', 'wp-element', 'wp-i18n', 'wp-block-editor'],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
        ]);
        foreach ($register_scripts as $name => $key) {
            self::registerScript($name, $key['src'], $key['deps'], $key['version']);
        }
    }

    /**
     * loadScripts.
     */
    public function loadScripts()
    {
        self::registerScripts();
        wp_enqueue_script('wp-color-picker');


        // Load google map script only for store map block
        if (class_exists('Load_Google_Map')) {
            $googlemap_settings = get_option('googlemap_settings', true);
            if (isset($googlemap_settings)) {
                if (isset($googlemap_settings['googlemap_enable']) && $googlemap_settings['googlemap_enable'] === 'enable' && isset($googlemap_settings['googlemap_api_key']) && $googlemap_settings['googlemap_api_key'] !== '') {

                    if (has_block('borobazar-blocks/borobazar-store-map')) {
                        wp_register_script('google-map-api', '//maps.googleapis.com/maps/api/js?key=' . $googlemap_settings['googlemap_api_key'] . '&libraries=places,geometry&language=en-US', array('jquery', 'underscore'), true, false);
                        wp_enqueue_script('google-map-api');
                        // Load google map script only for store map block
                    }
                }
            }
        }


        self::enqueueScript('borobazar-admin');
        self::enqueueScript('if-gutenberg-block-scripts');
        self::localizeScripts(
            'if-gutenberg-block-scripts',
            'BOROBAZAR_HELPER_ADMIN_LOCALIZE',
            [
                'pluginDirPath' => plugin_dir_path(__DIR__),
                'pluginDirUrl' => plugin_dir_url(__DIR__),
                'imagePath' => BOROBAZAR_HELPER_ASSETS . 'admin/images/',
                'globalImagePath' => BOROBAZAR_HELPER_ASSETS . 'global/images/',
                'googleMap' => class_exists('Load_Google_Map') ? get_option('googlemap_settings', true) : [],
            ]
        );
    }
}
