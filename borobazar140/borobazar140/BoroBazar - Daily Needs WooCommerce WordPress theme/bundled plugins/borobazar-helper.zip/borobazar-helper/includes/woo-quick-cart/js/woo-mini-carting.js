(function ($) {
	const cartItems = mini_quick_cart_woocommerce
		? mini_quick_cart_woocommerce.cartItems
		: [];

	// mini-cart add/sub button
	const loading = (selector) => {
		$(selector).block({
			message: null,
			overlayCSS: {
				background: "#fff",
				opacity: 0.6,
				zIndex: 1,
			},
		});
	};

	const unLoading = (selector) => {
		$(selector).unblock();
	};

	$("body").on("click", ".mini-cart-update-qty", function (e) {
		e.preventDefault();

		const product_id = $(this).data("product_id");
		const type = $(this).data("type");
		const source = $(this).data("source");
		const loaderSelector = `.borobazar-product-${product_id}`;

		const addToCartTimer = 2500;

		const data = {
			action: "mini_cart_woocommerce_update_qty",
			product_id,
			type,
		};

		loading(loaderSelector);

		$.post(mini_quick_cart_woocommerce.ajax_url, data, function (response) {
			const responseData = response.data;
			const header = $("#masthead>div");

			if (response.success === false) {
				$.toast({
					text: responseData.message,
					showHideTransition: "fade",
					hideAfter: addToCartTimer,
					position: {
						right: 10,
						top: 10 + header[0].getBoundingClientRect().bottom,
					},
					stack: false,
					bgColor: "#fff",
				});
			}

			if (response.success) {
				$(document.body).trigger("wc_fragment_refresh");
				$(document.body).trigger("wc_fragments_loaded");
				$(`.borobazar-cart-product-${product_id}`).html(responseData.quantity);

				if ($(".gridster").length) {
					$(`.gs-cart-product-${product_id}`).html(responseData.quantity);
				}

				if (responseData.quantity) {
					// hide + btn
					$(`.borobazar-add-to-cart-${product_id}`).removeClass("flex");
					$(`.borobazar-add-to-cart-${product_id}`).addClass("hidden");
					// show quantity
					$(`.borobazar-qty-button-${product_id}`).removeClass("hidden");
					$(`.borobazar-qty-button-${product_id}`).addClass("flex");
					// added to btn show
					$(`.added-to-cart-${product_id}`).removeClass("hidden");
					$(`.added-to-cart-${product_id}`).addClass("flex");

					if ($(".gridster").length) {
						$(`.gs-add-to-cart-${product_id}`).removeClass("flex");
						$(`.gs-add-to-cart-${product_id}`).addClass("hidden");
						$(`.gs-qty-button-${product_id}`).removeClass("hidden");
						$(`.gs-qty-button-${product_id}`).addClass("flex");
						$(`.added-to-cart-${product_id}`).removeClass("hidden");
						$(`.added-to-cart-${product_id}`).addClass("flex");
					}
				} else {
					// hide + btn
					$(`.borobazar-add-to-cart-${product_id}`).removeClass("hidden");
					$(`.borobazar-add-to-cart-${product_id}`).addClass("flex");
					// show quantity
					$(`.borobazar-qty-button-${product_id}`).removeClass("flex");
					$(`.borobazar-qty-button-${product_id}`).addClass("hidden");
					// added to btn show
					$(`.added-to-cart-${product_id}`).removeClass("flex");
					$(`.added-to-cart-${product_id}`).addClass("hidden");

					if ($(".gridster").length) {
						$(`.gs-add-to-cart-${product_id}`).removeClass("hidden");
						$(`.gs-add-to-cart-${product_id}`).addClass("flex");
						$(`.gs-qty-button-${product_id}`).removeClass("flex");
						$(`.gs-qty-button-${product_id}`).addClass("hidden");
						$(`.added-to-cart-${product_id}`).removeClass("flex");
						$(`.added-to-cart-${product_id}`).addClass("hidden");
					}
				}

				//Toast message
				if (source !== "mini_cart") {
					$.toast({
						text: responseData.details.markup,
						showHideTransition: "fade",
						hideAfter: addToCartTimer,
						position: {
							right: 10,
							top: 10 + header[0].getBoundingClientRect().bottom,
						},
						stack: false,
						bgColor: "#fff",
					});
				}
			}
			unLoading(loaderSelector);
		}).fail(function () {
			console.log(mini_quick_cart_woocommerce.message);
		});
	});
})(jQuery);
