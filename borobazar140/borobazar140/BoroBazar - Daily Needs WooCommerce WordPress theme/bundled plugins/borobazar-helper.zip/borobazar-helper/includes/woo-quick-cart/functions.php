<?php

if (!function_exists('ifIsSimpleProduct')) {
    /**
     * ifIsSimpleProduct.
     *
     * @param mixed $product_id
     *
     * @return void
     */
    function ifIsSimpleProduct($product_id)
    {
        return wc_get_product($product_id)->is_type('simple');
    }
}

/**
 * getIFCustomFields.
 *
 * @param int $product_id
 *
 * @return array
 */
function getIFCustomFields($product_id)
{
    $step = get_post_meta($product_id, '_borobazar_woocommerce_step_down', true);
    $unit = get_post_meta($product_id, '_borobazar_woocommerce_product_unit', true);
    $label = get_post_meta($product_id, '_borobazar_woocommerce_product_unit_label', true);

    return [
        'step' => $step,
        'unit' => $unit,
        'label' => $label,
    ];
}

/**
 * ifProductAddToCartValidity.
 *
 * @param int $product_id
 *
 * @return bool
 */
function ifProductAddToCartValidity($product_id)
{
    $product_qty_in_cart = WC()->cart->get_cart_item_quantities();
    $current_session_order_id = isset(WC()->session->order_awaiting_payment) ? absint(WC()->session->order_awaiting_payment) : 0;
    $product = wc_get_product($product_id);

    // Check stock based on stock-status.
    if (!$product->is_in_stock()) {
        return false;
    }

    // We only need to check products managing stock, with a limited stock qty.
    if (!$product->managing_stock() || $product->backorders_allowed()) {
        return true;
    }

    // Check stock based on all items in the cart and consider any held stock within pending orders.
    $held_stock = wc_get_held_stock_quantity($product, $current_session_order_id);
    $required_stock = $product_qty_in_cart[$product->get_stock_managed_by_id()];
    $required_stock = 1 + $required_stock;

    if ($product->get_stock_quantity() < ($held_stock + $required_stock)) {
        return false;
    }

    return true;
}

/**
 * borobazar_check_product_in_cart_by_ID.
 *
 * @param int $product_id
 *
 * @return void
 */
function borobazar_check_product_in_cart_by_ID($product_id)
{
    if (!is_null(WC()->cart) && !WC()->cart->is_empty()) {
        $cart_items = WC()->cart->get_cart();

        if (!count($cart_items)) {
            return false;
        }

        foreach ($cart_items as $cart_item_key => $cart_item) {
            if ($cart_item['product_id'] === $product_id) {
                return $cart_item['quantity'];
            }
        }
    }

    return false;
}
