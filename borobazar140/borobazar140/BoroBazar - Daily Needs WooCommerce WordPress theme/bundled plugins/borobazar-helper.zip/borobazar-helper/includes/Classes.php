<?php

namespace BoroBazarHelper;

// Exit if accessed directly.
defined('ABSPATH') || exit;
// Admin Classes
use BoroBazarHelper\Admin\AdminScripts;
use BoroBazarHelper\Admin\AdminStyles;
// Builder Classes
use BoroBazarHelper\Builder\PostTypeTaxonomyMeta;
use BoroBazarHelper\Builder\TermMetaSettings;
// Front Classes
use BoroBazarHelper\Front\GridDataBuilder;
use BoroBazarHelper\Front\AjaxHandler;
use BoroBazarHelper\Front\Internationalization;
use BoroBazarHelper\Front\Scripts;
use BoroBazarHelper\Front\Shortcodes;
use BoroBazarHelper\Front\Styles;
// Settings Panel Classes
use BoroBazarHelper\Settings\CustomizerSettings;
// Traits
use BoroBazarHelper\Traits\TemplateLoader;
// Quick Carting Classes
use BoroBazarHelper\WooQuickCart\WooQuickCartAjax;
use BoroBazarHelper\WooQuickCart\WooQuickCartFront;

/**
 * Classes.
 */
class Classes
{
    use TemplateLoader;

    /**
     * __construct.
     */
    public function __construct()
    {
        add_action('plugins_loaded', [$this, 'classes']);
    }

    /**
     * classes.
     */
    public function classes()
    {
        if (is_admin()) {
            new AdminStyles();
            new AdminScripts();
        }
        if (class_exists('Kirki')) {
            new CustomizerSettings();
        }
        new AjaxHandler();
        new GridDataBuilder();
        new Internationalization();
        new PostTypeTaxonomyMeta();
        new Scripts();
        new Styles();
        new Shortcodes();
        new TermMetaSettings();
        new WooQuickCartAjax();
        new WooQuickCartFront();
    }
}
