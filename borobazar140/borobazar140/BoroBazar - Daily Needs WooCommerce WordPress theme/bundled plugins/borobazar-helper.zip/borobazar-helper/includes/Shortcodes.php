<?php

namespace BoroBazarHelper\Front;

// Exit if accessed directly.
defined('ABSPATH') || exit;

use BoroBazarHelper\Traits\BlockHelper;
use BoroBazarHelper\Traits\BlockPostData;

/**
 * Shortcodes.
 */
class Shortcodes
{
    use BlockHelper;
    use BlockPostData;

    public function __construct()
    {
        $this->prepareShortCodeTemplates();
        add_action('save_post', [$this, 'borobabazarClearTransient']);
    }

    public function borobabazarClearTransient()
    {
        // get dynamic transient names and delete it with options.
        $boroBazarAllTransientNames = '';
        $boroBazarAllTransientNames = get_option('borobazar_transient_names', false);

        if (!empty($boroBazarAllTransientNames)) {
            foreach ($boroBazarAllTransientNames as $boroBazarAllTransientName) {
                if (false !== get_transient($boroBazarAllTransientName)) {
                    delete_transient($boroBazarAllTransientName);
                }
            }
        }
        delete_option('borobazar_transient_names');

        // delete product categories transient
        if (false !== get_transient('transient_borobazar_product_categories')) {
            delete_transient('transient_borobazar_product_categories');
        }
        if (false !== get_transient('transient_borobazar_borobazar_product_brands')) {
            delete_transient('transient_borobazar_borobazar_product_brands');
        }
        if (false !== get_transient('transient_borobazar_borobazar_product_price_ranges')) {
            delete_transient('transient_borobazar_borobazar_product_price_ranges');
        }
        if (false !== get_transient('transient_borobazar_borobazar_product_genre')) {
            delete_transient('transient_borobazar_borobazar_product_genre');
        }
    }

    public function prepareShortCodeTemplates()
    {
        $templates_array = apply_filters('borobazar_shortcode_lists', [
            'accordion',
            'app',
            'call-to-action',
            'category-grid',
            'collection',
            'contact-form',
            'contact-info',
            "counter",
            'extended-search',
            'image',
            'media-and-text',
            'scroll-to-content',
            'search-banner',
            'search-results',
            'search',
            'slider',
            'store-map',
            'team',
            'wrapper',
            'posts',
            // widgets
            'widgets/about',
            'widgets/newsletter',
            'widgets/quick-links',

        ]);

        foreach ($templates_array as $template) {
            $this->requireShortCodeFiles($template);
        }
    }

    public function requireShortCodeFiles($template)
    {
        require_once BOROBAZAR_HELPER_SHORTCODE_PATH . $template . '.php';
    }
}
