<?php

namespace BoroBazarHelper\Front;

use BoroBazarHelper\Traits\NativeSearchTrait;

class AjaxHandler
{
    use NativeSearchTrait;
    /**
     * Action hook used by the AJAX class.
     *
     * @var string
     */
    const ACTION = 'borobazar_helper_ajax';

    /**
     * Action argument used by the nonce validating the AJAX request.
     *
     * @var string
     */
    const NONCE = 'borobazar_helper_ajax_nonce';

    /**
     * Register the AJAX handler class with all the appropriate WordPress hooks.
     */
    /**
     * AjaxHandler constructor.
     */
    public function __construct()
    {
        add_action('wp_ajax_' . self::ACTION, array($this, 'handleAjax'));
        add_action('wp_ajax_nopriv_' . self::ACTION, array($this, 'handleAjax'));
    }

    public function handleAjax()
    {
        if (!wp_verify_nonce($_POST['nonce'], self::NONCE)) {
            die('Busted!');
        }

        $ajax_data = $_POST;
        unset($ajax_data['nonce']);
        unset($ajax_data['action']);

        $textSearch = '';
        if (isset($ajax_data['search_type']) && $ajax_data['search_type'] === 'global') {
            $textSearch = $this->processGlobalParams($ajax_data['params']);
            $ajax_data['text-search'] = $textSearch;
            unset($ajax_data['params']);
        }

        switch ($ajax_data['action_type']) {
            case 'search':
                $params = apply_filters('borobazar_processed_search_params', $this->processParams($ajax_data));
                $results = isset($params['post__in']) && !count($params['post__in']) ? ['posts' => 0, 'count' => 0] : $this->search($params);
                wp_send_json_success([
                    'listing'        => $results['posts'],
                    'count'          => $results['count'],
                    'searchTags'     => $params['searchTags'],
                    'searchTagsType' => $params['searchTagsType'],
                    'message'        => esc_html__('Successfully grab the products', 'borobazar-helper'),
                    'countText'      => sprintf(
                        /* translators: 1: count, 2: count plural. */
                        _n('%s item', '%s items', $results['count'], 'borobazar-helper'),
                        $results['count']
                    ),
                ]);
                break;
        }

        exit();
    }

    /**
     * Process params
     *
     * @param array $data
     * @return void
     */
    public function processParams($data)
    {

        $args           = [];
        $tax_query      = ['relation' => 'AND'];
        $meta_query     = ['relation' => 'AND'];
        $categories     = [];
        $brands         = [];
        $productGenre   = [];
        $priceRanges    = [];
        $tags           = [];
        $colors         = [];
        $searchTags     = [];
        $searchTagsType = [];
        $orderBy        = 'title';
        $order          = 'ASC';

        if (isset($data['search_type']) && $data['search_type'] !== 'global') {
            $params = !empty($data) ? $data['params'] : [];
            parse_str($params, $queries);
        } else {
            $queries = $data;
        }

        $searchedTaxonomyName = isset($queries) && !empty($queries['product_taxonomy_by']) ? $queries['product_taxonomy_by'] : '';

        $predefinedTaxonomy = [
            'product_cat',
            // 'product_tag',
            'borobazar_product_brands',
            'borobazar_product_price_ranges',
            'borobazar_product_genre',
        ];

        // custom taxonomy search query
        // if ((!empty($data['block_type']) && $data['block_type'] === 'quick_search') && !in_array($searchedTaxonomyName, $predefinedTaxonomy)) {
        //     $customTaxQuery = $this->dynamicTaxonomySearchReady($queries, $searchedTaxonomyName);
        //     if (!empty($customTaxQuery) && !empty($customTaxQuery['taxonomy']) && !empty($customTaxQuery['term'])) {
        //         $tax_query[] = array(
        //             'taxonomy' => $customTaxQuery['taxonomy'],
        //             'field'    => 'slug',
        //             'terms'    => $customTaxQuery['term'],
        //         );
        //     }
        // }

        if (!in_array($searchedTaxonomyName, $predefinedTaxonomy)) {
            $customTaxQuery = $this->dynamicTaxonomySearchReady($queries, $searchedTaxonomyName);
            if (!empty($customTaxQuery) && !empty($customTaxQuery['taxonomy']) && !empty($customTaxQuery['term'])) {
                $searchTags[]     = $customTaxQuery['term'];
                $searchTagsType[] = $customTaxQuery['taxonomy'];
                $tax_query[] = array(
                    'taxonomy' => $customTaxQuery['taxonomy'],
                    'field'    => 'slug',
                    'terms'    => $customTaxQuery['term'],
                );
            }
        }

        // default taxonomy search query
        foreach ($queries as $key => $param) {
            switch ($key) {
                case 'text-search':
                    // $args['s']        = str_replace('_', ' ', $param);
                    if (get_theme_mod('borobazar_limit_search_to_post_title', 'off') !== "on") {
                        $args['s'] = str_replace('_', ' ', $param);
                    } else {
                        $args['search_product_title'] = str_replace('_', ' ', $param);
                    }
                    $searchTags[]     = $param;
                    $searchTagsType[] = 'text-search';
                    break;

                case 'page':
                    $args['posts_per_page'] = $this->getProductLimit() * $param;
                    break;

                case 'product-tag':
                    $tags             = array_values($param);
                    $searchTags[]     = array_values($param);
                    $searchTagsType[] = 'product-tag';
                    break;

                case 'product-category':
                    $categories       = array_values($param);
                    $searchTags[]     = array_values($param);
                    $searchTagsType[] = 'product-category';
                    break;

                case 'product-brand':
                    $brands           = array_values($param);
                    $searchTags[]     = array_values($param);
                    $searchTagsType[] = 'product-brand';
                    break;

                case 'product-genre':
                    $productGenre     = array_values($param);
                    $searchTags[]     = array_values($param);
                    $searchTagsType[] = 'product-genre';
                    break;

                case 'product-color':
                    $colors           = array_values($param);
                    $searchTags[]     = array_values($param);
                    $searchTagsType[] = 'product-color';
                    break;

                case 'product-price':
                    $priceRanges      = array_values($param);
                    $searchTags[]     = array_values($param);
                    $searchTagsType[] = 'product-price';
                    break;

                case 'order_by':
                    $splitParams = explode('-', $param);
                    $orderBy     = isset($splitParams[0]) ? $splitParams[0] : 'title';
                    $order       = isset($splitParams[1]) ? $splitParams[1] : 'ASC';
                    break;
            }
        }

        if (count($tags)) {
            $tax_query[] = array(
                'taxonomy' => 'product_tag',
                'field'    => 'slug',
                'terms'    => $tags,
            );
        }

        if (count($categories)) {
            $tax_query[] = array(
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => $categories,
            );
        }

        if (count($brands)) {
            $tax_query[] = array(
                'taxonomy' => 'borobazar_product_brands',
                'field'    => 'slug',
                'terms'    => $brands,
            );
        }

        if (count($priceRanges)) {
            $tax_query[] = array(
                'taxonomy' => 'borobazar_product_price_ranges',
                'field'    => 'slug',
                'terms'    => $priceRanges,
            );
        }

        if (count($productGenre)) {
            $tax_query[] = array(
                'taxonomy' => 'borobazar_product_genre',
                'field'    => 'slug',
                'terms'    => $productGenre,
            );
        }

        if (count($colors)) {
            $tax_query[] = array(
                'taxonomy' => 'pa_color',
                'field'    => 'slug',
                'terms'    => $colors,
            );
        }


        if (get_theme_mod('woo_hidden_product_switch', 'off') === 'on') {
            $tax_query[] = array(
                'taxonomy' => 'product_visibility',
                'field'    => 'name',
                'terms'    => 'exclude-from-catalog',
                'operator' => 'NOT IN',
            );
        }

        if (count($tax_query) > 1) {
            $args['tax_query'] = $tax_query;
        }

        if (get_theme_mod('remove_out_of_stock_from_search', 'no') === 'yes') {
            $meta_query[] = [
                'key' => '_stock_status',
                'value' => 'instock',
                'compare' => '=',
            ];
        }

        if (count($meta_query) > 1) {
            $args['meta_query'] = $meta_query;
        }

        $args['orderby'] = $orderBy;
        $args['order']   = $order;

        $numberSorting = ['_price', '_wc_average_rating'];

        if (in_array($orderBy, $numberSorting)) {
            $args['orderby']  = 'meta_value_num';
            $args['meta_key'] = $orderBy;
        }

        $args['searchTags'] = $this->flattenTags($searchTags);

        $args['searchTagsType'] = $searchTagsType;

        return $args;
    }


    public function dynamicTaxonomySearchReady($queries, $searchedTaxonomyName)
    {
        $customTaxonomy = $searchTags = $searchTagsType = $queryBuilder = [];
        $termName = '';

        if (!empty($queries)) {
            if (in_array($searchedTaxonomyName, $queries)) {
                $termName = !empty($queries) && isset($queries[$searchedTaxonomyName]) ? $queries[$searchedTaxonomyName] : '';
            } else {
                $termName = [];
            }
            $queryBuilder['taxonomy'] = $searchedTaxonomyName;
            $queryBuilder['term'] = $termName;

            return $queryBuilder;
        }

        return $queryBuilder;
    }

    /**
     * Flatten search tags
     *
     * @param array $params
     * @return array
     */
    public function flattenTags(array $params)
    {
        $results = array();

        array_walk_recursive($params, function ($param) use (&$results) {
            $results[] = $param;
        });

        return array_filter($results);
    }

    /**
     * Process global search params
     *
     * @param [type] $params
     * @return string
     */
    public function processGlobalParams($params)
    {
        $text = '';

        if (empty($params)) {
            return $text;
        }

        foreach ($params as $key => $param) {
            if ($param['name'] === 'text') {
                $text = $param['value'];
            }
        }

        return $text;
    }
}
