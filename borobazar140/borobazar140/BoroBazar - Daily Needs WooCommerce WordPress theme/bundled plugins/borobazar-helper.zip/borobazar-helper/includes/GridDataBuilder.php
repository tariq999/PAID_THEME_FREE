<?php

namespace BoroBazarHelper\Front;

use BoroBazarHelper\Traits\LangTrait;
use WP_Post;

class GridDataBuilder
{
  use LangTrait;

  public function __construct()
  {
    add_filter('allowed_meta', [$this, 'allowedMeta'], 1);
    add_filter('borobazar_process_grid_data', [$this, 'override'], 1);
  }

  /**
   * Modify post data.
   *
   * @return array
   */
  public function override(WP_Post $post)
  {
    if (class_exists('SitePress')) {
      $processedData = $this->prepare_wpml_data($post->ID);

      return $processedData;
    }

    $metaData = $productGalleryImageLink = [];

    $product = wc_get_product($post->ID);
    $categoriesObject = get_the_terms($post->ID, 'product_cat') ? get_the_terms($post->ID, 'product_cat') : [];
    $tagObject = get_the_terms($post->ID, 'product_tag') ? get_the_terms($post->ID, 'product_tag') : [];
    $productType = get_the_terms($post->ID, 'product_type') ? current(get_the_terms($post->ID, 'product_type'))->slug : '';
    $isOnSale = $product->is_on_sale();
    $stock_qty = $product->get_manage_stock() ? $product->get_stock_quantity() : -1;
    $isInStock = $product->is_in_stock();
    $productUnitLabel = get_post_meta($post->ID, '_borobazar_woocommerce_product_unit_label') ? current(get_post_meta($post->ID, '_borobazar_woocommerce_product_unit_label')) : '';
    $productUnit = get_post_meta($post->ID, '_borobazar_woocommerce_product_unit') ? current(get_post_meta($post->ID, '_borobazar_woocommerce_product_unit')) : '';
    $productVisibility = !empty($product) ? $product->get_catalog_visibility() : '';

    $galleryAttachmentIDs = $product->get_gallery_image_ids();
    foreach ($galleryAttachmentIDs as $galleryAttachmentID) {
      $productGalleryImageLink[] = wp_get_attachment_url($galleryAttachmentID);
    }

    $categories = array_map(function (\WP_Term $term) {
      return [
        'name' => html_entity_decode($term->name),
        'url' => get_term_link($term),
      ];
    }, $categoriesObject);

    $categoriesSlug = array_map(function (\WP_Term $term) {
      return html_entity_decode($term->slug);
    }, $categoriesObject);

    $tags = array_map(function (\WP_Term $term) {
      return [
        'name' => html_entity_decode($term->name),
        'url' => get_term_link($term),
      ];
    }, $tagObject);

    $tagsSlug = array_map(function (\WP_Term $term) {
      return html_entity_decode($term->slug);
    }, $tagObject);

    $postMeta = get_metadata('post', $post->ID);
    $indexedMetaKeys = apply_filters('allowed_meta', []);

    foreach ($postMeta as $metakey => $metaValue) {
      if (in_array($metakey, $indexedMetaKeys)) {
        $metaData[$metakey] = current($metaValue);
      }
    }

    $processedData = array_merge([
      'post_id'                   => $post->ID,
      'title'                     => $post->post_title,
      'permalink'                 => get_post_permalink($post->ID),
      'thumbnail'                 => get_the_post_thumbnail_url($post->ID, 'borobazar-grid-thumb'),
      'thumbnail_size'            => wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'borobazar-grid-thumb'),
      'category'                  => $categories,
      'category_slug'             => $categoriesSlug,
      'tag'                       => $tags,
      'tag_slug'                  => $tagsSlug,
      'product_type'              => $productType,
      'price_html'                => $product->get_price_html(),
      'on_sale'                   => $isOnSale,
      'stock_quantity'            => $stock_qty,
      'is_in_stock'               => $isInStock,
      'product_gallery'           => $productGalleryImageLink,
      'product_short_description' => !empty($product) ? $product->get_short_description() : '',
      'product_unit'              => $productUnit,
      'product_unit_label'        => $productUnitLabel,
      'product_visibility'        => $productVisibility,
    ], $metaData);

    return $processedData;
  }

  /**
   * Data for WPML.
   *
   * @param int $post_id
   *
   * @return array
   */
  public function prepare_wpml_data($post_id)
  {
    global $sitepress;
    $default = $sitepress->get_default_language();

    $translated_ids = $this->get_translated_ids($post_id);
    $default_id = isset($translated_ids[$default]) ? $translated_ids[$default] : $post_id;

    $title = $this->get_translated_titles($translated_ids);
    $thumbnail = $this->get_translated_thumbnails($translated_ids);
    $thumbnailSize = $this->get_translated_thumbnails_size($translated_ids);
    $permalink = $this->get_translated_permalink($default_id, $translated_ids);

    $categories = $this->get_translated_post_terms($default_id, $translated_ids, 'product_cat');
    $categoriesSlug = $this->get_formatted_slugs($categories);

    $tags = $this->get_translated_post_terms($default_id, $translated_ids, 'product_tag');
    $tagsSlug = $this->get_formatted_slugs($tags);

    $product = wc_get_product($default_id);
    $productType = get_the_terms($default_id, 'product_type') ? current(get_the_terms($default_id, 'product_type'))->slug : '';
    $isOnSale = $product->is_on_sale();
    $stock_qty = $product->get_manage_stock() ? $product->get_stock_quantity() : -1;
    $isInStock = $product->is_in_stock();
    $productVisibility = !empty($product) ? $product->get_catalog_visibility() : '';

    $galleryAttachmentIDs = $product->get_gallery_image_ids();
    $productGalleryImageLink = [];
    if (!empty($galleryAttachmentIDs)) {
      foreach ($galleryAttachmentIDs as $galleryAttachmentID) {
        $productGalleryImageLink[] = wp_get_attachment_url($galleryAttachmentID);
      }
    }

    $postMeta = get_metadata('post', $default_id);
    $indexedMetaKeys = apply_filters('allowed_meta', []);

    $metaData = [];
    if (!empty($postMeta)) {
      foreach ($postMeta as $metakey => $metaValue) {
        if (in_array($metakey, $indexedMetaKeys)) {
          $metaData[$metakey] = current($metaValue);
        }
      }
    }

    $results = array_merge([
      'post_id'            => $translated_ids,
      'title'              => $title,
      'permalink'          => $permalink,
      'thumbnail'          => $thumbnail,
      'thumbnail_size'     => $thumbnailSize,
      'category'           => $categories,
      'category_slug'      => $categoriesSlug,
      'tag'                => $tags,
      'tag_slug'           => $tagsSlug,
      'product_type'       => $productType,
      'price_html'         => $product->get_price_html(),
      'on_sale'            => $isOnSale,
      'stock_quantity'     => $stock_qty,
      'is_in_stock'        => $isInStock,
      'product_gallery'    => $productGalleryImageLink,
      'product_visibility' => $productVisibility,
    ], $metaData);

    return $results;
  }

  /**
   * Restrict meta key.
   *
   * @return array
   */
  public function allowedMeta()
  {
    return [
      '_sku',
      '_regular_price',
      '_sale_price',
      '_price',
      'total_sales',
      '_purchase_note',
      '_wc_average_rating',
      '_wc_review_count',
      '_thumbnail_id',
    ];
  }
}
