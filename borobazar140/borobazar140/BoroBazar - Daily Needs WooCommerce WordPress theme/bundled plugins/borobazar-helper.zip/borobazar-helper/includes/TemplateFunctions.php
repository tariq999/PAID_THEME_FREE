<?php

use BoroBazarHelper\Classes;

defined('ABSPATH') || exit;

if (!function_exists('ifGridLoopItemsEmptyFunc')) {
    /**
     * ifGridLoopItemsEmptyFunc.
     *
     * @return void
     */
    function ifGridLoopItemsEmptyFunc()
    {
        $empty_image = BOROBAZAR_HELPER_ASSETS . 'global/images/not-found.svg';
        $template = new Classes();

        return $template->borobazar_get_template_part(
            'global/empty_grid.php',
            [
                'empty_image' => $empty_image,
                'alt_image' => esc_html__('Nothing Found', 'borobazar-helper'),
                'empty_message' => esc_html__('Nothing Found :(', 'borobazar-helper'),
            ]
        );
    }
}

if (!function_exists('ifShortCodeHeading')) {
    /**
     * ifShortCodeHeading.
     *
     * @return void
     */
    function ifShortCodeHeading($attributes)
    {
        $html = $headerTitle = '';
        $showHeading = false;

        $headerTitle = isset($attributes) ? $attributes['headerTitle'] : esc_html__('On sale', 'borobazar-helper');
        $buttonTtitle = isset($attributes) ? $attributes['buttonTtitle'] : esc_html__('See All Product', 'borobazar-helper');
        $showHeading = isset($attributes) ? $attributes['showHeading'] : false;

        if ($showHeading && (!empty($headerTitle) || !empty($buttonTtitle))) {
            $html .= '<div class="gs-grid-section-heading">';
            if (!empty($headerTitle)) {
                $html .= '<h2 class="gs-grid-heading-title">';
                $html .= esc_html($headerTitle, 'borobazar-helper');
                $html .= '</h2>';
            }
            if (!empty($buttonTtitle)) {
                $html .= '<a href="' . esc_url(wc_get_page_permalink('shop')) . '" class="gs-grid-button">';
                $html .= esc_html($buttonTtitle, 'borobazar-helper');
                $html .= '</a>';
            }
            $html .= '</div>';
        }
        echo apply_filters('if_grid_block_heading_html', $html);
    }
}

if (!function_exists('ifGridSliderStart')) {
    /**
     * ifGridSliderStart.
     *
     * @return void
     */
    function ifGridSliderStart()
    {
        $html = '';
        $html .= '<div class="swiper product-category-slider"> <div class="swiper-wrapper">';
        echo apply_filters('if_product_slider_start', $html);
    }
}

if (!function_exists('ifGridSliderEnd')) {
    /**
     * ifGridSliderEnd.
     *
     * @return void
     */
    function ifGridSliderEnd()
    {
        $html = '';
        $html .= '</div> </div>';
        echo apply_filters('if_product_slider_end', $html);
    }
}


if (!function_exists('ifSearchBlockRenderBefore')) {
    /**
     * ifSearchBlockRenderBefore.
     *
     * @param string $customClass
     * @param string $padding
     *
     * @return void
     */
    function ifSearchBlockRenderBefore($attributes, $customClass, $padding)
    {
        $template = new Classes();

        return $template->borobazar_get_template_part(
            'global/template_render_before_search.php',
            [
                'attributes' => $attributes,
                'customClass' => $customClass,
                'padding' => $padding,
            ]
        );
    }
}

if (!function_exists('ifSearchBlockRenderAfter')) {
    /**
     * ifSearchBlockRenderAfter.
     *
     * @return void
     */
    function ifSearchBlockRenderAfter()
    {
        $template = new Classes();

        return $template->borobazar_get_template_part(
            'global/template_render_after_search.php',
            []
        );
    }
}

// ifGridSliderStart
// ifGridSliderEnd

if (!function_exists('ifTemplateRenderBeforeWrap')) {
    /**
     * ifTemplateRenderBeforeWrap.
     *
     * @param string $customClass
     * @param string $padding
     *
     * @return void
     */
    function ifTemplateRenderBeforeWrap($customClass, $padding)
    {
        $template = new Classes();

        return $template->borobazar_get_template_part(
            'global/template_render_before.php',
            [
                'customClass' => $customClass,
                'padding' => $padding,
            ]
        );
    }
}

if (!function_exists('ifTemplateRenderAfterWrap')) {
    /**
     * ifTemplateRenderAfterWrap.
     *
     * @return void
     */
    function ifTemplateRenderAfterWrap()
    {
        $template = new Classes();

        return $template->borobazar_get_template_part(
            'global/template_render_after.php',
            []
        );
    }
}

if (!function_exists('ifGridLoopItemThumbnailsFunc')) {
    /**
     * ifGridLoopItemThumbnailsFunc.
     *
     * @return void
     */
    function ifGridLoopItemThumbnailsFunc($post_ID, $thumbnail_url, $gallery, $fallback_img = '', $slider = '')
    {
        $html = $animation = $borobazarhelper_settings = '';
        $splicedGalleryIDs = [];
        $borobazarhelper_settings = get_option('borobazarhelper_settings');
        $animation = !empty($borobazarhelper_settings) ? $borobazarhelper_settings['if_lazyload_images'] : '';

        if (!empty($borobazarhelper_settings) && $animation !== 'false') {
            $html .= ' <lottie-player class="gs-image-loader" src="' . esc_url(BOROBAZAR_HELPER_ASSETS . 'global/data/image-loader-data.json') . '"
            background="transparent" speed="1" style="width: 300px; height: 300px;" loop autoplay></lottie-player>';
        } else {
            $html .= '<svg xmlns="http://www.w3.org/2000/svg" class="gs-image-loader" width="38" height="38" viewBox="0 0 38 38"
            stroke="#212121">
            <g fill="none" fill-rule="evenodd">
                <g transform="translate(1 1)" stroke-width="2">
                <circle stroke-opacity=".3" cx="18" cy="18" r="18" />
                <path d="M36 18c0-9.94-8.06-18-18-18">
                    <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur="1s"
                    repeatCount="indefinite" />
                </path>
                </g>
            </g>
            </svg>';
        }
        $html .= '<img class="lazyload gs-lazy-image" src="' . $thumbnail_url . '" alt="item-image-' . $post_ID . '">';
        if (!empty($gallery)) {
            ifGridLoopItemThumbnailGalleryFunc($gallery, $fallback_img);
        }

        echo apply_filters('if_grid_loop_item_image', $html);
    }
}

if (!function_exists('ifGridLoopItemThumbnailGalleryFunc')) {
    /**
     * ifGridLoopItemThumbnailGalleryFunc
     *
     * @param  array $gallery
     * @param  string $fallback_img
     * @return void
     */
    function ifGridLoopItemThumbnailGalleryFunc($gallery, $fallback_img)
    {
        $html = '';
        if (!empty($gallery) && isset($gallery)) {
            foreach ($gallery as $key => $image) {
                if (is_array($image)) {
                    $url = !empty($image['url']) ? $image['url'] : $fallback_img;
                    $html .= ' <img class="thumb-1" src="' . esc_url($url) . '" alt="product-grid-gallery-item">';
                } else {
                    $url = !empty(wp_get_attachment_url($image, 'full')) ? wp_get_attachment_url($image, 'full') : $fallback_img;
                    $html .= ' <img class="thumb-1" src="' . esc_url($url) . '" alt="product-grid-gallery-item">';
                }
            }
        }
        echo apply_filters('if_grid_loop_item_image_gallery', $html);
    }
}
