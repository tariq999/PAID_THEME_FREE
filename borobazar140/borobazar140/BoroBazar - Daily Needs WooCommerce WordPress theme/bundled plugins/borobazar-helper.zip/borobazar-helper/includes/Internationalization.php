<?php

namespace BoroBazarHelper\Front;

// Exit if accessed directly.
defined('ABSPATH') || exit;
/**
 * Internationalization.
 */
class Internationalization
{
    /**
     * __construct.
     */
    public function __construct()
    {
        add_action('init', [$this, 'loadTextDomain']);
    }

    /**
     * loadTextDomain.
     */
    public function loadTextDomain()
    {
        load_plugin_textdomain(
            'borobazar-helper',
            false,
            'borobazar-helper/languages'
        );
    }
}
