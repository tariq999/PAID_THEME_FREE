<?php
// Utility Functions

//Background styles for block
if (!function_exists('getBoroBazarBackgroundStyles')) {
    /**
     * getBoroBazarBackgroundStyles
     *
     * @param  mixed $attributes
     * @return string
     */
    function getBoroBazarBackgroundStyles($attributes)
    {
        extract($attributes);
        $styles = '';
        $styles .= 'background-color:' . $backgroundColor . ';';
        if ($backgroundImage) {
            $styles .= 'background-image:' . 'url(' . $backgroundImage . ');';
            $styles .= 'background-size:' . $backgroundSize . ';';
            $styles .= 'background-attachment:' . $backgroundAttachment . ';';
            $styles .= 'background-repeat:' . $backgroundRepeat . ';';
            $styles .= 'background-position-x:' . $backgroundPositionX . ';';
            $styles .= 'background-position-y:' . $backgroundPositionY . ';';
        }

        return $styles;
    }
}

//Mobile Background styles for block
if (!function_exists('getBoroBazarBackgroundStylesForMobile')) {
    /**
     * getBoroBazarBackgroundStyles
     *
     * @param  mixed $attributes
     * @return string
     */
    function getBoroBazarBackgroundStylesForMobile($attributes)
    {
        extract($attributes);
        $styles = '';
        $styles .= 'background-color:' . $backgroundColorForMobile . ';';
        if ($backgroundImage) {
            $styles .= 'background-image:' . 'url(' . $backgroundImageForMobile . ');';
            $styles .= 'background-size:' . $backgroundSizeForMobile . ';';
            $styles .= 'background-attachment:' . $backgroundAttachmentForMobile . ';';
            $styles .= 'background-repeat:' . $backgroundRepeatForMobile . ';';
            $styles .= 'background-position-x:' . $backgroundPositionXForMobile . ';';
            $styles .= 'background-position-y:' . $backgroundPositionYForMobile . ';';
        }

        return $styles;
    }
}

//Padding styles for block
if (!function_exists('getBoroBazarPaddingStyles')) {
    /**
     * getBoroBazarPaddingStyles
     *
     * @param  mixed $attributes
     * @return string
     */
    function getBoroBazarPaddingStyles($attributes)
    {
        extract($attributes);
        $styles = '';
        $styles .= '--desktop-padding-top:' . $paddingTop['desktop'] . 'px;';
        $styles .= '--laptop-padding-top:' . $paddingTop['laptop'] . 'px;';
        $styles .= '--tab-padding-top:' . $paddingTop['tab'] . 'px;';
        $styles .= '--mobile-padding-top:' . $paddingTop['mobile'] . 'px;';
        $styles .= '--desktop-padding-right:' . $paddingRight['desktop'] . 'px;';
        $styles .= '--laptop-padding-right:' . $paddingRight['laptop'] . 'px;';
        $styles .= '--tab-padding-right:' . $paddingRight['tab'] . 'px;';
        $styles .= '--mobile-padding-right:' . $paddingRight['mobile'] . 'px;';
        $styles .= '--desktop-padding-bottom:' . $paddingBottom['desktop'] . 'px;';
        $styles .= '--laptop-padding-bottom:' . $paddingBottom['laptop'] . 'px;';
        $styles .= '--tab-padding-bottom:' . $paddingBottom['tab'] . 'px;';
        $styles .= '--mobile-padding-bottom:' . $paddingBottom['mobile'] . 'px;';
        $styles .= '--desktop-padding-left:' . $paddingLeft['desktop'] . 'px;';
        $styles .= '--laptop-padding-left:' . $paddingLeft['laptop'] . 'px;';
        $styles .= '--tab-padding-left:' . $paddingLeft['tab'] . 'px;';
        $styles .= '--mobile-padding-left:' . $paddingLeft['mobile'] . 'px;';

        return $styles;
    }
}

//Padding styles for block
if (!function_exists('getBoroBazarMarginStyles')) {
    /**
     * getBoroBazarMarginStyles
     *
     * @param  mixed $attributes
     * @return string
     */
    function getBoroBazarMarginStyles($attributes)
    {
        extract($attributes);
        $styles = '';
        $styles .= '--desktop-margin-top:' . $marginTop['desktop'] . 'px;';
        $styles .= '--laptop-margin-top:' . $marginTop['laptop'] . 'px;';
        $styles .= '--tab-margin-top:' . $marginTop['tab'] . 'px;';
        $styles .= '--mobile-margin-top:' . $marginTop['mobile'] . 'px;';
        $styles .= '--desktop-margin-right:' . $marginRight['desktop'] . 'px;';
        $styles .= '--laptop-margin-right:' . $marginRight['laptop'] . 'px;';
        $styles .= '--tab-margin-right:' . $marginRight['tab'] . 'px;';
        $styles .= '--mobile-margin-right:' . $marginRight['mobile'] . 'px;';
        $styles .= '--desktop-margin-bottom:' . $marginBottom['desktop'] . 'px;';
        $styles .= '--laptop-margin-bottom:' . $marginBottom['laptop'] . 'px;';
        $styles .= '--tab-margin-bottom:' . $marginBottom['tab'] . 'px;';
        $styles .= '--mobile-margin-bottom:' . $marginBottom['mobile'] . 'px;';
        $styles .= '--desktop-margin-left:' . $marginLeft['desktop'] . 'px;';
        $styles .= '--laptop-margin-left:' . $marginLeft['laptop'] . 'px;';
        $styles .= '--tab-margin-left:' . $marginLeft['tab'] . 'px;';
        $styles .= '--mobile-margin-left:' . $marginLeft['mobile'] . 'px;';

        return $styles;
    }
}

// make full width element based when align is full
if (!function_exists('makeFullWidthElement')) {
    /**
     * makeFullWidthElement
     *
     * @param  string
     * @return string
     */
    function makeFullWidthElement($align)
    {
        if ($align === 'full') {
            return 'relative w-screen -ml-50vw left-2/4';
        } else {
            return '';
        }
    }
}

// height styles for block
if (!function_exists('getBoroBazarHeightStyles')) {
    /**
     * getBoroBazarHeightStyles
     *
     * @param  mixed $attributes
     * @return string
     */
    function getBoroBazarHeightStyles($attributes)
    {
        extract($attributes);
        $styles = '';
        $styles .= '--desktop-height:' . $height['desktop'] . 'px;';
        $styles .= '--laptop-height:' . $height['laptop'] . 'px;';
        $styles .= '--tab-height:' . $height['tab'] . 'px;';
        $styles .= '--mobile-height:' . $height['mobile'] . 'px;';

        return $styles;
    }
}

// box shadow for block
if (!function_exists('getBoroBazarShadowStyles')) {
    /**
     * getBoroBazarShadowStyles
     *
     * @param  mixed $attributes
     * @return string
     */
    function getBoroBazarShadowStyles($attributes)
    {
        extract($attributes);
        $horizontal = $boxShadow['horizontal'] ? $boxShadow['horizontal'] : 0;
        $vertical   = $boxShadow['vertical'] ? $boxShadow['vertical'] : 0;
        $blur       = $boxShadow['blur'] ? $boxShadow['blur'] : 0;
        $spread     = $boxShadow['spread'] ? $boxShadow['spread'] : 0;
        $color      = $boxShadow['color'] ? $boxShadow['color'] : "rgba(0, 0, 0, 1)";

        return '--block-shadow: ' . $horizontal . 'px ' . $vertical . 'px ' . $blur . 'px ' . $spread . 'px ' . $color;
    }
}


if (!function_exists('borobazarGetPages')) {
    /**
     * Get all pages
     *
     * @return array
     */
    function borobazarGetPages()
    {
        $args = array(
            'post_type'   => 'page',
            'sort_order'  => 'asc',
            'sort_column' => 'post_title',
            'post_status' => 'publish'
        );

        $pages = get_pages($args);

        $results[] = 'Please Select';

        foreach ($pages as $key => $page) {
            $results[$page->ID] = $page->post_title;
        }

        return $results;
    }
}

if (!function_exists('borobazarGetTranslatedSearchPageID')) {
    /**
     * borobazarGetTranslatedSearchPageID
     *
     * @param  mixed $object_id
     * @param  string $type
     * @return void
     */
    function borobazarGetTranslatedSearchPageID($object_id, $type)
    {
        $current_language = apply_filters('wpml_current_language', NULL);
        // if array
        if (is_array($object_id)) {
            $translated_object_ids = array();
            foreach ($object_id as $id) {
                $translated_object_ids[] = apply_filters('wpml_object_id', $id, $type, true, $current_language);
            }
            return $translated_object_ids;
        }
        // if string
        elseif (is_string($object_id)) {
            // check if we have a comma separated ID string
            $is_comma_separated = strpos($object_id, ",");

            if ($is_comma_separated !== FALSE) {
                // explode the comma to create an array of IDs
                $object_id     = explode(',', $object_id);

                $translated_object_ids = array();
                foreach ($object_id as $id) {
                    $translated_object_ids[] = apply_filters('wpml_object_id', $id, $type, true, $current_language);
                }

                // make sure the output is a comma separated string (the same way it came in!)
                return implode(',', $translated_object_ids);
            }
            // if we don't find a comma in the string then this is a single ID
            else {
                return apply_filters('wpml_object_id', intval($object_id), $type, true, $current_language);
            }
        }
        // if int
        else {
            return apply_filters('wpml_object_id', $object_id, $type, true, $current_language);
        }
    }
}
