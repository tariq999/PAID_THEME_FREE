<?php

namespace BoroBazarHelper\Front;

defined('ABSPATH') || exit;

use BoroBazarHelper\Classes;
use BoroBazarHelper\Traits\BlockPostData;
use BoroBazarHelper\Traits\StyleScriptLoader;

/**
 * Scripts.
 */
class Scripts
{
    use StyleScriptLoader;
    use BlockPostData;

    /**
     * __construct.
     */
    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'loadScripts']);
    }

    /**
     * loadScripts.
     */
    public function loadScripts()
    {
        $searchPageSlug = $searchPage = '';
        $transfer_data = new Classes();
        $isSearchPage = function_exists('borobazar_is_search_page') ? borobazar_is_search_page() : true;
        $searchPage = (int) get_theme_mod('borobazar_search_page');

        if (!empty($searchPage)) {
            if (class_exists('SitePress')) {
                $translatedSearchPage = borobazarGetTranslatedSearchPageID($searchPage, 'page');
                $searchPageSlug = esc_url(get_permalink($translatedSearchPage));
            } else {
                $searchPageSlug = esc_url(get_permalink($searchPage));
            }
        }

        self::registerScripts();

        // jQuery Toast
        self::enqueueScript('jquery.toast.min');

        // Load google map script only for store map block
        if (class_exists('Load_Google_Map')) {
            $googlemap_settings = get_option('googlemap_settings', true);
            if (isset($googlemap_settings)) {
                if (isset($googlemap_settings['googlemap_enable']) && $googlemap_settings['googlemap_enable'] === 'enable' && isset($googlemap_settings['googlemap_api_key']) && $googlemap_settings['googlemap_api_key'] !== '') {

                    if (has_block('borobazar-blocks/borobazar-store-map')) {
                        wp_register_script('google-map-api', '//maps.googleapis.com/maps/api/js?key=' . $googlemap_settings['googlemap_api_key'] . '&libraries=places,geometry&language=en-US', ['jquery', 'underscore'], true, false);
                        wp_enqueue_script('google-map-api');
                        wp_register_script('borobazar-helper-map', BOROBAZAR_HELPER_ASSETS . 'client/js/borobazar-helper-map.js', ['google-map-api'], true, false);
                        wp_enqueue_script('borobazar-helper-map');
                    }
                }
            }
        }

        // Global Search Area
        if (!$isSearchPage || !has_block('borobazar-blocks/borobazar-search-block') || !has_block('borobazar-blocks/borobazar-extended-search-block')) {
            self::enqueueScript('borobazar-global-native-search');
            self::localizeScripts('borobazar-global-native-search', 'BOROBAZAR_GLOBAL_SEARCH', [
                'ajax_url'          => admin_url('admin-ajax.php'),
                'action'            => 'borobazar_helper_ajax',
                'nonce'             => wp_create_nonce('borobazar_helper_ajax_nonce'),
                'cartItems'         => self::checkIFProductInCart(),
                'scrollExtraHeight' => get_theme_mod('borobazar_scroll_extra_height', 100),
                'lang'              => class_exists('SitePress') ? ICL_LANGUAGE_CODE : '',
            ]);
            $productTemplate = !class_exists('SitePress') ? 'grid/grid_global_search.php' : 'grid/grid_global_search_wpml.php';
            $transfer_data->borobazar_get_template_part($productTemplate, [
                'showHiddenProduct' => get_theme_mod('woo_hidden_product_switch', 'off'),
            ]);
        }

        // Native Search
        if ((has_block('borobazar-blocks/borobazar-search-block') || has_block('borobazar-blocks/borobazar-extended-search-block')) && has_block('borobazar-blocks/borobazar-search-result')) {
            wp_dequeue_script('borobazar-global-native-search');
            self::enqueueScript('borobazar-native-search');
            self::localizeScripts('borobazar-native-search', 'BOROBAZAR_SEARCH', [
                'ajax_url'          => admin_url('admin-ajax.php'),
                'action'            => 'borobazar_helper_ajax',
                'nonce'             => wp_create_nonce('borobazar_helper_ajax_nonce'),
                'cartItems'         => self::checkIFProductInCart(),
                'loadMoreProductBy' => get_theme_mod('borobazar_load_more_product_by', 'click'),
                'scrollExtraHeight' => get_theme_mod('borobazar_scroll_extra_height', 100),
                'lang'              => class_exists('SitePress') ? ICL_LANGUAGE_CODE : '',
            ]);
        }

        // Banner search
        if (has_block('borobazar-blocks/search-banner')) {
            self::enqueueScript('borobazar-banner-search');
            self::localizeScripts('borobazar-banner-search', 'BOROBAZAR_BANNER_SEARCH', [
                'ajax_url'          => admin_url('admin-ajax.php'),
                'action'            => 'borobazar_helper_ajax',
                'nonce'             => wp_create_nonce('borobazar_helper_ajax_nonce'),
                'scrollExtraHeight' => get_theme_mod('borobazar_scroll_extra_height', 100),
                'siteUrl'           => site_url(),
                'isMultiSite'       => is_multisite(),
                'searchPageSlug'    => $searchPageSlug,
                'siteSlug'          => get_theme_mod('borobazar_site_slug'),
                'hasQuickSearch'    => has_block('borobazar-blocks/borobazar-search-block'),
                'hasExtendedSearch' => has_block('borobazar-blocks/borobazar-extended-search-block'),
            ]);
        }

        // mini-cart area quick carting ajax
        self::enqueueScript('borobazar-woo-mini-quick-cart');
        wp_localize_script('borobazar-woo-mini-quick-cart', 'mini_quick_cart_woocommerce', [
            'ajax_url'       => admin_url('admin-ajax.php'),
            'message'        => esc_html__('Message from ', 'borobazar-helper'),
            'cartItems'      => self::checkIFProductInCart(),
            'addToCartTimer' => get_theme_mod('woo_mini_cart_timer', 3500),
            'nonce'          => wp_create_nonce('mini_cart_ajax_nonce'),
        ]);

        // Quick Cart area
        self::enqueueScript('borobazar-woo-quick-cart');
        self::localizeScripts('borobazar-woo-quick-cart', 'IF_WOOCOMMERCE', [
            'ajax_url'       => admin_url('admin-ajax.php'),
            'message'        => esc_html__('Message from ', 'borobazar-helper'),
            'cartItems'      => self::checkIFProductInCart(),
            'addToCartTimer' => get_theme_mod('woo_mini_cart_timer', 3500),
            'nonce'          => wp_create_nonce('borobazar_helper_ajax_nonce'),
        ]);

        // Helper main
        self::enqueueScript('borobazar-helper-main');
        self::localizeScripts('borobazar-helper-main', 'BOROBAZAR_HELPER_DATA', [
            'action'         => 'borobazar_helper_ajax',
            'ajax_url'       => admin_url('admin-ajax.php'),
            'nonce'          => wp_create_nonce('borobazar_helper_ajax_nonce'),
            'siteUrl'        => site_url(),
            'isMultiSite'    => is_multisite(),
            'searchPageSlug' => $searchPageSlug,
            'siteSlug'       => get_theme_mod('borobazar_site_slug'),
        ]);
    }

    /**
     * registerScripts.
     */
    private static function registerScripts()
    {
        $register_scripts = apply_filters('borobazar_frontend_scripts_array', [
            'jquery.toast.min'               => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'client/library/jquery.toast.min.js',
                'deps'    => [],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'borobazar-woo-quick-cart'       => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'client/js/woo-quick-cart.js',
                'deps'    => ['jquery.toast.min'],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'borobazar-woo-mini-quick-cart'  => [
                'src'     => BOROBAZAR_HELPER_WOO_QUICK_CART . 'js/woo-mini-carting.js',
                'deps'    => ['jquery.toast.min'],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'borobazar-native-search'        => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'client/js/borobazar-native-search.js',
                'deps'    => ['jquery', 'underscore', 'wp-i18n'],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'borobazar-global-native-search' => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'client/js/borobazar-global-native-search.js',
                'deps'    => ['jquery', 'underscore', 'wp-i18n'],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'borobazar-banner-search'        => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'client/js/borobazar-banner-search.js',
                'deps'    => ['jquery', 'underscore'],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'borobazar-category-sirius'      => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'client/js/category-slider/borobazar-sirius.js',
                'deps'    => ['jquery', 'swiper'],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'borobazar-category-vega'        => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'client/js/category-slider/borobazar-vega.js',
                'deps'    => ['jquery', 'swiper'],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'borobazar-category-rigel'       => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'client/js/category-slider/borobazar-rigel.js',
                'deps'    => ['jquery', 'swiper'],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
            'borobazar-helper-main'          => [
                'src'     => BOROBAZAR_HELPER_ASSETS . 'client/js/borobazar-helper-main.js',
                'deps'    => [],
                'version' => BOROBAZAR_HELPER_VERSION,
            ],
        ]);

        foreach ($register_scripts as $name => $key) {
            self::registerScript($name, $key['src'], $key['deps'], $key['version']);
        }
    }
}
