/**
 * Gutenberg Blocks
 *
 * All blocks related JavaScript files should be imported here.
 * You can create a new block folder in this dir and include code
 * for that block here as well.
 *
 * All blocks should be included here since this is the file that
 * Webpack is compiling as the input file.
 */

// Global styles
import './editor.scss';
import './style.scss';

// Block Category
import './block-category';

// blocks
import './block/accordion';
import './block/category-grid';
import './block/contact-form';
import './block/extended-search';
import './block/scroll-to-content';
import './block/search';
import './block/search-results';
import './block/slider';
import './block/collection';
import './block/app';
import './block/call-to-cation';
import './block/search-banner';
import './block/store-map';
import './block/wrapper';
import './block/contact-info';
import './block/media-and-text';
import './block/counter';
import './block/image';
import './block/team';
import './block/posts';
// widgets
import './block/widgets/about';
import './block/widgets/quick-links';
import './block/widgets/newsletter';

//Layout
import './layout';

// settings
import './termMetaSettings/add';
import './termMetaSettings/edit';
