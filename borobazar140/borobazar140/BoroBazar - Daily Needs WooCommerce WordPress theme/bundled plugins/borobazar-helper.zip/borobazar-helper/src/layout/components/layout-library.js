/**
 * Layout Library UI.
 *
 * Interface for browsing, searching, filtering and inserting sections and layouts.
 */

/**
 * Dependencies.
 */
import map from "lodash/map";
import classnames from "classnames";
import LayoutLibraryItem from "./layout-library-item";
import { LayoutsContext } from "../layouts-provider";

/**
 * WordPress dependencies.
 */
const { __ } = wp.i18n;
const { Component, Fragment } = wp.element;
const {
  Button,
  ButtonGroup,
  TextControl,
  SelectControl,
  Dashicon,
  Tooltip,
} = wp.components;

export default class LayoutLibrary extends Component {
  constructor() {
    super(...arguments);

    this.state = {
      category: "all",
      search: undefined,
      activeView: "grid",
    };
  }

  /* Conditionally load the layout array based on the tab. */
  getLayoutArray() {
    let component = [];

    switch (this.props.currentTab) {
      case "borobazar-layouts-tab-layouts":
        component = this.props.context.layouts;
        break;
      case "borobazar-layouts-tab-sections":
        component = this.props.context.sections;
        break;
      case "borobazar-layouts-tab-favorites":
        component = this.props.context.favorites;
        break;
    }

    return component;
  }

  render() {
    /* Grab the layout array. */
    const blockLayout = this.getLayoutArray();
    /* Set a default category. */
    const cats = ["all"];

    /* Build a category array. */
    if (blockLayout && blockLayout.length) {
      for (let i = 0; i < blockLayout.length; i++) {
        for (let c = 0; c < blockLayout[i].category.length; c++) {
          if (!cats.includes(blockLayout[i].category[c])) {
            cats.push(blockLayout[i].category[c]);
          }
        }
      }
    }

    /* Setup categories for select menu. */
    const catOptions = cats.map((item) => {
      return {
        value: item,
        label: item.charAt(0).toUpperCase() + item.slice(1),
      };
    });

    /* Expand each layout full width. */
    const onZoom = () => {
      const imageZoom = document.querySelector(".borobazar-layouts-zoom-button");
      imageZoom.parentNode.classList.toggle("borobazar-layouts-zoom-layout");
    };
    return (
      <Fragment key={"layout-library-fragment-" + this.props.clientId}>
        {/* Category filter and search header. */}
        <div className="borobazar-layouts-modal-header">
          <SelectControl
            key={"layout-library-select-categories-" + this.props.clientId}
            label={__("Categories", "borobazar-helper")}
            value={this.state.category}
            options={catOptions}
            onChange={(value) => this.setState({ category: value })}
          />
          <TextControl
            key={"layout-library-search-layouts-" + this.props.clientId}
            type="text"
            value={this.state.search}
            placeholder={__("Search...", "borobazar-helper")}
            onChange={(value) => this.setState({ search: value })}
          />
          <div className={"borobazar-layouts-view"}>
            {/* {
						<div className={'borobazar-layouts-view-left'}>
							<p>
								{__('Showing: ', 'borobazar-helper') + this.props &&
								this.props.data &&
								this.props.data.length
									? this.props.data.length
									: 0}
							</p>
						</div>
					} */}

            {/* Grid width view. */}
            <div className={"borobazar-layouts-view-right"}>
              {/* Full width layout view. */}
              <Tooltip
                key={"layout-library-full-view-tooltip-" + this.props.clientId}
                text={__("Full Width View", "borobazar-helper")}
              >
                <Button
                  key={"layout-library-full-view-button-" + this.props.clientId}
                  className={classnames(
                    this.state.activeView === "full"
                      ? "borobazar-btn-active"
                      : null,
                    "borobazar-layouts-full-view-button"
                  )}
                  isSmall
                  onClick={() =>
                    this.setState({
                      activeView: "full",
                    })
                  }
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 18 18"
                  >
                    <path
                      id="Path_18879"
                      data-name="Path 18879"
                      d="M0,0H18V18H0Z"
                      fill="none"
                    />
                    <rect
                      id="Rectangle_1934"
                      data-name="Rectangle 1934"
                      width="12"
                      height="12"
                      rx="2"
                      transform="translate(3 3)"
                      stroke-width="1.5"
                      stroke="currentColor"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      fill="none"
                    />
                  </svg>
                </Button>
              </Tooltip>
              <Tooltip
                key={"layout-library-grid-view-tooltip-" + this.props.clientId}
                text={__("Grid View", "borobazar-helper")}
              >
                <Button
                  key={"layout-library-grid-view-button-" + this.props.clientId}
                  className={classnames(
                    this.state.activeView === "grid"
                      ? "borobazar-btn-active"
                      : null,
                    "borobazar-layouts-grid-view-button"
                  )}
                  isSmall
                  onClick={() =>
                    this.setState({
                      activeView: "grid",
                    })
                  }
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    viewBox="0 0 18 18"
                  >
                    <path
                      id="Path_18879"
                      data-name="Path 18879"
                      d="M0,0H18V18H0Z"
                      fill="none"
                    />
                    <rect
                      id="Rectangle_1934"
                      data-name="Rectangle 1934"
                      width="12"
                      height="12"
                      rx="2"
                      transform="translate(3 3)"
                      stroke-width="1.5"
                      stroke="currentColor"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      fill="none"
                    />
                    <line
                      id="Line_20"
                      data-name="Line 20"
                      y2="12"
                      transform="translate(9 3)"
                      fill="none"
                      stroke="currentColor"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="1.5"
                    />
                  </svg>
                </Button>
              </Tooltip>
            </div>
          </div>
        </div>

        <LayoutsContext.Consumer>
          {(context) => (
            <ButtonGroup
              key={"layout-library-context-button-group-" + this.props.clientId}
              className={classnames(
                "borobazar-layouts-choices",
                this.state.activeView === "full"
                  ? "borobazar-layouts-view-full"
                  : null
              )}
              aria-label={__("Layout Options", "borobazar-helper")}
            >
              {map(
                this.props.data,
                ({ name, key, image, content, category, keywords }) => {
                  if (
                    ("all" === this.state.category ||
                      category.includes(this.state.category)) &&
                    (!this.state.search ||
                      (keywords &&
                        keywords.some((x) =>
                          x
                            .toLowerCase()
                            .includes(this.state.search.toLowerCase())
                        )))
                  ) {
                    return (
                      /* Section and layout items. */
                      <LayoutLibraryItem
                        key={"layout-library-item-" + key}
                        name={name}
                        itemKey={
                          key
                        } /* 'key' is reserved, so we use itemKey. */
                        image={image}
                        content={content}
                        context={context}
                        clientId={this.props.clientId}
                      />
                    );
                  }
                }
              )}
            </ButtonGroup>
          )}
        </LayoutsContext.Consumer>
      </Fragment>
    );
  }
}
