/**
 * BLOCK: BoroBazar Blocks Layout
 */

/**
 * Import dependencies.
 */
import LayoutsProvider from "./layouts-provider";
import "./styles/style.scss";
import "./styles/editor.scss";
import Modal from "./components/layout-modal";
const { __ } = wp.i18n;

/**
 * Add a Layout button to the toolbar.
 */

// document.addEventListener('DOMContentLoaded', appendImportButton);
window.addEventListener(
	"load",
	function () {
		setTimeout(() => {
			appendImportButton();
		}, 5000);
	},
	false
);

/**
 * Build the layout inserter button.
 */
function appendImportButton() {
	const toolbar = document.querySelector(".edit-post-header");
	const toolbarSettings = document.querySelector(".edit-post-header__settings");
	if (!toolbar) {
		return;
	}
	const buttonDiv = document.createElement("div");
	let html = '<div class="borobazar-toolbar-insert-layout">';
	html += `<button id="borobazarLayoutButton" class="components-button components-icon-button is-tertiary" aria-label="${__(
		"BoroBazar Layouts",
		"borobazar-helper"
	)}"><svg width="22" height="22" viewBox="0 0 80 80" fill="none" style="margin:0 5px;" xmlns="http://www.w3.org/2000/svg">
  <rect width="80" height="80" rx="22" fill="#02B290"/>
  <path fill-rule="evenodd" clip-rule="evenodd" d="M39.9998 55.459C36.2246 55.459 32.7913 53.328 31.2035 50.0205C30.8681 49.3224 31.1813 48.4885 31.9008 48.1632C32.6203 47.8378 33.4797 48.1416 33.8151 48.8398C34.9321 51.1668 37.3438 52.6622 39.9998 52.6622C42.6581 52.6622 45.0698 51.1668 46.1846 48.8398C46.5199 48.1395 47.3771 47.8378 48.0989 48.1632C48.8184 48.4885 49.1315 49.3203 48.7962 50.0205C47.2084 53.328 43.7751 55.459 39.9998 55.459ZM35.5828 21.5893C34.448 22.6903 33.744 24.2072 33.744 25.8728V27.6677H39.9998H46.2557V25.8728C46.2557 24.2051 45.5517 22.6882 44.4169 21.5893C41.9674 19.2126 38.0345 19.2126 35.5828 21.5893ZM24.6101 62.9746H39.9998H55.3896C57.7524 62.9746 59.8133 61.0935 59.6867 58.8053L58.1943 31.837C58.0678 29.5487 56.2601 27.6677 53.8972 27.6677H49.136V25.8728C49.136 23.4337 48.1077 21.2165 46.4533 19.6113C42.8979 16.1637 37.1018 16.1637 33.5464 19.6134C31.8919 21.2187 30.8637 23.4358 30.8637 25.875V27.6698H26.1024C23.7396 27.6698 21.9319 29.5509 21.8053 31.8392L20.313 58.8074C20.1886 61.0957 22.2472 62.9746 24.6101 62.9746Z" fill="white"/>
  </svg>
   ${__(" BoroBazar Layouts ", "borobazar-helper")}</button>`;
	html += "</div>";
	buttonDiv.innerHTML = html;
	toolbar.insertBefore(buttonDiv, toolbarSettings);
	document
		.getElementById("borobazarLayoutButton")
		.addEventListener("click", abInsertLayout);
}

/**
 * Add the Layout block on click.
 */
function abInsertLayout() {
	wp.element.render(
		<LayoutsProvider>
			<Modal />
		</LayoutsProvider>,
		document.createElement("div")
	);
	// const block = wp.blocks.createBlock('borobazar-blocks/borobazar-layouts');
	// wp.data.dispatch('core/editor').insertBlocks(block);
}
