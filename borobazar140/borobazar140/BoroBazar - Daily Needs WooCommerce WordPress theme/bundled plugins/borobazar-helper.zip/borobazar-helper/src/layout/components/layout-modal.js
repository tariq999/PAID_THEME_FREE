/**
 * Layout modal window with tab panel.
 */

import LayoutLibrary from "./layout-library";
import { LayoutsContext } from "../layouts-provider";
const { __ } = wp.i18n;
const { Component, Fragment } = wp.element;
const { Modal, TabPanel } = wp.components;

class LayoutModal extends Component {
	constructor() {
		super(...arguments);

		this.state = {
			modalOpen: true,
			currentTab: "borobazar-layouts-tab-sections",
		};
	}

	render() {
		return (
			<Fragment key={"layout-modal-fragment-" + this.props.clientId}>
				{/* Launch the layout modal window */}
				{this.state.modalOpen ? (
					<LayoutsContext.Consumer
						key={"layouts-context-provider-" + this.props.clientId}
					>
						{(context) => (
							<Modal
								key={"layout-modal-modal-component-" + this.props.clientId}
								className="borobazar-layouts-modal"
								title={
									<Fragment>
										{__(" BoroBazar Layouts ", "borobazar-helper")}
									</Fragment>
								}
								onRequestClose={() => this.setState({ modalOpen: false })}
							>
								<TabPanel
									key={"layout-modal-tabpanel-" + this.props.clientId}
									className="borobazar-layouts-modal-panel"
									activeClass="borobazar-layouts-modal-active-tab"
									onSelect={(tabName) =>
										this.setState({
											currentTab: tabName,
										})
									}
									tabs={[
										{
											name: "borobazar-layouts-tab-sections",
											title: __("Sections", "borobazar-helper"),
											className: "borobazar-layouts-tab-sections",
										},
										{
											name: "borobazar-layouts-tab-layouts",
											title: __("Pages", "borobazar-helper"),
											className: "borobazar-layouts-tab-layouts",
										},
									]}
								>
									{(tab) => {
										const tabContent = __(
											"Default tab content",
											"borobazar-helper"
										);

										if (tab.name) {
											if ("borobazar-layouts-tab-sections" === tab.name) {
												return [
													<LayoutLibrary
														key={
															"layout-library-sections-" + this.props.clientId
														}
														clientId={this.props.clientId}
														currentTab={this.state.currentTab}
														data={context.sections}
														context={context}
													/>,
												];
											}

											if ("borobazar-layouts-tab-layouts" === tab.name) {
												return [
													<LayoutLibrary
														key={
															"layout-library-layouts-" + this.props.clientId
														}
														clientId={this.props.clientId}
														currentTab={this.state.currentTab}
														data={context.layouts}
														context={context}
													/>,
												];
											}
										}
										return <div>{tabContent}</div>;
									}}
								</TabPanel>
							</Modal>
						)}
					</LayoutsContext.Consumer>
				) : null}
			</Fragment>
		);
	}
}
export default LayoutModal;
