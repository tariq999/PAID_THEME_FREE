export const BoroBazarIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="30"
    height="30"
    viewBox="0 0 30 30"
  >
    <defs>
      <linearGradient
        id="linear-gradient"
        x2="1"
        y2="1"
        gradientUnits="objectBoundingBox"
      >
        <stop offset="0" stop-color="#536ffc" />
        <stop offset="1" stop-color="#fc5c7d" />
      </linearGradient>
      <filter
        id="Path_18702"
        x="4.184"
        y="3.773"
        width="21.607"
        height="22.453"
        filterUnits="userSpaceOnUse"
      >
        <feOffset input="SourceAlpha" />
        <feGaussianBlur stdDeviation="0.5" result="blur" />
        <feFlood flood-opacity="0.161" />
        <feComposite operator="in" in2="blur" />
        <feComposite in="SourceGraphic" />
      </filter>
    </defs>
    <g id="thumb_80" data-name="thumb 80" transform="translate(15337 4562)">
      <circle
        id="Ellipse_2876"
        data-name="Ellipse 2876"
        cx="15"
        cy="15"
        r="15"
        transform="translate(-15337 -4562)"
        fill="url(#linear-gradient)"
      />
      <g
        transform="matrix(1, 0, 0, 1, -15337, -4562)"
        filter="url(#Path_18702)"
      >
        <path
          id="Path_18702-2"
          data-name="Path 18702"
          d="M1018.369,391.377a8.975,8.975,0,0,1,8.949,6.167h-4.393a4.8,4.8,0,0,0-4.584-2.729c-3.328,0-5.7,2.428-5.7,6.3,0,3.847,2.374,6.3,5.7,6.3a4.781,4.781,0,0,0,4.584-2.756h4.393c-1.282,3.928-4.721,6.166-8.949,6.166a9.727,9.727,0,0,1,0-19.453Z"
          transform="translate(-1003.03 -386.1)"
          fill="#fff"
        />
      </g>
    </g>
  </svg>
);
