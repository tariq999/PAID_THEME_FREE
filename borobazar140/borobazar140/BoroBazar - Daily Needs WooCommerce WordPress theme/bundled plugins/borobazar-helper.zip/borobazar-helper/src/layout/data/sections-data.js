export const sectionData = [
	{
		type: 'section',
		key: 'banner-default',
		name: 'Banner (Default)',
		content:
			'<!-- wp:borobazar-blocks/slider {"paddingTop":{"desktop":25,"laptop":25,"tab":20,"mobile":15},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":25,"laptop":25,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"slideItems":[{"slogan":"GROCERY STORE","title":"Free Delivery \u003cbr\u003efrom your area","description":"Get ready for spring as soon as\u003cbr\u003etoday with $0 delivery fees.","button":"Explore More","image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/12/Banner-1.webp","url":"https://borobazar.redq.io/search/","opensInNewTab":false,"contentPosition":"center left","textAlign":"left","backgroundPosition":"20% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#eaf2f5","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":450,"laptop":450,"tab":350,"mobile":200},"paddingTop":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingRight":{"desktop":60,"laptop":60,"tab":60,"mobile":25},"paddingBottom":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingLeft":{"desktop":60,"laptop":60,"tab":60,"mobile":25}},{"slogan":"BREAKFAST FOOD","title":"Fresh Healthy \u003cbr\u003ebreakfast food","description":"Get ready for spring as soon as \u003cbr\u003etoday with $0 delivery fees.","button":"Explore More","image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/12/Banner-2.webp","url":"https://borobazar.redq.io/search/","opensInNewTab":false,"contentPosition":"center left","textAlign":"left","backgroundPosition":"20% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f3f2f0","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":450,"laptop":450,"tab":350,"mobile":200},"paddingTop":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingRight":{"desktop":60,"laptop":60,"tab":60,"mobile":25},"paddingBottom":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingLeft":{"desktop":60,"laptop":60,"tab":60,"mobile":25}}],"template":"content","slidesPerView":{"desktop":2,"laptop":2,"tab":1,"mobile":1},"spaceBetween":{"desktop":20,"laptop":20,"tab":20,"mobile":20}} /-->',
		category: ['Default demo'],
		keywords: ['banner', 'home'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/banner-default.webp',
	},
	{
		type: 'section',
		key: 'banner-with-category',
		name: 'Banner with Category',
		content:
			'<!-- wp:borobazar-blocks/search-banner {"title":"Fresh food that deserve to eat","description":"Get your groceries items delivered in less than an hour","searchSuggestions":"Popular Search: Coconut, Meat, Vegetable, Apple, Orange","placeholder":"What are you looking for..","searchLayout":"rose","backgroundImage":"https://borobazar.redq.io/trendy/wp-content/uploads/sites/8/2022/03/banner-borobazar.png","minHeight":{"desktop":650,"laptop":500,"tab":450,"mobile":380},"className":"hide-br-mobile"} /--> <!-- wp:borobazar-blocks/category-grid {"categoryTemplate":"rigel","marginTop":{"desktop":"-33","laptop":"-30","tab":"-30","mobile":"-30"},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":40,"laptop":30,"tab":30,"mobile":15},"paddingBottom":{"desktop":90,"laptop":80,"tab":60,"mobile":60},"paddingLeft":{"desktop":40,"laptop":30,"tab":30,"mobile":15},"className":"-mt-12"} /-->',
		category: ['Trendy demo'],
		keywords: ['banner', 'hero', 'category'],
		image: 'https://s3.amazonaws.com/redqteam.com/borobazarwp/assets/2.webp',
	},
	{
		type: 'section',
		key: 'promo-slider',
		name: 'Promo slider',
		content:
			'<!-- wp:borobazar-blocks/slider {"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"slideItems":[{"slogan":"","title":"Refer friends \u0026amp; get 10% \u003cbr\u003eDiscount on all item.","description":"LEARN MORE","button":"Button","image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/11/refer-1.svg","url":"https://borobazar.redq.io/terms-condition/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#ffeed6","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#665f56","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":400,"laptop":400,"tab":300,"mobile":200},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Fastest delivery system\u003cbr\u003ethat we ever built.","description":"LEARN MORE","button":"Button","image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/11/Group-5.svg","url":"https://borobazar.redq.io/faq/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#ccedff","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#665f56","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Join inner cycle to help\u003cbr\u003e us improve our system.","description":"LEARN MORE","button":"Button","image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/11/feedback-1.svg","url":"https://borobazar.redq.io/contact/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#d7f1ec","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#665f56","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Share your thoughts with us and get prize.","description":"LEARN MORE","button":"Button","image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/11/favorites-1.svg","url":"https://borobazar.redq.io/terms-condition/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#ffe1e1","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}}],"template":"promo","slidesPerView":{"desktop":4,"laptop":3,"tab":2,"mobile":1.15},"spaceBetween":{"desktop":20,"laptop":20,"tab":20,"mobile":10}} /-->',
		category: ['Default demo'],
		keywords: ['slider', 'home', 'promotional'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/promo-slider.webp',
	},
	{
		type: 'section',
		key: 'best-seller',
		name: 'Best selling products',
		content: `<!-- wp:gridster/block-title {"title":"Best Sellers In Your Area","paddingTop":{"desktop":60,"laptop":60,"tab":45,"mobile":35},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":25,"laptop":25,"tab":20,"mobile":20},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15}} /-->

    <!-- wp:gridster/best-selling {"postsPerPage":10,"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"featured_product_view":"slider","showSeeAllButton":true} /-->`,
		category: ['Default demo'],
		keywords: ['gridster', 'best selling', 'product'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/best-seller.webp',
	},
	{
		type: 'section',
		key: 'best-selling-trendy',
		name: 'Best selling products (Trendy)',
		content: `<!-- wp:gridster/block-title {"title":"Best seller grocery near you","subTitle":"We provide best quality \u0026amp; fresh grocery items near your location","alignment":"center","paddingRight":{"desktop":40,"laptop":30,"tab":30,"mobile":15},"paddingBottom":{"desktop":60,"laptop":60,"tab":60,"mobile":60},"paddingLeft":{"desktop":40,"laptop":30,"tab":30,"mobile":15}} /-->

<!-- wp:gridster/best-selling {"postsPerPage":12,"gridTemplate":"grid_oak","paddingRight":{"desktop":40,"laptop":40,"tab":30,"mobile":15},"paddingBottom":{"desktop":80,"laptop":80,"tab":60,"mobile":60},"paddingLeft":{"desktop":40,"laptop":40,"tab":30,"mobile":15}} /-->`,
		category: ['Default demo'],
		keywords: ['gridster', 'best selling', 'product'],
		image: 'https://s3.amazonaws.com/redqteam.com/borobazarwp/assets/3.webp',
	},
	{
		type: 'section',
		key: 'super-deals',
		name: 'Super Deals (Trendy)',
		content: `<!-- wp:gridster/block-title {"title":"Super Deals","subTitle":"We provide best quality \u0026amp; fresh grocery items near your location","alignment":"center","paddingRight":{"desktop":40,"laptop":30,"tab":30,"mobile":15},"paddingBottom":{"desktop":60,"laptop":60,"tab":60,"mobile":40},"paddingLeft":{"desktop":40,"laptop":30,"tab":30,"mobile":15}} /-->

<!-- wp:gridster/super-deals {"postsPerPage":9,"gridTemplate":"grid_maple","paddingRight":{"desktop":40,"laptop":30,"tab":30,"mobile":15},"paddingBottom":{"desktop":90,"laptop":80,"tab":60,"mobile":60},"paddingLeft":{"desktop":40,"laptop":30,"tab":30,"mobile":15}} -->
<!-- wp:gridster/cherry-picked-one {"editMode":"false","post":[{"label":"Just Desserts Special Chocolate Cake","value":1069,"id":1069,"slug":"just-desserts-special-chocolate-cake"}]} /-->
<!-- /wp:gridster/super-deals -->`,
		category: ['Default demo'],
		keywords: ['gridster', 'super deals', 'countdown', 'product'],
		image: 'https://s3.amazonaws.com/redqteam.com/borobazarwp/assets/4.webp',
	},
	{
		type: 'section',
		key: 'selected-category',
		name: 'Selected category (e.g. Fresh Vegetables)',
		content: `<!-- wp:gridster/block-title {"title":"Fresh Vegetables","paddingTop":{"desktop":60,"laptop":60,"tab":45,"mobile":35},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":25,"laptop":25,"tab":20,"mobile":20},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15}} /-->

    <!-- wp:gridster/handpicked-category {"term":"fresh_vegetables","postsPerPage":15,"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"featured_product_view":"slider"} /-->`,
		category: ['Default demo'],
		keywords: ['gridster', 'fresh', 'product', 'category'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/vegetable.webp',
	},
	{
		type: 'section',
		key: 'curated-collections',
		name: 'Curated Collections',
		content: `<!-- wp:gridster/block-title {"title":"Curated Collections","paddingTop":{"desktop":60,"laptop":60,"tab":45,"mobile":35},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":25,"laptop":25,"tab":20,"mobile":20},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15}} /-->

    <!-- wp:borobazar-blocks/collections-block {"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"collectionItems":[{"image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/12/img.webp","url":"https://borobazar.redq.io/blog/an-assortment-of-cherries-for-energizing-the-fruits/","opensInNewTab":false,"title":"Feel the thirsty in Summer anytime","description":"Your body's way of telling you strongcription","button":"Explore","overlayOpacity":0,"overlay":"#000000","backgroundPosition":"50% 50%","bgColor":"#fff","titleColor":"#000","descriptionColor":"#808080","buttonColor":"#02b290","buttonHoverColor":"#01a585"},{"image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/12/img-1.webp","url":"https://borobazar.redq.io/blog/a-taste-of-blueberry-from-natures-perfection/","opensInNewTab":false,"title":"Most popular item for Fast food","description":"Tasty and spicy fast food with different flavors.","button":"Explore","overlayOpacity":0,"overlay":"#000000","backgroundPosition":"50% 50%","bgColor":"#fff","titleColor":"#000","descriptionColor":"#808080","buttonColor":"#02b290","buttonHoverColor":"#01a585"},{"image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/12/img-2.webp","url":"https://borobazar.redq.io/blog/feeling-of-love-is-not-lost-in-old-friends-in-home/","opensInNewTab":false,"title":"Authentic Japanese food in real taste","description":"Your body's way of telling you that it's make strong","button":"Explore","overlayOpacity":0,"overlay":"#000000","backgroundPosition":"50% 50%","bgColor":"#fff","titleColor":"#000","descriptionColor":"#808080","buttonColor":"#02b290","buttonHoverColor":"#01a585"},{"image":"https://borobazar.redq.io/wp-content/uploads-demo/2021/12/img-3.webp","url":"https://borobazar.redq.io/blog/simple-15-mins-fruity-cake-to-cherish-dishes/","opensInNewTab":false,"title":"Explore our Family of Freshpet® Foods","description":"Your pet’s way of telling you that it's make taste","button":"Explore","overlayOpacity":0,"overlay":"#000000","backgroundPosition":"50% 50%","bgColor":"#fff","titleColor":"#000","descriptionColor":"#808080","buttonColor":"#02b290","buttonHoverColor":"#01a585"}]} /-->`,
		category: ['Default demo'],
		keywords: ['selected', 'curated', 'collections'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/colleciton.webp',
	},
	{
		type: 'section',
		key: 'banner-modern',
		name: 'Search banner (Modern)',
		content:
			'<!-- wp:borobazar-blocks/search-banner {"title":"Healthy Vegetable that \u003cbr\u003eDeserve to Eat Fresh","description":"We source and sell the very best beef, lamb,\u003cbr\u003e fish \u0026amp; herbs with the care from farmers.","placeholder":"What are you looking for..","backgroundImage":"https://borobazar.redq.io/modern/wp-content/uploads-demo/sites/2/2021/12/banner.webp","minHeight":{"desktop":650,"laptop":500,"tab":450,"mobile":380},"className":"hide-br-mobile"} /-->',
		category: ['Modern demo'],
		keywords: ['search', 'hero', 'banner'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/banner-modern.webp',
	},
	{
		type: 'section',
		key: 'feature-slider',
		name: 'Feature slider',
		content:
			'<!-- wp:borobazar-blocks/slider {"paddingTop":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"slideItems":[{"slogan":"","title":"Refer spring cleaning for home appliance","description":"Get your clean on supplies.","button":"Button","image":"https://borobazar.redq.io/modern/wp-content/uploads-demo/sites/2/2021/12/img-2.png","url":"https://borobazar.redq.io/terms-condition/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#ffeed6","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#665f56","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":400,"laptop":400,"tab":300,"mobile":200},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Fast pet choice for fresh \u0026amp; healty food","description":"Get your clean on supplies.","button":"Button","image":"https://borobazar.redq.io/modern/wp-content/uploads-demo/sites/2/2021/11/2.png","url":"https://borobazar.redq.io/faq/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#d9ecd2","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#665f56","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Join washing item with big discount","description":"Get your clean on supplies.","button":"Button","image":"https://borobazar.redq.io/modern/wp-content/uploads-demo/sites/2/2021/11/3.png","url":"https://borobazar.redq.io/contact/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#dbe5ef","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#665f56","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Fresh quality meat\u003cbr\u003eitem with discount ","description":"Get your clean on supplies.","button":"Button","image":"https://borobazar.redq.io/modern/wp-content/uploads-demo/sites/2/2021/11/4.png","url":"https://borobazar.redq.io/terms-condition/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#efd8d4","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}}],"template":"feature","slidesPerView":{"desktop":4,"laptop":3,"tab":2,"mobile":1},"spaceBetween":{"desktop":20,"laptop":20,"tab":20,"mobile":10}} /-->',
		category: ['Modern demo', 'Standard demo', 'Vintage demo'],
		keywords: ['slider', 'feature', 'product'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/feature-slider.webp',
	},
	{
		type: 'section',
		key: 'categories-modern',
		name: 'Product Categories (Modern)',
		content: `<!-- wp:gridster/block-title {"title":"Choose categories from below","alignment":"center","paddingTop":{"desktop":70,"laptop":70,"tab":60,"mobile":40},"paddingBottom":{"desktop":40,"laptop":40,"tab":35,"mobile":25}} /-->

    <!-- wp:borobazar-blocks/category-grid {"categoryOrderBy":"name","categoryTemplate":"vega","paddingRight":{"desktop":40,"laptop":40,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":40,"tab":20,"mobile":15}} /-->`,
		category: ['Modern demo'],
		keywords: ['product', 'category', 'list', 'grid'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/categories-modern.webp',
	},
	{
		type: 'section',
		key: 'best-seller-modern',
		name: 'Best Selling Product (Modern)',
		content: `<!-- wp:gridster/block-title {"title":"Best seller grocery near you","alignment":"center","paddingTop":{"desktop":70,"laptop":70,"tab":60,"mobile":40},"paddingBottom":{"desktop":40,"laptop":40,"tab":35,"mobile":25}} /-->

    <!-- wp:gridster/best-selling {"postsPerPage":21,"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"showSeeAllButton":true} /-->`,
		category: ['Modern demo'],
		keywords: ['product', 'selling', 'grid'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/best-seller-modern.webp',
	},
	{
		type: 'section',
		key: 'collection-modern',
		name: 'Collections Modern',
		content:
			'<!-- wp:borobazar-blocks/collections-block {"paddingTop":{"desktop":70,"laptop":70,"tab":60,"mobile":40},"paddingRight":{"desktop":40,"laptop":40,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":40,"tab":20,"mobile":15},"template":"modern","collectionItems":[{"image":"https://borobazar.redq.io/modern/wp-content/uploads-demo/sites/2/2021/12/mini-banner-1.webp","url":"https://borobazar.redq.io/modern/an-assortment-of-cherries-for-energizing-the-fruits/","opensInNewTab":false,"title":"Love Spicy Food?\u003cbr\u003eTry Chinese item ","description":"Get your fresh food for diet plan\u003cbr\u003eand get healthy anytime. ","button":"Explore Food","overlayOpacity":25,"overlay":"#f7f7f7","backgroundPosition":"0% 50%","bgColor":"#fff","titleColor":"#000","descriptionColor":"#808080","buttonColor":"#02b290","buttonHoverColor":"#01a585"},{"image":"https://borobazar.redq.io/modern/wp-content/uploads-demo/sites/2/2021/12/mini-banner-2.webp","url":"https://borobazar.redq.io/modern/a-taste-of-blueberry-from-natures-perfection/","opensInNewTab":false,"title":"Amazing Pet food\u003cbr\u003eitems available ","description":"Get your fresh food for diet plan\u003cbr\u003eand get healthy anytime. ption","button":"Explore Food","overlayOpacity":25,"overlay":"#f7f7f7","backgroundPosition":"5% 50%","bgColor":"#fff","titleColor":"#000","descriptionColor":"#808080","buttonColor":"#02b290","buttonHoverColor":"#01a585"},{"image":"https://borobazar.redq.io/modern/wp-content/uploads-demo/sites/2/2021/12/mini-banner-3.webp","url":"https://borobazar.redq.io/modern/feeling-of-love-is-not-lost-in-old-friends-in-home/","opensInNewTab":false,"title":"Your Perfect Diet\u003cbr\u003eChoice to burn ","description":"Get your fresh food for diet plan\u003cbr\u003eand get healthy anytime. iption","button":"Explore Food","overlayOpacity":25,"overlay":"#f7f7f7","backgroundPosition":"0% 50%","bgColor":"#fff","titleColor":"#000","descriptionColor":"#808080","buttonColor":"#02b290","buttonHoverColor":"#01a585"}]} /-->',
		category: ['Modern demo'],
		keywords: ['collection'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/collection-modern.webp',
	},
	{
		type: 'section',
		key: 'popular-product-modern',
		name: 'Popular product (Modern)',
		content: `<!-- wp:gridster/block-title {"title":"Popular Product that we sold","alignment":"center","paddingTop":{"desktop":70,"laptop":70,"tab":60,"mobile":40},"paddingBottom":{"desktop":40,"laptop":40,"tab":35,"mobile":25}} /-->

    <!-- wp:gridster/special-deals {"editMode":"false","posts":[{"label":"Great Value Tortilla Chips Cantina Style","value":140,"id":140,"slug":"great-value-tortilla-chips-cantina-style"},{"label":"Frito Pays Bold Mix Family Size","value":197,"id":197,"slug":"frito-pays-bold-mix-family-size"},{"label":"Pays Kettle cooked chips","value":155,"id":155,"slug":"pays-kettle-cooked-chips"},{"label":"Mays BBQ chips","value":164,"id":164,"slug":"164"},{"label":"Hot Corn Potato Chips Family size","value":174,"id":174,"slug":"hot-corn-potato-chips-family-size"},{"label":"Pays Kettle cooked Potato Chips","value":181,"id":181,"slug":"pays-kettle-cooked-potato-chips"},{"label":"Chocolate Chip Cookie,","value":1067,"id":1067,"slug":"chocolate-chip-cookie"},{"label":"Calavo Fresh Avocado","value":99,"id":99,"slug":"calavo-fresh-avocado"},{"label":"Fresh Cilantro","value":105,"id":105,"slug":"fresh-cilantro"},{"label":"Gourmet Garden Lightly Dried Cilantro","value":110,"id":110,"slug":"gourmet-garden-lightly-dried-cilantro"},{"label":"Organic Girl Lettuce","value":77,"id":77,"slug":"organic-girl-lettuce"},{"label":"Organic Spring Mix","value":82,"id":82,"slug":"organic-spring-mix"},{"label":"Organic Green Cabbage","value":118,"id":118,"slug":"organic-greencabbage"},{"label":"Freshness Guaranteed Mango Slices","value":132,"id":132,"slug":"freshness-guaranteed-mango-slices"}],"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15}} /-->`,
		category: ['Modern demo'],
		keywords: ['popular', 'product', 'grid'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/popular-product-modern.webp',
	},
	{
		type: 'section',
		key: 'banner-vintage',
		name: 'Banner Slider (Vintage)',
		content:
			'<!-- wp:borobazar-blocks/slider {"slideItems":[{"slogan":"","title":"Start ordering from us\u003cbr\u003e\u0026amp; meet your needs!","description":"We source and sell the very best beef, lamb,\u003cbr\u003efish \u0026amp; herbs with the care from farmers.","button":"Explore More","image":"https://borobazar.redq.io/vintage/wp-content/uploads-demo/sites/3/2021/12/banner-1.webp","url":"https://borobazar.redq.io/vintage/search/","opensInNewTab":false,"contentPosition":"center center","textAlign":"center","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#ffffff","titleColor":"#ffffff","descriptionColor":"#ffffff","buttonColor":"#ffffff","buttonTextColor":"#000000","buttonHoverColor":"#01a585","buttonHoverTextColor":"#ffffff","height":{"desktop":550,"laptop":450,"tab":450,"mobile":380},"paddingTop":{"desktop":0,"laptop":30,"tab":30,"mobile":30},"paddingRight":{"desktop":0,"laptop":15,"tab":15,"mobile":15},"paddingBottom":{"desktop":0,"laptop":30,"tab":30,"mobile":30},"paddingLeft":{"desktop":0,"laptop":15,"tab":15,"mobile":15}},{"slogan":"","title":"Fresh produce from us\u003cbr\u003e\u0026amp; meet your needs! ","description":" We source and sell the very best beef, lamb,\u003cbr\u003efish \u0026amp; herbs with the care from farmers.  ","button":" Explore More","image":"https://borobazar.redq.io/vintage/wp-content/uploads-demo/sites/3/2021/12/slide-2.webp","url":"https://borobazar.redq.io/vintage/search/","opensInNewTab":false,"contentPosition":"center center","textAlign":"center","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#ffffff","titleColor":"#ffffff","descriptionColor":"#ffffff","buttonColor":"#ffffff","buttonTextColor":"#000000","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":550,"laptop":450,"tab":450,"mobile":380},"paddingTop":{"desktop":0,"laptop":30,"tab":30,"mobile":30},"paddingRight":{"desktop":0,"laptop":15,"tab":15,"mobile":15},"paddingBottom":{"desktop":0,"laptop":30,"tab":30,"mobile":30},"paddingLeft":{"desktop":0,"laptop":15,"tab":15,"mobile":15}},{"slogan":"","title":"Order products from us\u003cbr\u003e\u0026amp; meet your needs! ","description":" We source and sell the very best beef, lamb,\u003cbr\u003efish \u0026amp; herbs with the care from farmers.  ","button":" Explore More ","image":"https://borobazar.redq.io/vintage/wp-content/uploads-demo/sites/3/2021/12/slide-3.webp","url":"https://borobazar.redq.io/vintage/search/","opensInNewTab":false,"contentPosition":"center center","textAlign":"center","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#ffffff","titleColor":"#ffffff","descriptionColor":"#ffffff","buttonColor":"#ffffff","buttonTextColor":"#000000","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":550,"laptop":450,"tab":450,"mobile":380},"paddingTop":{"desktop":0,"laptop":30,"tab":30,"mobile":30},"paddingRight":{"desktop":0,"laptop":15,"tab":15,"mobile":15},"paddingBottom":{"desktop":0,"laptop":30,"tab":30,"mobile":30},"paddingLeft":{"desktop":0,"laptop":15,"tab":15,"mobile":15}}],"template":"hero","slidesPerView":{"desktop":1,"laptop":1,"tab":1,"mobile":1}} /-->',
		category: ['Vintage demo'],
		keywords: ['slider', 'hero', 'content'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/banner-vintage.webp',
	},
	{
		type: 'section',
		key: 'quick-search-vintage',
		name: 'Quick search (Vintage)',
		content: `<!-- wp:borobazar-blocks/borobazar-search-block {"paddingTop":{"desktop":50,"laptop":40,"tab":30,"mobile":30},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":70,"laptop":70,"tab":60,"mobile":50},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15}} -->
    <!-- wp:borobazar-blocks/borobazar-search-result /-->
    <!-- /wp:borobazar-blocks/borobazar-search-block -->`,
		category: ['Vintage demo'],
		keywords: ['search', 'product', 'grid'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/quick-search-vintage.webp',
	},
	{
		type: 'section',
		key: 'banner-standard',
		name: 'Banner search (Standard)',
		content:
			'<!-- wp:borobazar-blocks/search-banner {"title":"Healthy Vegetable you \u003cbr\u003eDeserve to Eat Fresh","description":"We source and sell the very best beef, lamb,\u003cbr\u003efish \u0026amp; herbs with the care from farmers.","backgroundImage":"https://borobazar.redq.io/standard/wp-content/uploads-demo/sites/5/2021/12/Banner.webp","minHeight":{"desktop":650,"laptop":500,"tab":450,"mobile":380},"className":"hide-br-mobile"} /-->',
		category: ['Standard demo'],
		keywords: ['banner', 'search', 'hero'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/banner-standard.webp',
	},
	{
		type: 'section',
		key: 'categories-standard',
		name: 'Product categories (Standard)',
		content: `<!-- wp:gridster/block-title {"title":"What food you love to order","subTitle":"Here order your favorite foods from different categories","alignment":"center","paddingTop":{"desktop":90,"laptop":90,"tab":70,"mobile":40},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":15},"paddingBottom":{"desktop":60,"laptop":60,"tab":40,"mobile":25},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":15},"titleFontSize":{"desktop":22,"laptop":20,"tab":20,"mobile":16},"subTitleFontSize":{"desktop":16,"laptop":15,"tab":15,"mobile":14}} /-->

    <!-- wp:borobazar-blocks/category-grid {"paddingRight":{"desktop":40,"laptop":40,"tab":20,"mobile":0},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15}} /-->`,
		category: ['Standard demo'],
		keywords: ['product', 'category', 'grid'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/categories-standard.webp',
	},
	{
		type: 'section',
		key: 'best-seller-standard',
		name: 'Best selling products (Standard)',
		content: `<!-- wp:gridster/block-title {"title":"Best seller grocery near you","subTitle":"We provide best quality \u0026amp; fresh grocery items near your location","alignment":"center","paddingTop":{"desktop":90,"laptop":90,"tab":70,"mobile":60},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":15},"paddingBottom":{"desktop":60,"laptop":60,"tab":40,"mobile":25},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":15}} /-->

    <!-- wp:gridster/best-selling {"postsPerPage":21,"paddingRight":{"desktop":40,"laptop":40,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"showSeeAllButton":true} /-->`,
		category: ['Standard demo'],
		keywords: ['product', 'selling', 'grid'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/best-seller-standard.webp',
	},
	{
		type: 'section',
		key: 'popular-product-standard',
		name: 'Popular products (Standard)',
		content: `<!-- wp:gridster/block-title {"title":"Popular Product that we sold","subTitle":"We provide best quality popular items near your location","alignment":"center","paddingTop":{"desktop":90,"laptop":90,"tab":70,"mobile":40},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":15},"paddingBottom":{"desktop":60,"laptop":60,"tab":40,"mobile":25},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":15}} /-->

    <!-- wp:gridster/special-deals {"editMode":"false","posts":[{"label":"Great Value Tortilla Chips Cantina Style","value":140,"id":140,"slug":"great-value-tortilla-chips-cantina-style"},{"label":"Frito Pays Bold Mix Family Size","value":197,"id":197,"slug":"frito-pays-bold-mix-family-size"},{"label":"Pays Kettle cooked chips","value":155,"id":155,"slug":"pays-kettle-cooked-chips"},{"label":"Mays BBQ chips","value":164,"id":164,"slug":"164"},{"label":"Hot Corn Potato Chips Family size","value":174,"id":174,"slug":"hot-corn-potato-chips-family-size"},{"label":"Pays Kettle cooked Potato Chips","value":181,"id":181,"slug":"pays-kettle-cooked-potato-chips"},{"label":"Ahoy Original Chocolate Chip Cookies","value":233,"id":233,"slug":"ahoy-original-chocolate-chip-cookies"},{"label":"Calavo Fresh Avocado","value":99,"id":99,"slug":"calavo-fresh-avocado"},{"label":"Fresh Cilantro","value":105,"id":105,"slug":"fresh-cilantro"},{"label":"Gourmet Garden Lightly Dried Cilantro","value":110,"id":110,"slug":"gourmet-garden-lightly-dried-cilantro"},{"label":"Organic Girl Lettuce","value":77,"id":77,"slug":"organic-girl-lettuce"},{"label":"Organic Spring Mix","value":82,"id":82,"slug":"organic-spring-mix"},{"label":"Organic Green Cabbage","value":118,"id":118,"slug":"organic-greencabbage"},{"label":"Freshness Guaranteed Mango Slices","value":132,"id":132,"slug":"freshness-guaranteed-mango-slices"}],"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":40,"laptop":40,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":40,"tab":20,"mobile":15}} /-->`,
		category: ['Standard demo'],
		keywords: ['product', 'popular', 'grid'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/popular-product-standard.webp',
	},
	{
		type: 'section',
		key: 'promo-banner',
		name: 'Promo banner',
		content:
			'<!-- wp:borobazar-blocks/slider {"paddingTop":{"desktop":90,"laptop":90,"tab":70,"mobile":30},"paddingRight":{"desktop":40,"laptop":40,"tab":20,"mobile":15},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":40,"laptop":40,"tab":20,"mobile":15},"slideItems":[{"slogan":"","title":"Super Discount 70% OFF","description":"We source and sell the best beef, lamb \u0026amp; duck, \u003cbr\u003esourced with the greatest care from farmer.","button":"Explore More","image":"https://borobazar.redq.io/standard/wp-content/uploads-demo/sites/5/2021/12/Banner-2.webp","url":"","opensInNewTab":false,"contentPosition":"center center","textAlign":"center","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#ffffff","descriptionColor":"#ffffff","buttonColor":"#ffffff","buttonTextColor":"#000000","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":400,"laptop":380,"tab":300,"mobile":200},"paddingTop":{"desktop":30,"laptop":30,"tab":30,"mobile":30},"paddingRight":{"desktop":25,"laptop":25,"tab":25,"mobile":25},"paddingBottom":{"desktop":30,"laptop":30,"tab":30,"mobile":30},"paddingLeft":{"desktop":25,"laptop":25,"tab":25,"mobile":25}}],"template":"content","slidesPerView":{"desktop":1,"laptop":1,"tab":1,"mobile":1},"className":"hide-br-mobile"} /-->',
		category: ['Standard demo'],
		keywords: ['promotional', 'ad', 'banner'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/banner-promo.webp',
	},
	{
		type: 'section',
		key: 'banner-minimal',
		name: 'Search banner (Minimal)',
		content:
			'<!-- wp:borobazar-blocks/search-banner {"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"title":"Thousand of Best Grocery Items","description":"Online Grocery Shopping at Low Price in Worldwide on InstaFood","placeholder":"What are you looking for..","backgroundImage":"https://borobazar.redq.io/minimal/wp-content/uploads-demo/sites/4/2021/12/Banner.webp","titleColor":"#0b4634","minHeight":{"desktop":480,"laptop":480,"tab":480,"mobile":420},"className":"hide-br-mobile"} /-->',
		category: ['Minimal demo'],
		keywords: ['banner', 'search', 'hero'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/banner-minimal.webp',
	},
	{
		type: 'section',
		key: 'quick-search-minimal',
		name: 'Quick search (Minimal)',
		content: `<!-- wp:borobazar-blocks/borobazar-search-block {"paddingTop":{"desktop":40,"laptop":40,"tab":20,"mobile":15},"paddingRight":{"desktop":40,"laptop":40,"tab":20,"mobile":15},"paddingBottom":{"desktop":70,"laptop":70,"tab":60,"mobile":40},"paddingLeft":{"desktop":40,"laptop":40,"tab":20,"mobile":15}} -->
    <!-- wp:borobazar-blocks/slider {"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":40,"laptop":40,"tab":40,"mobile":35},"slideItems":[{"slogan":"","title":"","description":"","button":"Button","image":"https://borobazar.redq.io/minimal/wp-content/uploads-demo/sites/4/2021/12/banner-4.webp","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":400,"laptop":400,"tab":300,"mobile":200},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"","description":"","button":"Button","image":"https://borobazar.redq.io/minimal/wp-content/uploads-demo/sites/4/2021/12/banner-2.webp","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"","description":"","button":"Button","image":"https://borobazar.redq.io/minimal/wp-content/uploads-demo/sites/4/2021/12/banner-3.webp","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"","description":"","button":"Button","image":"https://borobazar.redq.io/minimal/wp-content/uploads-demo/sites/4/2021/12/banner-5.png","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"","description":"","button":"Button","image":"https://borobazar.redq.io/minimal/wp-content/uploads-demo/sites/4/2021/12/banner-5.png","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}}],"slidesPerView":{"desktop":3,"laptop":3,"tab":2,"mobile":1},"spaceBetween":{"desktop":20,"laptop":20,"tab":10,"mobile":0}} /-->
    
    <!-- wp:borobazar-blocks/borobazar-search-result /-->
    <!-- /wp:borobazar-blocks/borobazar-search-block -->`,
		category: ['Minimal demo'],
		keywords: ['search', 'grid', 'product'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/quick-search-minimal.webp',
	},
	{
		type: 'section',
		key: 'call-to-action',
		name: 'Call to action (Trendy)',
		content:
			'<!-- wp:borobazar-blocks/call-to-action-block {"paddingTop":{"desktop":132,"laptop":100,"tab":60,"mobile":100},"paddingRight":{"desktop":40,"laptop":30,"tab":30,"mobile":15},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":40,"laptop":30,"tab":30,"mobile":15},"title":"Make your online shop easier with our mobile app","description":"We offers high-quality films and the best documentary selection, and the ability to browse alphabetically and by genre","ctaButton":{"url":"https://instafood.test/product/morrisons-6-medium-free-range-eggs/","opensInNewTab":false},"ctaButtonText":"Order More","backgroundColor":"#fffaf0","backgroundImage":"https://borobazar.redq.io/trendy/wp-content/uploads/sites/8/2022/03/New-Project.png"} /-->',
		category: ['Trendy demo'],
		keywords: ['call to action'],
		image: 'https://s3.amazonaws.com/redqteam.com/borobazarwp/assets/5.webp',
	},
	{
		type: 'section',
		key: 'banner-default-elegant',
		name: 'Banner Type Two (Elegant)',
		content:
			'<!-- wp:borobazar-blocks/slider {"paddingTop":{"desktop":25,"laptop":25,"tab":20,"mobile":15},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":20,"laptop":20,"tab":20,"mobile":12},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"slideItems":[{"slogan":"BREAKFAST ITEMS","title":"\u003cstrong\u003eFresh Healthy\u003c/strong\u003e\u003cbr\u003e\u003cstrong\u003ebreakfast food\u003c/strong\u003e","description":"Get ready for spring as soon as\u003cbr\u003etoday with $0 delivery fees.","button":"Explore More","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/Baanner.png","url":"https://borobazar.redq.io/search/","opensInNewTab":false,"contentPosition":"center left","textAlign":"left","backgroundPosition":"13% 0%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#eaf2f5","overlayOpacity":15,"overlay":"#abb8c3","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#000000","buttonColor":"#fcb900","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":450,"laptop":450,"tab":350,"mobile":200},"paddingTop":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingRight":{"desktop":60,"laptop":60,"tab":60,"mobile":25},"paddingBottom":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingLeft":{"desktop":60,"laptop":60,"tab":60,"mobile":25}},{"slogan":"DELICIOUS SNACKS","title":"Best Oven \u003cbr\u003eBaked Pizza","description":"Get ready for spring as soon as \u003cbr\u003etoday with $0 delivery fees.","button":"Explore More","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/b.png","url":"https://borobazar.redq.io/search/","opensInNewTab":false,"contentPosition":"center left","textAlign":"left","backgroundPosition":"100% 87%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#eaf2f5","overlayOpacity":15,"overlay":"#abb8c3","sloganColor":"#ffffff","titleColor":"#ffffff","descriptionColor":"#f3f3f3","buttonColor":"#fcb900","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":450,"laptop":450,"tab":350,"mobile":200},"paddingTop":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingRight":{"desktop":60,"laptop":60,"tab":60,"mobile":25},"paddingBottom":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingLeft":{"desktop":60,"laptop":60,"tab":60,"mobile":25}}],"template":"content","slidesPerView":{"desktop":2,"laptop":2,"tab":1,"mobile":1},"spaceBetween":{"desktop":20,"laptop":20,"tab":20,"mobile":20}} /-->',
		category: ['Elegant demo'],
		keywords: ['banner', 'home'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/banner-default.webp',
	},
	{
		type: 'section',
		key: 'promo-slider-elegant',
		name: 'Promo slider Type Two (Elegant)',
		content:
			'<!-- wp:borobazar-blocks/slider {"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":25,"laptop":25,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"slideItems":[{"slogan":"","title":"Digital Coupons","description":"Save time and money, load before you go","button":"Button","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/coupon-1.png","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f4f2eb","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":400,"laptop":400,"tab":300,"mobile":200},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Weekly Newsfeed","description":"Browse our newsfeed \u0026amp; add items in cart","button":"Button","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/Group2.png","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f4f2eb","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Digital Spotlight","description":"Find products easily \u0026amp; navigate store with the app","button":"Button","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/favorites-2.png","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f4f2eb","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Online Promotion","description":"Select an online shopping store to see current offers","button":"Button","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/Group-14103.png","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f4f2eb","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"Support Center","description":"Member services are always here to help","button":"Button","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/asdenshot_1.png","url":"","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f4f2eb","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}}],"template":"promo-v2","slidesPerView":{"desktop":4,"laptop":4,"tab":2,"mobile":1},"spaceBetween":{"desktop":20,"laptop":20,"tab":20,"mobile":0}} /-->',
		category: ['Elegant demo'],
		keywords: ['slider', 'home', 'promotional'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/layout-promo-slider-two.webp',
	},
	{
		type: 'section',
		key: 'collection-modern-elegant',
		name: 'Collections Slider (Elegant)',
		content:
			'<!-- wp:borobazar-blocks/slider {"paddingTop":{"desktop":55,"laptop":25,"tab":20,"mobile":15},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":25,"laptop":25,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"slideItems":[{"slogan":"","title":"","description":"","button":"Button","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/Group-14099.png","url":"https://borobazar.redq.io/elegant/search/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":400,"laptop":400,"tab":300,"mobile":200},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"","description":"","button":"Button","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/Group-14100.png","url":"https://borobazar.redq.io/elegant/search/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}},{"slogan":"","title":"","description":"","button":"Button","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/Group-14101.png","url":"https://borobazar.redq.io/elegant/search/","opensInNewTab":false,"contentPosition":"top left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#02B290","buttonTextColor":"#ffffff","buttonHoverColor":"#01A585","buttonHoverTextColor":"#ffffff","height":{"desktop":300,"laptop":300,"tab":200,"mobile":120},"paddingTop":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingRight":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingBottom":{"desktop":0,"laptop":0,"tab":0,"mobile":0},"paddingLeft":{"desktop":0,"laptop":0,"tab":0,"mobile":0}}],"slidesPerView":{"desktop":3,"laptop":3,"tab":3,"mobile":1},"spaceBetween":{"desktop":30,"laptop":25,"tab":20,"mobile":0}} /-->',
		category: ['Elegant demo'],
		keywords: ['collection'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/layout-collection-type-two.webp',
	},
	{
		type: 'section',
		key: 'banner-slider-elegant',
		name: 'Banner Slider Type Two (Elegant)',
		content:
			'<!-- wp:borobazar-blocks/slider {"paddingTop":{"desktop":55,"laptop":25,"tab":20,"mobile":15},"paddingRight":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"paddingBottom":{"desktop":25,"laptop":25,"tab":20,"mobile":15},"paddingLeft":{"desktop":40,"laptop":32,"tab":20,"mobile":15},"slideItems":[{"slogan":"DISCOUNT FOOD","title":"Have a safe delivery","description":"Get ready for spring as soon as today\u003cbr\u003ewith zero dollar delivery fees.","button":"Explore More","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/Banner.png","url":"https://borobazar.redq.io/elegant/search/","opensInNewTab":false,"contentPosition":"center left","textAlign":"left","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#fcb900","buttonTextColor":"#ffffff","buttonHoverColor":"#01a585","buttonHoverTextColor":"#ffffff","height":{"desktop":500,"laptop":450,"tab":350,"mobile":200},"paddingTop":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingRight":{"desktop":60,"laptop":60,"tab":60,"mobile":25},"paddingBottom":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingLeft":{"desktop":56,"laptop":60,"tab":60,"mobile":25}},{"slogan":"BE SAFE, KEEP SAFE","title":"Let’s stop Covid-19","description":"Don’t miss this opportunity at a special discount just for this week.","button":"Explore More","image":"https://borobazar.redq.io/elegant/wp-content/uploads/sites/9/2022/09/Bannear.png","url":"https://borobazar.redq.io/elegant/search/","opensInNewTab":false,"contentPosition":"top center","textAlign":"center","backgroundPosition":"50% 50%","backgroundRepeat":false,"fixedBackground":false,"backgroundSize":"cover","backgroundColor":"#f9f9f9","overlayOpacity":0,"overlay":"#000000","sloganColor":"#000000","titleColor":"#000000","descriptionColor":"#4A5568","buttonColor":"#fcb900","buttonTextColor":"#ffffff","buttonHoverColor":"#01a585","buttonHoverTextColor":"#ffffff","height":{"desktop":500,"laptop":450,"tab":350,"mobile":200},"paddingTop":{"desktop":50,"laptop":35,"tab":35,"mobile":35},"paddingRight":{"desktop":60,"laptop":60,"tab":60,"mobile":25},"paddingBottom":{"desktop":35,"laptop":35,"tab":35,"mobile":35},"paddingLeft":{"desktop":60,"laptop":60,"tab":60,"mobile":25}}],"template":"content","slidesPerView":{"desktop":2,"laptop":2,"tab":1,"mobile":1},"spaceBetween":{"desktop":30,"laptop":25,"tab":0,"mobile":0}} /-->',
		category: ['Elegant demo'],
		keywords: ['slider', 'hero', 'content'],
		image:
			'https://s3.amazonaws.com/redqteam.com/borobazarwp/layouts/layout-banner-type-three.webp',
	},
];
