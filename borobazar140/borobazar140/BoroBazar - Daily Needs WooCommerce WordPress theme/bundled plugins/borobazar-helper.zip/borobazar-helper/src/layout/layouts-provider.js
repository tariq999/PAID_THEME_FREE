/**
 * Layouts Provider for the Layout Block.
 *
 * Provides layouts, sections to other components
 * using React's Context API.
 */

import React, { createContext, Component } from 'react';
import { layoutData } from './data/layouts-data';
import { sectionData } from './data/sections-data';

export const LayoutsContext = createContext({
	layouts: '',
	sections: '',
	all: '',
});

export default class LayoutsProvider extends Component {
	state = {
		layouts: '',
		sections: '',
		all: '',
	};

	async componentDidMount() {
		const all = layoutData.concat(sectionData);
		const layouts = layoutData;
		const sections = sectionData;
		this.setState({ all, layouts, sections });
	}

	render() {
		return (
			<LayoutsContext.Provider
				value={{
					layouts: this.state.layouts,
					sections: this.state.sections,
					all: this.state.all,
				}}
			>
				{this.props.children}
			</LayoutsContext.Provider>
		);
	}
}
