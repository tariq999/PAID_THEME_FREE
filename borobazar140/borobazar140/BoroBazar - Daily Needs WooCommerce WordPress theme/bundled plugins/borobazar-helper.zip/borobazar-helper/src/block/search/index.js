/**
 * BLOCK: Product Search
 **/

const { registerBlockType } = wp.blocks;
const { InnerBlocks } = wp.blockEditor;
const { __ } = wp.i18n;
import "./editor.scss";
import "./style.scss";
import attributes from "./attributes";
import edit from "./edit";
import { QuickSearchIcon } from "./icon";

registerBlockType('borobazar-blocks/borobazar-search-block', {
	title: __('Quick Search', 'borobazar-helper'),
	icon: <QuickSearchIcon />,
	textdomain: 'borobazar-helper',
	example: {
		attributes: {},
	},
	category: 'borobazar-blocks-category',
	keywords: [
		__('Search block', 'borobazar-helper'),
		__('Product search', 'borobazar-helper'),
		__('Search page', 'borobazar-helper'),
		__('Find', 'borobazar-helper'),
	],
	attributes,
	edit,
	save: () => {
		return <InnerBlocks.Content />;
	},
	getEditWrapperProps() {
		return { 'data-align': 'full' };
	},
});
