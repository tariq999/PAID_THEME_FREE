export default {
	image: {
		type: "string",
		default: "",
	},
	alt: {
		type: "string",
		default: "",
	},
};
