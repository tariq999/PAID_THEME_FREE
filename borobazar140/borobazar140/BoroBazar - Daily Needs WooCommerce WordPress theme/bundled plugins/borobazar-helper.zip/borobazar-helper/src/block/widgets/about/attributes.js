const { __ } = wp.i18n;

export default {
	image: {
		type: "string",
		default: BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath + "logo.svg",
	},
	content: {
		type: "string",
		default: __(
			"We offers high-quality films and the best documentary selection, and the ability to browse alphabetically",
			"borobazar-helper"
		),
	},
	socialLinks: {
		type: "array",
		default: [
			{
				icon: BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath + "facebook.svg",
				link: {
					url: "",
					opensInNewTab: false,
				},
			},
			{
				icon: BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath + "twitter.svg",
				link: {
					url: "",
					opensInNewTab: false,
				},
			},
			{
				icon: BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath + "youtube.svg",
				link: {
					url: "",
					opensInNewTab: false,
				},
			},
			{
				icon: BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath + "instagram.svg",
				link: {
					url: "",
					opensInNewTab: false,
				},
			},
		],
	},
};
