/**
 * BLOCK: Store Map
 **/
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./editor.scss";
import "./style.scss";
import { MapIcon } from "./icon";
import attributes from "./attributes";
import StoreMap from "./edit";

// check goggle map loader plugin exists
const googleMapAPI = BOROBAZAR_HELPER_ADMIN_LOCALIZE
	? BOROBAZAR_HELPER_ADMIN_LOCALIZE.googleMap
	: {};
	
registerBlockType("borobazar-blocks/borobazar-store-map", {
	title: __("Store Map", "borobazar-helper"),
	description: __(
		"Easily add your store location in a google map.",
		"borobazar-helper"
	),
	category: "borobazar-blocks-category",
	icon: <MapIcon />,
	keywords: [
		__("Map", "borobazar-helper"),
		__("Store Map", "borobazar-helper"),
		__("Contact us map", "borobazar-helper"),
		__("Store location", "borobazar-helper"),
		__("Store area", "borobazar-helper"),
	],
	attributes,
	edit: (props) =>
		Object.keys(googleMapAPI).length > 0 &&
		googleMapAPI.googlemap_api_key !== "" ? (
			<StoreMap {...props} />
		) : (
			<div className="h-28 grid place-content-center m-4 p-4 rounded-md md:text-base border border-red-500">
				{__(
					"Please install and activate our Google Map Loader plugin, and configure it.",
					"borobazar-helper"
				)}
			</div>
		),
	save: () => null,
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
