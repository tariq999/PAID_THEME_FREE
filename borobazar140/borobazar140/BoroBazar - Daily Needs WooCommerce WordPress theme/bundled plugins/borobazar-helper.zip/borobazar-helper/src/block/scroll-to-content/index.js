/**
 * BLOCK: Scroll to content
 **/
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./editor.scss";
import "./style.scss";
import attributes from "./attributes";
import edit from "./edit";
import { ScrollToContentIcon } from "./icon";

registerBlockType("borobazar-blocks/borobazar-scroll-to-content", {
	title: __("Scroll to Content", "borobazar-helper"),
	description: __(
		"Helps to build terms and condition and privacy policy type page easily.",
		"borobazar-helper"
	),
	icon: <ScrollToContentIcon />,
	category: "borobazar-blocks-category",
	keywords: [
		__("Privacy policy", "borobazar-helper"),
		__("Terms and Conditions", "borobazar-helper"),
		__("Tabs", "borobazar-helper"),
		__("Scroll to Content", "borobazar-helper"),
	],
	attributes,
	textdomain: "borobazar-helper",
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
	edit,
	save: () => {
		return null;
	},
});
