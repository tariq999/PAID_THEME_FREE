import { PlusIcon, UploadIcon, CloseIcon } from "./icon";
// wp imports
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { PanelBody } = wp.components;
const { RichText, MediaUpload, ColorPaletteControl, InspectorControls } =
	wp.blockEditor;

// components
export default (props) => {
	const {
		attributes: {
			title,
			description,
			contactInfo,
			titleColor,
			descriptionColor,
		},
		setAttributes,
		isSelected,
		className = "",
	} = props;

	function updateContactInfo(key, content, index) {
		const allContactInfo = contactInfo;
		allContactInfo[index] = {
			...allContactInfo[index],
			[key]: content,
		};
		setAttributes({ contactInfo: [...allContactInfo] });
	}

	function addNewContactInfo() {
		const allContactInfo = contactInfo;
		const newContactInfo = {
			icon: "",
			title: "",
			description: "",
		};
		setAttributes({ contactInfo: [...allContactInfo, newContactInfo] });
	}

	function removeContactInfo(index) {
		const allContactInfo = contactInfo;
		allContactInfo.splice(index, 1);
		setAttributes({ contactInfo: [...allContactInfo] });
	}

	return (
		<Fragment>
			<div className={`borobazar-contact-info-block ${className}`}>
				<RichText
					tagName="h3"
					value={title}
					onChange={(title) => setAttributes({ title })}
					placeholder={__("Title", "borobazar-helper")}
					allowedFormats={[]}
					className="mb-3 sm:mb-5"
					style={{
						color: titleColor,
					}}
				/>
				<RichText
					tagName="div"
					value={description}
					onChange={(description) => setAttributes({ description })}
					placeholder={__("Description", "borobazar-helper")}
					className="mb-8 sm:mb-10"
					style={{
						color: descriptionColor,
					}}
				/>
				{contactInfo.length && (
					<div className="grid gap-8">
						{contactInfo.map((item, index) => (
							<div
								key={`contact-info-item-key${index}`}
								className="flex items-center relative group"
							>
								<div className="w-14 sm:w-[68px] shrink-0 grid place-content-start">
									<MediaUpload
										onSelect={(content) =>
											updateContactInfo("icon", content.url, index)
										}
										allowed={["image"]}
										type="image"
										render={({ open }) => (
											<div
												onClick={open}
												className="cursor-pointer"
												title={__("Upload", "borobazar-helper")}
											>
												{item.icon ? (
													<img
														src={item.icon}
														alt={item.title}
														className="w-10 sm:w-[50px] h-10 sm:h-[50px] object-scale-down"
													/>
												) : (
													<UploadIcon />
												)}
											</div>
										)}
									/>
								</div>
								<div className="content flex-1">
									<RichText
										tagName="h6"
										value={item.title}
										onChange={(content) =>
											updateContactInfo("title", content, index)
										}
										placeholder={__(
											"Enter contact info title",
											"borobazar-helper"
										)}
										allowedFormats={[]}
										className="mt-0 mb-2"
										style={{
											color: titleColor,
										}}
									/>
									<RichText
										tagName="div"
										value={item.description}
										onChange={(content) =>
											updateContactInfo("description", content, index)
										}
										placeholder={__(
											"Enter contact info description",
											"borobazar-helper"
										)}
										style={{
											color: descriptionColor,
										}}
									/>
								</div>

								{isSelected && (
									<button
										onClick={() => removeContactInfo(index)}
										className="absolute top-0 right-0 z-5 rounded-full inline-flex items-center justify-center w-7 h-7 text-red-600 bg-red-200 transition-opacity duration-200 opacity-0 hover:text-white hover:bg-red-600 group-hover:opacity-100 group-focus:opacity-100"
									>
										<CloseIcon />
									</button>
								)}
							</div>
						))}
					</div>
				)}

				{isSelected && (
					<button
						onClick={() => addNewContactInfo()}
						className="w-full h-10 mt-7 flex items-center justify-center rounded transition-colors duration-200 hover:bg-gray-300"
					>
						<PlusIcon className="w-[18px] h-[18px] mr-2" />
						{__("Add new info", "borobazar-helper")}
					</button>
				)}
			</div>
			{/* End of edit block */}

			<InspectorControls>
				<PanelBody
					title={__("Color Settings", "borobazar-helper")}
					initialOpen={false}
				>
					<div style={{ marginBottom: "24px" }}>
						<ColorPaletteControl
							label={__("Title Color:", "borobazar-helper")}
							value={titleColor}
							onChange={(value) =>
								setAttributes({
									titleColor: value,
								})
							}
						/>
					</div>

					<div style={{ marginBottom: "24px" }}>
						<ColorPaletteControl
							label={__("Description Color:", "borobazar-helper")}
							value={descriptionColor}
							onChange={(value) =>
								setAttributes({
									descriptionColor: value,
								})
							}
						/>
					</div>
				</PanelBody>
			</InspectorControls>
			{/* End block settings */}
		</Fragment>
	);
};
