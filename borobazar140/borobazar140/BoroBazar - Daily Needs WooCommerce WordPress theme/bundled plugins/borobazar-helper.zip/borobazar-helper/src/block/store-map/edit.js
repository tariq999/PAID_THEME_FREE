import React, { useState, useEffect } from "react";
// wp imports
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { PanelBody, SelectControl, ToggleControl } = wp.components;
const { MediaUpload, InspectorControls } = wp.blockEditor;
// custom components
import MapAutoComplete from "../../components/mapAutoComplete";
import HeightSettings from "../../components/heightSettings";
import { Map, SilverMap } from "./map";
import { UploadIcon, CloseIcon } from "./icon";

const StoreMap = (props) => {
	const {
		attributes: {
			theme,
			marker,
			height,
			locationData,
			markerAnimation,
			fullWidth,
		},
		attributes,
		setAttributes,
		className,
	} = props;

	// prevent marker layer undefined issue on init render
	const [mapLoaded, setMapLoaded] = useState(false);
	useEffect(() => {
		setMapLoaded(true);
	}, [mapLoaded]);

	// block height
	const blockHeight = {
		"--desktop-height": height.desktop + "px",
		"--laptop-height": height.laptop + "px",
		"--tab-height": height.tab + "px",
		"--mobile-height": height.mobile + "px",
	};

	return (
		<Fragment>
			<div
				className={`borobazar-store-map ${className} ${
					fullWidth ? "borobazar-full-width-block" : ""
				}`}
			>
				<div className="borobazar-store-map-wrapper">
					{mapLoaded && (
						<Fragment>
							{theme === "silver" ? (
								<SilverMap
									marker={marker}
									markerAnimation={markerAnimation}
									containerElement={
										<div
											className="borobazar-block-height-wrapper bg-base"
											style={blockHeight}
										/>
									}
									mapElement={<div style={{ height: `100%` }} />}
									location={locationData}
								/>
							) : (
								<Map
									marker={marker}
									markerAnimation={markerAnimation}
									containerElement={
										<div
											className="borobazar-block-height-wrapper bg-base"
											style={blockHeight}
										/>
									}
									mapElement={<div style={{ height: `100%` }} />}
									location={locationData}
								/>
							)}
						</Fragment>
					)}
				</div>
			</div>
			{/* End of edit part*/}

			<InspectorControls>
				<PanelBody title={__("Map Settings", "borobazar-helper")}>
					<ToggleControl
						label={__("Full Width", "borobazar-helper")}
						checked={fullWidth}
						onChange={(value) => setAttributes({ fullWidth: value })}
						help="There will be no horizontal spacing."
					/>

					<div className="borobazar-store-map-address">
						<label style={{ display: "block", marginBottom: "6px" }}>
							{__("Set Store Address:", "borobazar-helper")}
						</label>
						<MapAutoComplete
							data={locationData}
							updateData={(selectedAddress) =>
								setAttributes({ ...attributes, locationData: selectedAddress })
							}
						/>
					</div>
					{/* end of address */}

					<SelectControl
						label={__("Set Map Theme:", "borobazar-helper")}
						value={theme}
						onChange={(selectedTheme) =>
							setAttributes({ ...attributes, theme: selectedTheme })
						}
						options={[
							{ value: "standard", label: "Standard" },
							{ value: "silver", label: "Silver" },
						]}
					/>
					{/* end of theme */}

					<div className="borobazar-store-map-marker">
						<label style={{ display: "block", marginBottom: "6px" }}>
							{__("Set Map Marker:", "borobazar-helper")}
						</label>
						<MediaUpload
							onSelect={(image) =>
								setAttributes({ ...attributes, marker: image.url })
							}
							allowed={["image"]}
							type="image"
							render={({ open }) => (
								<div
									onClick={open}
									className="borobazar-store-map-marker-handler"
								>
									{marker ? (
										<img src={marker} alt="Map marker" />
									) : (
										<UploadIcon />
									)}
									{__(
										"Click here to upload custom map marker image (48 x 56)",
										"borobazar-helper"
									)}
								</div>
							)}
						/>

						{marker ? (
							<button
								onClick={() => setAttributes({ marker: "" })}
								className="borobazar-store-map-marker-clear"
							>
								<CloseIcon />
							</button>
						) : null}
					</div>
					{/* end of marker */}

					<div style={{ marginTop: "24px" }}>
						<ToggleControl
							label={__("Enable/Disable Marker Animation", "borobazar-helper")}
							help={
								markerAnimation
									? __("Has marker animation.", "borobazar-helper")
									: __("No marker animation.", "borobazar-helper")
							}
							checked={markerAnimation}
							onChange={() => {
								setAttributes({
									...attributes,
									markerAnimation: !markerAnimation,
								});
							}}
						/>
					</div>
				</PanelBody>

				<HeightSettings height={height} setAttributes={setAttributes} />
			</InspectorControls>
			{/* End of inspector controls */}
		</Fragment>
	);
};

export default StoreMap;
