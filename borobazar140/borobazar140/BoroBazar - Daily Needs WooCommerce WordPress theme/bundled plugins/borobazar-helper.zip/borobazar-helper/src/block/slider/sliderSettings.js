import { useState } from "react";
const { Fragment } = wp.element;
const { __ } = wp.i18n;
const { RangeControl, PanelBody, ToggleControl, SelectControl } = wp.components;
import Devices from "../../components/devices";

export default ({
	slidesPerView,
	spaceBetween,
	centeredSlides,
	grabCursor,
	loop,
	autoplay,
	autoplayTime,
	speed,
	template,
	setAttributes,
}) => {
	const [device, setDevice] = useState("desktop");
	const handleDevice = (device) => {
		setDevice(device);
	};
	return (
		<Fragment>
			<PanelBody
				title={__("Slider Settings", "borobazar-helper")}
				icon="slides"
				initialOpen={true}
			>
				{template !== "hero" && (
					<Fragment>
						<div className="borobazar-block-inline-wrap">
							<label>{__("Slides per view", "borobazar-helper")}</label>
							<Devices
								device={device}
								handleDevice={(device) => handleDevice(device)}
							/>
						</div>

						<RangeControl
							value={slidesPerView[device]}
							onChange={(value) =>
								setAttributes({
									slidesPerView: {
										...slidesPerView,
										[device]: value,
									},
								})
							}
							min={1}
							max={10}
							required
						/>
					</Fragment>
				)}
				<div className="borobazar-block-inline-wrap">
					<label>
						{__("Distance between slides (in px)", "borobazar-helper")}
					</label>
					<Devices
						device={device}
						handleDevice={(device) => handleDevice(device)}
					/>
				</div>
				<RangeControl
					value={spaceBetween[device]}
					onChange={(value) =>
						setAttributes({
							spaceBetween: {
								...spaceBetween,
								[device]: value,
							},
						})
					}
					min={0}
					max={60}
					required
				/>
				<RangeControl
					label={__("Slider Speed (in ms)", "borobazar-helper")}
					value={speed}
					onChange={(value) =>
						setAttributes({
							speed: value,
						})
					}
					min={100}
					max={1500}
					required
				/>

				<ToggleControl
					label={__("Autoplay", "borobazar-helper")}
					help={__("Set to true to enable autoplay", "borobazar-helper")}
					checked={autoplay}
					onChange={() =>
						setAttributes({
							autoplay: autoplay === true ? false : true,
						})
					}
				/>
				{autoplay ? (
					<RangeControl
						label={__("Autoplay transitions (in ms)", "borobazar-helper")}
						value={autoplayTime}
						onChange={(value) =>
							setAttributes({
								autoplayTime: value,
							})
						}
						min={500}
						max={10000}
						required
					/>
				) : (
					""
				)}
				<ToggleControl
					label={__("Loop", "borobazar-helper")}
					help={__(
						"Set to true to enable continuous loop mode",
						"borobazar-helper"
					)}
					checked={loop}
					onChange={() =>
						setAttributes({
							loop: loop === true ? false : true,
						})
					}
				/>
				<ToggleControl
					label={__("Centered Slides", "borobazar-helper")}
					help={__(
						"If true, then active slide will be centered",
						"borobazar-helper"
					)}
					checked={centeredSlides}
					onChange={() =>
						setAttributes({
							centeredSlides: centeredSlides === true ? false : true,
						})
					}
				/>
				<ToggleControl
					label={__("Grab Cursor", "borobazar-helper")}
					help={__(
						"If true, user will see the 'grab' cursor when hover on slider",
						"borobazar-helper"
					)}
					checked={grabCursor}
					onChange={() =>
						setAttributes({
							grabCursor: grabCursor === true ? false : true,
						})
					}
				/>
			</PanelBody>
		</Fragment>
	);
};
