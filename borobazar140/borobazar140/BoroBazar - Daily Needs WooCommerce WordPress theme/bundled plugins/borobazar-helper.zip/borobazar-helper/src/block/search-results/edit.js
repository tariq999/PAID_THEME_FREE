const { Fragment } = wp.element;
const { __ } = wp.i18n;
const { PanelBody, ToggleControl } = wp.components;
const { InspectorControls } = wp.blockEditor;
const { useSelect } = wp.data;
import TemplateSwitcher from '../../components/templateSwitcher';
import PaddingSettings from '../../components/paddingSettings';
import {
	AlpineGridPreview,
	AlpineGridPreviewRTL,
	OakGridPreview,
	OakGridPreviewRTL,
	MapleGridPreview,
	MapleGridPreviewRTL,
	SweetGridPreview,
	SweetGridPreviewRTL,
	BroomstickGridPreview,
	BroomstickGridPreviewRTL,
	ObsidianGridPreview,
	ObsidianGridPreviewRTL
} from './icon';

export default (props) => {
	const {
		attributes: {
			gridTemplate,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
			scrollToTop,
		},
		setAttributes,
		className,
		isSelected,
	} = props;

	if (isSelected) {
		setAttributes({ align: 'full' });
	}

	const isRTL = useSelect((select) => {
		return !!select('core/block-editor').getSettings().isRTL;
	}, []);

	const padding = {
		'--desktop-padding-top': paddingTop.desktop + 'px',
		'--laptop-padding-top': paddingTop.laptop + 'px',
		'--tab-padding-top': paddingTop.tab + 'px',
		'--mobile-padding-top': paddingTop.mobile + 'px',
		'--desktop-padding-right': paddingRight.desktop + 'px',
		'--laptop-padding-right': paddingRight.laptop + 'px',
		'--tab-padding-right': paddingRight.tab + 'px',
		'--mobile-padding-right': paddingRight.mobile + 'px',
		'--desktop-padding-bottom': paddingBottom.desktop + 'px',
		'--laptop-padding-bottom': paddingBottom.laptop + 'px',
		'--tab-padding-bottom': paddingBottom.tab + 'px',
		'--mobile-padding-bottom': paddingBottom.mobile + 'px',
		'--desktop-padding-left': paddingLeft.desktop + 'px',
		'--laptop-padding-left': paddingLeft.laptop + 'px',
		'--tab-padding-left': paddingLeft.tab + 'px',
		'--mobile-padding-left': paddingLeft.mobile + 'px',
	};

	let productCard, gridClass;

	switch (gridTemplate) {
		case 'grid_alpine':
			productCard = isRTL ? <AlpineGridPreviewRTL /> : <AlpineGridPreview />;
			gridClass =
				'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			break;

		case 'grid_oak':
			productCard = isRTL ? <OakGridPreviewRTL /> : <OakGridPreview />;
			gridClass =
				'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			break;

		case 'grid_maple':
			productCard = isRTL ? <MapleGridPreviewRTL /> : <MapleGridPreview />;
			gridClass =
				'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			break;
		case 'grid_sweetgum':
			productCard = isRTL ? <SweetGridPreviewRTL /> :<SweetGridPreview />;
			gridClass =
				'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			break;
		case 'grid_broomstick':
			productCard =isRTL ? <BroomstickGridPreviewRTL /> : <BroomstickGridPreview />;
			gridClass =
				'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			break;
		case 'grid_obsidian':
			productCard = isRTL ? <ObsidianGridPreviewRTL /> :<ObsidianGridPreview />;
			gridClass =
		        'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			break;

		default:
			productCard = isRTL ? <AlpineGridPreviewRTL /> : <AlpineGridPreview />;
			gridClass =
				'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			break;
	}

	const switcherItems = [
		{
			preview: isRTL ? <AlpineGridPreviewRTL /> : <AlpineGridPreview />,
			label: __('Alpine', 'borobazar-helper'),
			value: 'grid_alpine',
		},
		{
			preview: isRTL ? <OakGridPreviewRTL /> : <OakGridPreview />,
			label: __('Oak', 'borobazar-helper'),
			value: 'grid_oak',
		},
		{
			preview: isRTL ? <MapleGridPreviewRTL /> : <MapleGridPreview />,
			label: __('Maple', 'borobazar-helper'),
			value: 'grid_maple',
		},
		{
			preview: isRTL ? <SweetGridPreviewRTL /> :<SweetGridPreview />,
			label: __('Sweetgum', 'borobazar-helper'),
			value: 'grid_sweetgum',
		},
		{
			preview: isRTL ? <BroomstickGridPreviewRTL /> :<BroomstickGridPreview />,
			label: __('Broomstick', 'borobazar-helper'),
			value: 'grid_broomstick',
		},
		{
			preview:isRTL ? <ObsidianGridPreviewRTL /> : <ObsidianGridPreview />,
			label: __('Obsidian', 'borobazar-helper'),
			value: 'grid_obsidian',
		},
	];

	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper ${className}`}
				style={padding}
			>
				<div className={`borobazar-products-block ${gridClass}`}>
					{[...Array(15)].map((index) => (
						<div key={index} className="grid-col">
							{productCard}
						</div>
					))}
				</div>
			</div>
			<InspectorControls>
				<PanelBody
					title={__('General Settings', 'borobazar-helper')}
					initialOpen={true}
				>
					<TemplateSwitcher
						label={__('Select Product Grid', 'borobazar-helper')}
						handleTemplate={(template) =>
							setAttributes({ gridTemplate: template })
						}
						template={gridTemplate}
						items={switcherItems}
					/>
					<br />
					<ToggleControl
						label={__('Scroll to top after search', 'borobazar-helper')}
						checked={scrollToTop}
						onChange={() =>
							setAttributes({
								scrollToTop: scrollToTop === false ? true : false,
							})
						}
					/>
				</PanelBody>
				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
		</Fragment>
	);
};
