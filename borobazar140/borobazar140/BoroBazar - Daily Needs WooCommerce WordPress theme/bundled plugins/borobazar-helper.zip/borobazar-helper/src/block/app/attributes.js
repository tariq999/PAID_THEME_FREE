export default {
	paddingTop: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	title: {
		type: "string",
		default: "",
	},
	description: {
		type: "string",
		default: "",
	},
	playStore: {
		type: "object",
		default: {
			url: "",
			opensInNewTab: false,
		},
	},
	appStore: {
		type: "object",
		default: {
			url: "",
			opensInNewTab: false,
		},
	},
	titleColor: {
		type: "string",
		default: "#000",
	},
	descriptionColor: {
		type: "string",
		default: "#808080",
	},
	backgroundColor: {
		type: "string",
		default: "#f2f2f2",
	},
	backgroundImage: {
		type: "string",
		default: "",
	},
	backgroundPosition: {
		type: "string",
		default: "50% 50%",
	},
	backgroundRepeat: {
		type: "boolean",
		default: false,
	},
	fixedBackground: {
		type: "boolean",
		default: false,
	},
	backgroundSize: {
		type: "string",
		default: "cover",
	},
	overlay: {
		type: "string",
		default: "#000",
	},
	overlayOpacity: {
		type: "string",
		default: 0,
	},
	fullWidth: {
		type: "boolean",
		default: false,
	},
};
