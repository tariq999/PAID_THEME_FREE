import { useState } from "react";
import { UploadIcon, PhotographIcon, CloseIcon } from "./icon";
// wp imports
const { __ } = wp.i18n;
const {
	RichText,
	MediaUpload,
	__experimentalLinkControl: LinkControl,
} = wp.blockEditor;
const { Fragment } = wp.element;
const { Button, Popover } = wp.components;

// components
export default (props) => {
	const [isVisible, setIsVisible] = useState(false);
	const [selectedItem, setSelectedItem] = useState(0);
	const {
		attributes: { image, content, socialLinks },
		setAttributes,
		isSelected,
		className,
	} = props;

	function selectedSocialProfile(index) {
		setSelectedItem(index);
		setIsVisible(true);
	}

	function updateSocialProfileIcon(icon) {
		const allSocialLinks = socialLinks;
		allSocialLinks[selectedItem] = {
			...allSocialLinks[selectedItem],
			icon: icon.url,
		};
		setAttributes({ socialLinks: [...allSocialLinks] });
	}

	function updateSocialProfileLink(newURL, newOpensInNewTab) {
		const normalizeURL = newURL.replace(/([^:]\/)\/+/g, "$1");
		const allSocialLinks = socialLinks;
		allSocialLinks[selectedItem] = {
			...allSocialLinks[selectedItem],
			link: {
				url: normalizeURL,
				opensInNewTab: newOpensInNewTab,
			},
		};
		setAttributes({ socialLinks: [...allSocialLinks] });
	}

	function addNewSocialProfile() {
		const allSocialLinks = socialLinks;
		const newSocialLink = {
			icon: "",
			link: {
				url: "",
				opensInNewTab: false,
			},
		};
		setSelectedItem(socialLinks.length);
		setAttributes({ socialLinks: [...allSocialLinks, newSocialLink] });
		setIsVisible(true);
	}

	function removeSocialProfile() {
		const allSocialLinks = socialLinks;
		allSocialLinks.splice(selectedItem, 1);
		setAttributes({ socialLinks: [...allSocialLinks] });
		setIsVisible(false);
	}

	return (
		<div className={`borobazar-footer-about-us ${className}`}>
			<div className="inline-flex items-center relative">
				<MediaUpload
					buttonProps={{
						className: "change-image",
					}}
					onSelect={(logo) => setAttributes({ image: logo.url })}
					allowed={["image"]}
					type="image"
					render={({ open }) => (
						<Button
							className={`borobazar-footer-about-us-logo ${
								image ? "image-uploded" : ""
							}`}
							isLarge
							isDefault={true}
							onClick={open}
							title={image ? "Click here to update image" : ""}
						>
							{image ? (
								<img
									className="max-w-[120px] sm:max-w-[auto]"
									src={image}
									alt="site logo"
								/>
							) : (
								<UploadIcon />
							)}
						</Button>
					)}
				/>

				{isSelected && image && (
					<button
						onClick={() => setAttributes({ image: "" })}
						className="absolute top-0 right-0 z-5 rounded-full inline-flex items-center justify-center w-7 h-7 text-red-600 bg-red-200"
					>
						<CloseIcon />
					</button>
				)}
			</div>
			{/* End of logo */}

			<RichText
				tagName="div"
				value={content}
				onChange={(content) => setAttributes({ content })}
				allowedFormats={[""]}
				className="borobazar-footer-about-us-content mt-2.5 sm:mt-5 md:mt-6 mb-4 sm:mb-6"
				placeholder={__(
					"Enter information content here...",
					"borobazar-helper"
				)}
			/>
			{/* End of short description */}

			<div className="flex flex-wrap items-center -mx-2.5 relative">
				{socialLinks.map((item, index) => (
					<Fragment>
						{item.icon ? (
							<img
								key={index}
								src={item.icon}
								title={__("Upload Image", "borobazar-helper")}
								onClick={() => selectedSocialProfile(index)}
								alt="social link"
								className="mx-2.5 cursor-pointer w-4 h-4 sm:w-5 sm:h-5"
							/>
						) : (
							<span
								key={index}
								title={__("Upload Image", "borobazar-helper")}
								onClick={() => selectedSocialProfile(index)}
								className="mx-2.5 cursor-pointer inline-flex items-center justify-center"
							>
								<PhotographIcon />
							</span>
						)}
					</Fragment>
				))}

				{isSelected && (
					<Button
						isPrimary
						onClick={() => addNewSocialProfile()}
						className="ml-6"
					>
						{__("Add New Item", "borobazar-helper")}
					</Button>
				)}
			</div>
			{/* End of social links */}

			{isSelected && isVisible && (
				<Popover
					position="middle right"
					style={{ zIndex: 1000 }}
					focusOnMount={true}
				>
					<button
						onClick={() => setIsVisible(false)}
						className="borobazar-popover-close-btn position-absolute"
					>
						<CloseIcon />
					</button>
					{/* End of popover dismiss */}

					<MediaUpload
						onSelect={(icon) => updateSocialProfileIcon(icon)}
						allowed={["image"]}
						type="image"
						render={({ open }) => (
							<div onClick={open} className="borobazar-footer-about-us-logo">
								{socialLinks[selectedItem].icon ? (
									<img src={socialLinks[selectedItem].icon} alt="Image" />
								) : (
									<UploadIcon />
								)}

								{__(
									"Click here to upload your social svg image (20 x 20)",
									"borobazar-helper"
								)}
							</div>
						)}
					/>
					{/* End of media upload */}

					<LinkControl
						value={socialLinks[selectedItem].link}
						showInitialSuggestions={true}
						onChange={({
							url: newURL = "",
							opensInNewTab: newOpensInNewTab,
						}) => {
							updateSocialProfileLink(newURL, newOpensInNewTab);
						}}
					/>
					{/* End of link control */}

					<div className="borobazar-popover-footer">
						<Button
							isSecondary
							onClick={() => removeSocialProfile()}
							className="text-center"
						>
							{__("Remove Item", "borobazar-helper")}
						</Button>
						<Button
							isPrimary
							onClick={() => setIsVisible(false)}
							className="text-center"
						>
							{__("Save Changes", "borobazar-helper")}
						</Button>
					</div>
					{/* End of actions */}
				</Popover>
			)}
			{/* End of add social link popover */}
		</div>
	);
};
