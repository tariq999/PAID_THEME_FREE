/**
 * BLOCK: Search Banner
 */

const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import './editor.scss';
import './style.scss';
import attributes from './attributes';
import edit from './edit';
import { CategoryBlockIcon } from './icon';

/**
 *  Register block
 */
registerBlockType('borobazar-blocks/category-grid', {
	title: __('Categories', 'borobazar-helper'),
	textdomain: 'borobazar-helper',
	keywords: [
		__('Category block', 'borobazar-helper'),
		__('Product category', 'borobazar-helper'),
		__('category grid', 'borobazar-helper'),
		__('category slider', 'borobazar-helper'),
	],
	category: 'borobazar-blocks-category',
	attributes,
	icon: <CategoryBlockIcon />,
	getEditWrapperProps() {
		return { 'data-align': 'full' };
	},
	supports: {
		align: false,
		reusable: false,
	},
	edit,
	save: () => {
		return null;
	},
});
