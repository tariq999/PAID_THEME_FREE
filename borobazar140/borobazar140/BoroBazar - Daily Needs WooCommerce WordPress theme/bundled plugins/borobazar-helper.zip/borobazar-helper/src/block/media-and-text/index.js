/**
 * BLOCK: App block
 **/

const { registerBlockType } = wp.blocks;
const { InnerBlocks } = wp.blockEditor;
const { __ } = wp.i18n;

import "./editor.scss";
import "./style.scss";
import attributes from "./attributes";
import edit from "./edit";
import { MediaTextAndCounterIcon } from "./icon";

registerBlockType("borobazar-blocks/media-and-text", {
	title: __("Media, Text and Counter", "borobazar-helper"),
	icon: <MediaTextAndCounterIcon />,
	textdomain: "borobazar-helper",
	category: "borobazar-blocks-category",
	keywords: [__("countdown", "borobazar-helper")],
	keywords: [__("image", "borobazar-helper")],
	attributes,
	edit,
	save: () => {
		return <InnerBlocks.Content />;
	},
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
