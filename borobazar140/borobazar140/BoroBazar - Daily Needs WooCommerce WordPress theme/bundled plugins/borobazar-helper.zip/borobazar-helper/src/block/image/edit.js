const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { TextareaControl, PanelBody } = wp.components;
const { InspectorControls, MediaPlaceholder } = wp.blockEditor;
import { RemoveIcon } from "./icon";

export default (props) => {
	const {
		attributes: { image, alt },
		setAttributes,
		className,
		isSelected,
	} = props;

	return (
		<Fragment>
			<div className={`borobazar-image-block relative ${className}`}>
				{isSelected && image && (
					<div className="borobazar-slider-slide-options">
						<div
							className="remove-slide"
							onClick={() => setAttributes({ image: "" })}
							title={__("Remove", "borobazar-helper")}
						>
							<RemoveIcon />
						</div>
					</div>
				)}

				{image ? (
					<img src={image} alt={alt ? alt : "image"} />
				) : (
					<MediaPlaceholder
						onSelect={(image) => {
							setAttributes({ image: image.url });
						}}
						allowedTypes={["image"]}
						value={image}
						labels={{
							title: __("Upload Image", "borobazar-helper"),
							instructions: __(
								"Drag images, upload new ones or select files from your library.",
								"borobazar-helper"
							),
						}}
					/>
				)}
			</div>

			<InspectorControls>
				<PanelBody
					title={__("General Settings", "borobazar-helper")}
					initialOpen={true}
				>
					<TextareaControl
						label="Alt text (alternative text)"
						help="Enter some text"
						value={alt}
						onChange={(value) => setAttributes({ alt: value })}
					/>
				</PanelBody>
			</InspectorControls>
		</Fragment>
	);
};
