import { useState } from 'react';
import { some } from 'lodash';
const { Fragment } = wp.element;
const { __ } = wp.i18n;
const {
	SelectControl,
	PanelBody,
	RangeControl,
	__experimentalInputControl: InputControl,
} = wp.components;
const { InspectorControls, PanelColorSettings, RichText, MediaPlaceholder } =
	wp.blockEditor;
import CustomColorControl from '../../components/customColorControl';
import PaddingSettings from '../../components/paddingSettings';
import Devices from '../../components/devices';
import Slider from './slider';
import { SearchIcon } from './icon';

export default (props) => {
	const {
		attributes: {
			title,
			description,
			searchSuggestions,
			searchSuggestionColor,
			placeholder,
			backgroundColor,
			searchLayout,
			titleColor,
			descriptionColor,
			backgroundType,
			backgroundImage,
			sliderImages,
			overlay,
			overlayOpacity,
			minHeight,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
		},
		setAttributes,
		className,
		isSelected,
	} = props;

	const [device, setDevice] = useState('desktop');

	const hasImages = !!sliderImages.length;
	const hasImagesWithId = hasImages && some(sliderImages, ({ id }) => id);

	const colors = [
		{
			value: backgroundColor,
			onChange: (value) => {
				setAttributes({
					backgroundColor: value,
				});
			},
			label: __('Background color', 'borobazar-helper'),
		},
		{
			value: titleColor,
			onChange: (value) => {
				setAttributes({
					titleColor: value,
				});
			},
			label: __('Title color', 'borobazar-helper'),
		},
		{
			value: descriptionColor,
			onChange: (value) => {
				setAttributes({
					descriptionColor: value,
				});
			},
			label: __('Description color', 'borobazar-helper'),
		},
		{
			value: searchSuggestionColor,
			onChange: (value) => {
				setAttributes({
					descriptionColor: value,
				});
			},
			label: __('Search Suggestion color', 'borobazar-helper'),
		},
	];

	let styles = {
		backgroundColor: backgroundColor,
		minHeight: minHeight.desktop,
	};
	if (backgroundType === 'image' && backgroundImage) {
		styles = {
			backgroundImage: `url(${backgroundImage})`,
			backgroundColor: backgroundColor,
			minHeight: minHeight.desktop,
		};
	}

	const padding = {
		'--desktop-padding-top': paddingTop.desktop + 'px',
		'--laptop-padding-top': paddingTop.laptop + 'px',
		'--tab-padding-top': paddingTop.tab + 'px',
		'--mobile-padding-top': paddingTop.mobile + 'px',
		'--desktop-padding-right': paddingRight.desktop + 'px',
		'--laptop-padding-right': paddingRight.laptop + 'px',
		'--tab-padding-right': paddingRight.tab + 'px',
		'--mobile-padding-right': paddingRight.mobile + 'px',
		'--desktop-padding-bottom': paddingBottom.desktop + 'px',
		'--laptop-padding-bottom': paddingBottom.laptop + 'px',
		'--tab-padding-bottom': paddingBottom.tab + 'px',
		'--mobile-padding-bottom': paddingBottom.mobile + 'px',
		'--desktop-padding-left': paddingLeft.desktop + 'px',
		'--laptop-padding-left': paddingLeft.laptop + 'px',
		'--tab-padding-left': paddingLeft.tab + 'px',
		'--mobile-padding-left': paddingLeft.mobile + 'px',
	};

	return (
		<Fragment>
			<div className="borobazar-block-spacing-wrapper" style={padding}>
				<div
					className={`borobazar-search-banner relative flex items-center justify-center py-14 px-4 overflow-hidden bg-cover bg-center bg-no-repeat ${className}`}
					style={styles}
				>
					{backgroundType === 'slider' && sliderImages && (
						<div className="absolute w-full h-full inset-0">
							<Slider slideItems={sliderImages} />
						</div>
					)}
					<div
						className="absolute w-full h-full inset-0 z-1"
						style={{
							background: overlay,
							opacity: overlayOpacity / 100,
						}}
					/>
					<div className="text-center relative z-10">
						<RichText
							tagName="h2"
							className="text-5xl leading-snug font-extrabold mt-0 mb-3"
							value={title}
							onChange={(value) => {
								setAttributes({ title: value });
							}}
							placeholder={__('Enter your title', 'borobazar-helper')}
							style={{ color: titleColor }}
						/>
						<RichText
							tagName="div"
							className="text-lg leading-loose"
							value={description}
							onChange={(value) => {
								setAttributes({ description: value });
							}}
							placeholder={__(
								'Enter your description here',
								'borobazar-helper'
							)}
							style={{ color: descriptionColor }}
						/>
						<div className="borobazar-search-banner-form flex max-w-full w-106 h-16 rounded-md bg-white overflow-hidden shadow-dropdown mt-10 mx-auto">
							{searchLayout === 'lily' ? (
								<Fragment>
									<RichText
										tagName="div"
										className="grow text-justify flex items-center whitespace-nowrap overflow-hidden text-ellipsis px-7 text-lightest"
										value={placeholder}
										onChange={(value) => {
											setAttributes({ placeholder: value });
										}}
										placeholder={__(
											'Enter your description here',
											'borobazar-helper'
										)}
									/>
									<div className="flex items-center justify-center px-6 shrink-0">
										<SearchIcon />
									</div>
								</Fragment>
							) : (
								<Fragment>
									<span className="borobazar-search-banner-redirect flex items-center justify-center px-3 md:pl-6 md:pr-4 shrink-0 cursor-pointer">
										<svg
											width="28"
											height="28"
											viewBox="0 0 28 28"
											fill="none"
											xmlns="http://www.w3.org/2000/svg"
										>
											<path
												d="M25.4731 24.0876L18.7845 17.399C20.0801 15.7987 20.8602 13.7652 20.8602 11.5504C20.8602 6.41706 16.6834 2.24023 11.5501 2.24023C6.41677 2.24023 2.23999 6.41701 2.23999 11.5503C2.23999 16.6836 6.41681 20.8604 11.5501 20.8604C13.7649 20.8604 15.7985 20.0804 17.3988 18.7848L24.0874 25.4733C24.2785 25.6644 24.5294 25.7605 24.7803 25.7605C25.0312 25.7605 25.2821 25.6644 25.4732 25.4733C25.8563 25.0902 25.8563 24.4708 25.4731 24.0876ZM11.5501 18.9004C7.49677 18.9004 4.20003 15.6037 4.20003 11.5503C4.20003 7.49697 7.49677 4.20023 11.5501 4.20023C15.6035 4.20023 18.9002 7.49697 18.9002 11.5503C18.9002 15.6037 15.6034 18.9004 11.5501 18.9004Z"
												fill="#02B290"
												stroke="#02B290"
												strokeWidth="0.3"
											/>
										</svg>
									</span>
									<RichText
										tagName="div"
										className="grow text-justify flex items-center whitespace-nowrap overflow-hidden text-ellipsis px-7 text-lightest"
										value={placeholder}
										onChange={(value) => {
											setAttributes({ placeholder: value });
										}}
										placeholder={__(
											'Enter your description here',
											'borobazar-helper'
										)}
									/>
									<span className="borobazar-search-banner-redirect flex items-center justify-center pr-2.5 shrink-0 cursor-pointer">
										<button className="transition-all bg-brand text-white text-sm md:text-[15px] leading-tight font-semibold p-3 md:px-5 md:py-3 lg:py-4 border-0 rounded-lg">
											Search Now
										</button>
									</span>
								</Fragment>
							)}
						</div>

						{isSelected && (
							<RichText
								tagName="p"
								className="mb-0 mt-7 font-medium leading-tight"
								value={searchSuggestions}
								onChange={(value) => {
									setAttributes({ searchSuggestions: value });
								}}
								placeholder={__(
									'Enter your search suggestions',
									'borobazar-helper'
								)}
								style={{ color: searchSuggestionColor }}
							/>
						)}
					</div>
				</div>
			</div>

			<InspectorControls>
				<PanelBody
					title={__('Banner Settings', 'borobazar-helper')}
					icon="format-image"
					initialOpen={true}
				>
					<SelectControl
						label={__('Select Background Type')}
						value={backgroundType}
						onChange={(value) => {
							setAttributes({ backgroundType: value });
						}}
						options={[
							{ value: 'image', label: 'Image' },
							{ value: 'slider', label: 'Slider' },
						]}
					/>
					{backgroundType === 'image' ? (
						<MediaPlaceholder
							onSelect={(image) => {
								setAttributes({ backgroundImage: image.url });
							}}
							allowedTypes={['image']}
							value={backgroundImage}
							labels={{
								title: __('Upload Background Image', 'borobazar-helper'),
								instructions: __(
									'Drag images, upload new ones or select files from your library.',
									'borobazar-helper'
								),
							}}
						/>
					) : (
						<MediaPlaceholder
							onSelect={(images) => {
								setAttributes({ sliderImages: images });
							}}
							allowedTypes={['image']}
							multiple
							addToGallery={hasImagesWithId}
							gallery
							value={hasImagesWithId ? sliderImages : undefined}
							labels={{
								title: __('Upload Slider Images', 'borobazar-helper'),
								instructions: __(
									'Drag images, upload new ones or select files from your library.',
									'borobazar-helper'
								),
							}}
						/>
					)}

					<div
						className="borobazar-block-inline-wrap"
						style={{ marginTop: 25 }}
					>
						<label htmlFor="banner-height">
							{__('Minimum Height', 'borobazar-helper')}
						</label>
						<Devices device={device} handleDevice={(d) => setDevice(d)} />
					</div>
					<InputControl
						id="banner-height"
						value={minHeight[device]}
						onChange={(value) => {
							const finalValue = parseInt(value);
							setAttributes({
								minHeight: {
									...minHeight,
									[device]: finalValue,
								},
							});
						}}
						suffix={<div style={{ padding: '0 5px' }}>px</div>}
						type="number"
					/>
				</PanelBody>

				<PanelBody
					title={__('Search Layout Settings', 'borobazar-helper')}
					icon="format-image"
					initialOpen={false}
				>
					<SelectControl
						label={__('Select Layout Type')}
						value={searchLayout}
						onChange={(value) => {
							setAttributes({ searchLayout: value });
						}}
						options={[
							{ value: 'rose', label: 'Rose' },
							{ value: 'lily', label: 'Lily' },
						]}
					/>
				</PanelBody>

				<PanelBody
					title={__('Overlay Settings', 'borobazar-helper')}
					initialOpen={false}
				>
					<CustomColorControl
						value={overlay}
						onChange={(value) => setAttributes({ overlay: value })}
					/>
					<RangeControl
						label={__('Opacity', 'borobazar-helper')}
						value={overlayOpacity}
						onChange={(value) => setAttributes({ overlayOpacity: value })}
						step={5}
						min={0}
						max={100}
					/>
				</PanelBody>

				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>

				<PanelColorSettings
					title={__('Color Settings', 'borobazar-helper')}
					initialOpen={false}
					colorSettings={colors}
				/>
			</InspectorControls>
		</Fragment>
	);
};
