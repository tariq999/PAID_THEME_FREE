const { InnerBlocks, InspectorControls } = wp.blockEditor;
const { PanelBody, ToggleControl, SelectControl } = wp.components;
const { Fragment } = wp.element;
const { useSelect } = wp.data;
const { __ } = wp.i18n;
import PaddingSettings from '../../components/paddingSettings';
import PostTypes from '../../components/data/getPostData';
// import "../../components/data/";

export default (props) => {
	const {
		className,
		setAttributes,
		attributes: {
			categoryOrderBy,
			categoryOrder,
			showEmptyCategory,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
			enableSubcategory,
			searchedTaxonomoy,
		},
	} = props;

	const isRTL = useSelect((select) => {
		return !!select('core/block-editor').getSettings().isRTL;
	}, []);

	const padding = {
		'--desktop-padding-top': paddingTop.desktop + 'px',
		'--laptop-padding-top': paddingTop.laptop + 'px',
		'--tab-padding-top': paddingTop.tab + 'px',
		'--mobile-padding-top': paddingTop.mobile + 'px',
		'--desktop-padding-right': paddingRight.desktop + 'px',
		'--laptop-padding-right': paddingRight.laptop + 'px',
		'--tab-padding-right': paddingRight.tab + 'px',
		'--mobile-padding-right': paddingRight.mobile + 'px',
		'--desktop-padding-bottom': paddingBottom.desktop + 'px',
		'--laptop-padding-bottom': paddingBottom.laptop + 'px',
		'--tab-padding-bottom': paddingBottom.tab + 'px',
		'--mobile-padding-bottom': paddingBottom.mobile + 'px',
		'--desktop-padding-left': paddingLeft.desktop + 'px',
		'--laptop-padding-left': paddingLeft.laptop + 'px',
		'--tab-padding-left': paddingLeft.tab + 'px',
		'--mobile-padding-left': paddingLeft.mobile + 'px',
	};

	const updateTFunc = (termValue) => {
		setAttributes({ searchedTaxonomoy: termValue });
	};	

	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper borobazar-search-block ${props.className}`}
				style={padding}
			>
				<div className="relative flex">
					{/*Dummy Sidebar */}
					<div className="bg-white shrink-0 w-98 lg:w-80 2xl:w-88 max-w-full py-4 md:py-7 lg:py-0 px-4 md:px-7 lg:pl-0 lg:pr">
						<div className="border border-lighter border-solid rounded-md">
							{[
								__('Fresh vegetables', 'borobazar-helper'),
								__('Quality milk', 'borobazar-helper'),
								__('Fast food items', 'borobazar-helper'),
								__('Fruits', 'borobazar-helper'),
								__('Fresh Meats', 'borobazar-helper'),
								__('Fish', 'borobazar-helper'),
								__('Cold drinks', 'borobazar-helper'),
								__('Grocery items', 'borobazar-helper'),
								__('Edible oils', 'borobazar-helper'),
								__('Diet Nutrition', 'borobazar-helper'),
							].map((item, index) => (
								<div
									key={index}
									className="border-b border-lighter border-solid last:border-0 flex items-center py-3 sm:py-3.5 m-0 px-4 sm:px-5"
								>
									<div className="w-8 sm:w-10 h-8 sm:h-10 mr-3.5 sm:mr-4 shrink-0 bg-base"></div>
									<span className="grow overflow-hidden text-ellipsis">
										{item}
									</span>
								</div>
							))}
						</div>
					</div>

					{/* InnerBlock */}
					<div className="grow w-full lg:w-calc-full-80 2xl:w-calc-full-88">
						<InnerBlocks
							allowedBlocks={[
								'borobazar-blocks/borobazar-search-result',
								'borobazar-blocks/slider',
								'core/shortcode',
								'core/image',
								'core/gallery',
								'core/media-text',
								// 'gridster/recent-product-grid',
								// 'gridster/handpicked-category',
								// 'gridster/handpicked-tag',
								// 'gridster/on-sale',
								// 'gridster/best-selling',
								// 'gridster/top-rated',
								// 'gridster/block-title',
								// 'gridster/special-deals',
								// 'gridster/featured-products',
							]}
							template={[['borobazar-blocks/borobazar-search-result', {}]]}
							templateInsertUpdatesSelection={false}
							__experimentalCaptureToolbars={true}
							templateLock={false}
							__experimentalPassedProps={{
								className: `borobazar-feature-items borobazar-fluid-block ${className}`,
							}}
						/>
					</div>
				</div>
			</div>
			<InspectorControls>
				<PanelBody
					title={__('Data Settings', 'borobazar-helper')}
					initialOpen={true}
				>
					<PostTypes
						title={__(
							'Choose Products taxonomy to search.',
							'borobazar-helper'
						)}
						showTaxonomy="true"
						showTerm="false"
						predefinedPostType="true"
						previousValue="product"
						previousTaxValue={searchedTaxonomoy}
						updateTax={(taxValue) => updateTFunc(taxValue)}
					/>
				</PanelBody>
				<PanelBody
					title={__('Layout Settings', 'borobazar-helper')}
					initialOpen={true}
				>
					{/* <ToggleControl
						label={__("Enable sub-categories", "borobazar-helper")}
						help={__(
							"If true, then sub-categories will be appear on search bar",
							"borobazar-helper"
						)}
						checked={enableSubcategory}
						onChange={() =>
							setAttributes({
								enableSubcategory: enableSubcategory === true ? false : true,
							})
						}
					/> */}
					<ToggleControl
						label={__('Hide empty category on Search bar', 'borobazar-helper')}
						help={__(
							'If selected, then category with no post assigned will hide',
							'borobazar-helper'
						)}
						checked={showEmptyCategory}
						onChange={() =>
							setAttributes({
								showEmptyCategory: showEmptyCategory === true ? false : true,
							})
						}
					/>
					<SelectControl
						label={__('Select category orderby', 'borobazar-helper')}
						value={categoryOrderBy}
						onChange={(value) => {
							setAttributes({ categoryOrderBy: value });
						}}
						options={[
							{ label: 'Menu Order', value: 'menu_order' },
							{ label: 'Name', value: 'name' },
							{ label: 'Term ID', value: 'term_id' },
							{ label: 'Count', value: 'count' },
						]}
						className="borobazar-contact-form-option"
					/>
					{categoryOrderBy !== 'menu_order' ? (
						<SelectControl
							label={__('Select category order', 'borobazar-helper')}
							value={categoryOrder}
							onChange={(value) => {
								setAttributes({ categoryOrder: value });
							}}
							options={[
								{ label: 'ASC', value: 'ASC' },
								{ label: 'DESC', value: 'DESC' },
							]}
							className="borobazar-contact-form-option"
						/>
					) : (
						''
					)}
				</PanelBody>
				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
		</Fragment>
	);
};
