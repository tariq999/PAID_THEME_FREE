import { withGoogleMap, GoogleMap, OverlayView } from "react-google-maps";

// default silver map style
const mapSilverStyle = [
	{
		elementType: "geometry",
		stylers: [
			{
				color: "#e7f2f0",
			},
		],
	},
	{
		elementType: "labels.icon",
		stylers: [
			{
				visibility: "off",
			},
		],
	},
	{
		elementType: "labels.text.fill",
		stylers: [
			{
				color: "#616161",
			},
		],
	},
	{
		elementType: "labels.text.stroke",
		stylers: [
			{
				color: "#e7f2f0",
			},
		],
	},
	{
		featureType: "administrative.land_parcel",
		elementType: "labels.text.fill",
		stylers: [
			{
				color: "#bdbdbd",
			},
		],
	},
	{
		featureType: "poi",
		elementType: "geometry",
		stylers: [
			{
				color: "#eeeeee",
			},
		],
	},
	{
		featureType: "poi",
		elementType: "labels.text.fill",
		stylers: [
			{
				color: "#757575",
			},
		],
	},
	{
		featureType: "poi.park",
		elementType: "geometry",
		stylers: [
			{
				color: "#e5e5e5",
			},
		],
	},
	{
		featureType: "poi.park",
		elementType: "labels.text.fill",
		stylers: [
			{
				color: "#9e9e9e",
			},
		],
	},
	{
		featureType: "road",
		elementType: "geometry",
		stylers: [
			{
				color: "#ffffff",
			},
		],
	},
	{
		featureType: "road.arterial",
		elementType: "labels.text.fill",
		stylers: [
			{
				color: "#757575",
			},
		],
	},
	{
		featureType: "road.highway",
		elementType: "geometry",
		stylers: [
			{
				color: "#dadada",
			},
		],
	},
	{
		featureType: "road.highway",
		elementType: "labels.text.fill",
		stylers: [
			{
				color: "#616161",
			},
		],
	},
	{
		featureType: "road.local",
		elementType: "labels.text.fill",
		stylers: [
			{
				color: "#9e9e9e",
			},
		],
	},
	{
		featureType: "transit.line",
		elementType: "geometry",
		stylers: [
			{
				color: "#e5e5e5",
			},
		],
	},
	{
		featureType: "transit.station",
		elementType: "geometry",
		stylers: [
			{
				color: "#eeeeee",
			},
		],
	},
	{
		featureType: "water",
		elementType: "geometry",
		stylers: [
			{
				color: "#c9c9c9",
			},
		],
	},
	{
		featureType: "water",
		elementType: "labels.text.fill",
		stylers: [
			{
				color: "#9e9e9e",
			},
		],
	},
];

const MarkerIcon = ({ marker, markerAnimation }) => {
	return (
		<div className="pin-wrap">
			<div
				className={`pin flex flex-col items-center relative ${
					!markerAnimation
						? "borobazar-disable-marker-animation"
						: "borobazar-enable-marker-animation"
				}`}
			>
				{marker ? (
					<img src={marker} alt="Marker" className="borobazar-marker-img" />
				) : null}
				{markerAnimation ? (
					<span className="borobazar-marker-animation flex items-center justify-center h-10 w-10 relative -z-1">
						<span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand opacity-20" />
						<span className="relative inline-flex rounded-full h-8 w-8 bg-brand opacity-40" />
					</span>
				) : null}
			</div>
		</div>
	);
};

const getPixelPositionOffset = (width, height) => ({
	x: -(width / 2),
	y: -(height / 2),
});

export const Map = withGoogleMap((props) => {
	const {
		marker = "",
		markerAnimation,
		location: { coordinate },
	} = props;

	return (
		<GoogleMap
			defaultZoom={13}
			center={{
				lat: coordinate.lat,
				lng: coordinate.lng,
			}}
			defaultOptions={{
				zoomControl: false,
				disableDefaultUI: true,
				keyboardShortcuts: false,
			}}
		>
			<OverlayView
				position={{ lat: coordinate.lat, lng: coordinate.lng }}
				mapPaneName={OverlayView.MARKER_LAYER}
				getPixelPositionOffset={getPixelPositionOffset}
			>
				<MarkerIcon marker={marker} markerAnimation={markerAnimation} />
			</OverlayView>
		</GoogleMap>
	);
});

export const SilverMap = withGoogleMap((props) => {
	const {
		marker = "",
		markerAnimation,
		location: { coordinate },
	} = props;

	return (
		<GoogleMap
			defaultZoom={13}
			center={{
				lat: coordinate.lat,
				lng: coordinate.lng,
			}}
			defaultOptions={{
				zoomControl: false,
				disableDefaultUI: true,
				keyboardShortcuts: false,
				styles: mapSilverStyle,
			}}
		>
			<OverlayView
				position={{ lat: coordinate.lat, lng: coordinate.lng }}
				mapPaneName={OverlayView.MARKER_LAYER}
				getPixelPositionOffset={getPixelPositionOffset}
			>
				<MarkerIcon marker={marker} markerAnimation={markerAnimation} />
			</OverlayView>
		</GoogleMap>
	);
});
