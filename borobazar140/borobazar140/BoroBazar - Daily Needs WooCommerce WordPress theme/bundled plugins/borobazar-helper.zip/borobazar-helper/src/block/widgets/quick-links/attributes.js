export default {
	title: {
		type: "string",
		default: "",
	},
	links: {
		type: "array",
		default: [],
	},
};
