export default {
	paddingTop: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	categoryOrderBy: {
		type: 'string',
		default: 'menu_order',
	},
	categoryOrder: {
		type: 'string',
		default: 'ASC',
	},
	showEmptyCategory: {
		type: 'boolean',
		default: false,
	},
	enableSubcategory: {
		type: 'boolean',
		default: false,
	},
	searchedTaxonomoy: {
		type: 'string',
		default: 'product_cat',
	},
};
