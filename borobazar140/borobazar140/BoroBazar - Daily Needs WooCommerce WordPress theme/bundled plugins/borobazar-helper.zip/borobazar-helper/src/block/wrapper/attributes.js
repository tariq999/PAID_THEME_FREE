export default {
	paddingTop: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	marginTop: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	marginRight: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	marginBottom: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	marginLeft: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	boxShadow: {
		type: "object",
		default: {
			horizontal: 0,
			vertical: 0,
			blur: 0,
			spread: 0,
			color: "",
		},
	},
	backgroundColor: {
		type: "string",
		default: "#ffffff",
	},
	borderRadius: {
		type: "number",
		default: 0,
	},
};
