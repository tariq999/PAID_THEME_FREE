/**
 * BLOCK: Collection
 **/

const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

import "./editor.scss";
import "./style.scss";
import attributes from "./attributes";
import edit from "./edit";
import { CollectionIcon } from "./icon";

registerBlockType("borobazar-blocks/collections-block", {
	title: __("Collection", "borobazar-helper"),
	icon: <CollectionIcon />,
	textdomain: "borobazar-helper",
	category: "borobazar-blocks-category",
	keywords: [
		__("Collection", "borobazar-helper"),
		__("Product collection", "borobazar-helper"),
		__("Product catalog", "borobazar-helper"),
		__("Group product", "borobazar-helper"),
	],
	attributes,
	edit,
	save: () => {
		return null;
	},
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
