/**
 * BLOCK: Search Banner
 */

const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./editor.scss";
import "./style.scss";
import attributes from "./attributes";
import edit from "./edit";
import { SliderIcon } from "./icon";

/**
 *  Register block
 */
registerBlockType("borobazar-blocks/slider", {
	title: __("Slider", "borobazar-helper"),
	category: "borobazar-blocks-category",
	keywords: [__("carousel", "borobazar-helper")],
	attributes,
	icon: <SliderIcon />,
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
	supports: {
		align: false,
	},
	edit,
	save: () => {
		return null;
	},
});
