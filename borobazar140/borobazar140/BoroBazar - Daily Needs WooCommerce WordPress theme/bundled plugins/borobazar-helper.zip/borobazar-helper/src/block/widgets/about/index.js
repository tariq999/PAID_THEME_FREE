/**
 * BLOCK: About Block
 **/

const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./editor.scss";
import { AboutIcon } from "./icon";
import attributes from "./attributes";
import edit from "./edit";

registerBlockType("borobazar-blocks/borobazar-about-info-block", {
	title: __("About Us - Footer Widget", "borobazar-helper"),
	description: __(
		"This blocks is used to show site details. You can show logo and business address.",
		"borobazar-helper"
	),
	icon: <AboutIcon />,
	category: "borobazar-blocks-category",
	keywords: [
		__("About block", "borobazar-helper"),
		__("Footer logo", "borobazar-helper"),
		__("Address blocks", "borobazar-helper"),
	],
	attributes,
	edit,
	save: () => null,
});
