/**
 * BLOCK: Collection
 **/

const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

import "./editor.scss";
import "./style.scss";
import attributes from "./attributes";
import edit from "./edit";
import { ImageIcon } from "./icon";

registerBlockType("borobazar-blocks/image-block", {
	title: __("Image", "borobazar-helper"),
	icon: <ImageIcon />,
	textdomain: "borobazar-helper",
	category: "borobazar-blocks-category",
	keywords: [__("Photo", "borobazar-helper")],
	parent: ["borobazar-blocks/media-and-text"],
	attributes,
	edit,
	save: () => {
		return null;
	},
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
