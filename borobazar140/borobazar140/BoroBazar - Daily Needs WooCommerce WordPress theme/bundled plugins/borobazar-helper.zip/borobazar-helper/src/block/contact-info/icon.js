export const ContactInfoIcon = () => (
	<svg version="1.1" x="0px" y="0px" viewBox="0 0 22 22">
		<path
			fill="#02B290"
			d="M16,21.4c-0.8,0-1.6-0.1-2.4-0.3c-2.7-0.6-5.4-2.3-7.7-4.6s-4-5.1-4.6-7.7C0.6,6,1.1,3.6,2.7,2.1l0.4-0.4
	c0.8-0.8,2.2-0.8,3,0l2.5,2.5c0.8,0.8,0.8,2.2,0,3L7.2,8.7c0.7,1.3,1.7,2.5,2.8,3.7c1.1,1.2,2.4,2.1,3.7,2.9l1.5-1.5
	c0.8-0.8,2.2-0.8,3,0l2.5,2.5c0.8,0.8,0.8,2.2,0,3l-0.4,0.4C19.3,20.9,17.8,21.4,16,21.4z M4.6,2.5c-0.2,0-0.3,0.1-0.4,0.2L3.7,3.1
	c-1.2,1.2-1.5,3.1-1,5.3c0.6,2.4,2.1,4.9,4.2,7s4.6,3.6,7,4.2c2.3,0.5,4.2,0.2,5.3-1l0.4-0.4c0.2-0.2,0.2-0.6,0-0.9l-2.5-2.5
	c-0.2-0.2-0.6-0.2-0.9,0l-1.9,1.9c-0.2,0.2-0.6,0.3-0.9,0.1c-1.6-0.8-3.1-2-4.6-3.4c-1.5-1.4-2.6-3-3.4-4.6c0-0.2,0.1-0.5,0.3-0.8
	l1.9-1.9c0.2-0.2,0.2-0.6,0-0.9L5.1,2.7C4.9,2.6,4.8,2.5,4.6,2.5z"
		/>
	</svg>
);

/**
 * https://heroicons.com/
 */
export function PlusIcon({ className = "h-6 w-6" }) {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			className={className}
			fill="none"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth={2}
				d="M12 4v16m8-8H4"
			/>
		</svg>
	);
}

export function UploadIcon() {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			className="h-6 w-6"
			fill="none"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth={2}
				d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
			/>
		</svg>
	);
}

export function CloseIcon() {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			className="h-6 w-6"
			fill="none"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth={2}
				d="M6 18L18 6M6 6l12 12"
			/>
		</svg>
	);
}
