/**
 * BLOCK: Contact Info
 **/

const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./style.scss";
import { ContactInfoIcon } from "./icon";
import attributes from "./attributes";
import edit from "./edit";

registerBlockType("borobazar-blocks/borobazar-contact-info-block", {
	title: __("Contact Info", "borobazar-helper"),
	description: __(
		"This block is used to show contact info details. You can show your contact info.",
		"borobazar-helper"
	),
	icon: <ContactInfoIcon />,
	category: "borobazar-blocks-category",
	keywords: [
		__("Contact Info block", "borobazar-helper"),
		__("Store Address", "borobazar-helper"),
		__("Contact Info", "borobazar-helper"),
	],
	attributes,
	edit,
	save: () => null,
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
