const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { RangeControl, PanelBody, ResizableBox, ToolbarButton } = wp.components;
const {
	InspectorControls,
	RichText,
	BlockControls,
	BlockVerticalAlignmentControl,
	InnerBlocks,
	ColorPaletteControl,
} = wp.blockEditor;
import { PullLeft, PullRight } from './icon';
import PaddingSettings from '../../components/paddingSettings';
import CustomColorControl from '../../components/customColorControl';

export default (props) => {
	const {
		attributes: {
			title,
			description,
			slogan,
			titleColor,
			descriptionColor,
			sloganColor,
			width,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
			verticalAlign,
			textAreaPosition,
		},
		setAttributes,
		className,
		isSelected,
		toggleSelection,
	} = props;

	// this limits the resize to a safe zone to avoid making broken layouts
	const widthConstraintPercentage = 30;
	const applyWidthConstraints = (width) =>
		Math.max(
			widthConstraintPercentage,
			Math.min(width, 100 - widthConstraintPercentage)
		);

	const colorSettings = [
		{
			label: __('Slogan Color', 'borobazar-helper'),
			color: sloganColor,
			onChange: (value) =>
				setAttributes({
					sloganColor: value,
				}),
		},
		{
			label: __('Title Color', 'borobazar-helper'),
			color: titleColor,
			onChange: (value) =>
				setAttributes({
					titleColor: value,
				}),
		},
		{
			label: __('Description Color', 'borobazar-helper'),
			color: descriptionColor,
			onChange: (value) =>
				setAttributes({
					descriptionColor: value,
				}),
		},
	];

	const padding = {
		'--desktop-padding-top': paddingTop.desktop + 'px',
		'--laptop-padding-top': paddingTop.laptop + 'px',
		'--tab-padding-top': paddingTop.tab + 'px',
		'--mobile-padding-top': paddingTop.mobile + 'px',
		'--desktop-padding-right': paddingRight.desktop + 'px',
		'--laptop-padding-right': paddingRight.laptop + 'px',
		'--tab-padding-right': paddingRight.tab + 'px',
		'--mobile-padding-right': paddingRight.mobile + 'px',
		'--desktop-padding-bottom': paddingBottom.desktop + 'px',
		'--laptop-padding-bottom': paddingBottom.laptop + 'px',
		'--tab-padding-bottom': paddingBottom.tab + 'px',
		'--mobile-padding-bottom': paddingBottom.mobile + 'px',
		'--desktop-padding-left': paddingLeft.desktop + 'px',
		'--laptop-padding-left': paddingLeft.laptop + 'px',
		'--tab-padding-left': paddingLeft.tab + 'px',
		'--mobile-padding-left': paddingLeft.mobile + 'px',
	};

	//Flex value for vertical alignment
	let alignItems = '';
	switch (verticalAlign) {
		case 'top':
			alignItems = 'flex-start';
			break;
		case 'center':
			alignItems = 'center';
			break;
		case 'bottom':
			alignItems = 'flex-end';
			break;

		default:
			alignItems = 'center';
			break;
	}

	return (
		<Fragment>
			{/* Block controls */}
			<BlockControls group="block">
				<BlockVerticalAlignmentControl
					onChange={(alignment) => setAttributes({ verticalAlign: alignment })}
					value={verticalAlign}
				/>
				<ToolbarButton
					icon={PullLeft}
					title={__('Show text on left')}
					isActive={textAreaPosition === 'left'}
					onClick={() => setAttributes({ textAreaPosition: 'left' })}
				/>
				<ToolbarButton
					icon={PullRight}
					title={__('Show text on right')}
					isActive={textAreaPosition === 'right'}
					onClick={() => setAttributes({ textAreaPosition: 'right' })}
				/>
			</BlockControls>

			{/* Block content */}
			<div
				className={`borobazar-block-spacing-wrapper borobazar-media-and-text ${className}`}
				style={padding}
			>
				<div
					className="flex"
					style={{
						alignItems: alignItems,
						flexDirection: textAreaPosition == 'left' ? 'row' : 'row-reverse',
					}}
				>
					<ResizableBox
						className={textAreaPosition == 'left' ? 'pr-11' : 'pl-11'}
						size={{ width: width + '%' }}
						minWidth="30%"
						maxWidth="70%"
						enable={{
							right: textAreaPosition == 'left' ? true : false,
							left: textAreaPosition == 'right' ? true : false,
						}}
						onResizeStop={(event, direction, elt) => {
							setAttributes({
								width: applyWidthConstraints(parseInt(elt.style.width)),
							});
							toggleSelection(true);
						}}
						onResizeStart={() => {
							toggleSelection(false);
						}}
					>
						<RichText
							className="text-sm font-bold tracking-wider relative pl-8 mt-0 mb-4 before:w-4 before:h-0.5 before:absolute before:top-1/2 before:-translate-y-2/4 before:left-0 before:bg-black before:block"
							value={slogan}
							placeholder={__('Slogan', 'borobazar-helper')}
							tagName="h4"
							onChange={(value) => setAttributes({ slogan: value })}
							allowedFormats={[]}
							style={{
								color: sloganColor,
							}}
						/>
						<RichText
							className=" text-3xl font-extrabold mt-0 mb-6 leading-normal"
							value={title}
							placeholder={__('Title', 'borobazar-helper')}
							tagName="h2"
							onChange={(value) => setAttributes({ title: value })}
							allowedFormats={[]}
							style={{
								color: titleColor,
							}}
						/>
						<RichText
							className="text-md lg:text-base leading-loose"
							value={description}
							placeholder={__('Description', 'borobazar-helper')}
							tagName="div"
							onChange={(value) => setAttributes({ description: value })}
							style={{
								color: descriptionColor,
							}}
						/>
					</ResizableBox>

					<div
						className={`media-area grow ${
							textAreaPosition == 'left' ? 'pl-11' : 'pr-11'
						}`}
					>
						<InnerBlocks
							renderAppender={isSelected && InnerBlocks.ButtonBlockAppender}
							allowedBlocks={[
								'borobazar-blocks/counter-block',
								'borobazar-blocks/image-block',
							]}
						/>
					</div>
				</div>
			</div>

			{/* Block Settings */}
			<InspectorControls>
				<PanelBody
					title={__('Width settings', 'borobazar-helper')}
					initialOpen={true}
				>
					<RangeControl
						label={__('Text area width', 'borobazar-helper')}
						value={width}
						onChange={(value) => setAttributes({ width: value })}
						step={1}
						min={30}
						max={70}
					/>
				</PanelBody>
				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
					initialOpen={true}
				/>
				<PanelBody
					title={__('Color Settings', 'borobazar-helper')}
					initialOpen={false}
				>
					{colorSettings.map((palette) => (
						<ColorPaletteControl
							label={palette.label}
							value={palette.color}
							onChange={palette.onChange}
						/>
					))}
				</PanelBody>
			</InspectorControls>
		</Fragment>
	);
};
