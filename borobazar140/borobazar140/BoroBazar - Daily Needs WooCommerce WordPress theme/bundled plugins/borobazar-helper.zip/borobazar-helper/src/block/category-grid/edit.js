const { Fragment } = wp.element;
const { __ } = wp.i18n;
const { PanelBody, ToggleControl, SelectControl } = wp.components;
const { InspectorControls } = wp.blockEditor;
const ServerSideRender = wp.serverSideRender;
import PaddingSettings from '../../components/paddingSettings';
import MarginSettings from '../../components/marginSettings';
import TemplateSwitcher from '../../components/templateSwitcher';
import {
	getBoroBazarPaddingStyles,
	getBoroBazarMarginStyles,
} from '../../components/utils';
import { SiriusIcon, VegaIcon, RigelIcon } from './icon';

export default (props) => {
	const {
		className,
		attributes: {
			categoryOrderBy,
			categoryOrder,
			marginTop,
			marginRight,
			marginBottom,
			marginLeft,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
			categoryTemplate,
			enableSubcategory,
			showEmptyCategory,
		},
		attributes,
		setAttributes,
	} = props;

	const templateItems = [
		{
			preview: <SiriusIcon />,
			label: __('Sirius', 'borobazar-helper'),
			value: 'sirius',
		},
		{
			preview: <VegaIcon />,
			label: __('Vega', 'borobazar-helper'),
			value: 'vega',
		},
		{
			preview: <RigelIcon />,
			label: __('Rigel', 'borobazar-helper'),
			value: 'rigel',
		},
	];

	const paddingStyle = getBoroBazarPaddingStyles(attributes);
	const marginStyle = getBoroBazarMarginStyles(attributes);

	let blockStyles = {};
	// margin settings only for rigel template
	if (categoryTemplate === 'rigel') {
		blockStyles = {
			...paddingStyle,
			...marginStyle,
		};
	} else {
		blockStyles = {
			...paddingStyle,
		};
	}
	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper borobazar-block-spacing-margin-wrapper ${className}`}
				style={blockStyles}
			>
				<ServerSideRender
					block="borobazar-blocks/category-grid"
					attributes={{
						categoryOrderBy,
						categoryOrder,
						marginTop,
						marginRight,
						marginBottom,
						marginLeft,
						paddingTop,
						paddingRight,
						paddingBottom,
						paddingLeft,
						categoryTemplate,
						enableSubcategory,
						showEmptyCategory,
					}}
				/>
			</div>
			<InspectorControls>
				<PanelBody
					title={__('General Settings', 'borobazar-helper')}
					initialOpen={true}
				>
					<ToggleControl
						label={__('Enable sub-categories', 'borobazar-helper')}
						help={__(
							'If true, then sub-categories will be appear on search bar',
							'borobazar-helper'
						)}
						checked={enableSubcategory}
						onChange={() =>
							setAttributes({
								enableSubcategory: enableSubcategory === true ? false : true,
							})
						}
					/>
					<ToggleControl
						label={__('Hide empty category on Search bar', 'borobazar-helper')}
						help={__(
							'If selected, then category with no post assigned will hide',
							'borobazar-helper'
						)}
						checked={showEmptyCategory}
						onChange={() =>
							setAttributes({
								showEmptyCategory: showEmptyCategory === true ? false : true,
							})
						}
					/>
					<SelectControl
						label={__('Select orderby', 'borobazar-helper')}
						value={categoryOrderBy}
						onChange={(value) => {
							setAttributes({ categoryOrderBy: value });
						}}
						options={[
							{ label: 'Menu Order', value: 'menu_order' },
							{ label: 'Name', value: 'name' },
							{ label: 'Term ID', value: 'term_id' },
							{ label: 'Count', value: 'count' },
						]}
						className="borobazar-contact-form-option"
					/>
					{categoryOrderBy !== 'menu_order' ? (
						<SelectControl
							label={__('Select order', 'borobazar-helper')}
							value={categoryOrder}
							onChange={(value) => {
								setAttributes({ categoryOrder: value });
							}}
							options={[
								{ label: 'ASC', value: 'ASC' },
								{ label: 'DESC', value: 'DESC' },
							]}
							className="borobazar-contact-form-option"
						/>
					) : (
						''
					)}

					<TemplateSwitcher
						label={__('Select category template', 'borobazar-helper')}
						template={categoryTemplate}
						items={templateItems}
						handleTemplate={(template) =>
							setAttributes({ categoryTemplate: template })
						}
					/>
				</PanelBody>
				{categoryTemplate === 'rigel' && (
					<MarginSettings
						marginTop={marginTop}
						marginRight={marginRight}
						marginBottom={marginBottom}
						marginLeft={marginLeft}
						setAttributes={setAttributes}
					/>
				)}
				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
		</Fragment>
	);
};
