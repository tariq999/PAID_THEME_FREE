import { useState, useEffect } from "react";
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { Button, RangeControl, PanelBody } = wp.components;
const { InspectorControls, RichText, ColorPaletteControl } = wp.blockEditor;
import { RemoveIcon } from "./icon";

export default (props) => {
	const {
		attributes: {
			counterItems,
			columnSize,
			backgroundColor,
			titleColor,
			descriptionColor,
			countColor,
			symbolColor,
		},
		setAttributes,
		className,
		isSelected,
	} = props;

	const [newCounterItem, addNewCounterItem] = useState(false);

	useEffect(() => {
		if (newCounterItem) {
			counterItems.length + 1;
		}
	}, [newCounterItem]);

	const addNewItem = () => {
		let allCounterItems = counterItems;
		setAttributes({
			counterItems: [
				...allCounterItems,
				{
					title: "",
					description: "",
					count: "",
					symbol: "",
				},
			],
		});
		addNewCounterItem(true);
		setCollapse(true);
	};

	const removeItem = (index) => {
		let allCounterItems = counterItems;
		allCounterItems.splice(index, 1);
		setAttributes({
			counterItems: [...allCounterItems],
		});
	};

	const colorSettings = [
		{
			label: __("Title Color", "borobazar-helper"),
			color: titleColor,
			onChange: (value) =>
				setAttributes({
					titleColor: value,
				}),
		},
		{
			label: __("Description Color", "borobazar-helper"),
			color: descriptionColor,
			onChange: (value) =>
				setAttributes({
					descriptionColor: value,
				}),
		},
		{
			label: __("Count Color", "borobazar-helper"),
			color: countColor,
			onChange: (value) =>
				setAttributes({
					countColor: value,
				}),
		},
		{
			label: __("Symbol Color", "borobazar-helper"),
			color: symbolColor,
			onChange: (value) => setAttributes({ symbolColor: value }),
		},
		{
			label: __("Background Color", "borobazar-helper"),
			color: backgroundColor,
			onChange: (value) => setAttributes({ backgroundColor: value }),
		},
	];

	let columnClassName = "";
	switch (columnSize) {
		case 1:
			columnClassName = "grid-cols-1";
			break;
		case 2:
			columnClassName = "grid-cols-2";
			break;
		case 3:
			columnClassName = "grid-cols-3";
			break;

		default:
			columnClassName = "grid-cols-2";
			break;
	}

	return (
		<Fragment>
			<div className={`borobazar-counter-block ${className}`}>
				<div
					className={`borobazar-counters-wrapper grid gap-8 ${columnClassName}`}
				>
					{counterItems &&
						counterItems.map((item, index) => {
							const handleAttribute = (key) => (value) => {
								let allCounterItems = counterItems;

								allCounterItems[index] = {
									...item,
									[key]: value,
								};
								setAttributes({
									counterItems: [...allCounterItems],
								});
							};

							return (
								<div
									key={index}
									className="relative bg-white rounded-xl px-14 py-11 transition-all shadow-countdown hover:shadow-countdown-hover"
									style={{ backgroundColor: backgroundColor }}
								>
									{/* Remove button */}
									{isSelected && (
										<div className="borobazar-slider-slide-options">
											<div
												className="remove-slide"
												onClick={() => removeItem(index)}
												title={__("Remove", "borobazar-helper")}
											>
												<RemoveIcon />
											</div>
										</div>
									)}

									<RichText
										tagName="div"
										className="text-lg font-semibold mb-2"
										placeholder={__("Title here", "borobazar-helper")}
										value={item.title}
										onChange={handleAttribute("title")}
										allowedFormats={[]}
										style={{ color: titleColor }}
									/>
									<div className="flex items-center">
										<RichText
											tagName="span"
											className="text-gx font-semibold leading-none"
											placeholder={__("100", "borobazar-helper")}
											value={item.count}
											onChange={handleAttribute("count")}
											allowedFormats={[]}
											mdivtiline={false}
											style={{ color: countColor }}
										/>
										<RichText
											tagName="span"
											className="text-5xl font-semibold leading-none"
											placeholder={__("%", "borobazar-helper")}
											value={item.symbol}
											onChange={handleAttribute("symbol")}
											allowedFormats={[]}
											mdivtiline={false}
											style={{ color: symbolColor }}
										/>
									</div>
									<RichText
										tagName="div"
										className="mt-4"
										placeholder={__("Description here", "borobazar-helper")}
										value={item.description}
										onChange={handleAttribute("description")}
										allowedFormats={[]}
										style={{ color: descriptionColor }}
									/>
								</div>
							);
						})}
				</div>
				{/* Add new item button */}
				{isSelected && (
					<div className="borobazar-slider-add-slide">
						<Button onClick={addNewItem} isPrimary>
							{__("Add New Item", "borobazar-helper")}
						</Button>
					</div>
				)}
			</div>

			<InspectorControls>
				<PanelBody
					title={__("Column Settings", "borobazar-helper")}
					initialOpen={true}
				>
					<RangeControl
						label={__("Column Size", "borobazar-helper")}
						value={columnSize}
						onChange={(value) => setAttributes({ columnSize: value })}
						step={1}
						min={1}
						max={3}
					/>
				</PanelBody>
				<PanelBody
					title={__("Color Settings", "borobazar-helper")}
					initialOpen={true}
				>
					{colorSettings.map((palette) => (
						<ColorPaletteControl
							label={palette.label}
							value={palette.color}
							onChange={palette.onChange}
						/>
					))}
				</PanelBody>
			</InspectorControls>
		</Fragment>
	);
};
