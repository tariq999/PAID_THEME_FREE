export default {
	categoryOrderBy: {
		type: 'string',
		default: 'menu_order',
	},
	categoryOrder: {
		type: 'string',
		default: 'ASC',
	},
	categoryTemplate: {
		type: 'string',
		default: 'sirius',
	},
	enableSubcategory: {
		type: 'boolean',
		default: false,
	},
	showEmptyCategory: {
		type: 'boolean',
		default: false,
	},
	marginTop: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	marginRight: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	marginBottom: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	marginLeft: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingTop: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
};
