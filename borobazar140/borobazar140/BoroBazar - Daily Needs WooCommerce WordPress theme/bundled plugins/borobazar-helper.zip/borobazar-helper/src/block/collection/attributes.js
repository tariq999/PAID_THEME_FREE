const { __ } = wp.i18n;

export default {
	paddingTop: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	template: {
		type: "string",
		default: "default",
	},
	collectionItems: {
		type: "array",
		default: [
			{
				image: "",
				url: "",
				opensInNewTab: false,
				title: __("Title", "borobazar-helper"),
				description: __("Description", "borobazar-helper"),
				button: __("Explore", "borobazar-helper"),
				overlayOpacity: 0,
				overlay: "#000000",
				backgroundPosition: "50% 50%",
				bgColor: "#fff",
				titleColor: "#000",
				descriptionColor: "#808080",
				buttonColor: "#02b290",
				buttonHoverColor: "#01a585",
			},
		],
		items: [{ type: "object" }],
	},
};
