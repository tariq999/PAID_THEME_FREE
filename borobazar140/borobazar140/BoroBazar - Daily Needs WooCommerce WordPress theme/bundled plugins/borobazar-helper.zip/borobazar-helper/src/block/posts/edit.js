const { __ } = wp.i18n;
const { InspectorControls, ColorPalette, MediaUpload } = wp.blockEditor;
import {
	__experimentalNumberControl as NumberControl,
	SelectControl,
	PanelBody,
	Button,
} from '@wordpress/components';
const ServerSideRender = wp.serverSideRender;
import PaddingSettings from '../../components/paddingSettings';
import TemplateSwitcher from '../../components/templateSwitcher';
import { getBoroBazarPaddingStyles } from '../../components/utils';
import { PostsTemplateIcon } from './icons';

export default (props) => {
	const {
		className,
		attributes: {
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
			titleColor,
			excerptColor,
			fallbackImage,
			template,
			postCount,
			postOrder,
			orderBy,
		},
		attributes,
		setAttributes,
	} = props;

	function onTitleColorChange(color) {
		setAttributes({ titleColor: color });
	}
	function onExcerptColorChange(color) {
		setAttributes({ excerptColor: color });
	}

	function onSelectFallbackImage(image) {
		setAttributes({ fallbackImage: image.sizes.full.url });
	}
	function onUnselectImage() {
		setAttributes({ fallbackImage: null });
	}

	function onNumberChange(number) {
		if (number > 0) setAttributes({ postCount: number });
	}

	function onOrderChange(value) {
		setAttributes({ postOrder: value });
	}

	function onOrderByChange(value) {
		setAttributes({ orderBy: value });
	}

	const paddingStyle = getBoroBazarPaddingStyles(attributes);

	const switcherItems = [
		{
			preview: <PostsTemplateIcon />,
			label: __('Post grid', 'borobazar-helper'),
			value: 'post-grid',
		},
	];

	return [
		<div
			className={`borobazar-block-spacing-wrapper posts-block ${className}`}
			style={paddingStyle}
		>
			<ServerSideRender
				block="borobazar-blocks/borobazar-posts"
				attributes={{
					paddingTop,
					paddingRight,
					paddingBottom,
					paddingLeft,
					titleColor,
					excerptColor,
					fallbackImage,
					template,
					postCount,
					postOrder,
					orderBy,
				}}
			/>
		</div>,
		<InspectorControls>
			<PanelBody title={__('Posts data settings', 'borobazar-helper')}>
				<NumberControl
					label={__('Post count:', 'borobazar-helper')}
					onChange={onNumberChange}
					value={postCount}
				/>
			</PanelBody>

			<PanelBody
				title={__('Post sorting options', 'borobazar-helper')}
				initialOpen={false}
			>
				<SelectControl
					label={__('Order by:', 'borobazar-helper')}
					value={orderBy}
					onChange={onOrderByChange}
					options={[
						{ value: 'none', label: __('None', 'borobazar-helper') },
						{ value: 'date', label: __('Date', 'borobazar-helper') },
						{ value: 'title', label: __('Title', 'borobazar-helper') },
						{
							value: 'menu_order',
							label: __('Menu Order', 'borobazar-helper'),
						},
						{
							value: 'comment_count',
							label: __('Comment Count', 'borobazar-helper'),
						},
						{ value: 'author', label: __('Author', 'borobazar-helper') },
						{ value: 'rand', label: __('Random', 'borobazar-helper') },
					]}
				/>
				{orderBy != 'menu_order' && orderBy != 'rand' && orderBy != 'none' && (
					<SelectControl
						label={__('Post order:', 'borobazar-helper')}
						value={postOrder}
						onChange={onOrderChange}
						options={[
							{ value: 'DESC', label: __('DESC', 'borobazar-helper') },
							{ value: 'ASC', label: __('ASC', 'borobazar-helper') },
						]}
					/>
				)}
			</PanelBody>

			<PanelBody
				title={__('Template Settings', 'borobazar-helper')}
				initialOpen={false}
			>
				<TemplateSwitcher
					label={__('Choose template', 'borobazar-helper')}
					handleTemplate={(template) => {
						setAttributes({ template });
					}}
					template={template}
					items={switcherItems}
				/>
			</PanelBody>

			<PaddingSettings
				paddingTop={paddingTop}
				paddingRight={paddingRight}
				paddingBottom={paddingBottom}
				paddingLeft={paddingLeft}
				setAttributes={setAttributes}
			/>

			<PanelBody
				title={__('Title Color', 'borobazar-helper')}
				initialOpen={false}
			>
				<ColorPalette value={titleColor} onChange={onTitleColorChange} />
			</PanelBody>
			<PanelBody
				title={__('Excerpt Color', 'borobazar-helper')}
				initialOpen={false}
			>
				<ColorPalette value={excerptColor} onChange={onExcerptColorChange} />
			</PanelBody>
			<PanelBody
				title={__('Select a fallback image', 'borobazar-helper')}
				initialOpen={false}
			>
				<p>
					<strong>
						{__(
							"If a post doesn't have a featured image, Your selected image will be shown.",
							'borobazar-helper'
						)}
					</strong>
				</p>
				{fallbackImage ? (
					<div>
						<img src={`${fallbackImage}`} />
					</div>
				) : null}
				<MediaUpload
					onSelect={onSelectFallbackImage}
					type="image"
					value={fallbackImage}
					render={({ open }) => (
						<Button
							onClick={open}
							icon="upload"
							className="editor-media-placeholder__button is-button is-default is-large"
						>
							{__('Select Fallback Image', 'borobazar-helper')}
						</Button>
					)}
				/>
				<Button icon="trash" onClick={onUnselectImage}>
					{__('Unselect Image', 'borobazar-helper')}
				</Button>
			</PanelBody>
		</InspectorControls>,
	];
};
