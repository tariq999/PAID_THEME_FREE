/**
 * BLOCK: Contact Form
 */

const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./editor.scss";
import "./style.scss";
import { ContactFormIcon } from "./icon";
import attributes from "./attributes";
import edit from "./edit";

registerBlockType("borobazar-blocks/borobazar-contact-form", {
	title: __("Contact Form", "borobazar-helper"),
	icon: <ContactFormIcon />,
	category: "borobazar-blocks-category",
	keywords: [
		__("borobazar blocks", "borobazar-helper"),
		__("contact form", "borobazar-helper"),
		__("contact us", "borobazar-helper"),
		__("email form", "borobazar-helper"),
	],
	attributes,
	edit,
	save: () => {
		return null;
	},
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
