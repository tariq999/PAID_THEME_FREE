/**
 * BLOCK: Quick Link
 **/
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./editor.scss";
// import "./style.scss";
import { LinkIcon } from "./icon";

import attributes from "./attributes";
import edit from "./edit";

registerBlockType("borobazar-blocks/borobazar-quick-link", {
	title: __("Quick Links - Footer Widget", "borobazar-helper"),
	description: __("Easily add quick link in your pages.", "borobazar-helper"),
	icon: <LinkIcon />,
	category: "borobazar-blocks-category",
	keywords: [
		__("pages", "borobazar-helper"),
		__("link", "borobazar-helper"),
		__("display page", "borobazar-helper"),
		__("page navigation", "borobazar-helper"),
		__("quick links", "borobazar-helper"),
		__("footer navigation", "borobazar-helper"),
	],
	attributes,
	edit,
	save: () => null,
});
