import { useState } from "react";
import { PlusIcon, CloseIcon } from "./icon";
// wp imports
const { __ } = wp.i18n;
const { RichText, __experimentalLinkControl: LinkControl } = wp.blockEditor;
const { Fragment } = wp.element;
const {
	Button,
	Popover,
	__experimentalInputControl: InputControl,
} = wp.components;

// components
export default (props) => {
	const [isVisible, setIsVisible] = useState(false);
	const [selectedItem, setSelectedItem] = useState(0);
	const {
		attributes: { title, links },
		setAttributes,
		isSelected,
		className = "",
	} = props;

	function addNewLink() {
		const allLinks = links;
		const newLink = {
			text: "Click here",
			link: {
				url: "#",
				opensInNewTab: false,
			},
		};
		setAttributes({ links: [...allLinks, newLink] });
		setSelectedItem(links.length);
		setIsVisible(true);
	}

	function updateOnSelectLink(index) {
		setSelectedItem(index);
		setIsVisible(true);
	}

	function updateQuickLinkText(text) {
		const allLinks = links;
		allLinks[selectedItem] = {
			...allLinks[selectedItem],
			text: text,
		};
		setAttributes({ links: [...allLinks] });
	}

	function updateQuickLinkURL(newURL, newOpensInNewTab) {
		const normalizeURL = newURL.replace(/([^:]\/)\/+/g, "$1");
		const allLinks = links;
		allLinks[selectedItem] = {
			...allLinks[selectedItem],
			link: {
				url: normalizeURL,
				opensInNewTab: newOpensInNewTab,
			},
		};
		setAttributes({ links: [...allLinks] });
	}

	function removeQuickLink() {
		const allLinks = links;
		allLinks.splice(selectedItem, 1);
		setAttributes({ links: [...allLinks] });
		setIsVisible(false);
	}

	return (
		<div className={`borobazar-quick-links flex flex-col ${className}`}>
			<RichText
				tagName="h3"
				value={title}
				onChange={(title) => setAttributes({ title })}
				placeholder={__("Add Title", "borobazar-helper")}
				allowedFormats={[]}
				className="borobazar-quick-links-title text-[15px] sm:text-base 3xl:text-[17px] mt-0 mb-2 sm:mb-2.5 md:mb-4"
			/>

			<Fragment>
				{links.map((item, index) => (
					<div
						key={`borobazar-quick-link-key-${index}`}
						className="borobazar-quick-link cursor-pointer self-start my-1.5 sm:my-2 sm:first:mt-1.5 last:mb-0 no-underline transition-colors duration-200 text-dark hover:text-brand focus:text-brand"
						onClick={() => updateOnSelectLink(index)}
					>
						{item.text}
					</div>
				))}

				{isSelected && (
					<button
						onClick={() => addNewLink()}
						className="w-full h-10 mt-7 flex items-center justify-center rounded transition-colors duration-200 hover:bg-gray-300"
					>
						<PlusIcon className="w-[18px] h-[18px] mr-2" />
						{__("Add new link", "borobazar-helper")}
					</button>
				)}

				{isSelected && isVisible && (
					<Popover
						position="middle right"
						style={{ zIndex: 1000 }}
						focusOnMount={true}
					>
						<div className="borobazar-popover-header">
							<h3>{__("Quick Link", "borobazar-helper")}</h3>
							<button
								onClick={() => setIsVisible(false)}
								className="borobazar-popover-close-btn"
							>
								<CloseIcon />
							</button>
						</div>

						<InputControl
							value={links[selectedItem].text}
							onChange={(text) => updateQuickLinkText(text)}
							placeholder={__("Add link text", "borobazar-helper")}
						/>
						<LinkControl
							value={links[selectedItem].link}
							showInitialSuggestions={true}
							onChange={({
								url: newURL = "",
								opensInNewTab: newOpensInNewTab,
							}) => {
								updateQuickLinkURL(newURL, newOpensInNewTab);
							}}
						/>

						<div className="borobazar-popover-footer">
							<Button
								isSecondary
								onClick={() => removeQuickLink()}
								className="text-center"
							>
								{__("Remove Item", "borobazar-helper")}
							</Button>
							<Button
								isPrimary
								onClick={() => setIsVisible(false)}
								className="text-center"
							>
								{__("Save Changes", "borobazar-helper")}
							</Button>
						</div>
					</Popover>
				)}
			</Fragment>
		</div>
	);
};
