import { useState, useEffect } from "react";
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const {
	Button,
	Popover,
	DropdownMenu,
	MenuItem,
	FocalPointPicker,
	RangeControl,
	PanelBody,
} = wp.components;
const {
	InspectorControls,
	RichText,
	MediaUpload,
	ColorPaletteControl,
	__experimentalLinkControl: LinkControl,
} = wp.blockEditor;
import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Navigation, Pagination, Scrollbar, A11y } from "swiper";
import PaddingSettings from "../../components/paddingSettings";
import CustomColorControl from "../../components/customColorControl";
import TemplateSwitcher from "../../components/templateSwitcher";
import {
	AddIcon,
	RemoveIcon,
	ImageUploadIcon,
	LinkIcon,
	SettingsIcon,
	DefaultTemplateIcon,
	ModernTemplateIcon,
} from "./icon";

// install Swiper components
SwiperCore.use([Navigation, Pagination, Scrollbar, A11y]);

export default (props) => {
	const {
		attributes: {
			collectionItems,
			template,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
		},
		setAttributes,
		className,
		isSelected,
	} = props;

	// States
	const [swiper, setSwiper] = useState(null);
	const [newSlide, addNewSlide] = useState(false);
	const [selectedItemIndex, setSelectedItemIndex] = useState(0);
	const [isPopoverOpen, setPopoverOpen] = useState(false);
	const [popoverContent, setPopoverContent] = useState(null);

	//useEffect
	useEffect(() => {
		if (swiper) {
			swiper.update();
			if (newSlide) swiper.slideTo(collectionItems.length + 1, 500, false);
			addNewSlide(false);
		}
	}, [collectionItems, newSlide]);

	//Selected item attributes
	const selectedItem = collectionItems[selectedItemIndex];
	let url,
		opensInNewTab,
		image,
		backgroundPosition,
		bgColor,
		titleColor,
		descriptionColor,
		buttonColor,
		buttonHoverColor,
		overlay,
		overlayOpacity;
	if (selectedItem) {
		url = selectedItem.url;
		opensInNewTab = selectedItem.opensInNewTab;
		image = selectedItem.image;
		backgroundPosition = selectedItem.backgroundPosition;
		bgColor = selectedItem.bgColor;
		titleColor = selectedItem.titleColor;
		descriptionColor = selectedItem.descriptionColor;
		buttonColor = selectedItem.buttonColor;
		buttonHoverColor = selectedItem.buttonHoverColor;
		overlay = selectedItem.overlay;
		overlayOpacity = selectedItem.overlayOpacity;
	}
	const selectedItemLink = { url, opensInNewTab };

	//convert backgroundPosition to focal point value
	const focalPoint = backgroundPosition
		? backgroundPosition.replaceAll("%", "")
		: "";
	const focalX = parseInt(focalPoint.split(" ")[0]);
	const focalY = parseInt(focalPoint.split(" ").pop());

	//Default attributes for collection item
	const defaultItem = {
		image: "",
		url: "",
		opensInNewTab: false,
		title: __("Title", "borobazar-helper"),
		description: __("Description", "borobazar-helper"),
		button: __("Explore", "borobazar-helper"),
		overlayOpacity: 0,
		overlay: "#000000",
		backgroundPosition: "50% 50%",
		bgColor: "#fff",
		titleColor: "#000",
		descriptionColor: "#808080",
		buttonColor: "#02b290",
		buttonHoverColor: "#01a585",
	};

	//Add new slide
	const addNewItem = () => {
		let allCollectionItems = collectionItems;
		setAttributes({
			collectionItems: [...allCollectionItems, defaultItem],
		});
		addNewSlide(true);
	};

	//Remove slide
	const removeItem = (index) => {
		let allCollectionItems = collectionItems;
		allCollectionItems.splice(index, 1);
		setAttributes({
			collectionItems: [...allCollectionItems],
		});
	};

	//Attribute handlers
	const handleAttribute = (index, value, key, item) => {
		let allCollectionItems = collectionItems;
		let finalValue = key == "image" ? value.url : value;
		allCollectionItems[index] = {
			...item,
			[key]: finalValue,
		};
		setAttributes({
			collectionItems: [...allCollectionItems],
		});
	};

	const handleSelectedAttribute = (value, key) => {
		let allCollectionItems = collectionItems;
		allCollectionItems[selectedItemIndex] = {
			...allCollectionItems[selectedItemIndex],
			[key]: value,
		};
		setAttributes({
			collectionItems: [...allCollectionItems],
		});
	};

	//Link handler
	const handleLink = (newURL, newOpensInNewTab) => {
		let allCollectionItems = collectionItems;
		const normalizeURL = newURL.replace(/([^:]\/)\/+/g, "$1");
		allCollectionItems[selectedItemIndex] = {
			...allCollectionItems[selectedItemIndex],
			url: normalizeURL,
			opensInNewTab: newOpensInNewTab,
		};
		setAttributes({
			collectionItems: [...allCollectionItems],
		});
	};

	const colorSettings = [
		{
			label: __("Background Color", "borobazar-helper"),
			color: bgColor,
			onChange: (value) => handleSelectedAttribute(value, "bgColor"),
		},
		{
			label: __("Title Color", "borobazar-helper"),
			color: titleColor,
			onChange: (value) => handleSelectedAttribute(value, "titleColor"),
		},
		{
			label: __("Description Color", "borobazar-helper"),
			color: descriptionColor,
			onChange: (value) => handleSelectedAttribute(value, "descriptionColor"),
		},
		{
			label: __("Button Color", "borobazar-helper"),
			color: buttonColor,
			onChange: (value) => handleSelectedAttribute(value, "buttonColor"),
		},
		{
			label: __("Button Hover Color", "borobazar-helper"),
			color: buttonHoverColor,
			onChange: (value) => handleSelectedAttribute(value, "buttonHoverColor"),
		},
	];

	const padding = {
		"--desktop-padding-top": paddingTop.desktop + "px",
		"--laptop-padding-top": paddingTop.laptop + "px",
		"--tab-padding-top": paddingTop.tab + "px",
		"--mobile-padding-top": paddingTop.mobile + "px",
		"--desktop-padding-right": paddingRight.desktop + "px",
		"--laptop-padding-right": paddingRight.laptop + "px",
		"--tab-padding-right": paddingRight.tab + "px",
		"--mobile-padding-right": paddingRight.mobile + "px",
		"--desktop-padding-bottom": paddingBottom.desktop + "px",
		"--laptop-padding-bottom": paddingBottom.laptop + "px",
		"--tab-padding-bottom": paddingBottom.tab + "px",
		"--mobile-padding-bottom": paddingBottom.mobile + "px",
		"--desktop-padding-left": paddingLeft.desktop + "px",
		"--laptop-padding-left": paddingLeft.laptop + "px",
		"--tab-padding-left": paddingLeft.tab + "px",
		"--mobile-padding-left": paddingLeft.mobile + "px",
	};

	const switcherItems = [
		{
			preview: <DefaultTemplateIcon />,
			label: __("Default", "borobazar-helper"),
			value: "default",
		},
		{
			preview: <ModernTemplateIcon />,
			label: __("Modern", "borobazar-helper"),
			value: "modern",
		},
	];

	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper borobazar-collection-block ${className}`}
				style={padding}
			>
				{/* Collection slider */}
				{collectionItems && (
					<Swiper
						spaceBetween={25}
						slidesPerView={template == "modern" ? 3 : 4}
						allowTouchMove={false}
						observer
						observeParents
						observeSlideChildren
						navigation={{
							nextEl: ".borobazar-slider-next-button",
							prevEl: ".borobazar-slider-prev-button",
						}}
						onSwiper={setSwiper}
					>
						{collectionItems &&
							collectionItems.map((item, index) => {
								return (
									<SwiperSlide key={index} className="py-1 h-auto">
										<div className="relative h-full">
											{/* Item settings */}
											{isSelected && (
												<div className="borobazar-slider-slide-options">
													{/* Slide Settings */}
													<DropdownMenu
														icon={<SettingsIcon />}
														label={__("Settings", "borobazar-helper")}
														popoverProps={{
															position: "bottom left",
														}}
													>
														{() => (
															<Fragment>
																{item.image && (
																	<MenuItem
																		onClick={() => {
																			setPopoverOpen(true);
																			setPopoverContent("image");
																			setSelectedItemIndex(index);
																		}}
																	>
																		Image Position
																	</MenuItem>
																)}
																<MenuItem
																	onClick={() => {
																		setPopoverOpen(true);
																		setPopoverContent("color");
																		setSelectedItemIndex(index);
																	}}
																>
																	Color settings
																</MenuItem>
																{template == "modern" && (
																	<MenuItem
																		onClick={() => {
																			setPopoverOpen(true);
																			setPopoverContent("overlay");
																			setSelectedItemIndex(index);
																		}}
																	>
																		Overlay settings
																	</MenuItem>
																)}
															</Fragment>
														)}
													</DropdownMenu>
													{/* Add link button */}
													<div
														className="add-link"
														title={__("Edit Link", "borobazar-helper")}
														onClick={() => {
															setPopoverOpen(true);
															setPopoverContent("link");
															setSelectedItemIndex(index);
														}}
													>
														<LinkIcon />
													</div>
													{/* Add image button */}
													<MediaUpload
														onSelect={(image) =>
															handleAttribute(index, image, "image", item)
														}
														allowed={["image"]}
														type="image"
														render={({ open }) => (
															<div
																onClick={open}
																className="edit-image"
																title={__(
																	"Upload/Change Image",
																	"borobazar-helper"
																)}
															>
																<ImageUploadIcon />
															</div>
														)}
													/>
													{/* Remove item button */}
													<div
														className="remove-slide"
														onClick={() => removeItem(index)}
														title={__("Remove", "borobazar-helper")}
													>
														<RemoveIcon />
													</div>
												</div>
											)}

											{/* Collection grid */}
											<div
												className={`relative rounded shadow-product h-full overflow-hidden ${
													template == "modern" && "flex items-center"
												}`}
												style={{ backgroundColor: item.bgColor }}
											>
												{/* image */}
												<div
													className={
														template == "modern"
															? "absolute w-full h-full top-0 left-0"
															: "h-72 overflow-hidden"
													}
												>
													{item.image ? (
														<Fragment>
															<img
																className="w-full h-full object-cover rounded-none"
																style={{
																	borderRadius: 0,
																	objectPosition: item.backgroundPosition,
																}}
																src={item.image}
																alt="slide-image"
															/>
														</Fragment>
													) : (
														template == "default" && (
															//Image Upload
															<MediaUpload
																onSelect={(image) =>
																	handleAttribute(index, image, "image", item)
																}
																allowed={["image"]}
																type="image"
																render={({ open }) => (
																	<div
																		onClick={open}
																		className="borobazar-slider-slide-upload"
																	>
																		<AddIcon />
																		{__("Upload Image", "borobazar-helper")}
																	</div>
																)}
															/>
														)
													)}
												</div>
												{/* overlay */}
												{template == "modern" && (
													<div
														className="absolute w-full h-full inset-0"
														style={{
															background: item.overlay,
															opacity: item.overlayOpacity / 100,
														}}
													/>
												)}
												{/* content */}
												<div
													className={`${
														template == "modern" ? "relative px-8 py-16" : "p-6"
													}`}
												>
													<RichText
														className={
															template == "modern"
																? "m-0 text-3xl font-bold leading-snug"
																: "m-0 text-lg font-semibold"
														}
														value={item.title}
														placeholder={__("Title", "borobazar-helper")}
														tagName={template == "modern" ? "h3" : "div"}
														onChange={(value) =>
															handleAttribute(index, value, "title", item)
														}
														style={{ color: item.titleColor }}
													/>
													<RichText
														className={
															template == "modern"
																? "mt-4 leading-loose"
																: "text-base mt-2.5"
														}
														value={item.description}
														placeholder={__("Description", "borobazar-helper")}
														tagName="div"
														onChange={(value) =>
															handleAttribute(index, value, "description", item)
														}
														style={{ color: item.descriptionColor }}
													/>
													{template == "modern" && (
														<RichText
															className="inline-flex text-sm text-white font-bold min-h-11 py-3 px-5 rounded mt-6"
															value={item.button}
															placeholder={__("Button", "borobazar-helper")}
															tagName="span"
															onChange={(value) =>
																handleAttribute(index, value, "button", item)
															}
															style={{
																background: item.buttonColor,
															}}
														/>
													)}
												</div>
											</div>
										</div>
									</SwiperSlide>
								);
							})}

						{/* Slide navigation's */}
						<div className="borobazar-slider-next-button size-small">
							<svg
								xmlns="http://www.w3.org/2000/svg"
								width="14.1"
								height="24"
								viewBox="0 0 14.1 24"
							>
								<path
									d="M110.841,12.005l-8.978-8.979a1.316,1.316,0,0,1,0-1.856l.787-.786a1.315,1.315,0,0,1,1.857,0l10.69,10.69a1.325,1.325,0,0,1,0,1.863l-10.68,10.68a1.315,1.315,0,0,1-1.857,0l-.787-.786a1.314,1.314,0,0,1,0-1.857Z"
									transform="translate(-101.48)"
									fill="currentColor"
								/>
							</svg>
						</div>
						<div className="borobazar-slider-prev-button size-small">
							<svg
								xmlns="http://www.w3.org/2000/svg"
								width="14.1"
								height="24"
								viewBox="0 0 14.1 24"
							>
								<path
									d="M106.218,12.005,115.2,3.026a1.316,1.316,0,0,0,0-1.856l-.787-.786a1.315,1.315,0,0,0-1.857,0l-10.69,10.69a1.325,1.325,0,0,0,0,1.863l10.68,10.68a1.315,1.315,0,0,0,1.857,0l.787-.786a1.314,1.314,0,0,0,0-1.857Z"
									transform="translate(-101.48)"
									fill="currentColor"
								/>
							</svg>
						</div>
					</Swiper>
				)}
				{/* Add new slide button */}
				{isSelected && (
					<div className="borobazar-slider-add-slide">
						<Button onClick={addNewItem} isPrimary>
							{__("Add New Slide", "borobazar-helper")}
						</Button>
					</div>
				)}

				{/* Central popover */}
				{isPopoverOpen && (
					<Popover
						position="middle"
						onClose={() => setPopoverOpen(false)}
						onFocusOutside={() => setPopoverOpen(false)}
						focusOnMount={popoverContent == "link" ? "firstElement" : false}
					>
						{/* Link control */}
						{popoverContent == "link" && (
							<LinkControl
								value={selectedItemLink}
								showInitialSuggestions={true}
								onChange={({
									url: newURL = "",
									opensInNewTab: newOpensInNewTab,
								}) => {
									handleLink(newURL, newOpensInNewTab);
								}}
							/>
						)}
						{/* image position */}
						{popoverContent == "image" && (
							<div style={{ width: 350, padding: 15 }}>
								<FocalPointPicker
									label={__("Image Position", "borobazar-helper")}
									url={image}
									value={{
										x: focalX / 100,
										y: focalY / 100,
									}}
									onChange={(value) => {
										handleSelectedAttribute(
											`${value.x * 100}% ${value.y * 100}%`,
											"backgroundPosition"
										);
									}}
								/>
							</div>
						)}
						{/* color settings */}
						{popoverContent == "color" && (
							<div style={{ width: 280, height: 360, padding: 16 }}>
								{colorSettings
									.splice(0, template == "default" ? 3 : 5)
									.map((palette) => (
										<ColorPaletteControl
											label={palette.label}
											value={palette.color}
											onChange={palette.onChange}
										/>
									))}
							</div>
						)}
						{/* Overlay settings */}
						{popoverContent == "overlay" && (
							<div style={{ width: 280, padding: 16 }}>
								<CustomColorControl
									value={overlay}
									onChange={(value) =>
										handleSelectedAttribute(value, "overlay")
									}
								/>
								<RangeControl
									label={__("Opacity", "borobazar-helper")}
									value={overlayOpacity}
									onChange={(value) =>
										handleSelectedAttribute(value, "overlayOpacity")
									}
									step={5}
									min={0}
									max={100}
								/>
							</div>
						)}
					</Popover>
				)}
			</div>

			<InspectorControls>
				<PanelBody
					title={__("Template Settings", "borobazar-helper")}
					initialOpen={true}
				>
					<TemplateSwitcher
						label={__("Select template", "borobazar-helper")}
						handleTemplate={(template) => setAttributes({ template: template })}
						template={template}
						items={switcherItems}
					/>
				</PanelBody>
				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
		</Fragment>
	);
};
