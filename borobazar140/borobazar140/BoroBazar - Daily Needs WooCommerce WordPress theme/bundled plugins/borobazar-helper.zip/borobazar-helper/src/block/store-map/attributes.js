export default {
	theme: {
		type: "string",
		default: "silver",
	},
	marker: {
		type: "string",
		default: BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath + "map-marker.svg",
	},
	markerAnimation: {
		type: "boolean",
		default: true,
	},
	height: {
		type: "object",
		default: {
			desktop: 420,
			laptop: 320,
			tab: 260,
			mobile: 180,
		},
	},
	locationData: {
		type: "object",
		default: {
			address: "",
			coordinate: {
				lat: 40.7127753,
				lng: -74.0059728,
			},
		},
	},
	fullWidth: {
		type: "boolean",
		default: false,
	},
};
