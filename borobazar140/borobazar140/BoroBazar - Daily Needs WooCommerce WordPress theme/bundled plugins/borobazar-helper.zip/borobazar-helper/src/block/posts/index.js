/**
 * BLOCK: Posts
 */

const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;
import edit from './edit';
import attributes from './attributes';
import './editor.scss';
import { PostsIcon } from './icons';

/**
 * Register block
 */
registerBlockType('borobazar-blocks/borobazar-posts', {
	title: __('Posts', 'borobazar-helper'),
	description: __('Post block to show post grid.', 'borobazar-helper'),
	icon: <PostsIcon />,
	category: 'borobazar-blocks-category',
	keywords: [
		__('posts', 'borobazar-helper'),
		__('posts grid', 'borobazar-helper'),
	],

	attributes,
	getEditWrapperProps() {
		return { 'data-align': 'full' };
	},
	edit,
	save: () => {
		return null;
	},
});
