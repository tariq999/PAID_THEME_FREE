import { useState } from 'react';
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const {
	Popover,
	FocalPointPicker,
	RangeControl,
	PanelBody,
	ToggleControl,
	SelectControl,
} = wp.components;
const {
	InspectorControls,
	RichText,
	MediaPlaceholder,
	ColorPaletteControl,
	__experimentalLinkControl: LinkControl,
} = wp.blockEditor;
import PaddingSettings from '../../components/paddingSettings';
import CustomColorControl from '../../components/customColorControl';

export default (props) => {
	const {
		attributes: {
			title,
			description,
			playStore,
			appStore,
			titleColor,
			descriptionColor,
			backgroundColor,
			backgroundImage,
			backgroundPosition,
			backgroundRepeat,
			fixedBackground,
			backgroundSize,
			overlay,
			overlayOpacity,
			fullWidth,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
		},
		setAttributes,
		className,
		isSelected,
	} = props;

	const [linkOption, setLinkOption] = useState('');
	const [isPopoverOpen, setPopoverOpen] = useState(false);

	//convert backgroundPosition to focal point value
	const focalPoint = backgroundPosition
		? backgroundPosition.replaceAll('%', '')
		: '';
	const focalX = parseInt(focalPoint.split(' ')[0]);
	const focalY = parseInt(focalPoint.split(' ').pop());

	const padding = {
		'--desktop-padding-top': paddingTop.desktop + 'px',
		'--laptop-padding-top': paddingTop.laptop + 'px',
		'--tab-padding-top': paddingTop.tab + 'px',
		'--mobile-padding-top': paddingTop.mobile + 'px',
		'--desktop-padding-right': paddingRight.desktop + 'px',
		'--laptop-padding-right': paddingRight.laptop + 'px',
		'--tab-padding-right': paddingRight.tab + 'px',
		'--mobile-padding-right': paddingRight.mobile + 'px',
		'--desktop-padding-bottom': paddingBottom.desktop + 'px',
		'--laptop-padding-bottom': paddingBottom.laptop + 'px',
		'--tab-padding-bottom': paddingBottom.tab + 'px',
		'--mobile-padding-bottom': paddingBottom.mobile + 'px',
		'--desktop-padding-left': paddingLeft.desktop + 'px',
		'--laptop-padding-left': paddingLeft.laptop + 'px',
		'--tab-padding-left': paddingLeft.tab + 'px',
		'--mobile-padding-left': paddingLeft.mobile + 'px',
	};

	const bgStyles = {
		backgroundColor: backgroundColor,
		backgroundImage: backgroundImage ? `url(${backgroundImage})` : '',
		backgroundRepeat: backgroundRepeat ? 'repeat' : 'no-repeat',
		backgroundPosition: backgroundPosition,
		backgroundAttachment: fixedBackground ? 'fixed' : '',
		backgroundSize: backgroundSize,
	};

	const colorSettings = [
		{
			label: __('Background Color', 'borobazar-helper'),
			color: backgroundColor,
			onChange: (value) => setAttributes({ backgroundColor: value }),
		},
		{
			label: __('Title Color', 'borobazar-helper'),
			color: titleColor,
			onChange: (value) => setAttributes({ titleColor: value }),
		},
		{
			label: __('Description Color', 'borobazar-helper'),
			color: descriptionColor,
			onChange: (value) => setAttributes({ descriptionColor: value }),
		},
	];

	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper borobazar-app-block ${
					fullWidth ? 'borobazar-full-width-block' : ''
				} ${className}`}
				style={padding}
			>
				<div
					className="relative px-4 sm:px-12 md:px-14 lg:px-20 xl:px-28 4xl:px-48 py-10 sm:py-12 md:py-13 lg:py-14 xl:py-18 4xl:py-24"
					style={bgStyles}
				>
					<div
						className="absolute w-full h-full inset-0"
						style={{
							background: overlay,
							opacity: overlayOpacity / 100,
						}}
					/>
					<div className="relative">
						<RichText
							className="text-xl sm:text-2xl lg:text-3xl xl:text-4xl font-bold mt-0 mb-4 leading-snug"
							value={title}
							placeholder={__('Title', 'borobazar-helper')}
							tagName="h2"
							onChange={(value) => setAttributes({ title: value })}
							allowedFormats={[]}
							style={{
								color: titleColor,
							}}
						/>
						<RichText
							className="text-md lg:text-base leading-loose mb-8"
							value={description}
							placeholder={__('Description', 'borobazar-helper')}
							tagName="div"
							onChange={(value) => setAttributes({ description: value })}
							style={{
								color: descriptionColor,
							}}
						/>
						<div className="flex items-center">
							<div className="relative mr-5 cursor-pointer">
								<img
									src={
										BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath +
										'app-store-btn.svg'
									}
									alt={__('App store button', 'borobazar-helper')}
									className="block"
								/>
								{isSelected && (
									<div
										className="absolute w-full h-full inset-0 bg-black flex items-center justify-center text-center rounded-md text-white text-sm px-1.5"
										onClick={() => {
											setLinkOption('appStore');
											setPopoverOpen(true);
										}}
									>
										{__(
											appStore.url
												? 'Replace App Store URL'
												: 'Add App Store URL',
											'borobazar-helper'
										)}
									</div>
								)}
							</div>
							<div className="relative cursor-pointer">
								<img
									src={
										BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath +
										'play-store-btn.svg'
									}
									alt={__('Play store button', 'borobazar-helper')}
									className="block"
								/>
								{isSelected && (
									<div
										className="absolute w-full h-full inset-0 bg-black flex items-center justify-center text-center rounded-md text-white text-sm px-1.5"
										onClick={() => {
											setLinkOption('playStore');
											setPopoverOpen(true);
										}}
									>
										{__(
											playStore.url
												? 'Replace Play Store URL'
												: 'Add Play Store URL',
											'borobazar-helper'
										)}
									</div>
								)}
							</div>
						</div>
					</div>
				</div>
			</div>

			{isPopoverOpen && (
				<Popover
					position="middle"
					onClose={() => setPopoverOpen(false)}
					onFocusOutside={() => setPopoverOpen(false)}
				>
					<LinkControl
						value={linkOption == 'playStore' ? playStore : appStore}
						showInitialSuggestions={true}
						onChange={({ url, opensInNewTab }) => {
							const normalizeURL = url.replace(/([^:]\/)\/+/g, '$1');
							linkOption == 'playStore'
								? setAttributes({
										playStore: {
											url: normalizeURL,
											opensInNewTab: opensInNewTab,
										},
								  })
								: setAttributes({
										appStore: {
											url: normalizeURL,
											opensInNewTab: opensInNewTab,
										},
								  });
						}}
					/>
				</Popover>
			)}

			<InspectorControls>
				{/* General settings */}
				<PanelBody
					title={__('General settings', 'borobazar-helper')}
					initialOpen={true}
				>
					<ToggleControl
						label={__('Full Width', 'borobazar-helper')}
						checked={fullWidth}
						onChange={(value) => setAttributes({ fullWidth: value })}
						help="There will be no horizontal spacing."
					/>
				</PanelBody>
				{/* Background Image settings */}
				<PanelBody
					title={__('Background image settings', 'borobazar-helper')}
					initialOpen={true}
				>
					<MediaPlaceholder
						onSelect={(image) => {
							setAttributes({ backgroundImage: image.url });
						}}
						allowedTypes={['image']}
						value={backgroundImage}
						labels={{
							title: __('Upload Background Image', 'borobazar-helper'),
							instructions: __(
								'Drag images, upload new ones or select files from your library.',
								'borobazar-helper'
							),
						}}
					/>

					{backgroundImage && (
						<div style={{ marginTop: 20 }}>
							<ToggleControl
								label={__('Fixed Background', 'borobazar-helper')}
								checked={fixedBackground}
								onChange={(value) => setAttributes({ fixedBackground: value })}
							/>
							<ToggleControl
								label={__('Repeated Background', 'borobazar-helper')}
								checked={backgroundRepeat}
								onChange={(value) => setAttributes({ backgroundRepeat: value })}
							/>
							<SelectControl
								label={__('Background Size', 'borobazar-helper')}
								value={backgroundSize}
								onChange={(value) => setAttributes({ backgroundSize: value })}
								options={[
									{ value: 'auto', label: 'Auto' },
									{ value: 'contain', label: 'Contain' },
									{ value: 'cover', label: 'Cover' },
								]}
							/>
							<FocalPointPicker
								label={__('Background Position', 'borobazar-helper')}
								url={backgroundImage}
								value={{
									x: focalX / 100,
									y: focalY / 100,
								}}
								onChange={(value) =>
									setAttributes({
										backgroundPosition: `${value.x * 100}% ${value.y * 100}%`,
									})
								}
							/>
						</div>
					)}
				</PanelBody>

				{/* Overlay settings */}
				<PanelBody
					title={__('Overlay', 'borobazar-helper')}
					initialOpen={false}
				>
					<CustomColorControl
						value={overlay}
						onChange={(value) => setAttributes({ overlay: value })}
					/>
					<RangeControl
						label={__('Opacity', 'borobazar-helper')}
						value={overlayOpacity}
						onChange={(value) => setAttributes({ overlayOpacity: value })}
						step={5}
						min={0}
						max={100}
					/>
				</PanelBody>

				{/* Color settings */}
				<PanelBody
					title={__('Color settings', 'borobazar-helper')}
					initialOpen={false}
				>
					{colorSettings.map((palette) => (
						<ColorPaletteControl
							label={palette.label}
							value={palette.color}
							onChange={palette.onChange}
						/>
					))}
				</PanelBody>

				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
		</Fragment>
	);
};
