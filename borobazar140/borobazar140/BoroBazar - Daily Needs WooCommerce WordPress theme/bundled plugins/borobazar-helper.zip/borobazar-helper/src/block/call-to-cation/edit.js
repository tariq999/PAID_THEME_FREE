import { useState } from 'react';
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { Popover, FocalPointPicker, PanelBody, ToggleControl, SelectControl } =
	wp.components;
const {
	InspectorControls,
	RichText,
	MediaPlaceholder,
	ColorPaletteControl,
	__experimentalLinkControl: LinkControl,
} = wp.blockEditor;
import PaddingSettings from '../../components/paddingSettings';

export default (props) => {
	const {
		attributes: {
			title,
			description,
			ctaButton,
			ctaButtonText,
			titleColor,
			descriptionColor,
			backgroundColor,
			backgroundImage,
			backgroundPosition,
			backgroundRepeat,
			fixedBackground,
			backgroundSize,
			fullWidth,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
		},
		setAttributes,
		className,
		// isSelected,
	} = props;

	const [isPopoverOpen, setPopoverOpen] = useState(false);

	//convert backgroundPosition to focal point value
	const focalPoint = backgroundPosition
		? backgroundPosition.replaceAll('%', '')
		: '';
	const focalX = parseInt(focalPoint.split(' ')[0]);
	const focalY = parseInt(focalPoint.split(' ').pop());

	const padding = {
		'--desktop-padding-top': paddingTop.desktop + 'px',
		'--laptop-padding-top': paddingTop.laptop + 'px',
		'--tab-padding-top': paddingTop.tab + 'px',
		'--mobile-padding-top': paddingTop.mobile + 'px',
		'--desktop-padding-right': paddingRight.desktop + 'px',
		'--laptop-padding-right': paddingRight.laptop + 'px',
		'--tab-padding-right': paddingRight.tab + 'px',
		'--mobile-padding-right': paddingRight.mobile + 'px',
		'--desktop-padding-bottom': paddingBottom.desktop + 'px',
		'--laptop-padding-bottom': paddingBottom.laptop + 'px',
		'--tab-padding-bottom': paddingBottom.tab + 'px',
		'--mobile-padding-bottom': paddingBottom.mobile + 'px',
		'--desktop-padding-left': paddingLeft.desktop + 'px',
		'--laptop-padding-left': paddingLeft.laptop + 'px',
		'--tab-padding-left': paddingLeft.tab + 'px',
		'--mobile-padding-left': paddingLeft.mobile + 'px',
	};

	const bgStyles = {
		backgroundColor: backgroundColor,
		// backgroundImage: backgroundImage ? `url(${backgroundImage})` : '',
		// backgroundRepeat: backgroundRepeat ? 'repeat' : 'no-repeat',
		// backgroundPosition: backgroundPosition,
		// backgroundAttachment: fixedBackground ? 'fixed' : '',
		// backgroundSize: backgroundSize,
	};

	const colorSettings = [
		{
			label: __('Background Color', 'borobazar-helper'),
			color: backgroundColor,
			onChange: (value) => setAttributes({ backgroundColor: value }),
		},
		{
			label: __('Title Color', 'borobazar-helper'),
			color: titleColor,
			onChange: (value) => setAttributes({ titleColor: value }),
		},
		{
			label: __('Description Color', 'borobazar-helper'),
			color: descriptionColor,
			onChange: (value) => setAttributes({ descriptionColor: value }),
		},
	];

	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper borobazar-app-block ${
					fullWidth ? 'borobazar-full-width-block' : ''
				} ${className}`}
				style={padding}
			>
				<div
					className="flex flex-col-reverse md:flex-row lg:grid lg:grid-cols-2 relative rounded-[30px]"
					style={bgStyles}
				>
					<div className="relative text-center md:text-left px-4 sm:px-12 md:px-8 lg:px-12 xl:px-20 3xl:px-28 4xl:pr-36 4xl:pl-40 py-10 sm:py-12 md:py-8 lg:py-10 xl:py-18 4xl:py-20">
						<RichText
							className="text-xl sm:text-2xl lg:text-3xl xl:text-[35px] 2xl:text-[40px] 4xl:text-[42px] font-bold mt-0 mb-4 xl:mb-5 leading-snug sm:leading-snug lg:leading-snug xl:leading-snug -tracking-[0.2px]"
							value={title}
							placeholder={__('Title', 'borobazar-helper')}
							tagName="h2"
							onChange={(value) => setAttributes({ title: value })}
							allowedFormats={[]}
							style={{
								color: titleColor,
							}}
						/>
						<RichText
							className="text-md lg:text-base leading-loose lg:leading-loose hide-br-mobile max-w-sm 2xl:max-w-lg"
							value={description}
							placeholder={__('Description', 'borobazar-helper')}
							tagName="div"
							onChange={(value) => setAttributes({ description: value })}
							style={{
								color: descriptionColor,
							}}
						/>
						<div className="flex justify-center md:justify-start items-center mt-5 lg:mt-8">
							<div className="grid grid-cols-[repeat(2,max-content)] gap-2.5 items-center justify-center transition-all bg-brand text-white text-base font-semibold px-8 py-4 lg:py-5 rounded-full no-underline -translate-y-0 hover:-translate-y-1 hover:text-white focus:text-white">
								<RichText
									value={ctaButtonText}
									placeholder={__('Order More', 'borobazar-helper')}
									tagName="span"
									onChange={(value) => setAttributes({ ctaButtonText: value })}
									style={{
										color: ctaButtonText,
									}}
									onClick={() => setPopoverOpen(true)}
								/>
								<svg
									width="17"
									height="17"
									viewBox="0 0 17 17"
									fill="none"
									xmlns="http://www.w3.org/2000/svg"
									className="ml-2.5"
								>
									<path
										d="M9.03003 1.62305L15.7681 8.36109L9.03003 15.0991"
										stroke="white"
										strokeWidth="2"
										strokeLinecap="round"
										strokeLinejoin="round"
									/>
									<path
										d="M14.8322 8.36133H1.16895"
										stroke="white"
										strokeWidth="2"
										strokeLinecap="round"
										strokeLinejoin="round"
									/>
								</svg>
							</div>
						</div>
					</div>
					<figure className="my-0 flex items-start ml-auto -mt-14 md:mt-0 lg:-mt-9 xl:-mt-24 4xl:-mt-18 max-w-xl 4xl:mr-48">
						<img src={backgroundImage} alt="" />
					</figure>
				</div>
			</div>

			{isPopoverOpen && (
				<Popover
					position="middle"
					onClose={() => setPopoverOpen(false)}
					onFocusOutside={() => setPopoverOpen(false)}
				>
					<LinkControl
						value={ctaButton}
						showInitialSuggestions={true}
						onChange={({ url, opensInNewTab }) => {
							const normalizeURL = url.replace(/([^:]\/)\/+/g, '$1');
							setAttributes({
								ctaButton: {
									url: normalizeURL,
									opensInNewTab: opensInNewTab,
								},
							});
						}}
					/>
				</Popover>
			)}

			<InspectorControls>
				{/* General settings */}
				<PanelBody
					title={__('General settings', 'borobazar-helper')}
					initialOpen={true}
				>
					<ToggleControl
						label={__('Full Width', 'borobazar-helper')}
						checked={fullWidth}
						onChange={(value) => setAttributes({ fullWidth: value })}
						help="There will be no horizontal spacing."
					/>
				</PanelBody>
				{/* Background Image settings */}
				<PanelBody
					title={__('Background image settings', 'borobazar-helper')}
					initialOpen={true}
				>
					<MediaPlaceholder
						onSelect={(image) => {
							setAttributes({ backgroundImage: image.url });
						}}
						allowedTypes={['image']}
						value={backgroundImage}
						labels={{
							title: __('Upload Background Image', 'borobazar-helper'),
							instructions: __(
								'Drag images, upload new ones or select files from your library.',
								'borobazar-helper'
							),
						}}
					/>

					{backgroundImage && (
						<div style={{ marginTop: 20 }}>
							<ToggleControl
								label={__('Fixed Background', 'borobazar-helper')}
								checked={fixedBackground}
								onChange={(value) => setAttributes({ fixedBackground: value })}
							/>
							<ToggleControl
								label={__('Repeated Background', 'borobazar-helper')}
								checked={backgroundRepeat}
								onChange={(value) => setAttributes({ backgroundRepeat: value })}
							/>
							<SelectControl
								label={__('Background Size', 'borobazar-helper')}
								value={backgroundSize}
								onChange={(value) => setAttributes({ backgroundSize: value })}
								options={[
									{ value: 'auto', label: 'Auto' },
									{ value: 'contain', label: 'Contain' },
									{ value: 'cover', label: 'Cover' },
								]}
							/>
							<FocalPointPicker
								label={__('Background Position', 'borobazar-helper')}
								url={backgroundImage}
								value={{
									x: focalX / 100,
									y: focalY / 100,
								}}
								onChange={(value) =>
									setAttributes({
										backgroundPosition: `${value.x * 100}% ${value.y * 100}%`,
									})
								}
							/>
						</div>
					)}
				</PanelBody>

				{/* Color settings */}
				<PanelBody
					title={__('Color settings', 'borobazar-helper')}
					initialOpen={false}
				>
					{colorSettings.map((palette, i) => (
						<ColorPaletteControl
							key={i}
							label={palette.label}
							value={palette.color}
							onChange={palette.onChange}
						/>
					))}
				</PanelBody>

				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
		</Fragment>
	);
};
