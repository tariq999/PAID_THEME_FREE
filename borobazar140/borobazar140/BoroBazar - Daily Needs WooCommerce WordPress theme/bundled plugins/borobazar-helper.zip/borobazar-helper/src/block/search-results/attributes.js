export default {
	gridTemplate: {
		type: 'string',
		default: 'grid_alpine',
	},
	paddingTop: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	scrollToTop: {
		type: 'boolean',
		default: false,
	},
};
