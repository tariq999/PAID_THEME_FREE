export const PullLeft = () => (
	<svg
		width="24"
		height="24"
		xmlns="http://www.w3.org/2000/svg"
		viewBox="0 0 24 24"
		role="img"
		aria-hidden="true"
		focusable="false"
	>
		<path d="M4 18h6V6H4v12zm9-9.5V10h7V8.5h-7zm0 7h7V14h-7v1.5z"></path>
	</svg>
);

export const PullRight = () => (
	<svg
		width="24"
		height="24"
		viewBox="0 0 24 24"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
	>
		<path
			d="M20 18H14V6H20V18ZM11 8.5V10H4V8.5H11ZM11 15.5H4V14H11V15.5Z"
			fill="black"
		/>
	</svg>
);

export const MediaTextAndCounterIcon = () => (
	<svg>
		<path
			fill="none"
			stroke="#02B290"
			strokeWidth="2"
			d="M11,20.2c5.1,0,9.2-4.1,9.2-9.2c0-5.1-4.1-9.2-9.2-9.2S1.8,5.9,1.8,11C1.8,16.1,5.9,20.2,11,20.2z"
		/>
		<path fill="none" stroke="#02B290" strokeWidth="2" d="M11,5.5V11l3.7,1.8" />
	</svg>
);
