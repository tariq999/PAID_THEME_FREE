export default {
	paddingTop: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	title: {
		type: "string",
		default: "",
	},
	description: {
		type: "string",
		default: "",
	},
	slogan: {
		type: "string",
		default: "",
	},
	titleColor: {
		type: "string",
		default: "#000",
	},
	descriptionColor: {
		type: "string",
		default: "#4D4D4D",
	},
	sloganColor: {
		type: "string",
		default: "#000",
	},
	width: {
		type: "number",
		default: 50,
	},
	verticalAlign: {
		type: "string",
		default: "center",
	},
	textAreaPosition: {
		type: "string",
		default: "left",
	},
};
