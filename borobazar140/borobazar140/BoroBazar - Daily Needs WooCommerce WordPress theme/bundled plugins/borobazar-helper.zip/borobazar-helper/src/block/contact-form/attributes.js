export default {
	selectedContactForm: {
		type: "string",
		default: "",
	},
};
