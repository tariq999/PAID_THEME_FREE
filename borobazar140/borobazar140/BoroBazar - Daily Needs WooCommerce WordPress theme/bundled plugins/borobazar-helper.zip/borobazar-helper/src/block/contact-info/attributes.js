const { __ } = wp.i18n;

export default {
	title: {
		type: "string",
		default: __("Support is our main priority", "borobazar-helper"),
	},
	description: {
		type: "string",
		default: __(
			"We created reusable react components, and modern mono repo so you can build multiple apps with common components.",
			"borobazar-helper"
		),
	},
	contactInfo: {
		type: "array",
		default: [
			{
				icon:
					BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath +
					"contact/location.svg",
				title: __("Office Location", "borobazar-helper"),
				description: __(
					"2756 Quiet Valley Lane, Reseda, California, United Stats",
					"borobazar-helper"
				),
			},
			{
				icon:
					BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath + "contact/phone.svg",
				title: __("Call us anytime", "borobazar-helper"),
				description: __(
					"Change the design through a range<br />+89 5631 564  +88 5321 036",
					"borobazar-helper"
				),
			},
			{
				icon:
					BOROBAZAR_HELPER_ADMIN_LOCALIZE.globalImagePath + "contact/at.svg",
				title: __("Send Mail", "borobazar-helper"),
				description: __(
					"support@redqagency.com<br />hire.us@redqteam.io",
					"borobazar-helper"
				),
			},
		],
	},
	titleColor: {
		type: "string",
		default: "#000000",
	},
	descriptionColor: {
		type: "string",
		default: "#595959",
	},
};
