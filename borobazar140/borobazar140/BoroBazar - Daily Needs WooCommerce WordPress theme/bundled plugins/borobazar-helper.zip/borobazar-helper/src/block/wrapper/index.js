/**
 * BLOCK: Wrapper
 **/
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const { InnerBlocks } = wp.blockEditor;

import "./style.scss";
import "./editor.scss";
import attributes from "./attributes";
import edit from "./edit";
import { WrapperIcon } from "./icon";

registerBlockType("borobazar-blocks/borobazar-wrapper", {
	title: __("Block Wrapper", "borobazar-helper"),
	icon: <WrapperIcon />,
	category: "borobazar-blocks-category",
	keywords: [
		__("wrapper", "borobazar-helper"),
		__("group block", "borobazar-helper"),
		__("parent block", "borobazar-helper"),
	],
	supports: {
		align: false,
	},
	attributes,
	edit,
	save: () => {
		return <InnerBlocks.Content />;
	},
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
