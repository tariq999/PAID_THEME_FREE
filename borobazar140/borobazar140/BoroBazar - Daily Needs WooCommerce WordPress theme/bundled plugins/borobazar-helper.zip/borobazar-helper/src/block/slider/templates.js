const { Fragment } = wp.element;
const { __ } = wp.i18n;
const {
	Button,
	Popover,
	DropdownMenu,
	MenuItem,
	MenuGroup,
	FocalPointPicker,
	RangeControl,
	Panel,
	PanelBody,
	ToggleControl,
	SelectControl,
	__experimentalAlignmentMatrixControl: AlignmentMatrixControl,
	__experimentalInputControl: InputControl,
} = wp.components;
const {
	MediaUpload,
	RichText,
	ColorPaletteControl,
	__experimentalLinkControl: LinkControl,
} = wp.blockEditor;
import {
	AddIcon,
	ImageUploadIcon,
	LinkIcon,
	RemoveIcon,
	SettingsIcon,
} from './icon';

export const ImageSlide = ({ slideItem, onUpload }) => {
	return (
		<Fragment>
			{slideItem.image ? (
				<Fragment>
					<img src={slideItem.image} alt="slide-image" />
				</Fragment>
			) : (
				// Media/Image Upload
				<MediaUpload
					onSelect={onUpload}
					allowed={['image']}
					type="image"
					render={({ open }) => (
						<div onClick={open} className="borobazar-slider-slide-upload">
							<AddIcon />
							{__('Upload Slide Image', 'borobazar-helper')}
						</div>
					)}
				/>
			)}
		</Fragment>
	);
};

export const ContentSlide = ({
	slideItem,
	contentPositionClasses,
	titleOnChange,
	sloganOnChange,
	desOnChange,
	buttonOnChange,
}) => {
	return (
		<div
			className={`borobazar-block-spacing-wrapper relative flex ${contentPositionClasses}`}
			style={{
				minHeight: slideItem.height['desktop'],
				backgroundColor: slideItem.backgroundColor,
				backgroundImage: `url(${slideItem.image})`,
				backgroundPosition: slideItem.backgroundPosition,
				backgroundRepeat: slideItem.backgroundRepeat ? 'repeat' : 'no-repeat',
				backgroundSize: slideItem.backgroundSize,
				backgroundAttachment: slideItem.fixedBackground ? 'fixed' : '',
			}}
		>
			<div
				className="absolute w-full h-full inset-0"
				style={{
					background: slideItem.overlay,
					opacity: slideItem.overlayOpacity / 100,
				}}
			/>
			<div className="relative" style={{ textAlign: slideItem.textAlign }}>
				<RichText
					className="text-md font-bold mb-2 font-h6"
					value={slideItem.slogan}
					placeholder={__('Slogan', 'borobazar-helper')}
					tagName="div"
					onChange={sloganOnChange}
					style={{ color: slideItem.sloganColor }}
				/>
				<RichText
					className="text-5xl font-bold leading-tight mb-4 font-h1"
					value={slideItem.title}
					placeholder={__('Title', 'borobazar-helper')}
					tagName="div"
					onChange={titleOnChange}
					style={{ color: slideItem.titleColor }}
				/>
				<RichText
					className="text-lg leading-loose mb-7"
					value={slideItem.description}
					placeholder={__('Description', 'borobazar-helper')}
					tagName="div"
					onChange={desOnChange}
					style={{ color: slideItem.descriptionColor }}
				/>
				<RichText
					className="inline-flex text-sm font-bold min-h-11 py-3 px-5 rounded"
					value={slideItem.button}
					placeholder={__('Button', 'borobazar-helper')}
					tagName="span"
					onChange={buttonOnChange}
					style={{
						color: slideItem.buttonTextColor,
						background: slideItem.buttonColor,
					}}
				/>
			</div>
		</div>
	);
};

export const HeroSlide = ({
	slideItem,
	contentPositionClasses,
	titleOnChange,
	desOnChange,
	buttonOnChange,
}) => {
	return (
		<div
			className={`borobazar-block-spacing-wrapper relative flex ${contentPositionClasses}`}
			style={{
				minHeight: slideItem.height['desktop'],
				backgroundColor: slideItem.backgroundColor,
				backgroundImage: `url(${slideItem.image})`,
				backgroundPosition: slideItem.backgroundPosition,
				backgroundRepeat: slideItem.backgroundRepeat ? 'repeat' : 'no-repeat',
				backgroundSize: slideItem.backgroundSize,
				backgroundAttachment: slideItem.fixedBackground ? 'fixed' : '',
			}}
		>
			<div
				className="absolute w-full h-full inset-0"
				style={{
					background: slideItem.overlay,
					opacity: slideItem.overlayOpacity / 100,
				}}
			/>
			<div className="relative" style={{ textAlign: slideItem.textAlign }}>
				<RichText
					className="text-5xl font-bold leading-tight mb-4 font-h2"
					value={slideItem.title}
					placeholder={__('Title', 'borobazar-helper')}
					tagName="div"
					onChange={titleOnChange}
					style={{ color: slideItem.titleColor }}
				/>
				<RichText
					className="text-lg leading-loose mb-7"
					value={slideItem.description}
					placeholder={__('Description', 'borobazar-helper')}
					tagName="div"
					onChange={desOnChange}
					style={{ color: slideItem.descriptionColor }}
				/>
				<RichText
					className="inline-flex text-sm font-bold min-h-11 py-3 px-5 rounded"
					value={slideItem.button}
					placeholder={__('Button', 'borobazar-helper')}
					tagName="span"
					onChange={buttonOnChange}
					style={{
						color: slideItem.buttonTextColor,
						background: slideItem.buttonColor,
					}}
				/>
			</div>
		</div>
	);
};

export const FeatureSlide = ({
	slideItem,
	titleOnChange,
	desOnChange,
	onUpload,
}) => {
	return (
		<div
			className="relative overflow-hidden flex items-center"
			style={{ backgroundColor: slideItem.backgroundColor }}
		>
			<div className="w-32 4xl:w-44 shrink-0 pr-4">
				{slideItem.image ? (
					<Fragment>
						<img
							className="block w-full h-full object-contain object-center"
							src={slideItem.image}
							alt="slide-image"
						/>
					</Fragment>
				) : (
					// Media/Image Upload
					<MediaUpload
						onSelect={onUpload}
						allowed={['image']}
						type="image"
						render={({ open }) => (
							<div
								onClick={open}
								className="borobazar-slider-slide-upload size-small"
							>
								<AddIcon />
								{__('Upload Image', 'borobazar-helper')}
							</div>
						)}
					/>
				)}
			</div>
			<div className="grow pl-2 4xl:pl-3 flex flex-col justify-center py-6 pr-5 4xl:pr-6">
				<RichText
					className="text-lg 4xl:text-xl font-bold font-h2 mb-2"
					value={slideItem.title}
					placeholder={__('Title', 'borobazar-helper')}
					tagName="div"
					onChange={titleOnChange}
					style={{ color: slideItem.titleColor }}
				/>
				<RichText
					className=""
					value={slideItem.description}
					placeholder={__('Description', 'borobazar-helper')}
					tagName="div"
					onChange={desOnChange}
					style={{ color: slideItem.descriptionColor }}
				/>
			</div>
		</div>
	);
};

export const PromoSlide = ({
	slideItem,
	titleOnChange,
	desOnChange,
	onUpload,
}) => {
	return (
		<div
			className="relative box-border overflow-hidden flex items-center p-4 lg:p-5 3xl:p-6 4xl:p-7"
			style={{ backgroundColor: slideItem.backgroundColor }}
		>
			<div className="w-18 sm:w-20 2xl:w-22 4xl:w-24 h-18 sm:h-20 2xl:h-22 4xl:h-24 rounded-full shadow-slim overflow-hidden flex items-center justify-center bg-white p-4 sm:p-5 shrink-0 mr-4 3xl:mr-5">
				{slideItem.image ? (
					<Fragment>
						<img
							className="block w-full h-full object-contain object-center"
							src={slideItem.image}
							alt="slide-image"
						/>
					</Fragment>
				) : (
					// Media/Image Upload
					<MediaUpload
						onSelect={onUpload}
						allowed={['image']}
						type="image"
						render={({ open }) => (
							<div
								onClick={open}
								className="borobazar-slider-slide-upload size-small"
								style={{ padding: 0 }}
							>
								<AddIcon />
							</div>
						)}
					/>
				)}
			</div>
			<div className="grow flex flex-col justify-center">
				<RichText
					className="text-sm sm:text-md lg:text-base 4xl:text-lg leading-relaxed 2xl:leading-relaxed 3xl:leading-relaxed font-bold mb-3 mt-0 font-h2"
					value={slideItem.title}
					placeholder={__('Title', 'borobazar-helper')}
					tagName="div"
					onChange={titleOnChange}
					style={{ color: slideItem.titleColor }}
				/>
				<RichText
					className="text-xs 4xl:text-sm font-semibold"
					value={slideItem.description}
					placeholder={__('Description', 'borobazar-helper')}
					tagName="div"
					onChange={desOnChange}
					style={{ color: slideItem.descriptionColor }}
				/>
			</div>
		</div>
	);
};

export const PromoSlideV2 = ({
	slideItem,
	titleOnChange,
	desOnChange,
	onUpload,
}) => {
	return (
		<div
			className="relative box-border overflow-hidden flex justify-center gap-5 items-center p-4 lg:p-5 3xl:p-6 4xl:p-7"
			style={{ backgroundColor: slideItem.backgroundColor }}
		>
			<div className="flex flex-col">
				<RichText
					className="text-sm sm:text-md lg:text-base 4xl:text-lg leading-relaxed 2xl:leading-relaxed 3xl:leading-relaxed font-bold mb-3 mt-0 font-h2"
					value={slideItem.title}
					placeholder={__('Title', 'borobazar-helper')}
					tagName="div"
					onChange={titleOnChange}
					style={{ color: slideItem.titleColor }}
				/>
				<RichText
					className="text-xs 4xl:text-sm font-semibold"
					value={slideItem.description}
					placeholder={__('Description', 'borobazar-helper')}
					tagName="div"
					onChange={desOnChange}
					style={{ color: slideItem.descriptionColor }}
				/>
			</div>
			<div className="borobazar-image-fade-in without-image-loader w-18 sm:w-20 3xl:w-22 4xl:w-24 h-18 sm:h-20 3xl:h-22 4xl:h-24 rounded-full shadow-slim overflow-hidden flex items-center bg-white p-4 sm:p-5 shrink-0">
				{slideItem.image ? (
					<Fragment>
						<img
							className="block w-full h-full object-contain object-center"
							src={slideItem.image}
							alt="slide-image"
						/>
					</Fragment>
				) : (
					// Media/Image Upload
					<MediaUpload
						onSelect={onUpload}
						allowed={['image']}
						type="image"
						render={({ open }) => (
							<div
								onClick={open}
								className="borobazar-slider-slide-upload size-small"
								style={{ padding: 0 }}
							>
								<AddIcon />
							</div>
						)}
					/>
				)}
			</div>
		</div>
	);
};
