export const AboutIcon = () => (
	<svg x="0px" y="0px" viewBox="0 0 111.6 111.6">
		<g>
			<path
				fill="#02B290"
				d="M79,99.5l-1.6,6.4c-4.7,1.8-8.4,3.3-11.2,4.2c-2.8,1-6,1.5-9.7,1.5c-5.7,0-10.1-1.4-13.2-4.1
		c-3.1-2.8-4.7-6.3-4.7-10.5c0-1.6,0.1-3.3,0.4-5.1c0.2-1.7,0.6-3.7,1.1-5.8l5.8-20.7c0.5-2,1-3.9,1.3-5.6c0.4-1.8,0.5-3.4,0.5-4.8
		c0-2.6-0.5-4.5-1.6-5.5c-1.1-1-3.2-1.6-6.3-1.6c-1.5,0-3.1,0.2-4.6,0.7c-1.6,0.5-2.9,0.9-4.1,1.3l1.6-6.4c3.8-1.6,7.5-2.9,11-4
		c3.5-1.1,6.8-1.7,9.9-1.7c5.6,0,10,1.4,13,4.1c3,2.7,4.6,6.2,4.6,10.6c0,0.9-0.1,2.5-0.3,4.7c-0.2,2.3-0.6,4.3-1.2,6.2L63.9,84
		c-0.5,1.7-0.9,3.5-1.3,5.7c-0.4,2.1-0.6,3.7-0.6,4.8c0,2.7,0.6,4.6,1.8,5.6c1.2,1,3.4,1.5,6.4,1.5c1.4,0,3-0.3,4.8-0.7
		C76.9,100.3,78.2,99.9,79,99.5z M80.4,13c0,3.6-1.4,6.7-4.1,9.2c-2.7,2.5-6,3.8-9.8,3.8c-3.8,0-7.1-1.3-9.9-3.8
		c-2.7-2.5-4.1-5.6-4.1-9.2c0-3.6,1.4-6.7,4.1-9.2c2.7-2.5,6-3.8,9.9-3.8c3.8,0,7.1,1.3,9.8,3.8C79.1,6.4,80.4,9.4,80.4,13z"
			/>
		</g>
	</svg>
);

/**
 * https://heroicons.com/
 */
export function PlusIcon() {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			className="h-6 w-6"
			fill="none"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth={2}
				d="M12 4v16m8-8H4"
			/>
		</svg>
	);
}

export function PhotographIcon() {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			className="h-6 w-6"
			fill="none"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth={2}
				d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
			/>
		</svg>
	);
}

export function UploadIcon() {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			className="h-6 w-6"
			fill="none"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth={2}
				d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
			/>
		</svg>
	);
}

export function CloseIcon() {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			className="h-6 w-6"
			fill="none"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth={2}
				d="M6 18L18 6M6 6l12 12"
			/>
		</svg>
	);
}
