/**
 * BLOCK: Product Search
 **/

const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

import './editor.scss';
import './style.scss';
import { ProductBlockIcon } from './icon';
import attributes from './attributes';
import edit from './edit';

registerBlockType('borobazar-blocks/borobazar-search-result', {
	title: __('Search Results', 'borobazar-helper'),
	icon: <ProductBlockIcon />,
	category: 'borobazar-blocks-category',
	keywords: [
		__('Search block', 'borobazar-helper'),
		__('Product grid', 'borobazar-helper'),
		__('Search page', 'borobazar-helper'),
		__('Search results', 'borobazar-helper'),
	],
	textdomain: 'borobazar-helper',
	attributes,
	parent: [
		'borobazar-blocks/borobazar-search-block',
		'borobazar-blocks/borobazar-extended-search-block',
	],
	usesContext: ['borobazar-blocks/borobazar-product-search-sidebar'],
	supports: {
		align: false,
		reusable: false,
	},
	getEditWrapperProps() {
		return { 'data-align': 'full' };
	},
	edit,
	save: () => {
		return null;
	},
});
