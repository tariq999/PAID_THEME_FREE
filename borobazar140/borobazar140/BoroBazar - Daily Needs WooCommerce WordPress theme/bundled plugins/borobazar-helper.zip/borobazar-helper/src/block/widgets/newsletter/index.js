/**
 * BLOCK: Newsletter
 **/
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
import "./editor.scss";
import { NewsletterIcon } from "./icon";
import attributes from "./attributes";
import edit from "./edit";

registerBlockType("borobazar-blocks/borobazar-newsletter", {
	title: __("Newsletter - Footer Widget", "borobazar-helper"),
	icon: <NewsletterIcon />,
	category: "borobazar-blocks-category",
	keywords: [
		__("newsletter", "borobazar-helper"),
		__("subscription", "borobazar-helper"),
		__("subscribe", "borobazar-helper"),
		__("email subscription", "borobazar-helper"),
	],
	attributes,
	edit,
	save: () => null,
});
