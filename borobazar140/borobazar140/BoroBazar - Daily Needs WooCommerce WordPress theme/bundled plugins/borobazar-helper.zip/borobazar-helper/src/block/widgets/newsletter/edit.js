const { __ } = wp.i18n;
const { TextControl, TextareaControl, PanelBody, PanelRow } = wp.components;
const ServerSideRender = wp.serverSideRender;
const { InspectorControls } = wp.blockEditor;

export default (props) => {
	const {
		attributes: { title, content, newsLetterLink },
		setAttributes,
		className,
	} = props;

	const onChangeTitle = (value) => {
		setAttributes({ title: value });
	};

	const onChangeContent = (value) => {
		setAttributes({ content: value });
	};

	const onChangeNewsLetterLink = (value) => {
		setAttributes({ newsLetterLink: value });
	};

	return (
		<div className={className}>
			<ServerSideRender
				block="borobazar-blocks/borobazar-newsletter"
				attributes={{ title, content, newsLetterLink }}
			/>

			<InspectorControls>
				<PanelBody title="Newsletter Settings" initialOpen={true}>
					<PanelRow>
						<TextControl
							label={__("Newsletter title", "borobazar-helper")}
							id="newsletter-title"
							onChange={onChangeTitle}
							value={title ? title : ""}
							placeholder={__("enter block title", "borobazar-helper")}
						/>
					</PanelRow>
					<PanelRow>
						<TextareaControl
							label={__("Newsletter content", "borobazar-helper")}
							id="newsletter-content"
							onChange={onChangeContent}
							value={content ? content : ""}
							placeholder={__(
								"enter newsletter description",
								"borobazar-helper"
							)}
						/>
					</PanelRow>
					<PanelRow>
						<TextControl
							label={__("Newsletter link", "borobazar-helper")}
							id="newsletter-link"
							onChange={onChangeNewsLetterLink}
							value={newsLetterLink ? newsLetterLink : ""}
							placeholder={__("enter newsletter link", "borobazar-helper")}
						/>
					</PanelRow>
				</PanelBody>
			</InspectorControls>
		</div>
	);
};
