/**
 * BLOCK: Accordion
 */

const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./editor.scss";
import "./style.scss";
import { AccordionIcon } from "./icon";
import attributes from "./attributes";
import edit from "./edit";

/**
 * Register block
 */
registerBlockType("borobazar-blocks/borobazar-accordion", {
	title: __("Accordion", "borobazar-helper"),
	description: __(
		"Accordion blocks to show accordion content.",
		"borobazar-helper"
	),
	icon: <AccordionIcon />,
	category: "borobazar-blocks-category",
	keywords: [
		__("faq", "borobazar-helper"),
		__("frequently ask question", "borobazar-helper"),
		__("accordion", "borobazar-helper"),
	],
	example: {
		attributes: {
			accordionItems: [
				{
					title: __("What is reqular license?", "borobazar-helper"),
					description: __(
						"Regular license can be used for end products that do not charge users for access or service (access is free and there will be no monthly subscription fee)."
					),
				},
				{
					title: __("What is update policy?", "borobazar-helper"),
					description: __(
						"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt",
						"borobazar-helper"
					),
				},
				{
					title: __("What is extended license?", "borobazar-helper"),
					description: __(
						"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt",
						"borobazar-helper"
					),
				},
			],
		},
	},
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
	attributes,
	edit,
	save: () => {
		return null;
	},
});
