export default {
	titleColor: {
		type: 'string',
		default: '#000000',
	},
	excerptColor: {
		type: 'string',
		default: '#000000',
	},
	paddingTop: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	fallbackImage: {
		type: 'string',
		default: null,
	},
	template: {
		type: 'string',
		default: 'post-grid',
	},
	postCount: {
		type: 'string',
		default: '12',
	},
	postOrder: {
		type: 'string',
		default: 'DESC',
	},

	orderBy: {
		type: 'string',
		default: 'none',
	},
};
