/**
 * BLOCK: Search Banner
 */

const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./editor.scss";
import "./style.scss";
import attributes from "./attributes";
import edit from "./edit";
import { SearchBlockIcon } from "./icon";

/**
 *  Register block
 */
registerBlockType("borobazar-blocks/search-banner", {
	title: __("Search Banner", "borobazar-helper"),
	category: "borobazar-blocks-category",
	attributes,
	icon: <SearchBlockIcon />,
	keywords: [
		__("Hero banner", "borobazar-helper"),
		__("Top banner", "borobazar-helper"),
		__("Main banner", "borobazar-helper"),
		__("Find", "borobazar-helper"),
	],
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
	supports: {
		align: false,
		reusable: false,
	},
	edit,
	save: () => {
		return null;
	},
});
