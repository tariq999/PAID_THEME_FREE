export default {
	teamMembers: {
		type: "array",
		default: [],
	},
	columnSize: {
		type: "number",
		default: 4,
	},
	nameColor: {
		type: "string",
		default: "#000000",
	},
	designationColor: {
		type: "string",
		default: "#595959",
	},
	paddingTop: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
};
