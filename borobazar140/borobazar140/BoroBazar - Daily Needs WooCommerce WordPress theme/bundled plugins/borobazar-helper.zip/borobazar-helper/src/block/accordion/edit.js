import { useState, useEffect } from 'react';
const { Fragment } = wp.element;
const { Button } = wp.components;
const { InspectorControls } = wp.blockEditor;
const { __ } = wp.i18n;

import AccordionItem from './accordionItem';
import PaddingSettings from '../../components/paddingSettings';

export default (props) => {
	const {
		attributes: {
			accordionItems,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
		},
		setAttributes,
		className,
		isSelected,
	} = props;

	const [newAccordionItem, addNewAccordionItem] = useState(false);
	const [collapse, setCollapse] = useState(false);

	useEffect(() => {
		if (newAccordionItem) {
			accordionItems.length + 1;
		}
	}, [newAccordionItem]);

	const handleAddNewAccordionItem = () => {
		let allAccordions = accordionItems;
		setAttributes({ accordionItems: [...allAccordions, { title: '' }] });
		addNewAccordionItem(true);
		setCollapse(true);
	};

	const handleRemoveAccordion = (index) => {
		let allAccordions = accordionItems;
		allAccordions.splice(index, 1);
		setAttributes({
			accordionItems: [...allAccordions],
		});
	};

	const padding = {
		'--desktop-padding-top': paddingTop.desktop + 'px',
		'--laptop-padding-top': paddingTop.laptop + 'px',
		'--tab-padding-top': paddingTop.tab + 'px',
		'--mobile-padding-top': paddingTop.mobile + 'px',
		'--desktop-padding-right': paddingRight.desktop + 'px',
		'--laptop-padding-right': paddingRight.laptop + 'px',
		'--tab-padding-right': paddingRight.tab + 'px',
		'--mobile-padding-right': paddingRight.mobile + 'px',
		'--desktop-padding-bottom': paddingBottom.desktop + 'px',
		'--laptop-padding-bottom': paddingBottom.laptop + 'px',
		'--tab-padding-bottom': paddingBottom.tab + 'px',
		'--mobile-padding-bottom': paddingBottom.mobile + 'px',
		'--desktop-padding-left': paddingLeft.desktop + 'px',
		'--laptop-padding-left': paddingLeft.laptop + 'px',
		'--tab-padding-left': paddingLeft.tab + 'px',
		'--mobile-padding-left': paddingLeft.mobile + 'px',
	};

	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper ${className}`}
				style={padding}
			>
				{accordionItems.map((item, index) => {
					const handleEditAccordion = (key) => (inputValue) => {
						let allAccordions = accordionItems;
						let value = inputValue;

						allAccordions[index] = {
							...item,
							[key]: value,
						};
						setAttributes({
							accordionItems: [...allAccordions],
						});
					};
					return (
						<AccordionItem
							title={item.title}
							description={item.description}
							titleOnChange={handleEditAccordion('title')}
							descriptionOnChange={handleEditAccordion('description')}
							handleRemoveAccordion={() => handleRemoveAccordion(index)}
							key={index}
							id={index}
							collapsed={collapse ? false : index !== 0 ? true : false}
							isSelected={isSelected}
						/>
					);
				})}
				{isSelected ? (
					<Button isPrimary isLarge onClick={handleAddNewAccordionItem}>
						{__('Add new item', 'borobazar-helper')}
					</Button>
				) : (
					''
				)}
			</div>

			<InspectorControls>
				<PaddingSettings
					initialOpen
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
		</Fragment>
	);
};
