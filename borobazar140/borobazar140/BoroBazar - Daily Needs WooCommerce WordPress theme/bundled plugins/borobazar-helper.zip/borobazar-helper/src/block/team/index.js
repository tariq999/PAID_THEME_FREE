/**
 * BLOCK: Team
 **/

const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;

import "./style.scss";
import { TeamIcon } from "./icon";
import attributes from "./attributes";
import edit from "./edit";

registerBlockType("borobazar-blocks/borobazar-team-block", {
	title: __("Team", "borobazar-helper"),
	description: __(
		"This block is for representing your team member",
		"borobazar-helper"
	),
	icon: <TeamIcon />,
	category: "borobazar-blocks-category",
	keywords: [
		__("Team block", "borobazar-helper"),
		__("Team", "borobazar-helper"),
	],
	attributes,
	edit,
	save: () => null,
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
