import { useState } from "react";
import { PlusIcon, UploadIcon, CloseIcon } from "./icon";
// wp imports
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { RangeControl, PanelBody } = wp.components;
const { RichText, MediaUpload, ColorPaletteControl, InspectorControls } =
	wp.blockEditor;
// custom imports
import PaddingSettings from "../../components/paddingSettings";
import { getBoroBazarPaddingStyles } from "../../components/utils";

// components
export default (props) => {
	const [selectedMember, setSelectedMember] = useState(0);
	const {
		attributes: {
			teamMembers,
			columnSize,
			nameColor,
			designationColor,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
		},
		attributes,
		setAttributes,
		isSelected,
		className = "",
	} = props;

	function updateTeamMember(key, content, index) {
		const allTeamMembers = teamMembers;
		allTeamMembers[index] = {
			...allTeamMembers[index],
			[key]: content,
		};
		setAttributes({ teamMembers: [...allTeamMembers] });
		setSelectedMember(index);
	}

	function addNewTeamMember() {
		const allTeamMembers = teamMembers;
		const newTeamMember = {
			thumb: "",
			name: "",
			designation: "",
		};
		setAttributes({ teamMembers: [...allTeamMembers, newTeamMember] });
		setSelectedMember(allTeamMembers.length);
	}

	function removeTeamMember(index) {
		const allTeamMembers = teamMembers;
		allTeamMembers.splice(index, 1);
		setAttributes({ teamMembers: [...allTeamMembers] });
	}

	// styles
	const paddingStyle = getBoroBazarPaddingStyles(attributes);
	const blockStyle = {
		...paddingStyle,
	};

	// set column class
	let columnClass = "";
	switch (columnSize) {
		case 6:
			columnClass =
				"grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6";
			break;

		case 5:
			columnClass = "grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5";
			break;

		case 4:
			columnClass = "grid-cols-2 md:grid-cols-3 lg:grid-cols-4";
			break;

		case 3:
			columnClass = "grid-cols-2 md:grid-cols-3";
			break;

		default:
			columnClass = "grid-cols-2";
			break;
	}

	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper borobazar-team-block ${className}`}
				style={blockStyle}
			>
				<div className={`grid gap-4 sm:gap-6 lg:gap-8 ${columnClass}`}>
					{teamMembers.map((member, index) => (
						<div
							key={`team-member-key${index}`}
							onClick={() => setSelectedMember(index)}
							className={`borobazar-team-member group relative ${
								isSelected &&
								"transition-all duration-200 hover:p-3 hover:border hover:border-red-300"
							} ${
								isSelected && selectedMember === index
									? "p-3 border border-red-300"
									: ""
							}`}
						>
							<div className="member-image mb-2 sm:mb-4">
								<MediaUpload
									onSelect={(content) =>
										updateTeamMember("thumb", content.url, index)
									}
									allowed={["image"]}
									type="image"
									render={({ open }) => (
										<div
											onClick={open}
											className="cursor-pointer"
											title={__(
												"Click here to upload image",
												"borobazar-helper"
											)}
										>
											{member.thumb ? (
												<img
													src={member.thumb}
													alt={member.name}
													className="w-full aspect-square object-cover"
												/>
											) : (
												<div className="flex items-center justify-center bg-base aspect-square">
													<UploadIcon />
												</div>
											)}
										</div>
									)}
								/>
							</div>
							<div className="member-info">
								<RichText
									tagName="h5"
									value={member.name}
									onChange={(content) =>
										updateTeamMember("name", content, index)
									}
									placeholder={__("Enter Name", "borobazar-helper")}
									allowedFormats={[]}
									className="mt-0 mb-0.5 text-sm sm:text-md sm:mb-1.5 md:mb-2"
									style={{
										color: nameColor,
									}}
								/>
								<RichText
									tagName="div"
									value={member.designation}
									onChange={(content) =>
										updateTeamMember("designation", content, index)
									}
									placeholder={__("Enter Designation", "borobazar-helper")}
									className="text-xs sm:text-md"
									style={{
										color: designationColor,
									}}
								/>
							</div>

							{isSelected && (
								<button
									onClick={() => removeTeamMember(index)}
									title={__("Delete", "borobazar-helper")}
									className="absolute top-2 right-2 z-5 rounded-full inline-flex items-center justify-center w-7 h-7 transition-opacity duration-200 opacity-0 text-white bg-red-600 hover:bg-red-500 group-hover:opacity-100 group-focus:opacity-100"
								>
									<CloseIcon />
								</button>
							)}
						</div>
					))}

					{isSelected && (
						<button
							onClick={() => addNewTeamMember()}
							className="w-full h-14 self-center flex items-center justify-center rounded transition-colors duration-200 bg-base hover:bg-gray-200"
						>
							<PlusIcon className="w-[18px] h-[18px] mr-2" />
							{__("Add new member", "borobazar-helper")}
						</button>
					)}
				</div>
			</div>
			{/* End of edit block */}

			<InspectorControls>
				<PanelBody
					title={__("Column Size", "borobazar-helper")}
					initialOpen={true}
				>
					<RangeControl
						value={columnSize}
						onChange={(value) =>
							setAttributes({
								columnSize: value,
							})
						}
						min={2}
						max={6}
						required
					/>
				</PanelBody>
				<PanelBody
					title={__("Color Settings", "borobazar-helper")}
					initialOpen={false}
				>
					<div style={{ marginBottom: "24px" }}>
						<ColorPaletteControl
							label={__("Name Color:", "borobazar-helper")}
							value={nameColor}
							onChange={(value) =>
								setAttributes({
									nameColor: value,
								})
							}
						/>
					</div>
					<div style={{ marginBottom: "24px" }}>
						<ColorPaletteControl
							label={__("Designation Color:", "borobazar-helper")}
							value={designationColor}
							onChange={(value) =>
								setAttributes({
									designationColor: value,
								})
							}
						/>
					</div>
				</PanelBody>
				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
			{/* End block settings */}
		</Fragment>
	);
};
