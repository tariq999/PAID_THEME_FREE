import { useState, useEffect } from "react";
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { Button } = wp.components;
const { RichText } = wp.blockEditor;
const { InspectorControls } = wp.blockEditor;

import PaddingSettings from "../../components/paddingSettings";
import { CloseIcon } from "./icon";

export default (props) => {
	const {
		className,
		attributes: {
			scrollItems,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
		},
		setAttributes,
	} = props;
	const [selectedItem, setSelectedItem] = useState(scrollItems[0]);
	const [currentCursor, setCurrentCursorItem] = useState({
		index: 0,
		remove: false,
	});
	useEffect(() => {
		setSelectedItem(scrollItems[scrollItems.length - 1]);
		if (currentCursor.remove) {
			const index =
				currentCursor.index >= scrollItems.length
					? currentCursor.index - 1
					: currentCursor.index;
			setSelectedItem(scrollItems[index]);
			setCurrentCursorItem({ index, remove: false });
		}
	}, [scrollItems.length, currentCursor]);
	const handleAddNewScrollItem = () => {
		const newScrollItem = { id: new Date().getTime(), title: "", content: "" };
		setAttributes({
			scrollItems: [...scrollItems, newScrollItem],
		});
	};

	const handleItemSelection = (id) => {
		const item = scrollItems.find((item) => id === item.id);
		setSelectedItem(item);
	};
	const handleDataSaving = (text, key) => {
		const index = scrollItems.findIndex((item) => selectedItem.id === item.id);
		if (index !== -1) {
			setSelectedItem({
				...selectedItem,
				[key]: text,
			});
			let changedScrollItems = scrollItems;
			changedScrollItems[index] = {
				...changedScrollItems[index],
				[key]: text,
			};
			setAttributes({
				scrollItems: [...changedScrollItems],
			});
		}
	};

	const handleRemoveItem = (index) => {
		let allScrollItems = scrollItems;
		const deletedItem = allScrollItems[index];
		allScrollItems.splice(index, 1);
		setAttributes({
			scrollItems: [...allScrollItems],
		});
		if (deletedItem.id === selectedItem.id) {
			setCurrentCursorItem({ index, remove: true });
		}
	};

	const padding = {
		"--desktop-padding-top": paddingTop.desktop + "px",
		"--laptop-padding-top": paddingTop.laptop + "px",
		"--tab-padding-top": paddingTop.tab + "px",
		"--mobile-padding-top": paddingTop.mobile + "px",
		"--desktop-padding-right": paddingRight.desktop + "px",
		"--laptop-padding-right": paddingRight.laptop + "px",
		"--tab-padding-right": paddingRight.tab + "px",
		"--mobile-padding-right": paddingRight.mobile + "px",
		"--desktop-padding-bottom": paddingBottom.desktop + "px",
		"--laptop-padding-bottom": paddingBottom.laptop + "px",
		"--tab-padding-bottom": paddingBottom.tab + "px",
		"--mobile-padding-bottom": paddingBottom.mobile + "px",
		"--desktop-padding-left": paddingLeft.desktop + "px",
		"--laptop-padding-left": paddingLeft.laptop + "px",
		"--tab-padding-left": paddingLeft.tab + "px",
		"--mobile-padding-left": paddingLeft.mobile + "px",
	};

	return (
		<Fragment>
			<div
				className={`borobazar-scroll-to-content borobazar-block-spacing-wrapper flex ${className}`}
				style={padding}
			>
				<div className="borobazar-scroll-to-content-nav w-80 shrink-0">
					<div className="borobazar-scroll-to-content-list">
						{scrollItems.map((item, index) => {
							return (
								<div
									key={index}
									onClick={() => handleItemSelection(item.id)}
									className={`relative flex items-center px-4 mb-6 text-main before:absolute before:h-full before:w-0.5 before:bg-transparent before:top-0 before:left-0 ${
										selectedItem && item && selectedItem.id === item.id
											? "before:bg-brand"
											: ""
									}`}
								>
									{scrollItems.length > 1 ? (
										<div
											className="remove-icon mr-4 cursor-pointer"
											onClick={() => handleRemoveItem(index)}
											title={__("Remove", "borobazar-helper")}
										>
											<CloseIcon />
										</div>
									) : (
										""
									)}
									<RichText
										className="grow"
										value={item.title}
										onChange={(text) => handleDataSaving(text, "title")}
										placeholder={__("Enter your title", "borobazar-helper")}
										allowedFormats={[]}
										mdivtiline={false}
									/>
								</div>
							);
						})}
					</div>
					<Button
						isPrimary
						isLarge
						onClick={handleAddNewScrollItem}
						style={{ marginTop: "30px" }}
					>
						{__("Add new item", "borobazar-helper")}
					</Button>
				</div>
				<div className="borobazar-scroll-to-content-content grow pl-20">
					{selectedItem ? (
						<RichText
							className="leading-loose text-dark"
							value={selectedItem.content}
							onChange={(text) => handleDataSaving(text, "content")}
							placeholder={__("Enter your content", "borobazar-helper")}
						/>
					) : null}
				</div>
			</div>
			<InspectorControls>
				<PaddingSettings
					initialOpen
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
		</Fragment>
	);
};
