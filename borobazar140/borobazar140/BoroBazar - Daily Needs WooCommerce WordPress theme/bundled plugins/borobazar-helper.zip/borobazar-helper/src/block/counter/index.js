/**
 * BLOCK: Collection
 **/

const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

import "./editor.scss";
import "./style.scss";
import attributes from "./attributes";
import edit from "./edit";

registerBlockType("borobazar-blocks/counter-block", {
	title: __("Counter", "borobazar-helper"),
	icon: "shield",
	textdomain: "borobazar-helper",
	category: "borobazar-blocks-category",
	keywords: [__("Counters", "borobazar-helper")],
	parent: ["borobazar-blocks/media-and-text"],
	attributes,
	edit,
	save: () => {
		return null;
	},
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
