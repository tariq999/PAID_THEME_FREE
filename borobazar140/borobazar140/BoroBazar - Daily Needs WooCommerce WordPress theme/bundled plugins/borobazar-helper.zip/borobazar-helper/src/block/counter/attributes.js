export default {
	columnSize: {
		type: "number",
		default: 2,
	},
	counterItems: {
		type: "array",
		default: [
			{
				title: "",
				description: "",
				count: "",
				symbol: "",
			},
		],
		items: [{ type: "object" }],
	},
	backgroundColor: {
		type: "string",
		default: "#fff",
	},
	titleColor: {
		type: "string",
		default: "#595959",
	},
	descriptionColor: {
		type: "string",
		default: "#666666",
	},
	countColor: {
		type: "string",
		default: "#02B290",
	},
	symbolColor: {
		type: "string",
		default: "#02B290",
	},
};
