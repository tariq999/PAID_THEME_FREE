const { __ } = wp.i18n;

export default {
	paddingTop: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: 'object',
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	title: {
		type: 'string',
		default: __('Groceries Delivered in 90 Minutes', 'borobazar-helper'),
	},
	description: {
		type: 'string',
		default: __(
			'Get your healthy foods & snacks delivered at your doorsteps all day everyday',
			'borobazar-helper'
		),
	},
	searchSuggestions: {
		type: 'string',
		default: __('', 'borobazar-helper'),
	},
	placeholder: {
		type: 'string',
		default: __('Search...', 'borobazar-helper'),
	},
	backgroundType: {
		type: 'string',
		default: 'image',
	},
	searchLayout: {
		type: 'string',
		default: 'lily',
	},
	backgroundImage: {
		type: 'string',
		default: '',
	},
	sliderImages: {
		type: 'array',
		default: [
			{
				url: '',
			},
		],
	},
	backgroundColor: {
		type: 'string',
		default: '#ffffff',
	},
	titleColor: {
		type: 'string',
		default: '#212121',
	},
	descriptionColor: {
		type: 'string',
		default: '#5A5A5A',
	},
	searchSuggestionColor: {
		type: 'string',
		default: '#5A5A5A',
	},
	overlay: {
		type: 'string',
		default: '#000',
	},
	overlayOpacity: {
		type: 'number',
		default: 0,
	},
	minHeight: {
		type: 'object',
		default: {
			desktop: 400,
			laptop: 400,
			tab: 400,
			mobile: 400,
		},
	},
};
