const { Fragment } = wp.element;
const { SelectControl, PanelBody } = wp.components;
const { withSelect } = wp.data;
const ServerSideRender = wp.serverSideRender;
const { InspectorControls } = wp.blockEditor;
const { __ } = wp.i18n;

import "./store";

export default withSelect((select) => {
	const cfPosts = select("borobazar-blocks/borobazar-contact-form").getCFList();
	return { cfPosts };
})((props) => {
	const {
		cfPosts,
		attributes: { selectedContactForm },
		setAttributes,
	} = props;

	const options = [
		{
			value: "",
			label: __("-- Select Form --", "borobazar-helper"),
		},
	];

	if (typeof cfPosts !== "undefined" && cfPosts !== []) {
		cfPosts.forEach(function (e, i) {
			options.push({
				value: e.id,
				label: e.title,
			});
		});
	}

	const updateFunc = (value) => {
		setAttributes({ selectedContactForm: value });
	};

	return (
		<Fragment>
			{selectedContactForm ? (
				<ServerSideRender
					block="borobazar-blocks/borobazar-contact-form"
					attributes={{ selectedContactForm }}
				/>
			) : (
				<SelectControl
					label={__("Select Contact Form", "borobazar-helper")}
					value={selectedContactForm || "none"}
					onChange={(newValue) => updateFunc(newValue)}
					options={options}
					className="borobazar-contact-form-option"
				/>
			)}

			<InspectorControls>
				<PanelBody
					title={__("General Settings", "borobazar-helper")}
					icon="welcome-widgets-menus"
					initialOpen={true}
				>
					<SelectControl
						label={__("Select Contact Form", "borobazar-helper")}
						value={selectedContactForm || "none"}
						onChange={(newValue) => updateFunc(newValue)}
						options={options}
					/>
				</PanelBody>
			</InspectorControls>
		</Fragment>
	);
});
