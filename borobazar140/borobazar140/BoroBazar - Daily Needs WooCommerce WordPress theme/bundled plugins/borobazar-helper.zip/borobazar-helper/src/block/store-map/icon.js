export function MapIcon() {
	return (
		<svg version="1.1" x="0px" y="0px" viewBox="0 0 21 21">
			<path
				fill="#02B290"
				d="M9.9,11.8c-2.2,0-4-1.8-4-4.1s1.8-4.1,4-4.1c2.2,0,4,1.8,4,4.1S12.2,11.8,9.9,11.8z M9.9,4.8c-1.7,0-3,1.4-3,3
	c0,1.6,1.4,3,3,3c1.6,0,3-1.4,3-3C12.9,6.1,11.6,4.8,9.9,4.8z"
			/>
			<path
				fill="#02B290"
				d="M9.8,21c-0.7,0-1.2-0.6-1.2-0.6C5.4,16.7,2,12.3,2,8c0-4.4,3.5-8,7.9-8c4.4,0,7.9,3.5,7.9,8
	c0,4.4-3.4,8.7-6.7,12.5C11.1,20.4,10.6,21,9.8,21z M9.9,1.6c-3.4,0-6.2,2.8-6.2,6.2c0,4.1,3.9,8.6,6.2,11.3
	c2.4-2.8,6.2-7.3,6.2-11.3C16.1,4.5,13.4,1.6,9.9,1.6z"
			/>
		</svg>
	);
}

/**
 * https://heroicons.com/
 */
export function UploadIcon() {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			className="h-6 w-6"
			fill="none"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth={2}
				d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
			/>
		</svg>
	);
}

export function CloseIcon() {
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			className="h-6 w-6"
			fill="none"
			viewBox="0 0 24 24"
			stroke="currentColor"
		>
			<path
				strokeLinecap="round"
				strokeLinejoin="round"
				strokeWidth={2}
				d="M6 18L18 6M6 6l12 12"
			/>
		</svg>
	);
}
