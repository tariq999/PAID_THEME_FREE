const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { InspectorControls } = wp.blockEditor;
const { PanelBody } = wp.components;
import SwiperCore, { Navigation, Pagination, Scrollbar, A11y } from 'swiper';
import PaddingSettings from '../../components/paddingSettings';
import TemplateSwitcher from '../../components/templateSwitcher';
import SliderSettings from './sliderSettings';
import Slider from './slider';
import {
	ContentSliderIcon,
	FeatureSliderIcon,
	HeroSliderIcon,
	ImageSliderIcon,
	PromoSliderIcon,
	PromoSliderV2Icon,
} from './icon';

// install Swiper components
SwiperCore.use([Navigation, Pagination, Scrollbar, A11y]);

export default (props) => {
	const {
		attributes: {
			slideItems,
			template,
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
			slidesPerView,
			spaceBetween,
			centeredSlides,
			grabCursor,
			loop,
			navigation,
			pagination,
			autoplay,
			autoplayTime,
			speed,
			autoHeight,
			blurInactiveSlide,
			navigationSize,
		},
		setAttributes,
		className,
		isSelected,
	} = props;

	const slideDefault = {
		slogan: '',
		title: '',
		description: '',
		button: 'Button',
		image: '',
		url: '',
		opensInNewTab: false,
		contentPosition: 'top left',
		textAlign: 'left',
		backgroundPosition: '50% 50%',
		backgroundRepeat: false,
		fixedBackground: false,
		backgroundSize: 'cover',
		backgroundColor: '#f9f9f9',
		overlayOpacity: 0,
		overlay: '#000000',
		sloganColor: '#000000',
		titleColor: '#000000',
		descriptionColor: '#4A5568',
		buttonColor: '#02B290',
		buttonTextColor: '#ffffff',
		buttonHoverColor: '#01A585',
		buttonHoverTextColor: '#ffffff',
		height: { desktop: 300, laptop: 300, tab: 200, mobile: 120 },
		paddingTop: { desktop: 0, laptop: 0, tab: 0, mobile: 0 },
		paddingRight: { desktop: 0, laptop: 0, tab: 0, mobile: 0 },
		paddingBottom: { desktop: 0, laptop: 0, tab: 0, mobile: 0 },
		paddingLeft: { desktop: 0, laptop: 0, tab: 0, mobile: 0 },
	};

	const padding = {
		'--desktop-padding-top': paddingTop.desktop + 'px',
		'--laptop-padding-top': paddingTop.laptop + 'px',
		'--tab-padding-top': paddingTop.tab + 'px',
		'--mobile-padding-top': paddingTop.mobile + 'px',
		'--desktop-padding-right': paddingRight.desktop + 'px',
		'--laptop-padding-right': paddingRight.laptop + 'px',
		'--tab-padding-right': paddingRight.tab + 'px',
		'--mobile-padding-right': paddingRight.mobile + 'px',
		'--desktop-padding-bottom': paddingBottom.desktop + 'px',
		'--laptop-padding-bottom': paddingBottom.laptop + 'px',
		'--tab-padding-bottom': paddingBottom.tab + 'px',
		'--mobile-padding-bottom': paddingBottom.mobile + 'px',
		'--desktop-padding-left': paddingLeft.desktop + 'px',
		'--laptop-padding-left': paddingLeft.laptop + 'px',
		'--tab-padding-left': paddingLeft.tab + 'px',
		'--mobile-padding-left': paddingLeft.mobile + 'px',
	};

	const switcherItems = [
		{
			preview: <ImageSliderIcon />,
			label: __('Image slider', 'borobazar-helper'),
			value: 'image',
		},
		{
			preview: <HeroSliderIcon />,
			label: __('Hero slider', 'borobazar-helper'),
			value: 'hero',
		},
		{
			preview: <ContentSliderIcon />,
			label: __('Content slider', 'borobazar-helper'),
			value: 'content',
		},
		{
			preview: <FeatureSliderIcon />,
			label: __('Feature slider', 'borobazar-helper'),
			value: 'feature',
		},
		{
			preview: <PromoSliderIcon />,
			label: __('Promo slider', 'borobazar-helper'),
			value: 'promo',
		},
		{
			preview: <PromoSliderV2Icon />,
			label: __('Promo slider v2', 'borobazar-helper'),
			value: 'promo-v2',
		},
	];

	return (
		<Fragment>
			<div className="borobazar-banner-block-preview">
				<div
					className={`borobazar-block-spacing-wrapper borobazar-slider ${className}`}
					style={padding}
				>
					<Slider
						slideItems={slideItems}
						template={template}
						slidesPerView={slidesPerView}
						spaceBetween={spaceBetween}
						centeredSlides={centeredSlides}
						navigation={navigation}
						speed={speed}
						isSelected={isSelected}
						navigationSize={navigationSize}
						breakpoints
						handleAdd={(allSlideItems) =>
							setAttributes({ slideItems: [...allSlideItems, slideDefault] })
						}
						setAttributes={(allSlideItems) =>
							setAttributes({
								slideItems: [...allSlideItems],
							})
						}
					/>
				</div>
			</div>
			<InspectorControls>
				{/* <BlockToolbar /> */}
				<PanelBody
					title={__('Template Settings', 'borobazar-helper')}
					initialOpen={true}
				>
					<TemplateSwitcher
						label={__('Choose template', 'borobazar-helper')}
						handleTemplate={(template) => {
							setAttributes({ template: template });
							template == 'hero' &&
								setAttributes({
									slidesPerView: { desktop: 1, laptop: 1, tab: 1, mobile: 1 },
								});
						}}
						template={template}
						items={switcherItems}
					/>
				</PanelBody>
				<SliderSettings
					slidesPerView={slidesPerView}
					spaceBetween={spaceBetween}
					centeredSlides={centeredSlides}
					grabCursor={grabCursor}
					loop={loop}
					navigation={navigation}
					pagination={pagination}
					autoplay={autoplay}
					autoplayTime={autoplayTime}
					speed={speed}
					autoHeight={autoHeight}
					blurInactiveSlide={blurInactiveSlide}
					navigationSize={navigationSize}
					template={template}
					setAttributes={setAttributes}
				/>

				<PaddingSettings
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
			</InspectorControls>
		</Fragment>
	);
};
