const { __ } = wp.i18n;
import { useState } from "react";
const { RichText } = wp.blockEditor;
const { Button } = wp.components;

export default ({
	title,
	description,
	titleOnChange,
	descriptionOnChange,
	handleRemoveAccordion,
	id,
	collapsed = false,
	isSelected,
}) => {
	const [collapse, setCollapse] = useState(collapsed);

	return (
		<div className="borobazar-collapse shadow-faq">
			<div className="borobazar-collapse-head">
				<div
					className={`borobazar-collapse-icon ${!collapse ? "open" : ""}`}
					onClick={() => setCollapse((collapse) => !collapse)}
				>
					<span></span>
				</div>
				<RichText
					tagName="h2"
					className="borobazar-collapse-title"
					placeholder={__("Enter title here ...", "borobazar-helper")}
					value={title}
					onChange={titleOnChange}
					allowedFormats={[]}
					mdivtiline={false}
				/>
				{isSelected ? (
					<Button
						isLink
						isDestructive
						className="borobazar-collapse-remove"
						onClick={handleRemoveAccordion}
					>
						{__("Remove", "borobazar-helper")}
					</Button>
				) : (
					""
				)}
			</div>
			<div
				className={`borobazar-collapse-content ${
					!collapse ? "content-open" : ""
				}`}
			>
				<div className="borobazar-collapse-content-inner">
					<RichText
						placeholder={__("Enter content here ...", "borobazar-helper")}
						value={description}
						onChange={descriptionOnChange}
					/>
				</div>
			</div>
		</div>
	);
};
