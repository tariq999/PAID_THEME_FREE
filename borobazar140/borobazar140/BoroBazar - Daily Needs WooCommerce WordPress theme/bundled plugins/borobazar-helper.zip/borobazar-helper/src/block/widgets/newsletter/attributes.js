const { __ } = wp.i18n;
export default {
	title: {
		type: "string",
		default: "Subscribe Now",
	},
	content: {
		type: "string",
		default: __(
			"Subscribe your email for newsletter and featured news based on your interest",
			"borobazar-helper"
		),
	},
	newsLetterLink: {
		type: "string",
		default: "#",
	},
};
