const { __ } = wp.i18n;

export default {
	paddingTop: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	slideItems: {
		type: "array",
		default: [
			{
				slogan: "",
				title: "",
				description: "",
				button: __("Button", "borobazar-helper"),
				image: "",
				url: "",
				opensInNewTab: false,
				contentPosition: "top left",
				textAlign: "left",
				backgroundPosition: "50% 50%",
				backgroundRepeat: false,
				fixedBackground: false,
				backgroundSize: "cover",
				backgroundColor: "#f9f9f9",
				overlayOpacity: 0,
				overlay: "#000000",
				sloganColor: "#000000",
				titleColor: "#000000",
				descriptionColor: "#4A5568",
				buttonColor: "#02B290",
				buttonTextColor: "#ffffff",
				buttonHoverColor: "#01A585",
				buttonHoverTextColor: "#ffffff",
				height: { desktop: 400, laptop: 400, tab: 300, mobile: 200 },
				paddingTop: { desktop: 0, laptop: 0, tab: 0, mobile: 0 },
				paddingRight: { desktop: 0, laptop: 0, tab: 0, mobile: 0 },
				paddingBottom: { desktop: 0, laptop: 0, tab: 0, mobile: 0 },
				paddingLeft: { desktop: 0, laptop: 0, tab: 0, mobile: 0 },
			},
		],
		items: [{ type: "object" }],
	},
	template: {
		type: "string",
		default: "image",
	},
	slidesPerView: {
		type: "object",
		default: {
			desktop: 1,
			laptop: 1,
			tab: 1,
			mobile: 1,
		},
	},
	spaceBetween: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	speed: {
		type: "number",
		default: 300,
	},
	centeredSlides: {
		type: "boolean",
		default: false,
	},
	grabCursor: {
		type: "boolean",
		default: false,
	},
	loop: {
		type: "boolean",
		default: false,
	},
	autoplay: {
		type: "boolean",
		default: false,
	},
	autoplayTime: {
		type: "number",
		default: 3000,
	},
};
