// wp imports
const { __ } = wp.i18n;
const { Fragment } = wp.element;
const { PanelBody, ColorPicker, RangeControl } = wp.components;
const { InspectorControls, InnerBlocks } = wp.blockEditor;
// custom imports
import PaddingSettings from "../../components/paddingSettings";
import MarginSettings from "../../components/marginSettings";
import ShadowSettings from "../../components/shadowSettings";
import {
	getBoroBazarPaddingStyles,
	getBoroBazarMarginStyles,
	getBoroBazarShadowStyles,
} from "../../components/utils";

const Wrapper = (props) => {
	const {
		className,
		hasChildBlocks,
		attributes: {
			paddingTop,
			paddingRight,
			paddingBottom,
			paddingLeft,
			marginTop,
			marginRight,
			marginBottom,
			marginLeft,
			boxShadow,
			backgroundColor,
			borderRadius,
		},
		attributes,
		setAttributes,
	} = props;

	const paddingStyle = getBoroBazarPaddingStyles(attributes);
	const marginStyle = getBoroBazarMarginStyles(attributes);
	const shadowStyle = getBoroBazarShadowStyles(boxShadow);
	const blockStyle = {
		...paddingStyle,
		...marginStyle,
		...shadowStyle,
		"--background-color": backgroundColor,
		"--border-radius": `${borderRadius}px`,
	};

	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper borobazar-block-spacing-margin-wrapper borobazar-block-shadow ${className}`}
				style={blockStyle}
			>
				<InnerBlocks
					renderAppender={
						hasChildBlocks ? "" : () => <InnerBlocks.ButtonBlockAppender />
					}
					templateInsertUpdatesSelection={false}
					__experimentalCaptureToolbars={true}
					templateLock={false}
				/>
			</div>
			{/* End of edit block */}

			<InspectorControls>
				<PaddingSettings
					panelTitle="Padding Settings"
					hidePanelIcon={true}
					paddingTop={paddingTop}
					paddingRight={paddingRight}
					paddingBottom={paddingBottom}
					paddingLeft={paddingLeft}
					setAttributes={setAttributes}
				/>
				<MarginSettings
					hidePanelIcon={true}
					marginTop={marginTop}
					marginRight={marginRight}
					marginBottom={marginBottom}
					marginLeft={marginLeft}
					setAttributes={setAttributes}
				/>
				<ShadowSettings boxShadow={boxShadow} setAttributes={setAttributes} />
				<PanelBody
					title={__("Background Color Settings", "borobazar-helper")}
					initialOpen={false}
				>
					<ColorPicker
						value={backgroundColor}
						onChangeComplete={(value) =>
							setAttributes({
								backgroundColor: value.hex,
							})
						}
					/>
				</PanelBody>
				<PanelBody
					title={__("Border Radius Settings", "borobazar-helper")}
					initialOpen={false}
				>
					<RangeControl
						value={borderRadius}
						onChange={(value) =>
							setAttributes({
								borderRadius: value,
							})
						}
						min={0}
						max={500}
						required
					/>
				</PanelBody>
			</InspectorControls>
			{/* End block settings */}
		</Fragment>
	);
};

export default Wrapper;
