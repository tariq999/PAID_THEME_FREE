import { useState, useEffect } from 'react';
const { Fragment } = wp.element;
const { __ } = wp.i18n;
const {
	Button,
	Popover,
	DropdownMenu,
	MenuItem,
	MenuGroup,
	FocalPointPicker,
	RangeControl,
	Panel,
	PanelBody,
	ToggleControl,
	SelectControl,
	__experimentalAlignmentMatrixControl: AlignmentMatrixControl,
	__experimentalInputControl: InputControl,
} = wp.components;
const {
	MediaUpload,
	ColorPaletteControl,
	__experimentalLinkControl: LinkControl,
} = wp.blockEditor;
import { Swiper, SwiperSlide } from 'swiper/react';
import SwiperCore, { Navigation, Pagination, Scrollbar, A11y } from 'swiper';
import CustomColorControl from '../../components/customColorControl';
import Devices from '../../components/devices';
import {
	ImageSlide,
	ContentSlide,
	FeatureSlide,
	HeroSlide,
	PromoSlide,
	PromoSlideV2,
} from './templates';
import { ImageUploadIcon, LinkIcon, RemoveIcon, SettingsIcon } from './icon';
// install Swiper components
SwiperCore.use([Navigation, Pagination, Scrollbar, A11y]);

export default ({
	slideItems,
	template,
	slidesPerView,
	spaceBetween,
	centeredSlides,
	speed,
	isSelected,
	handleAdd,
	setAttributes,
	breakpoints,
}) => {
	//States
	const [selectedItemIndex, setSelectedItemIndex] = useState(0);
	const [isPopoverOpen, setPopoverOpen] = useState(false);
	const [popoverContent, setPopoverContent] = useState(null);
	const [swiper, setSwiper] = useState(null);
	const [newSlide, addNewSlide] = useState(false);
	const [device, setDevice] = useState('desktop');

	//SelectedItems attributes
	const selectedItem = slideItems[selectedItemIndex];
	let url,
		opensInNewTab,
		image,
		height,
		paddingTop,
		paddingRight,
		paddingBottom,
		paddingLeft,
		backgroundPosition,
		fixedBackground,
		backgroundRepeat,
		backgroundSize,
		backgroundColor,
		contentPosition,
		textAlign,
		sloganColor,
		titleColor,
		descriptionColor,
		buttonColor,
		buttonTextColor,
		buttonHoverColor,
		buttonHoverTextColor,
		overlayOpacity,
		overlay;

	if (selectedItem) {
		url = selectedItem.url;
		opensInNewTab = selectedItem.opensInNewTab;
		image = selectedItem.image;
		height = selectedItem.height;
		paddingTop = selectedItem.paddingTop;
		paddingRight = selectedItem.paddingRight;
		paddingBottom = selectedItem.paddingBottom;
		paddingLeft = selectedItem.paddingLeft;
		backgroundPosition = selectedItem.backgroundPosition;
		fixedBackground = selectedItem.fixedBackground;
		backgroundRepeat = selectedItem.backgroundRepeat;
		backgroundSize = selectedItem.backgroundSize;
		backgroundColor = selectedItem.backgroundColor;
		contentPosition = selectedItem.contentPosition;
		textAlign = selectedItem.textAlign;
		sloganColor = selectedItem.sloganColor;
		titleColor = selectedItem.titleColor;
		descriptionColor = selectedItem.descriptionColor;
		buttonColor = selectedItem.buttonColor;
		buttonTextColor = selectedItem.buttonTextColor;
		buttonHoverColor = selectedItem.buttonHoverColor;
		buttonHoverTextColor = selectedItem.buttonHoverTextColor;
		overlayOpacity = selectedItem.overlayOpacity;
		overlay = selectedItem.overlay;
	}

	const selectedItemLink = { url, opensInNewTab };

	//convert backgroundPosition to focal point value
	const focalPoint = backgroundPosition
		? backgroundPosition.replaceAll('%', '')
		: '';
	const focalX = parseInt(focalPoint.split(' ')[0]);
	const focalY = parseInt(focalPoint.split(' ').pop());

	//useEffect
	useEffect(() => {
		if (swiper) {
			swiper.update();
			if (newSlide) swiper.slideTo(slideItems.length + 1, 500, false);
			addNewSlide(false);
		}
	}, [slideItems, newSlide]);

	//Add new slide
	const addNewItem = () => {
		let allSlideItems = slideItems;
		handleAdd(allSlideItems);
		addNewSlide(true);
	};
	//Remove slide
	const removeItem = (index) => {
		let allSlideItems = slideItems;
		allSlideItems.splice(index, 1);
		setAttributes(allSlideItems);
	};
	//Link handler
	const handleLink = (newURL, newOpensInNewTab) => {
		let allSlideItems = slideItems;
		const normalizeURL = newURL.replace(/([^:]\/)\/+/g, '$1');
		allSlideItems[selectedItemIndex] = {
			...allSlideItems[selectedItemIndex],
			url: normalizeURL,
			opensInNewTab: newOpensInNewTab,
		};
		setAttributes(allSlideItems);
	};
	//Attribute handlers
	const handleAttribute = (index, value, key, singleSlide) => {
		let allSlideItems = slideItems;
		let finalValue = key == 'image' ? value.url : value;
		allSlideItems[index] = {
			...singleSlide,
			[key]: finalValue,
		};
		setAttributes(allSlideItems);
	};
	const handleSelectedAttribute = (value, key) => {
		let allSlideItems = slideItems;
		allSlideItems[selectedItemIndex] = {
			...allSlideItems[selectedItemIndex],
			[key]: value,
		};
		setAttributes(allSlideItems);
	};
	//Padding handler
	const handleResponsiveAttr = (value, attribute, key) => {
		let allSlideItems = slideItems;
		allSlideItems[selectedItemIndex] = {
			...allSlideItems[selectedItemIndex],
			[key]: {
				...attribute,
				[device]: value,
			},
		};
		setAttributes(allSlideItems);
	};

	const spaceBetweenDesktop = breakpoints ? spaceBetween.desktop : spaceBetween;
	const slidesPerViewDesktop = breakpoints
		? slidesPerView.desktop
		: slidesPerView;

	const colorSettings = [
		{
			label: __('Background Color', 'borobazar-helper'),
			color: backgroundColor,
			onChange: (value) => handleSelectedAttribute(value, 'backgroundColor'),
		},
		{
			label: __('Slogan Color', 'borobazar-helper'),
			color: sloganColor,
			onChange: (value) => handleSelectedAttribute(value, 'sloganColor'),
		},
		{
			label: __('Title Color', 'borobazar-helper'),
			color: titleColor,
			onChange: (value) => handleSelectedAttribute(value, 'titleColor'),
		},
		{
			label: __('Description Color', 'borobazar-helper'),
			color: descriptionColor,
			onChange: (value) => handleSelectedAttribute(value, 'descriptionColor'),
		},
		{
			label: __('Button Color', 'borobazar-helper'),
			color: buttonColor,
			onChange: (value) => handleSelectedAttribute(value, 'buttonColor'),
		},
		{
			label: __('Button text Color', 'borobazar-helper'),
			color: buttonTextColor,
			onChange: (value) => handleSelectedAttribute(value, 'buttonTextColor'),
		},
		{
			label: __('Button hover Color', 'borobazar-helper'),
			color: buttonHoverColor,
			onChange: (value) => handleSelectedAttribute(value, 'buttonHoverColor'),
		},
		{
			label: __('Button hover text Color', 'borobazar-helper'),
			color: buttonHoverTextColor,
			onChange: (value) =>
				handleSelectedAttribute(value, 'buttonHoverTextColor'),
		},
	];

	const colorSettingsMinimal = [
		{
			label: __('Title Color', 'borobazar-helper'),
			color: titleColor,
			onChange: (value) => handleSelectedAttribute(value, 'titleColor'),
		},
		{
			label: __('Description Color', 'borobazar-helper'),
			color: descriptionColor,
			onChange: (value) => handleSelectedAttribute(value, 'descriptionColor'),
		},
		{
			label: __('Background Color', 'borobazar-helper'),
			color: backgroundColor,
			onChange: (value) => handleSelectedAttribute(value, 'backgroundColor'),
		},
	];

	return (
		<Fragment>
			{/* Slider */}
			<Swiper
				spaceBetween={spaceBetweenDesktop}
				slidesPerView={slidesPerViewDesktop}
				allowTouchMove={false}
				observer
				observeParents
				observeSlideChildren
				navigation={{
					nextEl: '.borobazar-slider-next-button',
					prevEl: '.borobazar-slider-prev-button',
				}}
				speed={speed}
				centeredSlides={centeredSlides}
				// scrollbar={{ draggable: true }}
				breakpoints={{
					// when window width is >= 767px
					767: {
						slidesPerView: breakpoints ? slidesPerView.tab : slidesPerView,
						spaceBetween: breakpoints ? spaceBetween.tab : spaceBetween,
					},
					// when window width is >= 1200px
					1200: {
						slidesPerView: breakpoints ? slidesPerView.laptop : slidesPerView,
						spaceBetween: breakpoints ? spaceBetween.laptop : spaceBetween,
					},
					// when window width is >= 1400px
					1400: {
						slidesPerView: breakpoints ? slidesPerView.desktop : slidesPerView,
						spaceBetween: breakpoints ? spaceBetween.desktop : spaceBetween,
					},
				}}
				onSwiper={setSwiper}
			>
				{/* Slide Items */}
				{slideItems &&
					slideItems.map((slideItem, index) => {
						let contentPositionClasses = '';
						const padding = {
							'--desktop-padding-top': slideItem.paddingTop.desktop + 'px',
							'--laptop-padding-top': slideItem.paddingTop.laptop + 'px',
							'--tab-padding-top': slideItem.paddingTop.tab + 'px',
							'--mobile-padding-top': slideItem.paddingTop.mobile + 'px',
							'--desktop-padding-right': slideItem.paddingRight.desktop + 'px',
							'--laptop-padding-right': slideItem.paddingRight.laptop + 'px',
							'--tab-padding-right': slideItem.paddingRight.tab + 'px',
							'--mobile-padding-right': slideItem.paddingRight.mobile + 'px',
							'--desktop-padding-bottom':
								slideItem.paddingBottom.desktop + 'px',
							'--laptop-padding-bottom': slideItem.paddingBottom.laptop + 'px',
							'--tab-padding-bottom': slideItem.paddingBottom.tab + 'px',
							'--mobile-padding-bottom': slideItem.paddingBottom.mobile + 'px',
							'--desktop-padding-left': slideItem.paddingLeft.desktop + 'px',
							'--laptop-padding-left': slideItem.paddingLeft.laptop + 'px',
							'--tab-padding-left': slideItem.paddingLeft.tab + 'px',
							'--mobile-padding-left': slideItem.paddingLeft.mobile + 'px',
						};

						switch (slideItem.contentPosition) {
							case 'top left':
								contentPositionClasses = 'items-start justify-start';
								break;
							case 'top center':
								contentPositionClasses = 'items-start justify-center';
								break;
							case 'top right':
								contentPositionClasses = 'items-start justify-end';
								break;
							case 'center left':
								contentPositionClasses = 'items-center justify-start';
								break;
							case 'center center':
								contentPositionClasses = 'items-center justify-center';
								break;
							case 'center right':
								contentPositionClasses = 'items-center justify-end';
								break;
							case 'bottom left':
								contentPositionClasses = 'items-end justify-start';
								break;
							case 'bottom center':
								contentPositionClasses = 'items-end justify-center';
								break;
							case 'bottom right':
								contentPositionClasses = 'items-end justify-end';
								break;
							default:
								contentPositionClasses = 'items-start justify-start';
								break;
						}
						return (
							// Slide Item
							<SwiperSlide key={index}>
								<div
									className={`borobazar-slider-item ${
										slideItem.image ? '' : 'h-full'
									}`}
									style={padding}
								>
									{/* Slide Options bar (sticky on top right) */}
									{isSelected && (
										<Fragment>
											<div className="borobazar-slider-slide-options">
												{/* Slide Settings */}
												{template !== 'image' && (
													<DropdownMenu
														icon={<SettingsIcon />}
														label={__('Settings', 'borobazar-helper')}
														popoverProps={{
															position: 'bottom left',
														}}
													>
														{() => (
															<Fragment>
																<MenuGroup
																	label={__(
																		'Slide options',
																		'borobazar-helper'
																	)}
																>
																	{template == 'content' ||
																	template == 'hero' ? (
																		<Fragment>
																			<MenuItem
																				onClick={() => {
																					setPopoverOpen(true);
																					setPopoverContent('content');
																					setSelectedItemIndex(index);
																				}}
																			>
																				Content settings
																			</MenuItem>
																			<MenuItem
																				onClick={() => {
																					setPopoverOpen(true);
																					setPopoverContent('bg');
																					setSelectedItemIndex(index);
																				}}
																			>
																				Background settings
																			</MenuItem>
																			<MenuItem
																				onClick={() => {
																					setPopoverOpen(true);
																					setPopoverContent('overlay');
																					setSelectedItemIndex(index);
																				}}
																			>
																				Overlay settings
																			</MenuItem>
																		</Fragment>
																	) : (
																		''
																	)}

																	<MenuItem
																		onClick={() => {
																			setPopoverOpen(true);
																			setPopoverContent('color');
																			setSelectedItemIndex(index);
																		}}
																	>
																		Color settings
																	</MenuItem>
																</MenuGroup>
															</Fragment>
														)}
													</DropdownMenu>
												)}
												{/* Add link button */}
												<div
													className="add-link"
													title={__('Edit Link', 'borobazar-helper')}
													onClick={() => {
														setPopoverOpen(true);
														setPopoverContent('link');
														setSelectedItemIndex(index);
													}}
												>
													<LinkIcon />
												</div>

												{/* Add image button */}
												<MediaUpload
													onSelect={(image) =>
														handleAttribute(index, image, 'image', slideItem)
													}
													allowed={['image']}
													type="image"
													render={({ open }) => (
														<div
															onClick={open}
															className="edit-image"
															title={__(
																'Upload/Change Image',
																'borobazar-helper'
															)}
														>
															<ImageUploadIcon />
														</div>
													)}
												/>

												{/* Remove slide button */}
												<div
													className="remove-slide"
													onClick={() => removeItem(index)}
													title={__('Remove', 'borobazar-helper')}
												>
													<RemoveIcon />
												</div>
											</div>
										</Fragment>
									)}

									{/* Image slide */}
									{template == 'image' && (
										<ImageSlide
											slideItem={slideItem}
											onUpload={(image) =>
												handleAttribute(index, image, 'image', slideItem)
											}
										/>
									)}

									{/* Content slide */}
									{template == 'content' && (
										<ContentSlide
											slideItem={slideItem}
											sloganOnChange={(value) =>
												handleAttribute(index, value, 'slogan', slideItem)
											}
											titleOnChange={(value) =>
												handleAttribute(index, value, 'title', slideItem)
											}
											desOnChange={(value) =>
												handleAttribute(index, value, 'description', slideItem)
											}
											buttonOnChange={(value) =>
												handleAttribute(index, value, 'button', slideItem)
											}
											onUpload={(image) =>
												handleAttribute(index, image, 'image', slideItem)
											}
											contentPositionClasses={contentPositionClasses}
										/>
									)}

									{/* Hero slide */}
									{template == 'hero' && (
										<HeroSlide
											slideItem={slideItem}
											titleOnChange={(value) =>
												handleAttribute(index, value, 'title', slideItem)
											}
											desOnChange={(value) =>
												handleAttribute(index, value, 'description', slideItem)
											}
											buttonOnChange={(value) =>
												handleAttribute(index, value, 'button', slideItem)
											}
											onUpload={(image) =>
												handleAttribute(index, image, 'image', slideItem)
											}
											contentPositionClasses={contentPositionClasses}
										/>
									)}

									{/* Feature Slide */}
									{template == 'feature' && (
										<FeatureSlide
											slideItem={slideItem}
											titleOnChange={(value) =>
												handleAttribute(index, value, 'title', slideItem)
											}
											desOnChange={(value) =>
												handleAttribute(index, value, 'description', slideItem)
											}
											onUpload={(image) =>
												handleAttribute(index, image, 'image', slideItem)
											}
										/>
									)}

									{/* Feature Slide */}
									{template == 'promo' && (
										<PromoSlide
											slideItem={slideItem}
											titleOnChange={(value) =>
												handleAttribute(index, value, 'title', slideItem)
											}
											desOnChange={(value) =>
												handleAttribute(index, value, 'description', slideItem)
											}
											onUpload={(image) =>
												handleAttribute(index, image, 'image', slideItem)
											}
										/>
									)}

									{/* Promo Slide v2 */}
									{template == 'promo-v2' && (
										<PromoSlideV2
											slideItem={slideItem}
											titleOnChange={(value) =>
												handleAttribute(index, value, 'title', slideItem)
											}
											desOnChange={(value) =>
												handleAttribute(index, value, 'description', slideItem)
											}
											onUpload={(image) =>
												handleAttribute(index, image, 'image', slideItem)
											}
										/>
									)}
								</div>
							</SwiperSlide>
						);
					})}

				{/* Slide navigation's */}
				<div className="borobazar-slider-next-button size-small">
					<svg
						xmlns="http://www.w3.org/2000/svg"
						width="14.1"
						height="24"
						viewBox="0 0 14.1 24"
					>
						<path
							d="M110.841,12.005l-8.978-8.979a1.316,1.316,0,0,1,0-1.856l.787-.786a1.315,1.315,0,0,1,1.857,0l10.69,10.69a1.325,1.325,0,0,1,0,1.863l-10.68,10.68a1.315,1.315,0,0,1-1.857,0l-.787-.786a1.314,1.314,0,0,1,0-1.857Z"
							transform="translate(-101.48)"
							fill="currentColor"
						/>
					</svg>
				</div>
				<div className="borobazar-slider-prev-button size-small">
					<svg
						xmlns="http://www.w3.org/2000/svg"
						width="14.1"
						height="24"
						viewBox="0 0 14.1 24"
					>
						<path
							d="M106.218,12.005,115.2,3.026a1.316,1.316,0,0,0,0-1.856l-.787-.786a1.315,1.315,0,0,0-1.857,0l-10.69,10.69a1.325,1.325,0,0,0,0,1.863l10.68,10.68a1.315,1.315,0,0,0,1.857,0l.787-.786a1.314,1.314,0,0,0,0-1.857Z"
							transform="translate(-101.48)"
							fill="currentColor"
						/>
					</svg>
				</div>
			</Swiper>

			{/* Add new slide button */}
			{isSelected ? (
				<div className="borobazar-slider-add-slide">
					<Button onClick={addNewItem} isPrimary>
						{__('Add New Slide', 'borobazar-helper')}
					</Button>
				</div>
			) : (
				''
			)}

			{/* Central popover */}
			{isPopoverOpen && (
				<Popover
					position="middle"
					onClose={() => setPopoverOpen(false)}
					onFocusOutside={() => setPopoverOpen(false)}
					// focusOnMount={popoverContent == "link" ? "firstElement" : false}
				>
					{popoverContent == 'link' && (
						<LinkControl
							value={selectedItemLink}
							showInitialSuggestions={true}
							onChange={({
								url: newURL = '',
								opensInNewTab: newOpensInNewTab,
							}) => {
								handleLink(newURL, newOpensInNewTab);
							}}
						/>
					)}
					{popoverContent == 'bg' && (
						<div style={{ width: 400, padding: 16 }}>
							<ToggleControl
								label={__('Fixed Background', 'borobazar-helper')}
								checked={fixedBackground}
								onChange={(value) =>
									handleSelectedAttribute(value, 'fixedBackground')
								}
							/>
							<ToggleControl
								label={__('Repeated Background', 'borobazar-helper')}
								checked={backgroundRepeat}
								onChange={(value) =>
									handleSelectedAttribute(value, 'backgroundRepeat')
								}
							/>
							<SelectControl
								label={__('Background Size', 'borobazar-helper')}
								value={backgroundSize}
								onChange={(value) =>
									handleSelectedAttribute(value, 'backgroundSize')
								}
								options={[
									{ value: 'auto', label: 'Auto' },
									{ value: 'contain', label: 'Contain' },
									{ value: 'cover', label: 'Cover' },
								]}
							/>
							<FocalPointPicker
								label={__('Background Position', 'borobazar-helper')}
								url={image}
								value={{
									x: focalX / 100,
									y: focalY / 100,
								}}
								onChange={(value) => {
									handleSelectedAttribute(
										`${value.x * 100}% ${value.y * 100}%`,
										'backgroundPosition'
									);
								}}
							/>
						</div>
					)}
					{popoverContent == 'content' && (
						<div style={{ width: 280, maxHeight: 360, padding: 16 }}>
							<div style={{ marginBottom: 20 }}>
								<Panel>
									<PanelBody
										title="Padding"
										initialOpen={false}
										style={{ marginBottom: 20 }}
									>
										<div className="borobazar-block-inline-wrap">
											<label>{__('Top', 'borobazar-helper')}</label>
											<Devices
												device={device}
												handleDevice={(device) => setDevice(device)}
											/>
										</div>
										<RangeControl
											value={paddingTop[device]}
											onChange={(value) =>
												handleResponsiveAttr(value, paddingTop, 'paddingTop')
											}
											min={0}
											max={300}
										/>
										<div className="borobazar-block-inline-wrap">
											<label>{__('Right', 'borobazar-helper')}</label>
											<Devices
												device={device}
												handleDevice={(device) => setDevice(device)}
											/>
										</div>
										<RangeControl
											value={paddingRight[device]}
											onChange={(value) =>
												handleResponsiveAttr(
													value,
													paddingRight,
													'paddingRight'
												)
											}
											min={0}
											max={300}
										/>
										<div className="borobazar-block-inline-wrap">
											<label>{__('Bottom', 'borobazar-helper')}</label>
											<Devices
												device={device}
												handleDevice={(device) => setDevice(device)}
											/>
										</div>
										<RangeControl
											value={paddingBottom[device]}
											onChange={(value) =>
												handleResponsiveAttr(
													value,
													paddingBottom,
													'paddingBottom'
												)
											}
											min={0}
											max={300}
										/>
										<div className="borobazar-block-inline-wrap">
											<label>{__('Left', 'borobazar-helper')}</label>
											<Devices
												device={device}
												handleDevice={(device) => setDevice(device)}
											/>
										</div>
										<RangeControl
											value={paddingLeft[device]}
											onChange={(value) =>
												handleResponsiveAttr(value, paddingLeft, 'paddingLeft')
											}
											min={0}
											max={300}
										/>
									</PanelBody>
								</Panel>
							</div>

							<div className="borobazar-block-inline-wrap">
								<label>{__('Minimum Height', 'borobazar-helper')}</label>
								<Devices
									device={device}
									handleDevice={(device) => setDevice(device)}
								/>
							</div>
							<InputControl
								value={height[device]}
								onChange={(value) => {
									let finalValue = parseInt(value);
									handleResponsiveAttr(finalValue, height, 'height');
								}}
								suffix={<div style={{ padding: '0 5px' }}>px</div>}
								type="number"
							/>

							<div style={{ marginTop: 20 }}>
								<SelectControl
									label={__('Text Alignment', 'borobazar-helper')}
									value={textAlign}
									onChange={(value) =>
										handleSelectedAttribute(value, 'textAlign')
									}
									options={[
										{ value: 'left', label: 'Left' },
										{ value: 'center', label: 'Center' },
										{ value: 'right', label: 'Right' },
									]}
								/>
							</div>

							<div style={{ margin: '20px 0' }}>Content position</div>
							<AlignmentMatrixControl
								value={contentPosition}
								onChange={(value) =>
									handleSelectedAttribute(value, 'contentPosition')
								}
								style={{ margin: 'auto' }}
							/>
						</div>
					)}
					{popoverContent == 'overlay' && (
						<div style={{ width: 280, padding: 16 }}>
							<CustomColorControl
								value={overlay}
								onChange={(value) => handleSelectedAttribute(value, 'overlay')}
							/>
							<RangeControl
								label={__('Opacity', 'borobazar-helper')}
								value={overlayOpacity}
								onChange={(value) =>
									handleSelectedAttribute(value, 'overlayOpacity')
								}
								step={5}
								min={0}
								max={100}
							/>
						</div>
					)}
					{popoverContent == 'color' && (
						<div style={{ width: 280, height: 360, padding: 16 }}>
							{template == 'hero' || template == 'content' ? (
								<Fragment>
									{colorSettings.map((palette) => (
										<ColorPaletteControl
											label={palette.label}
											value={palette.color}
											onChange={palette.onChange}
										/>
									))}
								</Fragment>
							) : (
								<Fragment>
									{colorSettingsMinimal.map((palette) => (
										<ColorPaletteControl
											label={palette.label}
											value={palette.color}
											onChange={palette.onChange}
										/>
									))}
								</Fragment>
							)}
						</div>
					)}
				</Popover>
			)}
		</Fragment>
	);
};
