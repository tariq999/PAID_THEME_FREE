export default {
	paddingTop: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingRight: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingBottom: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	paddingLeft: {
		type: "object",
		default: {
			desktop: 0,
			laptop: 0,
			tab: 0,
			mobile: 0,
		},
	},
	accordionItems: {
		type: "array",
		default: [
			{
				title: "",
				description: "",
			},
		],
	},
};
