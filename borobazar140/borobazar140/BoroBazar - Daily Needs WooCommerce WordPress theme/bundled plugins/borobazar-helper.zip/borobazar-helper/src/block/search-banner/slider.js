import { Swiper, SwiperSlide } from "swiper/react";
import SwiperCore, { Pagination, Autoplay } from "swiper";

// install Swiper components
SwiperCore.use([Pagination, Autoplay]);

export default ({ slideItems }) => {
	return (
		<Swiper
			spaceBetween={0}
			slidesPerView={1}
			pagination={{ clickable: true }}
			autoplay={{ delay: 6500, disableOnInteraction: false }}
			allowTouchMove={false}
			loop={true}
			speed={800}
			className="w-full h-full"
		>
			{slideItems.map((slideItem, index) => (
				<SwiperSlide key={index}>
					<div
						className="borobazar-search-banner-slide w-full h-full bg-cover bg-center bg-no-repeat"
						style={{ backgroundImage: `url(${slideItem.url})` }}
					/>
				</SwiperSlide>
			))}
		</Swiper>
	);
};
