/**
 * BLOCK: App block
 **/

const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;

import "./editor.scss";
import "./style.scss";
import attributes from "./attributes";
import edit from "./edit";
import { AppBannerIcon } from "./icon";

registerBlockType("borobazar-blocks/app-block", {
	title: __("App Banner", "borobazar-helper"),
	icon: <AppBannerIcon />,
	textdomain: "borobazar-helper",
	example: {
		attributes: {
			title: "Make your online shop easier<br>with our mobile app",
			description:
				"We offer high-quality films and the best documentary selection,<br>and the ability to browse alphabetically and by genre",
			backgroundColor: "#f2f2f2",
			descriptionColor: "#808080",
			titleColor: "#000",
			appStore: {
				url: "#",
				opensInNewTab: true,
			},
			playStore: {
				url: "#",
				opensInNewTab: true,
			},
		},
	},
	category: "borobazar-blocks-category",
	keywords: [
		__("play store", "borobazar-helper"),
		__("app store", "borobazar-helper"),
		__("app link", "borobazar-helper"),
		__("mobile app", "borobazar-helper"),
		__("app banner", "borobazar-helper"),
		__("download", "borobazar-helper"),
	],
	attributes,
	edit,
	save: () => {
		return null;
	},
	getEditWrapperProps() {
		return { "data-align": "full" };
	},
});
