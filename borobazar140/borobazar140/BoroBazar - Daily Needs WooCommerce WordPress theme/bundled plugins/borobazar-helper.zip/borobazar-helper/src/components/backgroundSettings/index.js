const { Fragment } = wp.element;
const { __ } = wp.i18n;
const { SelectControl, Button } = wp.components;
const { MediaUpload } = wp.blockEditor;

export default ({
  backgroundImage,
  backgroundRepeat,
  backgroundSize,
  backgroundAttachment,
  backgroundPositionX,
  backgroundPositionY,
  handleMedia,
  handleRemove,
  handleRepeat,
  handleSize,
  handleAttachment,
  handlePositionX,
  handlePositionY,
}) => {
  return (
    <Fragment>
      <MediaUpload
        buttonProps={{
          className: 'change-image',
        }}
        onSelect={handleMedia}
        allowed={['image']}
        type="image"
        render={({ open }) => {
          return (
            <Fragment>
              {backgroundImage ? (
                <div
                  className="borobazar-block-setting-image-preview"
                  style={{ marginBottom: '24px' }}
                >
                  <Button
                    isDefault
                    isSmall
                    onClick={handleRemove}
                    style={{ marginBottom: '10px' }}
                  >
                    {__('Remove Image', 'borobazar-helper')}
                  </Button>
                  <img
                    src={backgroundImage}
                    alt="image"
                    style={{
                      width: '100%',
                      height: 'auto',
                      border: '1px solid #ddd',
                    }}
                  />
                </div>
              ) : (
                <Button
                  isSecondary
                  isLarge
                  onClick={open}
                  style={{ marginBottom: '24px' }}
                >
                  {__('Upload Background Image', 'borobazar-helper')}
                </Button>
              )}
            </Fragment>
          );
        }}
      />
      <SelectControl
        label={__('Background Repeat', 'borobazar-helper')}
        value={backgroundRepeat}
        onChange={handleRepeat}
        options={[
          { value: 'no-repeat', label: 'No Repeat' },
          { value: 'repeat', label: 'Repeat' },
          { value: 'repeat-x', label: 'Repeat X' },
          { value: 'repeat-y', label: 'Repeat Y' },
        ]}
      />
      <SelectControl
        label={__('Background Size', 'borobazar-helper')}
        value={backgroundSize}
        onChange={handleSize}
        options={[
          { value: 'auto', label: 'Auto' },
          { value: 'contain', label: 'Contain' },
          { value: 'cover', label: 'Cover' },
        ]}
      />
      <SelectControl
        label={__('Background Attachment', 'borobazar-helper')}
        value={backgroundAttachment}
        onChange={handleAttachment}
        options={[
          { value: 'scroll', label: 'Scroll' },
          { value: 'fixed', label: 'Fixed' },
          { value: 'local', label: 'Local' },
        ]}
      />
      <SelectControl
        label={__('Background Position x', 'borobazar-helper')}
        value={backgroundPositionX}
        onChange={handlePositionX}
        options={[
          { value: 'left', label: 'Left' },
          { value: 'center', label: 'Center' },
          { value: 'right', label: 'Right' },
        ]}
      />
      <SelectControl
        label={__('Background Position y', 'borobazar-helper')}
        value={backgroundPositionY}
        onChange={handlePositionY}
        options={[
          { value: 'top', label: 'Top' },
          { value: 'center', label: 'Center' },
          { value: 'bottom', label: 'Bottom' },
        ]}
      />
    </Fragment>
  );
};
