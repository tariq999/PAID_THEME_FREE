const { Fragment } = wp.element;
// const { __ } = wp.i18n;
const { useSelect } = wp.data;
import {
	AlpineGridPreview,
	AlpineGridPreviewRTL,
	OakGridPreview,
	OakGridPreviewRTL,
	MapleGridPreview,
	MapleGridPreviewRTL,
} from './icon';

export default (props) => {
	const { gridTemplate, sidebar, className, padding } = props;

	// check if it's on RTL mode
	const isRTL = useSelect((select) => {
		return !!select('core/block-editor').getSettings().isRTL;
	}, []);

	let productCard, gridClass, gridCount;

	switch (gridTemplate) {
		case 'grid_alpine':
			productCard = isRTL ? <AlpineGridPreviewRTL /> : <AlpineGridPreview />;
			gridClass = sidebar
				? 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5'
				: 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			gridCount = 12;
			break;

		case 'grid_oak':
			productCard = isRTL ? <OakGridPreviewRTL /> : <OakGridPreview />;
			gridClass = sidebar
				? 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5'
				: 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			gridCount = 9;
			break;

		case 'grid_maple':
			productCard = isRTL ? <MapleGridPreviewRTL /> : <MapleGridPreview />;
			gridClass = sidebar
				? 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5'
				: 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			gridCount = 9;
			break;

		default:
			productCard = isRTL ? <AlpineGridPreviewRTL /> : <AlpineGridPreview />;
			gridClass = sidebar
				? 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5'
				: 'grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5';
			gridCount = 12;
			break;
	}

	return (
		<Fragment>
			<div
				className={`borobazar-block-spacing-wrapper ${className}`}
				style={padding}
			>
				<div className={`borobazar-products-block ${gridClass}`}>
					{[...Array(gridCount)].map((index) => (
						<div key={index} className="grid-col">
							{productCard}
						</div>
					))}
				</div>
			</div>
		</Fragment>
	);
};
