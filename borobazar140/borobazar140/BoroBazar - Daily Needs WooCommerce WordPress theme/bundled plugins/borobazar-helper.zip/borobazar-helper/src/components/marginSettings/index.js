import { useState } from "react";
// wp imports
const { __ } = wp.i18n;
const { PanelBody, __experimentalNumberControl: NumberControl } = wp.components;
// custom imports
import Devices from "../devices";

const MarginSettings = ({
	marginTop,
	marginRight,
	marginBottom,
	marginLeft,
	setAttributes,
	panelTitle = "Margin Settings",
	hidePanelIcon = false,
	initialOpen = false,
}) => {
	const [device, setDevice] = useState("desktop");
	const handleDevice = (device) => {
		setDevice(device);
	};

	return (
		<PanelBody
			title={__(panelTitle, "borobazar-helper")}
			icon={!hidePanelIcon ? "image-flip-horizontal" : ""}
			initialOpen={initialOpen}
		>
			<div className="borobazar-block-inline-wrap">
				<label>{__("Top", "borobazar-helper")}</label>
				<Devices
					device={device}
					handleDevice={(device) => handleDevice(device)}
				/>
			</div>
			<div style={{ marginBottom: "24px" }}>
				<NumberControl
					value={marginTop[device]}
					onChange={(value) =>
						setAttributes({
							marginTop: {
								...marginTop,
								[device]: value,
							},
						})
					}
					required
				/>
			</div>

			<div className="borobazar-block-inline-wrap">
				<label>{__("Right", "borobazar-helper")}</label>
				<Devices
					device={device}
					handleDevice={(device) => handleDevice(device)}
				/>
			</div>
			<div style={{ marginBottom: "24px" }}>
				<NumberControl
					value={marginRight[device]}
					onChange={(value) =>
						setAttributes({
							marginRight: {
								...marginRight,
								[device]: value,
							},
						})
					}
					required
				/>
			</div>

			<div className="borobazar-block-inline-wrap">
				<label>{__("Bottom", "borobazar-helper")}</label>
				<Devices
					device={device}
					handleDevice={(device) => handleDevice(device)}
				/>
			</div>
			<div style={{ marginBottom: "24px" }}>
				<NumberControl
					value={marginBottom[device]}
					onChange={(value) =>
						setAttributes({
							marginBottom: {
								...marginBottom,
								[device]: value,
							},
						})
					}
					required
				/>
			</div>

			<div className="borobazar-block-inline-wrap">
				<label>{__("Left", "borobazar-helper")}</label>
				<Devices
					device={device}
					handleDevice={(device) => handleDevice(device)}
				/>
			</div>
			<div style={{ marginBottom: "24px" }}>
				<NumberControl
					value={marginLeft[device]}
					onChange={(value) =>
						setAttributes({
							marginLeft: {
								...marginLeft,
								[device]: value,
							},
						})
					}
					required
				/>
			</div>
		</PanelBody>
	);
};

export default MarginSettings;
