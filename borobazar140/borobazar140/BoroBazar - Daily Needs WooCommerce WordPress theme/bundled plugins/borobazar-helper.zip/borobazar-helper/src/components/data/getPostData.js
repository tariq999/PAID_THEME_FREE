import { useState } from 'react';
import PropTypes from 'prop-types';

const { Fragment } = wp.element;
const { __ } = wp.i18n;
const { SelectControl } = wp.components;
const { useSelect } = wp.data;

const PostTypeSelect = (props) => {
	// declare local states
	const [postType, setPostType] = useState(previousValue || '');
};

const PostTypes = (props) => {
	// grab props
	const {
		predefinedPostType,
		showTaxonomy,
		showTerm,
		previousValue,
		previousTaxValue,
		previousTermValue,
		update,
		updateTax,
		updateTerm,
		exludeItem,
		excludeArray,
		excludeTaxonomy,
	} = props;

	// declare local states
	const [postType, setPostType] = useState(previousValue || '');
	const [taxonomy, setTaxonomy] = useState(previousTaxValue || '');
	const [term, setTerm] = useState(previousTermValue || '');

	// fetched post types, taxonomies, terms
	const posts = useSelect(
		(select) => {
			const type = select('core').getPostTypes();
			const taxQuery = {
				per_page: -1,
				hide_empty: false,
				post_type: postType,
			};

			const matchedPostType =
				type && type.find((obj) => obj.slug === postType.postType);

			let fetchTaxonomy = [];
			if (matchedPostType) {
				for (const key in matchedPostType) {
					if (key === 'taxonomies') {
						const index = matchedPostType[key].indexOf(taxonomy.taxonomy);
						if (index !== -1) {
							fetchTaxonomy = select('core').getEntityRecords(
								'taxonomy',
								taxonomy.taxonomy,
								taxQuery
							);
						} else {
							fetchTaxonomy = [];
						}
					}
				}
			}
			const taxonomyLists = fetchTaxonomy;
			return { type, taxonomyLists };
		},
		[postType, taxonomy, term]
	);
	const { type, taxonomyLists } = posts;

	// declares default parameters for select items
	let tempPostTypeArray = [
		{
			label: __('Select Post type', 'borobazar-helper'),
			value: '',
		},
	];
	let tempTaxOptions = [
		{
			label: __('Select taxonomy', 'borobazar-helper'),
			value: '',
		},
	];

	let tempTaxTermOptions = [
		{
			label: __('Select term', 'borobazar-helper'),
			value: '',
		},
	];

	// prepare post type array for users
	if (type && type.length > 0) {
		for (let i = 0; i < type.length; i++) {
			let tempOptions = {};
			tempOptions.taxonomies = type[i].taxonomies;
			tempOptions.label = type[i].name;
			tempOptions.value = type[i].slug;
			tempPostTypeArray.push(tempOptions);
		}
	}

	// Exclude given post type
	if (exludeItem === 'true') {
		tempPostTypeArray = tempPostTypeArray.filter(function (obj) {
			return !this.has(obj.value);
		}, new Set(excludeArray.map((obj) => obj.value)));
	}

	// taxonomy array build for select options
	if (showTaxonomy === 'true') {
		const selectedPostTax =
			tempPostTypeArray &&
			tempPostTypeArray.find((o) => o.value === previousValue);

		if (selectedPostTax) {
			const tempTaxArray = selectedPostTax ? selectedPostTax.taxonomies : [];
			if (tempTaxArray && tempTaxArray.length > 0) {
				for (let index = 0; index < tempTaxArray.length; index++) {
					let tempObj = {};
					tempObj.label = tempTaxArray[index];
					tempObj.value = tempTaxArray[index];
					tempTaxOptions.push(tempObj);
				}
			}
		}

		// Exclude given taxonomy
		if ((tempTaxOptions && tempTaxOptions.length > 1) && (excludeTaxonomy && excludeTaxonomy.length > 0)) {
			tempTaxOptions = tempTaxOptions.filter(function (obj) {
				return !this.has(obj.value);
			}, new Set(excludeTaxonomy.map((obj) => obj.value)));
		}
	}

	// term array build for select options
	if (showTerm === 'true') {
		if (taxonomyLists && taxonomyLists.length > 0) {
			for (let index = 0; index < taxonomyLists.length; index++) {
				let tempTermObj = {};
				tempTermObj.label = taxonomyLists[index].name;
				tempTermObj.value = taxonomyLists[index].slug;
				tempTermObj.id = taxonomyLists[index].id;
				tempTermObj.parent = taxonomyLists[index].parent;
				tempTermObj.count = taxonomyLists[index].count;
				tempTaxTermOptions.push(tempTermObj);
			}
		}
	}

	// render components in Inspector panels
	return (
		<Fragment>
			{predefinedPostType && predefinedPostType !== 'true' ? (
				<Fragment>
					{tempPostTypeArray && tempPostTypeArray.length > 1 ? (
						<SelectControl
							label={__('Select Post type', 'borobazar-helper')}
							value={previousValue || postType}
							onChange={(postType) => {
								setPostType({ postType });
								update(postType);
							}}
							options={tempPostTypeArray}
						/>
					) : (
						<SelectControl
							label={__('Select Post type', 'borobazar-helper')}
							value=""
							options={[{ label: 'Data is loading ...', value: '' }]}
						/>
					)}
				</Fragment>
			) : (
				<input
					type="hidden"
					onChange={(previousValue) => {
						setPostType({ postType: previousValue });
					}}
				/>
			)}

			{showTaxonomy === 'true' ? (
				postType !== '' && tempTaxOptions && tempTaxOptions.length > 1 ? (
					<SelectControl
						label={__('Select taxonomy', 'borobazar-helper')}
						value={previousTaxValue || taxonomy}
						onChange={(taxonomy) => {
							setTaxonomy({ taxonomy });
							updateTax(taxonomy);
						}}
						options={tempTaxOptions}
					/>
				) : (
					<SelectControl
						label={__('Choose Post Type first..!', 'borobazar-helper')}
						value=""
						options={[{ label: 'Data is loading ...', value: '' }]}
					/>
				)
			) : (
				''
			)}

			{showTerm === 'true' ? (
				tempTaxTermOptions && tempTaxTermOptions.length > 1 ? (
					<SelectControl
						label={__(`Select ${taxonomy.taxonomy}`, 'borobazar-helper')}
						value={previousTermValue || term}
						onChange={(term) => {
							setTerm({ term });
							updateTerm(term);
						}}
						options={tempTaxTermOptions}
					/>
				) : (
					''
				)
			) : (
				''
			)}
		</Fragment>
	);
};

PostTypes.propTypes = {
	predefinedPostType: PropTypes.string,
	showTaxonomy: PropTypes.string,
	showTerm: PropTypes.string,
	exludeItem: PropTypes.string,
	excludeArray: PropTypes.array,
	excludeTaxonomy: PropTypes.array,
	previousValue: PropTypes.string,
	previousTaxValue: PropTypes.string,
	previousTermValue: PropTypes.string,
	update: PropTypes.func,
	updateTax: PropTypes.func,
	updateTerm: PropTypes.func,
};

export default PostTypes;
