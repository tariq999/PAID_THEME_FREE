const { data, apiRequest } = wp;
const apiFetch = wp.apiFetch;
const { addQueryArgs } = wp.url;
const { registerStore, dispatch } = data;

const DEFAULT_STATE = {};

registerStore("borobazar-blocks/data-product-tags", {
	reducer(state = DEFAULT_STATE, action) {
		switch (action.type) {
			case "GET_PRODUCT_CATEGORY_LIST":
				return {
					forms: action.data,
				};
		}
		return state;
	},

	actions: {
		setTagList(data) {
			return {
				type: "GET_PRODUCT_CATEGORY_LIST",
				data: data,
			};
		},
	},

	selectors: {
		getTagList(data) {
			if (typeof data.forms !== "undefined") {
				return data.forms;
			}
		},
	},

	resolvers: {
		async getTagList() {
			let result = [];
			// result = await apiRequest({
			// 	path: "/wc/v3/products/categories?per_page=20"
			// });
			result = await apiFetch({
				path: addQueryArgs(`/wc/v3/products/tags`, {
					per_page: -1,
				}),
			});
			dispatch("borobazar-blocks/data-product-tags").setTagList(result);
		},
	},
});
