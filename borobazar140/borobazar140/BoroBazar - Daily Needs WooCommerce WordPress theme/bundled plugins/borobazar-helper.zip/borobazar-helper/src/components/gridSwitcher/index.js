const { Fragment } = wp.element;
const { __ } = wp.i18n;
const { PanelBody } = wp.components;
const { useSelect } = wp.data;

import TemplateSwitcher from './templateSwitcher';
import {
	AlpineGridPreview,
	AlpineGridPreviewRTL,
	OakGridPreview,
	OakGridPreviewRTL,
	MapleGridPreview,
	MapleGridPreviewRTL,
} from './icon';
import './editor.scss';

export default (props) => {
	const {
		attributes: { gridTemplate },
		setAttributes,
	} = props;

	// to check if RTL mode is on
	const isRTL = useSelect((select) => {
		return !!select('core/block-editor').getSettings().isRTL;
	}, []);

	const quickCartItems = [
		{
			preview: isRTL ? <AlpineGridPreviewRTL /> : <AlpineGridPreview />,
			label: __('Alpine', 'borobazar-helper'),
			value: 'grid_alpine',
		},
		{
			preview: isRTL ? <OakGridPreviewRTL /> : <OakGridPreview />,
			label: __('Oak', 'borobazar-helper'),
			value: 'grid_oak',
		},
		{
			preview: isRTL ? <MapleGridPreviewRTL /> : <MapleGridPreview />,
			label: __('Maple', 'borobazar-helper'),
			value: 'grid_maple',
		},
	];

	return (
		<div className="borobazar-helper-grids">
			<PanelBody
				title={__('Product Grids', 'borobazar-helper')}
				initialOpen={false}
			>
				<Fragment>
					<TemplateSwitcher
						label={__('Select Grid layout', 'borobazar-helper')}
						handleTemplate={(template) =>
							setAttributes({ gridTemplate: template })
						}
						template={gridTemplate}
						items={quickCartItems}
					/>
				</Fragment>
			</PanelBody>
		</div>
	);
};
