import { useState } from "react";
const { RangeControl, PanelBody } = wp.components;
const { __ } = wp.i18n;
import Devices from "../devices";

const HeightSettings = ({ height, setAttributes, initialOpen = false }) => {
	const [device, setDevice] = useState("desktop");
	const handleDevice = (device) => {
		setDevice(device);
	};

	return (
		<PanelBody
			title={__("Height Settings", "borobazar-helper")}
			initialOpen={initialOpen}
		>
			<div className="borobazar-block-inline-wrap">
				<label>{__("Height", "borobazar-helper")}</label>
				<Devices
					device={device}
					handleDevice={(device) => handleDevice(device)}
				/>
			</div>
			<RangeControl
				value={height[device]}
				onChange={(value) =>
					setAttributes({
						height: {
							...height,
							[device]: value,
						},
					})
				}
				min={0}
				max={600}
				required
			/>
		</PanelBody>
	);
};

export default HeightSettings;
