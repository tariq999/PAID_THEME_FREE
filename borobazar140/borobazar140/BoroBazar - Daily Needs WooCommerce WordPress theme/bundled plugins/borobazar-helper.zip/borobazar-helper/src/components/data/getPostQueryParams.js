import PropTypes from "prop-types";
const { RangeControl, SelectControl, ToggleControl, PanelBody } = wp.components;
const { __ } = wp.i18n;

const PostQueryParams = (props) => {
	const {
		title,
		postsPerPage,
		orderBy,
		order,
		slider,
		sliderMode,
		setAttributes,
		initialOpen = false,
	} = props;

	const orderOptions = [
		{ label: "Descending", value: "DESC" },
		{ label: "Ascending", value: "ASC" },
	];

	const orderByOptions = [
		{ label: "Post ID", value: "ID" },
		{ label: "Post title", value: "post_title" },
		{ label: "Post modified", value: "post_modified" },
		{ label: "Post parent", value: "post_parent" },
		{ label: "Menu Order", value: "menu_order" },
		{ label: "Name", value: "post_name" },
		{ label: "Author", value: "post_author" },
		{ label: "Date", value: "date" },
		{ label: "Random", value: "rand" },
		{ label: "Comment Count", value: "comment_count" },
	];

	const sliderOptions = [
		{ label: "Disable", value: "disable" },
		{ label: "Enable", value: "enable" },
	];
	return (
		<PanelBody
			title={title || __("Query [parameters]", "borobazar-helper")}
			icon="image-flip-horizontal"
			initialOpen={initialOpen}
		>
			{postsPerPage ? (
				<RangeControl
					label={__("Product count", "borobazar-helper")}
					value={postsPerPage}
					onChange={(value) =>
						setAttributes({
							postsPerPage: value,
						})
					}
					min={props.min || 1}
					max={props.max || 1000}
					required
				/>
			) : (
				""
			)}

			{sliderMode ? (
				<SelectControl
					label={__("Products slider ?", "borobazar-helper")}
					value={slider}
					onChange={(value) => {
						setAttributes({
							slider: value,
						});
					}}
					options={sliderOptions}
				/>
			) : (
				""
			)}

			{order ? (
				<SelectControl
					label={__("Select order", "borobazar-helper")}
					value={order}
					onChange={(value) => {
						setAttributes({
							order: value,
						});
					}}
					options={orderOptions}
				/>
			) : (
				""
			)}

			{orderBy ? (
				<SelectControl
					label={__("Select orderby", "borobazar-helper")}
					value={orderBy}
					onChange={(value) => {
						setAttributes({
							orderBy: value,
						});
					}}
					options={orderByOptions}
				/>
			) : (
				""
			)}
		</PanelBody>
	);
};

PostQueryParams.propTypes = {
	title: PropTypes.string,
	postsPerPage: PropTypes.number,
	order: PropTypes.string,
	orderBy: PropTypes.string,
	sliderMode: PropTypes.bool,
	slider: PropTypes.string,
	initialOpen: PropTypes.bool,
	setAttributes: PropTypes.func,
};

export default PostQueryParams;
