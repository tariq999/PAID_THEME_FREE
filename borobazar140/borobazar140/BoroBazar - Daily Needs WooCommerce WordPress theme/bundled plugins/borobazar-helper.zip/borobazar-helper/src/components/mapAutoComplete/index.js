import React, { Component } from 'react';
import PropTypes from 'prop-types';
import PlacesAutocomplete, {
	geocodeByAddress,
	getLatLng,
} from 'react-places-autocomplete';

class MapAutoComplete extends Component {
	constructor(props) {
		super(props);
		this.state = this.props.data || {
			address: '',
			coordinate: {
				lat: 0,
				lng: 0,
			},
		};
	}

	handleChange = address => {
		this.setState({ address });
	};

	handleSelect = address => {
		geocodeByAddress(address)
			.then(results => getLatLng(results[0]))
			.then(latLng =>
				this.setState({
					address: address,
					coordinate: {
						lat: latLng.lat,
						lng: latLng.lng,
					},
				})
			)
			.catch(error => console.error('Error', error));
	};

	render() {
		const { updateData } = this.props;
		if (
			this.state.address !== '' ||
			this.state.address !== 'undefined' ||
			Object.entries(this.state.coordinate).length !== 0
		) {
			updateData(this.state);
		}
		return (
			<PlacesAutocomplete
				value={this.state.address}
				onChange={this.handleChange}
				onSelect={this.handleSelect}
			>
				{({ getInputProps, suggestions, getSuggestionItemProps, loading }) => (
					<div>
						<input
							{...getInputProps({
								placeholder: 'Search Places ...',
								className: 'location-search-input',
							})}
						/>

						<div className="autocomplete-dropdown-container">
							{loading && <div>Loading...</div>}
							{suggestions.map(suggestion => {
								const className = suggestion.active
									? 'suggestion-item--active'
									: 'suggestion-item';
								const style = suggestion.active
									? {
											backgroundColor: '#1985ba',
											cursor: 'pointer',
											color: '#ffffff',
									  }
									: { backgroundColor: '#ffffff', cursor: 'pointer' };
								return (
									<div
										{...getSuggestionItemProps(suggestion, {
											className,
											style,
										})}
									>
										<span>{suggestion.description}</span>
									</div>
								);
							})}
						</div>
					</div>
				)}
			</PlacesAutocomplete>
		);
	}
}

MapAutoComplete.propTypes = {
	data: PropTypes.object,
	updateData: PropTypes.func,
};
export default MapAutoComplete;
