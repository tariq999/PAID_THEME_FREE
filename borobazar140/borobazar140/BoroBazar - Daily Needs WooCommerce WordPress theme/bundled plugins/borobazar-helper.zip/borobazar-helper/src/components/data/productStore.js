const { data, apiRequest } = wp;
const apiFetch = wp.apiFetch;
const { addQueryArgs } = wp.url;
const { registerStore, dispatch } = data;

const DEFAULT_STATE = {};

registerStore("borobazar-blocks/data-products-store", {
	reducer(state = DEFAULT_STATE, action) {
		switch (action.type) {
			case "GET_PRODUCT_LIST":
				return {
					forms: action.data,
				};
		}
		return state;
	},

	actions: {
		setProductList(data) {
			return {
				type: "GET_PRODUCT_LIST",
				data: data,
			};
		},
	},

	selectors: {
		getProductList(data) {
			if (typeof data.forms !== "undefined") {
				return data.forms;
			}
		},
	},

	resolvers: {
		async getProductList() {
			let result = [];
			result = await apiFetch({
				path: addQueryArgs(`/wc/v3/products`, {
					per_page: -1,
				}),
			});
			dispatch("borobazar-blocks/data-products-store").setProductList(result);
		},
	},
});
