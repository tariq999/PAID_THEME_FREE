import { DesktopIcon, LaptopIcon, MobileIcon, TabIcon } from './icons';
const { __ } = wp.i18n;

import './editor.scss';

export default ({ device, handleDevice }) => {
	return (
		<div className="borobazar-block-device-wrap">
			<button
				onClick={() => handleDevice('desktop')}
				className={`borobazar-block-device-btn ${
					device === 'desktop' ? 'active' : ''
				}`}
				title={__('Desktop', 'borobazar-helper')}
			>
				<DesktopIcon />
			</button>
			<button
				onClick={() => handleDevice('laptop')}
				className={`borobazar-block-device-btn ${
					device === 'laptop' ? 'active' : ''
				}`}
				title={__('Laptop', 'borobazar-helper')}
			>
				<LaptopIcon />
			</button>
			<button
				onClick={() => handleDevice('tab')}
				className={`borobazar-block-device-btn ${
					device === 'tab' ? 'active' : ''
				}`}
				title={__('Tab', 'borobazar-helper')}
			>
				<TabIcon />
			</button>
			<button
				onClick={() => handleDevice('mobile')}
				className={`borobazar-block-device-btn ${
					device === 'mobile' ? 'active' : ''
				}`}
				title={__('Mobile', 'borobazar-helper')}
			>
				<MobileIcon />
			</button>
		</div>
	);
};
