import { useState, useEffect } from "react";
import PropTypes from "prop-types";

const { Fragment } = wp.element;
const { __ } = wp.i18n;
const { SelectControl } = wp.components;

const ProductCategories = (props) => {
	// grab props
	const { title, previousTermValue, updateTerm, getCategories } = props;

	// declare local states
	const [term, setTerm] = useState(previousTermValue || "");

	let tempTaxTermOptions = [
		{
			label: __("Select a option", "borobazar-helper"),
			value: "",
		},
	];

	if (getCategories && getCategories.length > 0) {
		for (let index = 0; index < getCategories.length; index++) {
			let tempTermObj = {};
			tempTermObj.label = getCategories[index].name;
			tempTermObj.value = getCategories[index].slug;
			tempTermObj.id = getCategories[index].id;
			tempTermObj.slug = getCategories[index].slug;
			tempTermObj.parent = getCategories[index].parent;
			tempTermObj.count = getCategories[index].count;
			tempTermObj.menu_order = getCategories[index].menu_order;
			tempTaxTermOptions.push(tempTermObj);
		}
	}

	// render components in Inspector panels
	return (
		<Fragment>
			{tempTaxTermOptions && tempTaxTermOptions.length > 1 ? (
				<SelectControl
					label={title || __('Select option', 'borobazar-helper')}
					value={previousTermValue || term}
					onChange={(term) => {
						setTerm({ term });
						updateTerm(term);
					}}
					options={tempTaxTermOptions}
					labelPosition="top"
				/>
			) : (
				'Wait A bit...'
			)}
		</Fragment>
	);
};

ProductCategories.propTypes = {
	title: PropTypes.string,
	showTaxonomy: PropTypes.string,
	showTerm: PropTypes.string,
	exludeItem: PropTypes.string,
	excludeArray: PropTypes.array,
	previousValue: PropTypes.string,
	previousTaxValue: PropTypes.string,
	previousTermValue: PropTypes.string,
	update: PropTypes.func,
	updateTax: PropTypes.func,
	updateTerm: PropTypes.func,
};

export default ProductCategories;
