import PropTypes from "prop-types";
const { RangeControl, SelectControl, PanelBody } = wp.components;
const { __ } = wp.i18n;

const PostQueryParams = (props) => {
	const { title, customOrderBy, setAttributes, initialOpen = false } = props;

	const orderByOptions = [
		{ label: "Select a Option", value: "none" },
		{ label: "Newest", value: "newest" },
		{ label: "Price: Low to High", value: "price_low_high" },
		{ label: "Price: High to Low", value: "price_high_low" },
	];

	return (
		<PanelBody
			title={title || __("Query [parameters]", "borobazar-helper")}
			icon="image-flip-horizontal"
			initialOpen={initialOpen}
		>
			{customOrderBy ? (
				<SelectControl
					label={__("Select orderby", "borobazar-helper")}
					value={customOrderBy}
					onChange={(value) => {
						setAttributes({
							customOrderBy: value,
						});
					}}
					options={orderByOptions}
				/>
			) : (
				""
			)}
		</PanelBody>
	);
};

PostQueryParams.propTypes = {
	postsPerPage: PropTypes.string,
	order: PropTypes.string,
	orderBy: PropTypes.string,
	setAttributes: PropTypes.func,
};

export default PostQueryParams;
