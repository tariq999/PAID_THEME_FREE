/**
 * WordPress dependencies
 */
import { Path, SVG } from "@wordpress/components";

export const DesktopIcon = () => (
  <SVG width="14" viewBox="0 0 512 384" fill="currentColor">
    <g transform="translate(0 -64)">
      <Path d="M486.4,64H25.6A25.6,25.6,0,0,0,0,89.6v256a25.6,25.6,0,0,0,25.6,25.6H238.933v51.2H153.6V448H358.4V422.4H264.533V371.2H486.4A25.6,25.6,0,0,0,512,345.6V89.6A25.6,25.6,0,0,0,486.4,64Zm0,281.6H25.6V89.6H486.4Z" />
    </g>
  </SVG>
);

export const LaptopIcon = () => (
  <SVG width="14" viewBox="0 0 512 358.4" fill="currentColor">
    <g transform="translate(0 -76.8)">
      <g>
        <Path d="M499.2,409.6H12.8a12.8,12.8,0,1,0,0,25.6H499.2a12.8,12.8,0,0,0,0-25.6Z" />
      </g>
      <g>
        <path d="M460.8,76.8H51.2a25.6,25.6,0,0,0-25.6,25.6v256A25.6,25.6,0,0,0,51.2,384H460.8a25.6,25.6,0,0,0,25.6-25.6v-256A25.6,25.6,0,0,0,460.8,76.8Zm0,281.6H51.2v-256H460.8v256Z" />
      </g>
    </g>
  </SVG>
);

export const MobileIcon = () => (
  <svg width="10" height="13" viewBox="0 0 307.2 512" fill="currentColor">
    <g id="smartphone" transform="translate(-102.4)">
      <g id="Group_3301" data-name="Group 3301">
        <g id="Group_3300" data-name="Group 3300">
          <path
            data-name="Path 6196"
            d="M302.933,42.667h-51.2a12.8,12.8,0,1,0,0,25.6h51.2a12.8,12.8,0,0,0,0-25.6Z"
          />
        </g>
      </g>
      <g id="Group_3303" data-name="Group 3303">
        <g id="Group_3302" data-name="Group 3302">
          <path
            data-name="Path 6197"
            d="M358.4,0H153.6a51.263,51.263,0,0,0-51.2,51.2V460.8A51.263,51.263,0,0,0,153.6,512H358.4a51.263,51.263,0,0,0,51.2-51.2V51.2A51.263,51.263,0,0,0,358.4,0ZM384,460.8a25.6,25.6,0,0,1-25.6,25.6H153.6A25.6,25.6,0,0,1,128,460.8V51.2a25.6,25.6,0,0,1,25.6-25.6H358.4A25.6,25.6,0,0,1,384,51.2V460.8Z"
          />
        </g>
      </g>
      <g id="Group_3305" data-name="Group 3305">
        <g id="Group_3304" data-name="Group 3304">
          <circle
            id="Ellipse_66"
            data-name="Ellipse 66"
            cx="25.6"
            cy="25.6"
            r="25.6"
            transform="translate(230.4 418.133)"
          />
        </g>
      </g>
      <g id="Group_3307" data-name="Group 3307">
        <g id="Group_3306" data-name="Group 3306">
          <circle
            id="Ellipse_67"
            data-name="Ellipse 67"
            cx="12.8"
            cy="12.8"
            r="12.8"
            transform="translate(196.267 42.667)"
          />
        </g>
      </g>
    </g>
  </svg>
);

export const TabIcon = () => (
  <svg width="14" height="12" viewBox="0 0 375.468 512" fill="currentColor">
    <g id="tablet" transform="translate(-68.267)">
      <g id="Group_3309" data-name="Group 3309">
        <g id="Group_3308" data-name="Group 3308">
          <path
            data-name="Path 6198"
            d="M392.533,0H119.467a51.263,51.263,0,0,0-51.2,51.2V460.8a51.263,51.263,0,0,0,51.2,51.2H392.534a51.263,51.263,0,0,0,51.2-51.2V51.2A51.264,51.264,0,0,0,392.533,0Zm25.6,460.8a25.6,25.6,0,0,1-25.6,25.6H119.467a25.6,25.6,0,0,1-25.6-25.6V51.2a25.6,25.6,0,0,1,25.6-25.6H392.534a25.6,25.6,0,0,1,25.6,25.6V460.8Z"
          />
        </g>
      </g>
      <g id="Group_3311" data-name="Group 3311">
        <g id="Group_3310" data-name="Group 3310">
          <circle
            id="Ellipse_68"
            data-name="Ellipse 68"
            cx="25.6"
            cy="25.6"
            r="25.6"
            transform="translate(230.4 418.133)"
          />
        </g>
      </g>
      <g id="Group_3313" data-name="Group 3313">
        <g id="Group_3312" data-name="Group 3312">
          <circle
            id="Ellipse_69"
            data-name="Ellipse 69"
            cx="12.8"
            cy="12.8"
            r="12.8"
            transform="translate(247.467 42.667)"
          />
        </g>
      </g>
    </g>
  </svg>
);
