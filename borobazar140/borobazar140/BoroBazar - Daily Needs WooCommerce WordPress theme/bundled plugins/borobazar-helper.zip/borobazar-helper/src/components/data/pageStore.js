const { data, apiRequest } = wp;
const apiFetch = wp.apiFetch;
const { addQueryArgs } = wp.url;
const { registerStore, dispatch } = data;

const DEFAULT_STATE = {};

registerStore("borobazar-blocks/data-pages", {
	reducer(state = DEFAULT_STATE, action) {
		switch (action.type) {
			case "GET_PAGE_LIST":
				return {
					forms: action.data,
				};
		}
		return state;
	},

	actions: {
		setPageList(data) {
			return {
				type: "GET_PAGE_LIST",
				data: data,
			};
		},
	},

	selectors: {
		getPageList(data) {
			if (typeof data.forms !== "undefined") {
				return data.forms;
			}
		},
	},

	resolvers: {
		async getPageList() {
			let result = [];
			result = await apiFetch({
				path: addQueryArgs(`/wp/v2/pages`, {
					per_page: -1,
				}),
			});
			dispatch("borobazar-blocks/data-pages").setPageList(result);
		},
	},
});
