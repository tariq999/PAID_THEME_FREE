import { useState } from 'react';
const { Fragment } = wp.element;
// const { Button, ButtonGroup } = wp.components;
const {
	ColorPaletteControl,
	__experimentalGradientPickerControl: GradientControl,
} = wp.blockEditor;

export default ({ value, onChange }) => {
	//States
	// eslint-disable-next-line no-unused-vars
	const [tab, setTab] = useState('solid');

	return (
		<Fragment>
			{/* Buttons */}
			{/* <ButtonGroup style={{ marginBottom: 12 }}>
				<Button
					variant="primary"
					isSmall
					isPressed={tab == "solid" ? true : false}
					onClick={() => setTab("solid")}
				>
					Solid
				</Button>
				<Button
					variant="primary"
					isSmall
					isPressed={tab == "gradient" ? true : false}
					onClick={() => setTab("gradient")}
				>
					Gradient
				</Button>
			</ButtonGroup> */}

			{/* Solid color palette */}
			{tab === 'solid' && (
				<ColorPaletteControl value={value} onChange={onChange} />
			)}

			{/* Gradient color palette */}
			{tab === 'gradient' && (
				<GradientControl value={value} onChange={onChange} />
			)}
		</Fragment>
	);
};
