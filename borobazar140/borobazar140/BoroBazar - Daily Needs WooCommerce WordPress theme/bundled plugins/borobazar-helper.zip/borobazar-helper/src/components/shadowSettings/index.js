// wp imports
const { __ } = wp.i18n;
const {
	PanelBody,
	RangeControl,
	ColorPicker,
	__experimentalNumberControl: NumberControl,
} = wp.components;

const ShadowSettings = ({
	boxShadow,
	setAttributes,
	panelTitle = "Shadow Settings",
	initialOpen = false,
}) => {
	const { horizontal, vertical, blur, spread, color } = boxShadow;
	function getRGBAformat(colorCode) {
		return `rgba(${colorCode.r}, ${colorCode.g}, ${colorCode.b}, ${colorCode.a})`;
	}

	return (
		<PanelBody
			title={__(panelTitle, "borobazar-helper")}
			initialOpen={initialOpen}
		>
			<div style={{ marginBottom: "24px" }}>
				<label style={{ display: "block", marginBottom: "8px" }}>
					{__("Horizontal:", "borobazar-helper")}
				</label>
				<NumberControl
					value={horizontal}
					onChange={(value) =>
						setAttributes({
							boxShadow: {
								...boxShadow,
								horizontal: value,
							},
						})
					}
					required
				/>
			</div>

			<div style={{ marginBottom: "24px" }}>
				<label style={{ display: "block", marginBottom: "8px" }}>
					{__("Vertical:", "borobazar-helper")}
				</label>
				<NumberControl
					value={vertical}
					onChange={(value) =>
						setAttributes({
							boxShadow: {
								...boxShadow,
								vertical: value,
							},
						})
					}
					required
				/>
			</div>

			<div style={{ marginBottom: "24px" }}>
				<label>{__("Blur:", "borobazar-helper")}</label>
				<RangeControl
					value={blur}
					onChange={(value) =>
						setAttributes({
							boxShadow: {
								...boxShadow,
								blur: value,
							},
						})
					}
					min={0}
					max={100}
					required
				/>
			</div>

			<div style={{ marginBottom: "24px" }}>
				<label style={{ display: "block", marginBottom: "8px" }}>
					{__("Spread:", "borobazar-helper")}
				</label>
				<NumberControl
					value={spread}
					onChange={(value) =>
						setAttributes({
							boxShadow: {
								...boxShadow,
								spread: value,
							},
						})
					}
					required
				/>
			</div>

			<div>
				<label style={{ display: "block", marginBottom: "8px" }}>
					{__("Shadow Color:", "borobazar-helper")}
				</label>
				<ColorPicker
					color={color}
					onChangeComplete={(value) =>
						setAttributes({
							boxShadow: {
								...boxShadow,
								color: getRGBAformat(value.rgb),
							},
						})
					}
				/>
			</div>
		</PanelBody>
	);
};

export default ShadowSettings;
