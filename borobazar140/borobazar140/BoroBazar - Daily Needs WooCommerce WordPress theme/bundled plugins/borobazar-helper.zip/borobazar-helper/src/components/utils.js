/**
 * handle padding settings css variable
 * @param  {} attributes
 */
export function getBoroBazarPaddingStyles(attributes) {
	const { paddingTop, paddingRight, paddingBottom, paddingLeft } = attributes;
	return {
		"--desktop-padding-top": `${paddingTop.desktop}px`,
		"--laptop-padding-top": `${paddingTop.laptop}px`,
		"--tab-padding-top": `${paddingTop.tab}px`,
		"--mobile-padding-top": `${paddingTop.mobile}px`,
		"--desktop-padding-right": `${paddingRight.desktop}px`,
		"--laptop-padding-right": `${paddingRight.laptop}px`,
		"--tab-padding-right": `${paddingRight.tab}px`,
		"--mobile-padding-right": `${paddingRight.mobile}px`,
		"--desktop-padding-bottom": `${paddingBottom.desktop}px`,
		"--laptop-padding-bottom": `${paddingBottom.laptop}px`,
		"--tab-padding-bottom": `${paddingBottom.tab}px`,
		"--mobile-padding-bottom": `${paddingBottom.mobile}px`,
		"--desktop-padding-left": `${paddingLeft.desktop}px`,
		"--laptop-padding-left": `${paddingLeft.laptop}px`,
		"--tab-padding-left": `${paddingLeft.tab}px`,
		"--mobile-padding-left": `${paddingLeft.mobile}px`,
	};
}

/**
 * handle margin settings css variable
 * @param  {} attributes
 */
export function getBoroBazarMarginStyles(attributes) {
	const { marginTop, marginRight, marginBottom, marginLeft } = attributes;
	return {
		"--desktop-margin-top": `${marginTop.desktop}px`,
		"--laptop-margin-top": `${marginTop.laptop}px`,
		"--tab-margin-top": `${marginTop.tab}px`,
		"--mobile-margin-top": `${marginTop.mobile}px`,
		"--desktop-margin-right": `${marginRight.desktop}px`,
		"--laptop-margin-right": `${marginRight.laptop}px`,
		"--tab-margin-right": `${marginRight.tab}px`,
		"--mobile-margin-right": `${marginRight.mobile}px`,
		"--desktop-margin-bottom": `${marginBottom.desktop}px`,
		"--laptop-margin-bottom": `${marginBottom.laptop}px`,
		"--tab-margin-bottom": `${marginBottom.tab}px`,
		"--mobile-margin-bottom": `${marginBottom.mobile}px`,
		"--desktop-margin-left": `${marginLeft.desktop}px`,
		"--laptop-margin-left": `${marginLeft.laptop}px`,
		"--tab-margin-left": `${marginLeft.tab}px`,
		"--mobile-margin-left": `${marginLeft.mobile}px`,
	};
}

/**
 * handle box shadow settings css variable
 * @param  {} boxShadow
 */
export function getBoroBazarShadowStyles(boxShadow) {
	const { horizontal, vertical, blur, spread, color } = boxShadow;
	const y = horizontal ? horizontal : 0;
	const x = vertical ? vertical : 0;
	const b = blur ? blur : 0;
	const s = spread ? spread : 0;
	const c = color ? color : "rgba(0, 0, 0, 1)";
	return {
		"--block-shadow": `${y}px ${x}px ${b}px ${s}px ${c}`,
	};
}
