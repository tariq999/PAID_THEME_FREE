import { useState } from "react";
const { RangeControl, PanelBody } = wp.components;
const { __ } = wp.i18n;
import Devices from "../devices";

export default ({
	paddingTop,
	paddingRight,
	paddingBottom,
	paddingLeft,
	setAttributes,
	panelTitle = "Spacing Settings",
	hidePanelIcon = false,
	initialOpen = false,
}) => {
	const [device, setDevice] = useState("desktop");
	const handleDevice = (device) => {
		setDevice(device);
	};

	return (
		<PanelBody
			title={__(panelTitle, "borobazar-helper")}
			icon={!hidePanelIcon ? "image-flip-horizontal" : ""}
			initialOpen={initialOpen}
		>
			<div className="borobazar-block-inline-wrap">
				<label>{__("Top", "borobazar-helper")}</label>
				<Devices
					device={device}
					handleDevice={(device) => handleDevice(device)}
				/>
			</div>
			<RangeControl
				value={paddingTop[device]}
				onChange={(value) =>
					setAttributes({
						paddingTop: {
							...paddingTop,
							[device]: value,
						},
					})
				}
				min={0}
				max={500}
				required
			/>
			<div className="borobazar-block-inline-wrap">
				<label>{__("Right", "borobazar-helper")}</label>
				<Devices
					device={device}
					handleDevice={(device) => handleDevice(device)}
				/>
			</div>
			<RangeControl
				value={paddingRight[device]}
				onChange={(value) =>
					setAttributes({
						paddingRight: {
							...paddingRight,
							[device]: value,
						},
					})
				}
				min={0}
				max={500}
				required
			/>
			<div className="borobazar-block-inline-wrap">
				<label>{__("Bottom", "borobazar-helper")}</label>
				<Devices
					device={device}
					handleDevice={(device) => handleDevice(device)}
				/>
			</div>
			<RangeControl
				value={paddingBottom[device]}
				onChange={(value) =>
					setAttributes({
						paddingBottom: {
							...paddingBottom,
							[device]: value,
						},
					})
				}
				min={0}
				max={500}
				required
			/>
			<div className="borobazar-block-inline-wrap">
				<label>{__("Left", "borobazar-helper")}</label>
				<Devices
					device={device}
					handleDevice={(device) => handleDevice(device)}
				/>
			</div>
			<RangeControl
				value={paddingLeft[device]}
				onChange={(value) =>
					setAttributes({
						paddingLeft: {
							...paddingLeft,
							[device]: value,
						},
					})
				}
				min={0}
				max={500}
				required
			/>
		</PanelBody>
	);
};
