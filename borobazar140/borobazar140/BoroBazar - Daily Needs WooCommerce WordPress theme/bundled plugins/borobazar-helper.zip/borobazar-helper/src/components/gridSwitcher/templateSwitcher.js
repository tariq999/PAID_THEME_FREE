export default ({ label, items, handleTemplate, template }) => {
	return (
		<div className="borobazar-template-switcher">
			<h2>{label}</h2>

			<div className="borobazar-template-switcher-items">
				{items.map((item, index) => {
					const preview = item.preview;
					const label = item.label;
					const value = item.value;
					return (
						<div
							className={`borobazar-template-switcher-item ${
								value == template ? "selected" : ""
							}`}
							key={index}
							onClick={() => handleTemplate(value)}
							template={template}
						>
							<div className="borobazar-template-switcher-preview">
								{preview}
							</div>
							<div className="borobazar-template-switcher-label">{label}</div>
						</div>
					);
				})}
			</div>
		</div>
	);
};
