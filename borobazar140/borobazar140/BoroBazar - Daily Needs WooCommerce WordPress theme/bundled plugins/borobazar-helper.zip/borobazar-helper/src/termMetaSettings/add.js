import React from "react";
import ReactDOM from "react-dom";

const TermMetaSettings = () => {
	let fields = [];
	try {
		fields = TERM_META_SETTINGS.fields;
	} catch (error) {}
	const ReuseForm = __REUSEFORM__;
	const getUpdatedFields = (data) => {
		document.getElementById("_borobazar_term_meta_data").value =
			JSON.stringify(data);
	};

	const reuseFormOption = {
		reuseFormId: "TermMetaSettings",
		fields,
		getUpdatedFields,
		errorMessages: {},
	};
	return <ReuseForm {...reuseFormOption} />;
};
const domElement = document.getElementById('borobazarTermMetabox');

domElement && ReactDOM.render(<TermMetaSettings />, domElement);
