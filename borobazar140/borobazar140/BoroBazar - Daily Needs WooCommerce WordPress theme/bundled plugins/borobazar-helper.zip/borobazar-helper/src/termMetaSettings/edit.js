import React from "react";
import ReactDOM from "react-dom";

const TermMetaEditSettings = () => {
	const fields = TERM_META_EDIT_SETTINGS && TERM_META_EDIT_SETTINGS.fields;
	let preValue = {};
	try {
		preValue = JSON.parse(TERM_META_EDIT_SETTINGS.preValue);
	} catch (error) {}
	const ReuseForm = __REUSEFORM__;

	const getUpdatedFields = (data) => {
		document.getElementById("_borobazar_term_meta_data").value =
			JSON.stringify(data);
	};

	const reuseFormOption = {
		reuseFormId: "TermMetaEditSettings",
		fields,
		getUpdatedFields,
		errorMessages: {},
		preValue,
	};
	return <ReuseForm {...reuseFormOption} />;
};
const domElement = document.getElementById('borobazarTermMetaboxEdit');

domElement && ReactDOM.render(<TermMetaEditSettings />, domElement);
