import React from "react";

export default (props) => {
	const { menus, changeMenu } = props;
	const menuArray = Object.keys(menus);
	menuArray.unshift("general");
	return (
		<div className={"borobazar-tab-menu-wrapper"}>
			{menuArray.map((menu) => {
				return (
					<button
						key={`menu_${menu}`}
						type="button"
						className={
							props.menuId === menu
								? "active borobazar-tab-menu-button"
								: "borobazar-tab-menu-button"
						}
						onClick={() => changeMenu(menu)}
					>
						{menu === "general" ? "General" : menus[menu]}
					</button>
				);
			})}
		</div>
	);
};
