import React, { useState, Fragment } from "react";
import ReactDOM from "react-dom";
import Menu from "./menu";
export const Settings = () => {
	let preValue = {};
	const fields = PAGE_SETTINGS && PAGE_SETTINGS.fields;
	const menus = PAGE_SETTINGS && PAGE_SETTINGS.menus;
	try {
		preValue = JSON.parse(PAGE_SETTINGS.preValue);
	} catch (error) {
		console.log(error);
	}

	const ReuseForm = __REUSEFORM__;

	const [menuId, setMenuId] = useState("general");
	const getUpdatedFields = (data) => {
		document.getElementById("_borobazar_page_settings").value =
			JSON.stringify(data);
	};
	const changeMenu = (newMenuId) => {
		setMenuId(newMenuId);
	};
	const reuseFormOption = {
		reuseFormId: "PageSettings",
		fields,
		getUpdatedFields,
		errorMessages: {},
		menuId,
		preValue,
	};
	return (
		<Fragment>
			<Menu
				fields={fields}
				changeMenu={changeMenu}
				menus={menus}
				menuId={menuId}
			/>
			<ReuseForm {...reuseFormOption} />
		</Fragment>
	);
};

const domElement = document.getElementById("borobazarPageSettings");
domElement &&
	ReactDOM.render(
		<Settings />,
		document.getElementById("borobazarPageSettings")
	);
