<?php

/**
 * Plugin Name: BoroBazar Theme Helper
 * Plugin URI: http://codecanyon.com/user/redqteam
 * Description: BoroBazar theme helper plugin is required the custom functionalities for the theme.
 * Author: redq
 * Author URI: http://redq.io.
 * Version: 1.4.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Tested up to: 6.3
 * Text Domain: borobazar-helper
 * Domain Path: /languages/
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt.
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

if (!defined('BOROBAZAR_HELPER_PLUGIN_FILE')) {
    define('BOROBAZAR_HELPER_PLUGIN_FILE', __FILE__);
}

use BoroBazarHelper\Classes;

/**
 * Main BoroBazarHelper Class for the plugin.
 *
 * @class BoroBazarHelper
 */
final class BoroBazarHelper
{
    /**
     * version.
     *
     * @var string
     */
    public $version = '1.4.0';

    /**
     * init a singleton instance.
     *
     * @return \BoroBazarHelper
     */
    public static function init()
    {
        static $instance = false;

        if (!$instance) {
            $instance = new self();
        }

        return $instance;
    }

    /**
     * class constructor.
     *
     * @return void
     */
    private function __construct()
    {
        $this->declareConstants();
        $this->classLoader();
        $this->initHooks();
    }

    /**
     * declareConstants.
     */
    public function declareConstants()
    {
        define('BOROBAZAR_HELPER_ABSPATH', dirname(BOROBAZAR_HELPER_PLUGIN_FILE) . '/');
        define('BOROBAZAR_HELPER_VERSION', $this->version);
        define('BOROBAZAR_HELPER_DIR', untrailingslashit(plugin_dir_path(__FILE__)));
        define('BOROBAZAR_HELPER_URL', untrailingslashit(plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__))));
        define('BOROBAZAR_HELPER_REQUIRED_PHP_VERSION', 7.4);
        define('BOROBAZAR_HELPER_REQUIRED_WP_VERSION', 5.9);
        define('BOROBAZAR_HELPER_ADMIN_VIEWS', BOROBAZAR_HELPER_DIR . '/admin-templates/');
        define('BOROBAZAR_HELPER_ASSETS', BOROBAZAR_HELPER_URL . '/assets/');
        define('BOROBAZAR_HELPER_DIST', BOROBAZAR_HELPER_URL . '/dist/');
        define('BOROBAZAR_HELPER_LOCAL_SETTINGS_TEMPLATE_PATH', BOROBAZAR_HELPER_DIR . '/includes/settings/local/');
        define('BOROBAZAR_HELPER_TEMPLATE_PATH', BOROBAZAR_HELPER_DIR . '/templates/');
        define('BOROBAZAR_HELPER_SETTINGS_TEMPLATE_PATH', BOROBAZAR_HELPER_DIR . '/includes/builder/settings-templates/');
        define('BOROBAZAR_HELPER_SHORTCODE_PATH', BOROBAZAR_HELPER_DIR . '/includes/shortcodes/');
        define('BOROBAZAR_HELPER_WOO_QUICK_CART', BOROBAZAR_HELPER_URL . '/includes/woo-quick-cart/');
    }

    /**
     * classLoader.
     */
    public function classLoader()
    {
        require_once BOROBAZAR_HELPER_DIR . DIRECTORY_SEPARATOR . 'vendor/autoload.php';
        require_once BOROBAZAR_HELPER_DIR . DIRECTORY_SEPARATOR . 'includes/woo-quick-cart/functions.php';
        require_once BOROBAZAR_HELPER_DIR . DIRECTORY_SEPARATOR . 'includes/Utils.php';
        new Classes();
    }

    /**
     * initHooks.
     */
    public function initHooks()
    {
        add_action('admin_init', [$this, 'checkPHPVersion']);
        add_action('init', [$this, 'ifIncludeTemplateFunctions']);
        if (!self::compatibleVersion()) {
            return;
        }
    }

    /**
     * ifIncludeTemplateFunctions.
     */
    public function ifIncludeTemplateFunctions()
    {
        include_once BOROBAZAR_HELPER_ABSPATH . 'includes/TemplateHooks.php';
        include_once BOROBAZAR_HELPER_ABSPATH . 'includes/TemplateFunctions.php';
    }

    /**
     * checkPHPVersion.
     */
    public function checkPHPVersion()
    {
        if (!self::compatibleVersion()) {
            if (is_plugin_active(plugin_basename(__FILE__))) {
                deactivate_plugins(plugin_basename(__FILE__));
                add_action('admin_notices', [$this, 'disableNotice']);
                if (isset($_GET['activate'])) {
                    unset($_GET['activate']);
                }
            }
        }
    }

    /**
     * compatibleVersion.
     *
     * @return bool
     */
    public static function compatibleVersion()
    {
        if (phpversion() < BOROBAZAR_HELPER_REQUIRED_PHP_VERSION || $GLOBALS['wp_version'] < BOROBAZAR_HELPER_REQUIRED_WP_VERSION) {
            return false;
        }

        return true;
    }

    /**
     * disableNotice.
     */
    public function disableNotice()
    {
        if (phpversion() < BOROBAZAR_HELPER_REQUIRED_PHP_VERSION) { ?>
            <div class="notice notice-error is-dismissible">
                <p>
                    <?php esc_html_e('Can not Activate BoroBazar Helper! BoroBazar Helper requires PHP ' . BOROBAZAR_HELPER_REQUIRED_PHP_VERSION . ' or higher!', 'borobazar-helper'); ?>
                </p>
            </div>
        <?php
        }
        if ($GLOBALS['wp_version'] < BOROBAZAR_HELPER_REQUIRED_WP_VERSION) { ?>
            <div class="notice notice-error is-dismissible">
                <p>
                    <?php esc_html_e('Can not Activate BoroBazar Helper! BoroBazar Helper requires Wordpress ' . BOROBAZAR_HELPER_REQUIRED_WP_VERSION . ' or higher!', 'borobazar-helper'); ?>
                </p>
            </div>
        <?php
        }

        if (!class_exists('WooCommerce')) { ?>
            <div class="notice notice-error is-dismissible">
                <p><?php esc_html_e('Can not Activate BoroBazarHelper! Please Activate WooCommerce First.', 'borobazar-helper'); ?>
                </p>
            </div>
        <?php } ?>
<?php
    }

    /**
     * templatePath.
     */
    public function templatePath()
    {
        return apply_filters('BOROBAZAR_HELPER_TEMPLATE_PATH', 'borobazarhelper/');
    }

    /**
     * pluginPath.
     */
    public function pluginPath()
    {
        return untrailingslashit(plugin_dir_path(__FILE__));
    }
}

/**
 * initialize the plugin works.
 *
 * @return \BoroBazarHelper
 */
function borobazarhelper()
{
    return BoroBazarHelper::init();
}

// fire up the plugin
$GLOBALS['borobazar-helper'] = borobazarhelper();
