<?php

use BoroBazarHelper\Traits\StyleScriptLoader;

StyleScriptLoader::enqueueScript('borobazar-category-sirius');

$allowedHTML = wp_kses_allowed_html('post');
$category_name = '';
if (!empty($category)) {
    $is_image = empty($image_url) ? 'fallback-image' : 'has-image';
    $category_name = $category->name;
}

?>

<a class="borobazar-category-sirius group block no-underline box-border mouse-move-effect" href="<?php echo esc_url($term_url); ?>">
    <span class="borobazar-category-sirius-thumb borobazar-image-fade-in bg-lighter block relative w-44 max-w-full rounded-full overflow-hidden mx-auto mb-4 <?php echo esc_attr($is_image); ?>">
        <img class="w-full h-auto block opacity-0 transition-opacity duration-200" width="176" height="176" src="<?php echo esc_url(BOROBAZAR_HELPER_ASSETS . 'global/images/shadow-placeholder.svg'); ?>" alt="<?php echo esc_attr__('Shadow placeholder', 'borobazar-helper'); ?>" aria-hidden="true" />
        <span class="flex items-center justify-center absolute inset-0 w-full h-full z-1">
            <?php if ($image_url) { ?>
                <img class="block max-w-full max-h-full opacity-0 mouse-move-effect-el" width="176" height="176" src="<?php echo esc_url($image_url[0]); ?>" alt="<?php echo esc_attr__($category_name, 'borobazar-helper'); ?>">
            <?php } else { ?>
                <svg class="block w-12" x="0px" y="0px" viewBox="0 0 60 46" width="48" height="48">
                    <g>
                        <path d="M53.335,46H6.725c-3.691,0-6.695-3.003-6.695-6.695V6.695C0.03,3.004,3.033,0,6.725,0h46.61   c3.692,0,6.695,3.003,6.695,6.695v32.61C60.03,42.997,57.027,46,53.335,46z M6.725,2C4.137,2,2.03,4.106,2.03,6.695v32.61   C2.03,41.894,4.136,44,6.725,44h46.61c2.589,0,4.695-2.106,4.695-4.695V6.695C58.03,4.106,55.924,2,53.335,2L6.725,2L6.725,2z" />
                        <path d="M39.03,22c-3.308,0-6-2.691-6-6s2.692-6,6-6c3.309,0,6,2.691,6,6S42.338,22,39.03,22z M39.03,12c-2.206,0-4,1.794-4,4   s1.794,4,4,4s4-1.794,4-4S41.235,12,39.03,12z" />
                        <path d="M53.335,46H30.474c-0.394,0-0.751-0.231-0.912-0.59s-0.097-0.78,0.165-1.074l15.556-17.5c0.379-0.427,1.115-0.427,1.495,0   l12.521,14.086c0.259,0.292,0.325,0.708,0.168,1.066C58.4,44.425,55.993,46,53.335,46z M32.701,44h20.634   c1.654,0,3.17-0.871,4.013-2.262L46.03,29.005L32.701,44z" />
                        <path d="M30.474,46H6.724c-3.691,0-6.695-3.003-6.695-6.695v-6.18c0-0.245,0.09-0.481,0.253-0.665l17-19.125   c0.379-0.427,1.115-0.427,1.495,0l20,22.5c0.337,0.379,0.337,0.95,0,1.329l-7.556,8.5C31.032,45.878,30.76,46,30.474,46z    M2.03,33.505v5.8C2.03,41.894,4.136,44,6.725,44h23.301l6.667-7.5L18.03,15.505L2.03,33.505z" />
                    </g>
                </svg>
            <?php } ?>
        </span>
    </span>
    <span class="borobazar-category-sirius-title text-main text-sm sm:text-md lg:text-base text-center block">
        <?php echo wp_kses($category_name, $allowedHTML); ?>
    </span>
</a>