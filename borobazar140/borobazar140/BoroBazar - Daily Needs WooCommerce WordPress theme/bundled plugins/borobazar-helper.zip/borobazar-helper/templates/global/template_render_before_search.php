<?php
$defaultSortBy = '';
if (isset($_GET['order_by']) && !empty($_GET['order_by'])) {
    $defaultSortBy = $_GET['order_by'];
}
?>

<div class="borobazar-product-search <?php echo esc_attr($layoutClass . ' ' . $customClass); ?>" style='background-color: <?php echo esc_attr($attributes['backgroundColor']); ?>'>

    <form id="borobazar-product-filter-form" action="#">
        <input type="hidden" class="hidden" name="action" value="borobazar_helper_ajax" />
        <input type="hidden" class="hidden" name="action_type" value="search" />

        <input type="hidden" class="hidden product-order-by" name="order_by" value="<?php echo esc_attr($defaultSortBy); ?>" />