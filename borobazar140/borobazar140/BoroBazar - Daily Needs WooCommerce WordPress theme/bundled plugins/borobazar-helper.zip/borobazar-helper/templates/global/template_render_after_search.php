<div class="reset-search-page">
    <a href="#" class="reset-form"><?php echo esc_html__('Reset', "borobazar-helper"); ?></a>
</div>
</form>

</div>