<?php
$allowedHTML = wp_kses_allowed_html('post');
$width = $height = '';
$url = isset($slide['url']) ? $slide['url'] : '';
$image = isset($slide['image']) ? $slide['image'] : '';
$newTab = isset($slide['opensInNewTab']) ? $slide['opensInNewTab'] : '';
$title = isset($slide['title']) ? $slide['title'] : '';
$description = isset($slide['description']) ? $slide['description'] : '';
$backgroundColor = isset($slide['backgroundColor']) ? $slide['backgroundColor'] : '';
$titleColor = isset($slide['titleColor']) ? $slide['titleColor'] : '';
$descriptionColor = isset($slide['descriptionColor']) ? $slide['descriptionColor'] : '';
?>

<div class="mouse-move-effect relative overflow-hidden flex" style="background-color: <?php echo esc_attr($backgroundColor) ?>">
    <div class="mouse-move-effect-scale borobazar-image-fade-in without-image-loader w-36 2xl:w-28 3xl:w-32 4xl:w-44 shrink-0 pr-4">
        <?php if ($image) { ?>
            <img class="mouse-move-effect-el block w-full h-full object-contain object-center opacity-0" width="176" height="176" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>" style="--d: 10">
        <?php } ?>
    </div>
    <div class="grow flex flex-col justify-center py-5 3xl:py-6 pr-4 3xl:pr-5 4xl:pr-6">
        <h3 class="text-lg 2xl:text-base 3xl:text-lg 4xl:text-xl font-bold mb-2 mt-0" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h3>
        <div class="text-sm 4xl:text-md" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?></div>
    </div>
</div>