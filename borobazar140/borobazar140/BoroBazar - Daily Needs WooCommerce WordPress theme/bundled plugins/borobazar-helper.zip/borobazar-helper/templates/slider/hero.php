<?php

$allowedHTML = wp_kses_allowed_html('post');
$url = isset($slide['url']) ? $slide['url'] : '';
$image = isset($slide['image']) ? $slide['image'] : '';
$newTab = isset($slide['opensInNewTab']) ? $slide['opensInNewTab'] : '';
$padding = isset($slide['paddingTop']) ? getBoroBazarPaddingStyles($slide) : '';
$backgroundSize = isset($slide['backgroundSize']) ? $slide['backgroundSize'] : '';
$fixedBackground = isset($slide['fixedBackground']) && $slide['fixedBackground'] ? 'fixed'  : 'unset';
$backgroundRepeat = isset($slide['backgroundRepeat']) && $slide['backgroundRepeat'] ? 'repeat' : 'no-repeat';
$backgroundPosition = isset($slide['backgroundPosition']) ? $slide['backgroundPosition'] : '';
$textAlign = isset($slide['textAlign']) ? $slide['textAlign'] : '';
$minHeight = isset($slide['height']) ? $slide['height'] : '';
$overlay = isset($slide['overlay']) ? $slide['overlay'] : '';
$overlayOpacity = isset($slide['overlayOpacity']) ? $slide['overlayOpacity'] : '';
$contentPosition = isset($slide['contentPosition']) ? $slide['contentPosition'] : '';
$title = isset($slide['title']) ? $slide['title'] : '';
$description = isset($slide['description']) ? $slide['description'] : '';
$button = isset($slide['button']) ? $slide['button'] : '';
$buttonColor = isset($slide['buttonColor']) ? $slide['buttonColor'] : '';
$buttonTextColor = isset($slide['buttonTextColor']) ? $slide['buttonTextColor'] : '';
$buttonHoverColor = isset($slide['buttonHoverColor']) ? $slide['buttonHoverColor'] : '';
$buttonHoverTextColor = isset($slide['buttonHoverTextColor']) ? $slide['buttonHoverTextColor'] : '';
$titleColor = isset($slide['titleColor']) ? $slide['titleColor'] : '';
$descriptionColor = isset($slide['descriptionColor']) ? $slide['descriptionColor'] : '';

$styles = '';
$styles .= 'background-image:' . 'url(' . $image . ');';
$styles .= 'background-size:' . $backgroundSize . ';';
$styles .= 'background-attachment:' . $fixedBackground . ';';
$styles .= 'background-repeat:' . $backgroundRepeat . ';';
$styles .= 'background-position:' . $backgroundPosition . ';';
$styles .= 'text-align:' . $textAlign . ';';
$styles .= '--desktop-min-height:' . $minHeight['desktop'] . 'px' . ';';
$styles .= '--laptop-min-height:' . $minHeight['laptop'] . 'px' . ';';
$styles .= '--tab-min-height:' . $minHeight['tab'] . 'px' . ';';
$styles .= '--mobile-min-height:' . $minHeight['mobile'] . 'px' . ';';

$buttonStyles = '';
$buttonStyles .= '--button-color:' . $buttonColor . ';';
$buttonStyles .= '--button-text-color:' . $buttonTextColor . ';';
$buttonStyles .= '--hover-color:' . $buttonHoverColor . ';';
$buttonStyles .= '--hover-text-color:' . $buttonHoverTextColor . ';';

$contentPositionClasses = '';
switch ($contentPosition) {
    case "top left":
        $contentPositionClasses = "items-start justify-start";
        break;
    case "top center":
        $contentPositionClasses = "items-start justify-center";
        break;
    case "top right":
        $contentPositionClasses = "items-start justify-end";
        break;
    case "center left":
        $contentPositionClasses = "items-center justify-start";
        break;
    case "center center":
        $contentPositionClasses = "items-center justify-center";
        break;
    case "center right":
        $contentPositionClasses = "items-center justify-end";
        break;
    case "bottom left":
        $contentPositionClasses = "items-end justify-start";
        break;
    case "bottom center":
        $contentPositionClasses = "items-end justify-center";
        break;
    case "bottom right":
        $contentPositionClasses = "items-end justify-end";
        break;
    default:
        $contentPositionClasses = "items-start justify-start";
        break;
}

?>

<div class="borobazar-slider-slide relative" style="<?php echo esc_attr($padding) ?>">
    <div class="borobazar-block-spacing-wrapper borobazar-min-height-wrapper relative flex <?php echo esc_attr($contentPositionClasses) ?>" style="<?php echo esc_attr($styles) ?>">
        <div class="absolute w-full h-full inset-0" style="background: <?php echo esc_attr($overlay) ?>; opacity: <?php echo esc_attr($overlayOpacity / 100) ?>"></div>
        <div class="relative">
            <?php if ($title) { ?>
                <h2 class="text-3xl sm:text-4xl xl:text-5xl leading-snug sm:leading-snug xl:leading-snug font-extrabold mt-0 mb-3" style="color: <?php echo esc_attr($titleColor) ?>">
                    <?php echo wp_kses($title, $allowedHTML); ?>
                </h2>
            <?php } ?>
            <?php if ($description) { ?>
                <div class="text-md sm:text-base xl:text-lg leading-loose sm:leading-loose xl:leading-loose mb-6 md:mb-8 mt-0" style="color: <?php echo esc_attr($descriptionColor) ?>">
                    <?php echo wp_kses($description, $allowedHTML); ?>
                </div>
            <?php } ?>
            <?php if ($newTab) { ?>
                <a class="no-underline box-border" href="<?php echo esc_url($url) ?>" target="_blank" rel="noopener noreferrer">
                    <span class="borobazar-slider-button inline-flex text-sm font-bold min-h-11 py-3 px-5 rounded cursor-pointer" style="<?php echo esc_attr($buttonStyles) ?>">
                        <?php echo wp_kses($button, $allowedHTML); ?>
                    </span>
                </a>
            <?php } else { ?>
                <a class="no-underline box-border" href="<?php echo esc_url($url) ?>" aria-label="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
                    <span class="borobazar-slider-button inline-flex text-xs sm:text-sm font-bold sm:min-h-11 py-2.5 sm:py-3 px-4 sm:px-5 rounded cursor-pointer" style="<?php echo esc_attr($buttonStyles) ?>">
                        <?php echo wp_kses($button, $allowedHTML); ?>
                    </span>
                </a>
            <?php } ?>
        </div>
    </div>
</div>