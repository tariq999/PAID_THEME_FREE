<?php
$allowedHTML = wp_kses_allowed_html('post');
$url = isset($slide['url']) ? $slide['url'] : '';
$image = isset($slide['image']) ? $slide['image'] : '';
$newTab = isset($slide['opensInNewTab']) ? $slide['opensInNewTab'] : '';
$title = isset($slide['title']) ? $slide['title'] : '';
$description = isset($slide['description']) ? $slide['description'] : '';
$backgroundColor = isset($slide['backgroundColor']) ? $slide['backgroundColor'] : '';
$titleColor = isset($slide['titleColor']) ? $slide['titleColor'] : '';
$descriptionColor = isset($slide['descriptionColor']) ? $slide['descriptionColor'] : '';
?>

<?php if ($url) { ?>
    <?php if ($newTab) { ?>
        <a class="no-underline box-border" href="<?php echo esc_url($url) ?>" target="_blank" rel="noopener noreferrer">
            < div class="relative overflow-hidden flex items-center p-4 lg:p-5 3xl:p-6 4xl:p-7" style="background-color: <?php echo esc_attr($backgroundColor) ?>">
                <div class="borobazar-image-fade-in without-image-loader w-18 sm:w-20 3xl:w-22 4xl:w-24 h-18 sm:h-20 3xl:h-22 4xl:h-24 rounded-full shadow-slim overflow-hidden flex items-center justify-center bg-white p-4 sm:p-5 shrink-0 mr-4 3xl:mr-5">
                    <?php if ($image) { ?>
                        <img class="block max-w-full h-auto mx-auto opacity-0 transition-opacity duration-200" width="96" height="96" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
                    <?php } ?>
                </div>
                <div class="grow flex flex-col justify-center ">
                    <h3 class="text-sm sm:text-md lg:text-base 4xl:text-lg leading-relaxed 2xl:leading-relaxed 3xl:leading-relaxed font-bold mb-3 mt-0" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h3>
                    <div class="text-xs 4xl:text-sm font-semibold" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?>
                        <svg class="borobazar-rtl-rotate ml-2" width="8" height="8" viewBox="0 0 8 8" fill="none">
                            <path d="M6.56145 3.25713L2.11776 0.214996C1.91255 0.0744069 1.70577 0 1.53391 0C1.20164 0 0.996094 0.266673 0.996094 0.71305L0.996094 7.28799C0.996094 7.73385 1.20138 8 1.53287 8C1.705 8 1.90847 7.92553 2.11414 7.78455L6.55989 4.74248C6.8458 4.54652 7.00413 4.28283 7.00413 3.99964C7.0042 3.71665 6.84768 3.45302 6.56145 3.25713Z" fill="#8C969F" />
                        </svg>
                    </div>
                </div>
            </>
        </a>
    <?php } else { ?>
        <a class="no-underline box-border" href="<?php echo esc_url($url) ?>">
            <div class="relative overflow-hidden flex items-center p-4 lg:p-5 3xl:p-6 4xl:p-7" style="background-color: <?php echo esc_attr($backgroundColor) ?>">
                <div class="borobazar-image-fade-in without-image-loader w-18 sm:w-20 3xl:w-22 4xl:w-24 h-18 sm:h-20 3xl:h-22 4xl:h-24 rounded-full shadow-slim overflow-hidden flex items-center justify-center bg-white p-4 sm:p-5 shrink-0 mr-4 3xl:mr-5">
                    <?php if ($image) { ?>
                        <img class=" block max-w-full h-auto mx-auto opacity-0 transition-opacity duration-200" width="96" height="96" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
                    <?php } ?>
                </div>
                <div class="grow flex flex-col justify-center ">
                    <h3 class="text-sm sm:text-md lg:text-base 4xl:text-lg leading-relaxed 2xl:leading-relaxed 3xl:leading-relaxed font-bold mb-3 mt-0" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h3>
                    <div class="text-xs 4xl:text-sm font-semibold" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?>
                        <svg class="borobazar-rtl-rotate ml-2" width="8" height="8" viewBox="0 0 8 8" fill="none">
                            <path d="M6.56145 3.25713L2.11776 0.214996C1.91255 0.0744069 1.70577 0 1.53391 0C1.20164 0 0.996094 0.266673 0.996094 0.71305L0.996094 7.28799C0.996094 7.73385 1.20138 8 1.53287 8C1.705 8 1.90847 7.92553 2.11414 7.78455L6.55989 4.74248C6.8458 4.54652 7.00413 4.28283 7.00413 3.99964C7.0042 3.71665 6.84768 3.45302 6.56145 3.25713Z" fill="#8C969F" />
                        </svg>
                    </div>
                </div>
            </div>
        </a>
    <?php } ?>
<?php } else { ?>
    <div class="relative box-border overflow-hidden flex items-center p-4 lg:p-5 3xl:p-6 4xl:p-7" style="background-color: <?php echo esc_attr($backgroundColor) ?>">
        <div class="borobazar-image-fade-in without-image-loader w-18 sm:w-20 3xl:w-22 4xl:w-24 h-18 sm:h-20 3xl:h-22 4xl:h-24 rounded-full shadow-slim overflow-hidden flex items-center justify-center bg-white p-4 sm:p-5 shrink-0 mr-4 3xl:mr-5">
            <?php if ($image) { ?>
                <img class="block max-w-full h-auto mx-auto opacity-0 transition-opacity duration-200" width="96" height="96" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
            <?php } ?>
        </div>
        <div class="grow flex flex-col justify-center">
            <h3 class="text-sm sm:text-md lg:text-base 4xl:text-lg leading-relaxed 2xl:leading-relaxed 3xl:leading-relaxed font-bold mb-3 mt-0" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h3>
            <div class="text-xs 4xl:text-sm font-semibold" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?>
                <svg width="8" height="8" viewBox="0 0 8 8" fill="none" class="ml-2">
                    <path d="M6.56145 3.25713L2.11776 0.214996C1.91255 0.0744069 1.70577 0 1.53391 0C1.20164 0 0.996094 0.266673 0.996094 0.71305L0.996094 7.28799C0.996094 7.73385 1.20138 8 1.53287 8C1.705 8 1.90847 7.92553 2.11414 7.78455L6.55989 4.74248C6.8458 4.54652 7.00413 4.28283 7.00413 3.99964C7.0042 3.71665 6.84768 3.45302 6.56145 3.25713Z" fill="#8C969F" />
                </svg>
            </div>
        </div>
    </div>
<?php } ?>