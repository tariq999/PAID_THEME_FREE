<?php
$width = $height = '';
$url = isset($slide['url']) ? $slide['url'] : '';
$image = isset($slide['image']) ? $slide['image'] : '';
$newTab = isset($slide['opensInNewTab']) ? $slide['opensInNewTab'] : '';

if (!empty($image)) {
    if (attachment_url_to_postid($image) === 0) {
        $width = 1840;
        $height = 500;
    } else {
        $image_id = attachment_url_to_postid($image);
        $image_attributes = wp_get_attachment_image_src($image_id, "full");
        $width = !empty($image_attributes) ? $image_attributes['1'] : 1840;
        $height = !empty($image_attributes) ? $image_attributes['2'] : 500;
    }
}

?>

<div class="borobazar-slider-slide relative">
    <?php if ($url) { ?>
        <?php if ($newTab) { ?>
            <a class="inline-flex items-center borobazar-image-fade-in" href="<?php echo esc_url($url) ?>" aria-label="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>" target="_blank" rel="noopener noreferrer">
                <img class="opacity-0 transition-opacity duration-200" width="<?php echo esc_attr($width); ?>" height="<?php echo esc_attr($height); ?>" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
            </a>
        <?php } else { ?>
            <a class="inline-flex items-center borobazar-image-fade-in" href="<?php echo esc_url($url) ?>" aria-label="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
                <img class="opacity-0 transition-opacity duration-200" width="<?php echo esc_attr($width); ?>" height="<?php echo esc_attr($height); ?>" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
            </a>
        <?php } ?>
    <?php } else { ?>
        <div class="inline-flex items-center borobazar-image-fade-in">
            <img class="opacity-0 transition-opacity duration-200" width="<?php echo esc_attr($width); ?>" height="<?php echo esc_attr($height); ?>" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
        </div>
    <?php } ?>
</div>