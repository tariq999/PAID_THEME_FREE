<?php
$allowedHTML = wp_kses_allowed_html('post');
$url = isset($slide['url']) ? $slide['url'] : '';
$image = isset($slide['image']) ? $slide['image'] : '';
$newTab = isset($slide['opensInNewTab']) ? $slide['opensInNewTab'] : '';
$title = isset($slide['title']) ? $slide['title'] : '';
$description = isset($slide['description']) ? $slide['description'] : '';
$backgroundColor = isset($slide['backgroundColor']) ? $slide['backgroundColor'] : '';
$titleColor = isset($slide['titleColor']) ? $slide['titleColor'] : '';
$descriptionColor = isset($slide['descriptionColor']) ? $slide['descriptionColor'] : '';
?>

<?php if ($url) { ?>
    <?php if ($newTab) { ?>
        <a class="no-underline box-border" href="<?php echo esc_url($url) ?>" target="_blank" rel="noopener noreferrer">
            <div class="relative box-border overflow-hidden flex justify-center gap-5 items-center p-4 lg:p-5 3xl:p-6 4xl:p-7" style="background-color: <?php echo esc_attr($backgroundColor) ?>">

                <div class="flex flex-col">
                    <h3 class="text-sm sm:text-md lg:text-base 4xl:text-lg leading-relaxed 2xl:leading-relaxed 3xl:leading-relaxed font-bold mb-3 mt-0" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h3>
                    <div class="text-xs 4xl:text-sm font-semibold" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?>
                    </div>
                </div>
                <div class="borobazar-image-fade-in without-image-loader w-18 sm:w-20 3xl:w-22 4xl:w-24 h-18 sm:h-20 3xl:h-22 4xl:h-24 rounded-full shadow-slim overflow-hidden flex items-center bg-white p-4 sm:p-5 shrink-0">
                    <?php if ($image) { ?>
                        <img class="block max-w-full h-auto mx-auto opacity-0 transition-opacity duration-200" width="96" height="96" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
                    <?php } ?>
                </div>
            </div>
        </a>
    <?php } else { ?>
        <a class="no-underline box-border" href="<?php echo esc_url($url) ?>">
            <div class="relative box-border overflow-hidden flex justify-center gap-5 items-center p-4 lg:p-5 3xl:p-6 4xl:p-7" style="background-color: <?php echo esc_attr($backgroundColor) ?>">

                <div class="flex flex-col">
                    <h3 class="text-sm sm:text-md lg:text-base 4xl:text-lg leading-relaxed 2xl:leading-relaxed 3xl:leading-relaxed font-bold mb-3 mt-0" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h3>
                    <div class="text-xs 4xl:text-sm font-semibold" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?>
                    </div>
                </div>
                <div class="borobazar-image-fade-in without-image-loader w-18 sm:w-20 3xl:w-22 4xl:w-24 h-18 sm:h-20 3xl:h-22 4xl:h-24 rounded-full shadow-slim overflow-hidden flex items-center bg-white p-4 sm:p-5 shrink-0">
                    <?php if ($image) { ?>
                        <img class="block max-w-full h-auto mx-auto opacity-0 transition-opacity duration-200" width="96" height="96" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
                    <?php } ?>
                </div>
            </div>
        </a>
    <?php } ?>
<?php } else { ?>
    <div class="relative box-border overflow-hidden flex justify-center gap-5 items-center p-4 lg:p-5 3xl:p-6 4xl:p-7" style="background-color: <?php echo esc_attr($backgroundColor) ?>">

        <div class="flex flex-col">
            <h3 class="text-sm sm:text-md lg:text-base 4xl:text-lg leading-relaxed 2xl:leading-relaxed 3xl:leading-relaxed font-bold mb-3 mt-0" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo wp_kses($title, $allowedHTML); ?></h3>
            <div class="text-xs 4xl:text-sm font-semibold" style="color: <?php echo esc_attr($descriptionColor) ?>"><?php echo wp_kses($description, $allowedHTML); ?>
            </div>
        </div>
        <div class="borobazar-image-fade-in without-image-loader w-18 sm:w-20 3xl:w-22 4xl:w-24 h-18 sm:h-20 3xl:h-22 4xl:h-24 rounded-full shadow-slim overflow-hidden flex items-center bg-white p-4 sm:p-5 shrink-0">
            <?php if ($image) { ?>
                <img class="block max-w-full h-auto mx-auto opacity-0 transition-opacity duration-200" width="96" height="96" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_attr__("Slide image", "borobazar-helper") ?>">
            <?php } ?>
        </div>
    </div>
<?php } ?>