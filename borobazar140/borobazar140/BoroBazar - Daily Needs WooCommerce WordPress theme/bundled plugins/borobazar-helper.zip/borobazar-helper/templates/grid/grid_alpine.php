<script type="text/html" id="borobazarGridTemplate">
<% let postArray = []; %>
<?php if ($showHiddenProduct === 'on') { ?>
<%
            postArray = listing.filter(function( obj ) {
                return obj.product_visibility !== 'hidden';
            });
        %>
<?php } else { ?>
<% postArray = listing %>
<?php } ?>

<div
    class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 3xl:grid-cols-5 4xl:grid-cols-6 gap-3 md:gap-4 2xl:gap-5">
    <% _.each(postArray, function(list, index ) { %>
    <%
        let id,
            thumbnail,
            thumbnail_size,
            title,
            price,
            regular_price,
            sale_price,
            permalink,
            permalink_with_search,
            product_unit,
            product_unit_label,
            on_sale,
            is_in_stock,
            product_type,
            rate,
            position,
            symbol,
            price_markup,
            regular_price_markup,
            price_html = '',
            discount_percentage,
            diff;

        id = list ? list.id : '';
        thumbnail = list ? list.thumbnail : '';
        thumbnail_size = list ? list.thumbnail_size : '';
        title = list ? list.title : '';
        permalink = list ? list.permalink : '';
        permalink_with_search = typeof searchQueryUrl === 'undefined' || _.isEmpty(searchQueryUrl) ? permalink : permalink + searchQueryUrl;
        product_unit = list ? list.product_unit : '';
        product_unit_label = list ? list.product_unit_label : '';
        on_sale = list ? list.on_sale : false;
        is_in_stock = list ? list.is_in_stock : '';
        product_type = list ? list.product_type : '';
        productGallery = list ? list.product_gallery : '';
        price = list ? list._price : 0;
        regular_price = list ? list._regular_price : 0;
        price_html = list ? list.price_html : '';

        if(product_type === 'simple'){
           regular_price = list._regular_price;
           sale_price = list._sale_price;
           diff=regular_price-sale_price;
           discount_percentage=Math.round((diff*100)/regular_price);
        }
        
        %>

    <div
        class="borobazar-alpine-product-card borobazar-product-<%= list.post_id %> shadow-product rounded bg-white overflow-hidden transition-all hover:shadow-product-hover">
        <div class="borobazar-alpine-product-card-thumb relative h-40 sm:h-48">
            <a href="<%=permalink_with_search%>"
                class="borobazar-image-fade-in flex items-center justify-center w-full h-full" aria-label="<%=title%>">
                <img loading="lazy"
                    class="max-w-full max-h-full w-auto h-auto block opacity-0 transition-opacity duration-200"
                    src="<%=thumbnail%>" width="<%=thumbnail_size[1]%>" height="<%=thumbnail_size[2]%>"
                    alt="<%=title%>">

                <% if (productGallery.length) {
                    var galleryImages = productGallery.slice(0,1);
                    _.each(galleryImages, function(image, index ) {
                     %>
                <img loading="lazy" class="thumb-1 opacity-0 transition-opacity duration-200" src="<%=image%>"
                    width="<%=thumbnail_size[1]%>" height="<%=thumbnail_size[2]%>" alt="<%=title%>">
                <% }) %>
                <% } %>

                <% if(!is_in_stock){ %>
                <span
                    class="product-badge text-xs text-white font-bold bg-error rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1"><?php echo esc_html__('Out Of Stock', 'borobazar-helper'); ?></span>
                <% } %>
                <% if (on_sale) { %>
                <% if (product_type === 'simple') { %>
                <span
                    class="product-badge text-xs text-white font-bold bg-brand rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                    <?php echo esc_html__('Save ', 'borobazar-helper'); ?><%=discount_percentage%><?php echo esc_html('%'); ?>
                </span>
                <% } %>
                <% if (product_type === 'variable') { %>
                <span
                    class="product-badge text-xs text-white font-bold bg-brand rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                    <?php echo esc_html__('On Sale ', 'borobazar-helper'); ?>
                </span>
                <% } %>

                <% } %>
            </a>

            <% if(is_in_stock){ %>
            <% if(product_type === 'simple'){ %>

            <!-- add to cart  -->
            <a href="#"
                class=" add-to-cart absolute flex items-center justify-center w-9 h-9 rounded-full bottom-3 right-3 sm:right-3.5 bg-brand z-1 text-white no-underline transition-all hover:text-white hover:bg-brand-hover focus:text-white product_type_simple  borobazar-update-qty borobazar-add-to-cart-<%= list.post_id %>"
                data-product_id="<%= list.post_id %>"
                aria-label="<?php echo esc_attr__('Add to cart', 'borobazar-helper'); ?>">
                <svg width="15" height="15" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M15.2 7.2H8.80005V0.799951C8.80005 0.358447 8.4416 0 7.99995 0C7.55845 0 7.2 0.358447 7.2 0.799951V7.2H0.799951C0.358447 7.2 0 7.55845 0 7.99995C0 8.4416 0.358447 8.80005 0.799951 8.80005H7.2V15.2C7.2 15.6416 7.55845 16 7.99995 16C8.4416 16 8.80005 15.6416 8.80005 15.2V8.80005H15.2C15.6416 8.80005 16 8.4416 16 7.99995C16 7.55845 15.6416 7.2 15.2 7.2Z"
                        fill="currentColor" stroke="white" stroke-width="0.5" />
                </svg>
            </a>

            <!-- counter -->
            <div
                class="flex justify-between p-0.75 absolute left-1/2 bottom-3 -translate-x-1/2 w-32 sm:w-36 4xl:w-40 h-9 sm:h-9.5 bg-white rounded-3xl z-1 shadow-counter borobazar-qty-button borobazar-qty-button-<%= list.post_id %>">
                <span
                    class="flex items-center justify-center w-11 sm:w-12 text-lightest cursor-pointer rounded-3xl transition-all hover:bg-base decrement borobazar-update-qty"
                    data-product_id="<%= list.post_id %>" data-type="minus"
                    title="<?php echo esc_attr__('Decrement', 'borobazar-helper'); ?>">
                    <svg class="w-3 sm:w-auto h-auto" width="16" height="4" viewBox="0 0 16 4" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M8.80005 1.20001H15.2C15.6416 1.20001 16 1.55846 16 1.99996C16 2.44161 15.6416 2.80006 15.2 2.80006H8.80005H7.2H0.799951C0.358447 2.80006 0 2.44161 0 1.99996C0 1.55846 0.358447 1.20001 0.799951 1.20001H7.2H8.80005Z"
                            fill="currentColor" stroke="currentColor" stroke-width="0.5" />
                    </svg>
                </span>

                <div
                    class="self-center text-sm sm:text-base text-main font-semibold borobazar-cart-qty borobazar-cart-product-<%=list.post_id%>">
                    <span class="cart-quantity"></span>
                </div>

                <span
                    class="flex items-center justify-center w-11 sm:w-12 text-lightest cursor-pointer rounded-3xl transition-all hover:bg-base increment borobazar-update-qty"
                    data-product_id="<%= list.post_id %>" data-type="plus"
                    title="<?php echo esc_attr__('Increment', 'borobazar-helper'); ?>">
                    <svg class="w-3 sm:w-auto h-auto" width="15" height="15" viewBox="0 0 16 16" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M15.2 7.2H8.80005V0.799951C8.80005 0.358447 8.4416 0 7.99995 0C7.55845 0 7.2 0.358447 7.2 0.799951V7.2H0.799951C0.358447 7.2 0 7.55845 0 7.99995C0 8.4416 0.358447 8.80005 0.799951 8.80005H7.2V15.2C7.2 15.6416 7.55845 16 7.99995 16C8.4416 16 8.80005 15.6416 8.80005 15.2V8.80005H15.2C15.6416 8.80005 16 8.4416 16 7.99995C16 7.55845 15.6416 7.2 15.2 7.2Z"
                            fill="currentColor" stroke="#8C969F" stroke-width="0.5" />
                    </svg>
                </span>
            </div>

            <% } else { %>

            <?php if ($showQuickView === "on" && $isActiveRedQWooCommerceQuickView === 'true') { ?>
            <a href="#redq-quick-view-modal"
                class="button-redq-woocommerce-quick-view absolute flex items-center justify-center w-9 h-9 rounded-full bottom-3 right-3.5 bg-brand z-1 text-white no-underline transition-all hover:text-white hover:bg-brand-hover focus:text-white"
                data-product_id="<%= list.post_id %>"
                aria-label="<?php echo esc_attr__('Quick View', 'borobazar-helper'); ?>" rel="modal:open">
                <svg stroke="currentColor" fill="none" stroke-width="2.1" viewBox="0 0 24 24" stroke-linecap="round"
                    stroke-linejoin="round" height="1.25em" width="1.25em" xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                    <circle cx="12" cy="12" r="3" />
                </svg>
            </a>
            <?php } else { ?>
            <a href="<%=permalink_with_search%>"
                class="add-to-cart absolute flex items-center justify-center w-9 h-9 rounded-full bottom-3 right-3.5 bg-brand z-1 text-white no-underline transition-all hover:text-white hover:bg-brand-hover focus:text-white"
                aria-label="<?php echo esc_attr__('View Details', 'borobazar-helper'); ?>">
                <svg stroke="currentColor" fill="none" stroke-width="2.2" viewBox="0 0 24 24" stroke-linecap="round"
                    stroke-linejoin="round" height="1.35em" width="1.35em" xmlns="http://www.w3.org/2000/svg">
                    <line x1="5" y1="12" x2="19" y2="12" />
                    <polyline points="12 5 19 12 12 19" />
                </svg>
            </a>
            <?php } ?>
            <% } %>
            <% } %>

        </div>
        <div class="px-3 sm:px-4 pb-3 sm:pb-6 pt-2.5 sm:pt-3">
            <div
                class="borobazar-alpine-product-card-price text-sm sm:text-base text-main font-semibold mb-0.5 sm:mb-1.5">
                <%=price_html%>
                <span class="unit text-sm sm:text-base text-main font-semibold">
                    <%= product_unit_label %>
                    <%= product_unit %>
                </span>
            </div>
            <a href="<%=permalink_with_search%>"
                class="borobazar-alpine-product-card-title block text-sm sm:text-md leading-6 overflow-hidden text-ellipsis no-underline"><%=title%></a>
        </div>

    </div>

    <% }) %>
</div>


<% if(count > postArray.length && loadMoreProductBy === 'click'){ %>
<div class='borobazar-product-search-loadmore mt-7 text-center'>
    <button
        class="inline-flex items-center text-sm min-h-11 py-3 px-6 rounded cursor-pointer bg-brand text-white hover:bg-brand-hover">
        <span class='loaded-text'><?php echo esc_html__('Load More', 'borobazar-helper'); ?></span>
        <span class='loading-text hidden'><?php echo esc_html__('Loading...', 'borobazar-helper'); ?></span>
        <svg class="hidden" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
            x="0px" y="0px" width="24px" height="24px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;"
            xml:space="preserve">
            <path fill="#fff"
                d="M43.935,25.145c0-10.318-8.364-18.683-18.683-18.683c-10.318,0-18.683,8.365-18.683,18.683h4.068c0-8.071,6.543-14.615,14.615-14.615c8.072,0,14.615,6.543,14.615,14.615H43.935z"
                transform="rotate(108.893 25 25)">
                <animateTransform attributeType="xml" attributeName="transform" type="rotate" from="0 25 25"
                    to="360 25 25" dur="0.8s" repeatCount="indefinite"></animateTransform>
            </path>
        </svg>
    </button>
</div>
<% } else { %>
<div class='borobazar-product-infinity-loadmore text-center hidden mt-6 md:mt-9'>
    <svg xmlns="http://www.w3.org/2000/svg" class="w-13 md:w-16 h-auto"
        style="margin: auto;background: rgba(255, 255, 255, 0);" width="70" height="70" viewBox="0 0 100 100"
        preserveAspectRatio="xMidYMid">
        <circle cx="50" cy="50" r="34" stroke="#cccccc" stroke-width="2" fill="none"></circle>
        <circle cx="50" cy="50" r="34" stroke="#212121" stroke-width="4" stroke-linecap="round" fill="none"
            transform="rotate(55.3041 50 50)">
            <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1.5384615384615383s"
                values="0 50 50;180 50 50;720 50 50" keyTimes="0;0.5;1"></animateTransform>
            <animate attributeName="stroke-dasharray" repeatCount="indefinite" dur="1.5384615384615383s"
                values="21.362830044410593 192.26547039969535;106.81415022205297 106.81415022205297;21.362830044410593 192.26547039969535"
                keyTimes="0;0.5;1"></animate>
        </circle>
    </svg>
</div>
<% } %>


<% if(!postArray.length){ %>
<div class="no-result-found flex flex-col items-center text-center">
    <svg class=" w-40 h-auto sm:w-auto" width="300" height="300" viewBox="0 0 200 200" fill="none"
        xmlns="http://www.w3.org/2000/svg">
        <path
            d="M51.5763 186.94C47.3363 186.04 -3.54366 177.78 0.196337 116.92C3.93634 56.0604 8.63634 37.7404 28.4363 31.0404C48.2363 24.3404 96.3163 -7.33963 134.056 22.7804C171.796 52.9004 212.516 79.9404 196.356 128.04C180.196 176.16 177.556 192.2 135.376 189.74C93.2163 187.3 71.7163 191.3 51.5763 186.94Z"
            fill="#F7F8FA" />
        <path
            d="M154.22 174.54C155.2 173.72 155.76 172.6 155.86 171.42C155.96 170.24 155.62 169.02 154.82 168.06L119.96 126.14C127.56 118.76 132.66 108.74 133.7 97.3802C136.02 72.0802 117.34 49.6202 92.0404 47.3002C66.7404 44.9802 44.2803 63.6602 41.9603 88.9602C39.6403 114.26 58.3204 136.72 83.6204 139.04C93.3204 139.94 102.62 137.72 110.52 133.24L112.7 131.8L147.74 173.94C149.36 175.9 152.26 176.16 154.22 174.54ZM123.8 96.4802C121.98 116.32 104.36 130.96 84.5404 129.14C64.7004 127.32 50.0603 109.7 51.8803 89.8802C53.7003 70.0602 71.3004 55.3802 91.1204 57.2002C110.96 59.0402 125.62 76.6402 123.8 96.4802Z"
            fill="#EFEFEF" />
        <path
            d="M47.2153 71.3401C45.3753 75.2601 43.7153 79.3001 42.5553 83.4601C41.4753 87.3201 41.1353 91.2401 41.2953 95.2401C41.5953 102.76 43.7953 110.14 47.6153 116.62C55.2553 129.6 68.9953 138.18 84.0153 139.32C93.4753 140.04 103.835 137.94 111.815 132.64C112.215 132.38 111.255 132.46 111.075 132.6C103.655 137.5 94.1353 139.48 85.3553 138.96C77.8353 138.5 70.4753 136.18 64.0753 132.2C51.8753 124.64 43.6953 111.48 42.4153 97.1601C42.0353 92.8201 42.1953 88.4401 43.2753 84.2201C44.4353 79.7201 46.1953 75.3601 48.1753 71.1801C48.2553 71.0001 47.3353 71.0801 47.2153 71.3401Z"
            fill="#6A79A8" />
        <path
            d="M113.198 133.141C117.738 138.601 122.278 144.041 126.818 149.501C133.078 157.021 139.338 164.541 145.598 172.061C146.158 172.721 146.698 173.421 147.278 174.081C149.658 176.801 154.138 176.121 155.878 173.021C155.958 172.881 155.058 172.941 154.918 173.181C153.298 176.081 149.958 175.821 147.998 173.501C147.378 172.761 146.758 172.021 146.138 171.261C143.558 168.141 140.958 165.041 138.378 161.921C131.858 154.081 125.338 146.241 118.798 138.381C117.238 136.501 115.678 134.641 114.118 132.761C113.958 132.621 113.038 132.941 113.198 133.141Z"
            fill="#6A79A8" />
        <path
            d="M69.356 62.4004C79.396 56.3205 92.016 55.6405 102.656 60.6205C111.136 64.6004 117.876 71.8804 121.156 80.6604C123.056 85.7404 123.776 91.2004 123.296 96.6004C123.276 96.7604 124.236 96.6404 124.256 96.3404C125.136 86.2804 121.776 76.2004 114.976 68.7204C108.076 61.1205 98.0959 56.7805 87.836 56.8405C81.056 56.8805 74.396 58.8205 68.596 62.3405C68.216 62.6005 69.176 62.5204 69.356 62.4004Z"
            fill="#6A79A8" />
        <path
            d="M156.678 171.08C157.658 170.26 158.218 169.14 158.318 167.96C158.418 166.78 158.078 165.56 157.278 164.6L122.418 122.68C130.018 115.3 135.118 105.28 136.158 93.9201C138.478 68.6201 119.798 46.1601 94.4979 43.8401C69.1779 41.5201 46.7178 60.2201 44.3978 85.5001C42.0778 110.8 60.7578 133.28 86.0579 135.6C95.7579 136.5 105.058 134.28 112.958 129.8L115.138 128.36L150.178 170.5C151.798 172.44 154.718 172.7 156.678 171.08ZM126.238 93.0201C124.418 112.86 106.798 127.5 86.9779 125.68C67.1579 123.86 52.4979 106.24 54.3179 86.4201C56.1379 66.6001 73.7579 51.9401 93.5779 53.7601C113.398 55.5801 128.058 73.1801 126.238 93.0201Z"
            fill="white" />
        <path
            d="M157.082 171.201C159.202 169.321 159.342 166.361 157.562 164.201C156.982 163.501 156.402 162.801 155.822 162.101C153.182 158.941 150.562 155.761 147.922 152.601C141.182 144.501 134.462 136.421 127.722 128.321C126.102 126.381 124.482 124.421 122.862 122.481C122.842 122.581 122.822 122.701 122.822 122.801C130.342 115.441 135.242 105.661 136.502 95.2006C137.602 86.0806 135.942 76.7606 131.742 68.5806C127.722 60.7606 121.502 54.1606 113.942 49.7006C106.142 45.1006 97.0217 42.9206 87.9817 43.3806C79.1217 43.8206 70.4417 46.8806 63.2217 52.0406C56.0417 57.1606 50.3617 64.3206 47.0617 72.5206C43.6417 81.0206 42.8217 90.5206 44.7417 99.4806C46.6017 108.161 51.0017 116.221 57.2817 122.501C63.5817 128.821 71.6817 133.241 80.4017 135.101C91.1217 137.381 102.482 135.801 112.142 130.641C113.302 130.021 114.362 129.301 115.462 128.561C115.202 128.561 114.962 128.561 114.702 128.561C119.202 133.961 123.682 139.361 128.182 144.761C134.622 152.501 141.042 160.221 147.482 167.961C148.202 168.821 148.902 169.681 149.622 170.541C151.502 172.781 154.682 173.101 157.002 171.281C157.522 170.881 156.722 170.621 156.382 170.901C154.322 172.521 151.902 171.801 150.342 169.941C149.682 169.141 149.002 168.341 148.342 167.521C145.602 164.241 142.902 161.001 140.202 157.741C133.582 149.781 126.942 141.801 120.322 133.841C118.742 131.941 117.162 130.041 115.582 128.161C115.402 127.941 115.022 128.041 114.822 128.161C98.7817 138.781 77.1217 137.481 62.1217 125.601C48.1417 114.541 41.7617 95.9006 46.0417 78.5806C50.2817 61.4406 64.5617 47.9406 81.9217 44.7206C99.6217 41.4406 117.942 49.2806 128.002 64.1606C132.882 71.3806 135.642 79.9606 135.842 88.6606C136.082 98.7806 132.922 108.861 126.902 116.981C125.422 118.961 123.782 120.821 122.022 122.561C121.942 122.641 121.902 122.781 121.982 122.881C126.202 127.961 130.442 133.041 134.662 138.141C141.022 145.781 147.382 153.441 153.742 161.081C154.622 162.121 155.482 163.181 156.362 164.221C156.522 164.401 156.662 164.581 156.822 164.761C158.342 166.701 158.122 169.301 156.282 170.941C155.842 171.341 156.782 171.461 157.082 171.201Z"
            fill="#6A79A8" />
        <path
            d="M125.759 93.0605C124.339 107.8 113.779 120.54 99.3986 124.34C84.8786 128.18 69.2186 122.14 60.8186 109.76C52.4186 97.3805 52.6786 80.5605 61.5386 68.5006C70.3986 56.4206 86.2786 51.1006 100.619 55.5006C114.619 59.8006 124.799 72.7206 125.819 87.3005C125.959 89.2205 125.919 91.1605 125.759 93.0605C125.719 93.5205 126.699 93.3805 126.739 92.9805C128.079 77.7405 119.539 62.9206 105.599 56.5806C91.7786 50.2806 75.1186 53.3606 64.3786 64.0806C53.4586 74.9605 50.5786 92.1005 57.4586 105.92C64.2586 119.58 79.2386 127.72 94.4186 125.96C109.279 124.22 121.999 113.28 125.739 98.7605C126.219 96.8805 126.559 94.9405 126.739 93.0005C126.759 92.5205 125.779 92.6605 125.759 93.0605Z"
            fill="#6A79A8" />
        <path opacity="0.5"
            d="M115.817 115.256C129.922 101.15 129.922 78.2805 115.817 64.1749C101.711 50.0693 78.8414 50.0693 64.7358 64.1749C50.6302 78.2805 50.6302 101.15 64.7358 115.256C78.8414 129.361 101.711 129.361 115.817 115.256Z"
            fill="white" />
        <path
            d="M93.7594 53.4606C78.6793 52.1406 63.8793 60.3606 57.2793 74.0406C50.5993 87.8806 53.5593 104.841 64.4793 115.621C75.3593 126.361 92.2794 129.141 106.039 122.521C119.779 115.921 128.239 101.161 126.699 85.9606C125.179 70.9206 113.999 58.0806 99.3594 54.4006C97.5194 53.9406 95.6394 53.6406 93.7594 53.4606C93.3594 53.4206 92.7394 54.0006 93.3994 54.0606C108.119 55.4606 120.759 66.1006 124.659 80.3806C128.599 94.8006 122.899 110.561 110.659 119.141C98.3194 127.781 81.4593 127.521 69.3193 118.601C57.3593 109.801 51.9793 94.1006 56.0193 79.8206C60.0393 65.6006 72.9193 55.0206 87.6793 53.9806C89.5793 53.8406 91.4994 53.8806 93.3994 54.0406C93.7994 54.0806 94.3994 53.5206 93.7594 53.4606Z"
            fill="#6A79A8" />
        <path
            d="M103.001 99.2211C101.021 96.8011 98.0006 95.0211 95.0406 94.1211C90.0806 92.6011 84.6006 93.5811 80.3006 96.4011C79.3006 97.0611 78.2806 97.8011 77.4806 98.7011C77.0806 99.1411 78.0206 99.2411 78.2806 98.9411C80.1806 96.8211 83.0406 95.3411 85.7606 94.6211C90.6606 93.3011 95.8006 94.4411 99.8206 97.5011C100.641 98.1211 101.461 98.8211 102.121 99.6211C102.361 99.9411 103.281 99.5811 103.001 99.2211Z"
            fill="#6A79A8" />
        <path
            d="M79.3778 84.6208C79.3778 83.6208 78.5778 82.8008 77.5778 82.8008C76.5778 82.8008 75.7578 83.6008 75.7578 84.6008C75.7578 85.6008 76.5578 86.4208 77.5578 86.4208C78.5578 86.4208 79.3778 85.6208 79.3778 84.6208Z"
            fill="#6A79A8" />
        <path
            d="M104.207 84.8429C104.26 83.8501 103.498 83.0024 102.505 82.9493C101.513 82.8962 100.665 83.658 100.612 84.6507C100.559 85.6435 101.32 86.4913 102.313 86.5443C103.306 86.5974 104.154 85.8356 104.207 84.8429Z"
            fill="#6A79A8" />
        <path
            d="M71.1955 96.2971C72.6423 96.2814 73.7982 94.7019 73.7773 92.7691C73.7564 90.8363 72.5665 89.2821 71.1197 89.2978C69.6729 89.3135 68.517 90.893 68.5379 92.8258C68.5588 94.7586 69.7487 96.3128 71.1955 96.2971Z"
            fill="#FF9C81" />
        <path
            d="M108.774 95.8762C110.221 95.8605 111.376 94.281 111.356 92.3482C111.335 90.4154 110.145 88.8612 108.698 88.8769C107.251 88.8926 106.095 90.4721 106.116 92.4049C106.137 94.3377 107.327 95.8919 108.774 95.8762Z"
            fill="#FF9C81" />
    </svg>
    <h2 class="text-base sm:text-xl"><?php echo esc_html__('Sorry, No Product Found :(', 'borobazar-helper') ?></h2>
</div>
<% } %>
</script>