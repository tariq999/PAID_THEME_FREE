<label class="borobazar-search-banner-form <?php echo esc_attr($templateName); ?> flex max-w-full w-98 xl:w-106 h-14 xl:h-16 rounded-md bg-white overflow-hidden shadow-dropdown mt-8 sm:mt-10 mx-auto">
    <span class="absolute inset-0 opacity-0 pointer-events-none">
        <?php echo wp_kses($attributes['placeholder'], $allowedHTML) ?>
    </span>

    <input type="search" name="text-search" placeholder="<?php echo esc_attr($attributes['placeholder']) ?>" class="grow text-justify border-0 borobazar-banner-text-search-input" id="text-search">

    <span class="borobazar-search-banner-redirect flex items-center justify-center px-6 shrink-0 cursor-pointer">
        <svg xmlns="http://www.w3.org/2000/svg" width="17.048" height="18" viewBox="0 0 17.048 18">
            <path data-name="Path 17130" d="M380.321,383.992l3.225,3.218c.167.167.341.329.5.506a.894.894,0,1,1-1.286,1.238c-1.087-1.067-2.179-2.131-3.227-3.236a.924.924,0,0,0-1.325-.222,7.509,7.509,0,1,1-3.3-14.207,7.532,7.532,0,0,1,6,11.936C380.736,383.462,380.552,383.685,380.321,383.992Zm-5.537.521a5.707,5.707,0,1,0-5.675-5.72A5.675,5.675,0,0,0,374.784,384.513Z" transform="translate(-367.297 -371.285)" fill="currentColor" />
        </svg>
    </span>
</label>