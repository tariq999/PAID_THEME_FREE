<div class="borobazar-search-banner-form <?php echo esc_attr($templateName); ?> flex max-w-full w-98 xl:w-106 h-14 xl:h-[4.375rem] rounded-md bg-white overflow-hidden shadow-dropdown mt-8 sm:mt-10 mx-auto">
    <span class="borobazar-search-banner-redirect flex items-center justify-center px-3 md:pl-6 md:pr-4 shrink-0 cursor-pointer">
        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M25.4731 24.0876L18.7845 17.399C20.0801 15.7987 20.8602 13.7652 20.8602 11.5504C20.8602 6.41706 16.6834 2.24023 11.5501 2.24023C6.41677 2.24023 2.23999 6.41701 2.23999 11.5503C2.23999 16.6836 6.41681 20.8604 11.5501 20.8604C13.7649 20.8604 15.7985 20.0804 17.3988 18.7848L24.0874 25.4733C24.2785 25.6644 24.5294 25.7605 24.7803 25.7605C25.0312 25.7605 25.2821 25.6644 25.4732 25.4733C25.8563 25.0902 25.8563 24.4708 25.4731 24.0876ZM11.5501 18.9004C7.49677 18.9004 4.20003 15.6037 4.20003 11.5503C4.20003 7.49697 7.49677 4.20023 11.5501 4.20023C15.6035 4.20023 18.9002 7.49697 18.9002 11.5503C18.9002 15.6037 15.6034 18.9004 11.5501 18.9004Z" fill="#02B290" stroke="#02B290" stroke-width="0.3" />
        </svg>
    </span>

    <label for="text-search" class="absolute inset-0 opacity-0 pointer-events-none">
        <?php echo wp_kses($attributes['placeholder'], $allowedHTML) ?>
    </label>

    <input id="text-search" type="search" name="text-search" placeholder="<?php echo esc_attr($attributes['placeholder']) ?>" class="grow text-justify border-0 borobazar-banner-text-search-input pl-0">

    <span class="borobazar-search-banner-redirect flex items-center justify-center pr-2.5 shrink-0 cursor-pointer">
        <button class="transition-all bg-brand text-white text-sm md:text-[15px] leading-tight font-semibold p-3 md:px-5 md:py-3 lg:py-4 border-0 rounded-lg"><?php echo esc_html__('Search Now', 'borobazar-helper'); ?>
        </button>
    </span>
</div>