<?php
$allowedHTML = wp_kses_allowed_html('post');

$predefinedTaxonomy = [
    'product_cat',
    'borobazar_product_brands',
    'borobazar_product_price_ranges',
    'borobazar_product_genre',
];

if (!empty($attributes['searchedTaxonomoy']) && !in_array($attributes['searchedTaxonomoy'], $predefinedTaxonomy)) {
    $category_thumb = '';
    $custom_thumb_meta = !empty($taxonomy_all_data['custom_thumb_term_meta']) ? $taxonomy_all_data['custom_thumb_term_meta'] : '';

    if (!empty($custom_thumb_meta)) {
        $decoded_thumb_data = json_decode($custom_thumb_meta, true);
        $get_custom_terms_thumb_ID = !empty($decoded_thumb_data) ? $decoded_thumb_data['term_meta_settings_field_id'][0]['id'] : '';

        if (!empty($get_custom_terms_thumb_ID)) {
            $category_thumb = wp_get_attachment_image_src($get_custom_terms_thumb_ID, 'thumbnail');
        }
    }
}
?>

<div class="borobazar-search-dropdown border-b border-lighter border-solid last:border-0">
    <div class="borobazar-search-dropdown-label hover:bg-lighter">
        <label class="borobazar-checkbox relative flex items-center py-3 sm:py-3.5 m-0 cursor-pointer px-4 sm:px-5">
            <?php if (isset($category_thumb) && $category_thumb) {
            ?>
            <span class="borobazar-image-fade-in w-8 sm:w-10 mr-3.5 sm:mr-4 shrink-0">
                <img class="block max-w-full h-auto opacity-0 transition-opacity duration-200" width="40" height="40"
                    src="<?php echo esc_url($category_thumb[0]); ?>" alt="<?php echo esc_attr($category->name); ?>">
            </span>
            <?php } ?>

            <span class="name grow overflow-hidden text-ellipsis">
                <?php echo wp_kses($category->name, $allowedHTML); ?>
            </span>
            <?php if (empty($product_sub_categories)) { ?>
            <input class="form-checkbox opacity-0 absolute" type="checkbox"
                value="<?php echo esc_attr($category->slug); ?>" name="<?php echo esc_attr($search_field_name); ?>">
            <?php if ($taxonomy_name != 'product_cat') { ?>
            <span
                class="borobazar-checkbox-icon relative block w-5 h-5 rounded-full bg-white border-light border-2 shrink-0 ml-3 bg-no-repeat bg-center transition-all after:w-5 after:h-5 after:absolute after:-top-0.5 after:-left-0.5 after:rounded-full after:bg-brand after:opacity-0 after:-z-1"></span>
            <?php } ?>
            <?php } ?>

            <?php if (!empty($product_sub_categories)) { ?>
            <span class="borobazar-search-dropdown-icon text-lightest rotate-0 transition-all">
                <svg class="block borobazar-rtl-rotate" width="8" height="12" viewBox="0 0 8 12" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M7.41993 5.99997C7.41993 6.21504 7.33781 6.43007 7.17392 6.59404L2.01414 11.7538C1.68592 12.082 1.15375 12.082 0.82566 11.7538C0.497567 11.4257 0.497567 10.8936 0.82566 10.5654L5.39132 5.99997L0.825819 1.43455C0.497726 1.10632 0.497726 0.574321 0.825819 0.246254C1.15391 -0.0821314 1.68607 -0.0821314 2.0143 0.246254L7.17408 5.4059C7.338 5.56995 7.41993 5.78499 7.41993 5.99997Z"
                        fill="currentColor" />
                </svg>
            </span>
            <?php } ?>
        </label>

    </div>

    <?php if (!empty($product_sub_categories)) { ?>
    <div class="borobazar-parameter-list borobazar-search-dropdown-children hidden px-5" data-limit="10">
        <?php foreach ($product_sub_categories as $subCategory) {
                $product_second_sub_categories = [];
                $subcategoryArgs = [
                    'taxonomy'     => $taxonomy_name,
                    'child_of'     => 0,
                    'parent'       => $subCategory->term_id,
                    'orderby'      => $attributes['categoryOrderBy'],
                    'order'        => $attributes['categoryOrder'],
                    'show_count'   => 0,
                    'pad_counts'   => 0,
                    'hierarchical' => 1,
                    'title_li'     => '',
                    'hide_empty'   => 0,
                ];
                $product_second_sub_categories = get_terms($subcategoryArgs); ?>

        <?php if (!empty($product_second_sub_categories)) { ?>
        <div class="borobazar-search-dropdown">
            <div class="borobazar-search-dropdown-label" style="background: #fff">
                <label
                    class="borobazar-checkbox borobazar-search-filter-checkbox relative flex items-center justify-between py-3 m-0 border-b border-lighter border-solid last:border-0 cursor-pointer">
                    <?php echo wp_kses($subCategory->name, $allowedHTML); ?>
                    <span class="borobazar-search-dropdown-icon text-lightest rotate-0 transition-all">
                        <svg class="block borobazar-rtl-rotate" width="8" height="12" viewBox="0 0 8 12" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M7.41993 5.99997C7.41993 6.21504 7.33781 6.43007 7.17392 6.59404L2.01414 11.7538C1.68592 12.082 1.15375 12.082 0.82566 11.7538C0.497567 11.4257 0.497567 10.8936 0.82566 10.5654L5.39132 5.99997L0.825819 1.43455C0.497726 1.10632 0.497726 0.574321 0.825819 0.246254C1.15391 -0.0821314 1.68607 -0.0821314 2.0143 0.246254L7.17408 5.4059C7.338 5.56995 7.41993 5.78499 7.41993 5.99997Z"
                                fill="currentColor" />
                        </svg>
                    </span>
                </label>
            </div>
            <div class="borobazar-parameter-list borobazar-search-dropdown-children hidden pl-5" data-limit="10">
                <?php foreach ($product_second_sub_categories as $product_second_sub_category) { ?>
                <label
                    class="borobazar-checkbox borobazar-search-filter-checkbox relative flex items-center justify-between text-sm py-3.5 m-0 border-b border-lighter border-solid last:border-0 cursor-pointer">
                    <?php echo wp_kses($product_second_sub_category->name, $allowedHTML); ?>
                    <input class="form-checkbox opacity-0 absolute" type="checkbox"
                        value="<?php echo esc_attr($product_second_sub_category->slug); ?>"
                        name="<?php echo esc_attr($search_field_name); ?>">
                    <span
                        class="borobazar-checkbox-icon relative block w-5 h-5 rounded-full bg-white border border-light border-2 shrink-0 ml-3 bg-no-repeat bg-center transition-all after:w-5 after:h-5 after:absolute after:-top-0.5 after:-left-0.5 after:rounded-full after:bg-brand after:opacity-0 after:-z-1"></span>
                </label>
                <?php } ?>
                <span
                    class="borobazar-parameter-load-more cursor-pointer flex items-center justify-center py-4 text-center text-brand text-sm font-medium transition-all hover:text-brand-hover hover:underline">
                    <?php echo esc_html__('Show more', 'borobazar-helper'); ?>
                    <svg class="text-lightest ml-1 " width="12" height="8" viewBox="0 0 12 8" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M5.99997 7.42017C5.7849 7.42017 5.56987 7.33805 5.4059 7.17417L0.24617 2.01439C-0.0820566 1.68616 -0.0820566 1.154 0.24617 0.825904C0.574263 0.497811 1.10632 0.497811 1.43457 0.825904L5.99997 5.39156L10.5654 0.826063C10.8936 0.49797 11.4256 0.49797 11.7537 0.826063C12.0821 1.15416 12.0821 1.68632 11.7537 2.01455L6.59404 7.17433C6.42999 7.33824 6.21495 7.42017 5.99997 7.42017Z"
                            fill="currentColor" />
                    </svg>
                </span>
            </div>
        </div>
        <?php } else { ?>
        <label
            class="borobazar-checkbox borobazar-search-filter-checkbox relative flex items-center justify-between py-3 m-0 border-b border-lighter border-solid last:border-0 cursor-pointer">
            <?php echo wp_kses($subCategory->name, $allowedHTML); ?>
            <input class="form-checkbox opacity-0 absolute" type="checkbox"
                value="<?php echo esc_attr($subCategory->slug); ?>" name="<?php echo esc_attr($search_field_name); ?>">
            <span
                class="borobazar-checkbox-icon relative block w-5 h-5 rounded-full bg-white border border-light border-2 shrink-0 ml-3 bg-no-repeat bg-center transition-all after:w-5 after:h-5 after:absolute after:-top-0.5 after:-left-0.5 after:rounded-full after:bg-brand after:opacity-0 after:-z-1"></span>
        </label>
        <?php } ?>

        <?php
            } ?>
        <span
            class="borobazar-parameter-load-more cursor-pointer flex items-center justify-center py-4 text-center text-brand text-sm font-medium transition-all hover:text-brand-hover hover:underline">
            <?php echo esc_html__('Show more', 'borobazar-helper'); ?>
            <svg class="text-lightest ml-1 " width="12" height="8" viewBox="0 0 12 8" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M5.99997 7.42017C5.7849 7.42017 5.56987 7.33805 5.4059 7.17417L0.24617 2.01439C-0.0820566 1.68616 -0.0820566 1.154 0.24617 0.825904C0.574263 0.497811 1.10632 0.497811 1.43457 0.825904L5.99997 5.39156L10.5654 0.826063C10.8936 0.49797 11.4256 0.49797 11.7537 0.826063C12.0821 1.15416 12.0821 1.68632 11.7537 2.01455L6.59404 7.17433C6.42999 7.33824 6.21495 7.42017 5.99997 7.42017Z"
                    fill="currentColor" />
            </svg>
        </span>
    </div>
    <?php } ?>

</div><!-- Category Dropdown -->