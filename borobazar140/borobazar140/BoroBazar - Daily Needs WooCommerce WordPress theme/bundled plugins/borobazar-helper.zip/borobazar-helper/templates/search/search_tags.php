<script type="text/html" id="borobazarSearchTags">
    <% _.each(searchTags, function(tag, index ) { %>
    <%
    let tagWithType = ''; 
    let tagName = tag.toLowerCase().replace(/\b[a-z]/g, function(letter) {
        return letter.toUpperCase();
    });
    tagWithType = tagName.replace(/-/g, ' ');
    %>

    <span data-tag="<%= tag %>" class="inline-flex text-sm text-lighter px-2 py-1 mr-2 mb-2 items-center border border-light rounded transition-all hover:text-dark hover:bg-base">
        <%= tagWithType %>
        <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="remove-search-tag ml-0.5 shrink-0 text-lightest w-5 h-5 py-0.5 -mr-1.5 cursor-pointer hover:text-dark hover:scale-110" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg">
            <path d="M289.94 256l95-95A24 24 0 00351 127l-95 95-95-95a24 24 0 00-34 34l95 95-95 95a24 24 0 1034 34l95-95 95 95a24 24 0 0034-34z"></path>
        </svg>
    </span>

    <% }) %>
</script>