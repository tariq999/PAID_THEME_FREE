<?php


$imageUrl = get_the_post_thumbnail_url($post->ID);

if (!$imageUrl && $fallbackImage) {
    $imageUrl = $fallbackImage;
}

if (!$imageUrl && !$fallbackImage) {
    $imageUrl = $fallbackImagePath;
}

$title = $post->post_title;
$excerpt = $post->post_excerpt ? $post->post_excerpt : __("Read More...", "borobazar-helpers");
$postUrl = get_permalink($post->ID);


if ($title && $post->post_status == 'publish') {
?>

    <div class="flex items-center rounded py-2.5 px-5 shadow-product">

        <div class="grow-0 shrink-0" style="flex-basis: 80px;">
            <img class="w-full h-full object-cover block" src="<?php echo esc_url($imageUrl) ?>">
        </div>
        <div class="ml-4 grow">
            <a class="block mb-2.5 no-underline" href="<?php echo esc_url($postUrl) ?>">
                <h6 class="m-0 text-[13px]" style="color: <?php echo esc_attr($titleColor) ?>"><?php echo esc_html($title) ?></h6>
            </a>


            <p class="m-0 text-[11px]" style="color: <?php echo esc_attr($excerptColor) ?>"><?php echo esc_html(substr(wp_strip_all_tags($excerpt), 0, 22)) . "..." ?></p>
        </div>
        <a class="block" href="<?php echo esc_url($postUrl) ?>">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" height="20" width="20">
                <g>
                    <path fill="none" d="M0 0h24v24H0z"></path>
                    <path d="M13.172 12l-4.95-4.95 1.414-1.414L16 12l-6.364 6.364-1.414-1.414z" fill=" #8C969F"></path>
                </g>
            </svg>
        </a>

    </div>

<?php
}

?>