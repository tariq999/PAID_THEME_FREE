<?php

// If this file is called directly, abort.
defined('ABSPATH') or exit();


if (!class_exists('RWQV_Settings')) {

    function my_plugin_add_settings()
    {

        class RWQV_Settings extends WC_Settings_Page
        {
            /**
             * Constructor.
             */
            public function __construct()
            {
                $this->id    = 'rwqv_settings';
                $this->label = esc_html__('Quick View', 'redq-woocommerce-quick-view');

                add_filter('woocommerce_settings_tabs_array', array($this, 'add_settings_page'), 20);
                add_action('woocommerce_settings_' . $this->id, array($this, 'output'));
                add_action('woocommerce_settings_save_' . $this->id, array($this, 'save'));
                add_action('woocommerce_sections_' . $this->id, array($this, 'output_sections'));
            }

            /**
             * Output the settings.
             */
            public function output()
            {
                global $current_section;

                $settings = $this->get_settings($current_section);

                WC_Admin_Settings::output_fields($settings);
            }

            /**
             * Save settings.
             */
            public function save()
            {
                global $current_section;

                $settings = $this->get_settings($current_section);
                WC_Admin_Settings::save_fields($settings);
            }

            /**
             * Get settings array.
             *
             * @param string $current_section
             *
             * @return array
             */
            public function get_settings($current_section = '')
            {

                $settings = apply_filters('woocommerce_products_general_settings', array(

                    array(
                        'title'     => esc_html__('WooCommerce Quick View', 'redq-woocommerce-quick-view'),
                        'type'      => 'title',
                        'id'        => 'rwqv_section_title',
                    ),

                    array(
                        'title'    => esc_html__('Select Modal Template', 'redq-woocommerce-quick-view'),
                        'desc'     => esc_html__('Please choose a modal template from the options.', 'redq-woocommerce-quick-view'),
                        'id'       => 'rwqv_modal_template',
                        'type'     => 'select',
                        'class'    => 'wc-enhanced-select',
                        'css'      => 'min-width:250px;',
                        'desc_tip' => true,
                        'options' => array(
                            'normal' => esc_html__('Normal', 'redq-woocommerce-quick-view'),
                            'full_width' => esc_html__('Full Width', 'redq-woocommerce-quick-view'),
                        ),
                    ),

                    array(
                        'type'  => 'sectionend',
                        'id'    => 'rnb_universal_label_end',
                    ),


                ));

                return apply_filters('woocommerce_get_settings_' . $this->id, $settings, $current_section);
            }
        }

        return new RWQV_Settings();
    }

    add_filter('woocommerce_get_settings_pages', 'my_plugin_add_settings', 15);
}
