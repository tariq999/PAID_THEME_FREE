<?php

if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

class RedQWoocommerceQuickViewAJAX
{
  public function __construct()
  {
    add_action('wp_ajax_redq_woocommerce_quick_view_show', [$this, 'redq_woocommerce_quick_view_show']);
    add_action('wp_ajax_nopriv_redq_woocommerce_quick_view_show', [$this, 'redq_woocommerce_quick_view_show']);

    add_action('wp_ajax_woocommerce_ajax_add_to_cart', [$this, 'woocommerce_ajax_add_to_cart']);
    add_action('wp_ajax_nopriv_woocommerce_ajax_add_to_cart', [$this, 'woocommerce_ajax_add_to_cart']);
  }

  public function redq_woocommerce_quick_view_show()
  {
    // phpcs:disable WordPress.Security.NonceVerification.Recommended
    if (!isset($_REQUEST['product_id'])) {
      die();
    }

    $product_id = intval($_REQUEST['product_id']);

    // Set the main wp query for the product.
    wp('p=' . $product_id . '&post_type=product');

    // Remove product thumbnails gallery.
    remove_action('woocommerce_product_thumbnails', 'woocommerce_show_product_thumbnails', 20);

    ob_start();
    wc_get_template('redq-quick-view-content.php', array("product_ID" => $product_id), '', REDQ_WOOCOMMERCE_QUICK_VIEW_DIR . '/templates/');
    echo ob_get_clean();  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

    // wp_send_json_success([
    //   'message'  => __('Successfully open popup', 'cartsy-helper'),
    // ]);
    wp_die();
    // phpcs:enable WordPress.Security.NonceVerification.Recommended
  }

  public function woocommerce_ajax_add_to_cart()
  {
    if (isset($_POST['forms'])) {
      $forms = explode('&', $_POST['forms']);
      $parent_id = str_replace('add-to-cart=', '', end($forms));
      $productIDs = [];

      array_pop($forms);
      $count = count($forms);

      foreach ($forms as $prod) {
        $temp = explode('=', $prod);
        $id = str_replace('%5D', '', $temp[0]);
        $id = str_replace('quantity%5B', '', $id);

        if (!empty($temp) && $temp[1] > 0) {
          $product_id = apply_filters('woocommerce_add_to_cart_product_id', absint($id));
          // $quantity = empty($_POST['quantity']) ? 1 : wc_stock_amount($temp[1]);
          $quantity = wc_stock_amount($temp[1]);

          $passed_validation = apply_filters('woocommerce_add_to_cart_validation', true, $product_id, $quantity);
          $product_status = get_post_status($product_id);

          if ($passed_validation && WC()->cart->add_to_cart($product_id, $quantity) && 'publish' === $product_status) {

            do_action('woocommerce_ajax_added_to_cart', $product_id);

            if ('yes' === get_option('woocommerce_cart_redirect_after_add')) {
              wc_add_to_cart_message(array($product_id => $quantity), true);
            }

            if ($count == 1) {
              WC_AJAX::get_refreshed_fragments();
            }
            $count--;
          } else {

            $data = array(
              'error' => true,
              'product_url' => apply_filters('woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id)
            );

            echo wp_send_json($data);
          }
        }
      }
    } else {
      $variation_data = [];
      $product_id = apply_filters('woocommerce_add_to_cart_product_id', absint($_POST['product_id']));
      $quantity = empty($_POST['quantity']) ? 1 : wc_stock_amount($_POST['quantity']);
      $variation_id = absint($_POST['variation_id']);
      $passed_validation = apply_filters('woocommerce_add_to_cart_validation', true, $product_id, $quantity);
      $product_status = get_post_status($product_id);

      if ($variation_id) {
        $variation_data = wc_get_product_variation_attributes($variation_id);
      }

      if ($passed_validation && WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variation_data) && 'publish' === $product_status) {

        do_action('woocommerce_ajax_added_to_cart', $product_id);

        if ('yes' === get_option('woocommerce_cart_redirect_after_add')) {
          wc_add_to_cart_message(array($product_id => $quantity), true);
        }

        WC_AJAX::get_refreshed_fragments();
      } else {

        $data = array(
          'error' => true,
          'product_url' => apply_filters('woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id)
        );

        echo wp_send_json($data);
      }
    }

    wp_die();
  }
}

new RedQWoocommerceQuickViewAJAX();
