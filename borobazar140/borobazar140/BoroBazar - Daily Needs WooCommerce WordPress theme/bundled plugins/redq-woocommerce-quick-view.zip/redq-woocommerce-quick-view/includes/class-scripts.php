<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class RedQWoocommerceQuickViewScripts
{
    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'load_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
    }

    public function admin_enqueue_scripts($hook)
    {
    }
    public function load_scripts()
    {
        // wp_register_style('jquery-modal', '//cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css', array(), $ver = false, $media = 'all');
        // wp_enqueue_style('jquery-modal');

        // wp_register_script('jquery-modal', '//cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js', array('jquery', 'woocommerce'), true, true);
        // wp_enqueue_script('jquery-modal');

        wp_register_style('jquery-modal', REDQ_WOOCOMMERCE_QUICK_VIEW_CSS . 'jquery.modal.min.css', array(), $ver = false, $media = 'all');
        wp_enqueue_style('jquery-modal');

        wp_register_script('jquery-modal', REDQ_WOOCOMMERCE_QUICK_VIEW_JS . 'jquery.modal.min.js', array('jquery', 'woocommerce'), true, true);
        wp_enqueue_script('jquery-modal');

        wp_register_script('redq-woocommerce-quick-view', REDQ_WOOCOMMERCE_QUICK_VIEW_JS . 'preview-popup-main.js', array('jquery', 'woocommerce', 'wc-add-to-cart', 'jquery-modal'), true, true);
        wp_enqueue_script('redq-woocommerce-quick-view');

        if (class_exists('WooCommerce')) {
            $currency_symbol = get_woocommerce_currency_symbol();
        } else {
            $currency_symbol = '';
        }
        wp_localize_script('redq-woocommerce-quick-view', 'redq_woocommerce_quick_view', [
            'site_url' => get_site_url(),
            'ajax_url' => admin_url('admin-ajax.php'),
            'woocommerce_currency_symbol' =>  $currency_symbol,
            'choose_an_option' =>  esc_html__("Choose an option", "redq-woocommerce-quick-view"),
        ]);
    }
}

new RedQWoocommerceQuickViewScripts();
