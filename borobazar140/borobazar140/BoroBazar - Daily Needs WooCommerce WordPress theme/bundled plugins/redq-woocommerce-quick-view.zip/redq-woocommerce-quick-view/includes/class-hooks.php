<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class RedQWoocommerceQuickViewHooks
{
    public function __construct()
    {
        add_filter('woocommerce_loop_add_to_cart_link', [$this, 'loop_add_to_cart_link'], 10, 2);

        // Load modal template.
        add_action('wp_footer', array($this, 'footer_script_html'));
        $this->redq_quick_view_action_template();
    }

    public function loop_add_to_cart_link($button, $product)
    {
        if (is_product_category() || is_shop()) {
            $quick_view_button_text = esc_html__("Quick View", "redq-woocommerce-quick-view");
            $quick_view_button = '<a href="#redq-quick-view-modal" class="button-redq-woocommerce-quick-view" data-product_id="' . $product->get_id() . '" rel="modal:open">' . $quick_view_button_text . '</a>';
            $combine_buttton = $quick_view_button . $button;
            return $combine_buttton;
        }
    }

    public function footer_script_html()
    {
        wp_enqueue_script('wc-add-to-cart-variation');
        if (version_compare(WC()->version, '3.0.0', '>=')) {
            if (current_theme_supports('wc-product-gallery-zoom')) {
                wp_enqueue_script('zoom');
            }
            if (current_theme_supports('wc-product-gallery-lightbox')) {
                wp_enqueue_script('photoswipe-ui-default');
                wp_enqueue_style('photoswipe-default-skin');
                if (has_action('wp_footer', 'woocommerce_photoswipe') === false) {
                    add_action('wp_footer', 'woocommerce_photoswipe', 15);
                }
            }
            wp_enqueue_script('wc-single-product');
        }

        $rwqv_modal_template = get_option('rwqv_modal_template');

?>
        <!-- Modal HTML embedded directly into document -->
        <div id="redq-quick-view-modal" class="modal rwqv-<?php echo esc_attr($rwqv_modal_template) ?>">
            <div class="redq-quick-view-modal-loader">
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="24px" height="24px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve">
                    <path fill="#fff" d="M43.935,25.145c0-10.318-8.364-18.683-18.683-18.683c-10.318,0-18.683,8.365-18.683,18.683h4.068c0-8.071,6.543-14.615,14.615-14.615c8.072,0,14.615,6.543,14.615,14.615H43.935z" transform="rotate(108.893 25 25)">
                        <animateTransform attributeType="xml" attributeName="transform" type="rotate" from="0 25 25" to="360 25 25" dur="0.8s" repeatCount="indefinite"></animateTransform>
                    </path>
                </svg>
            </div>
            <div id="redq-quick-view-content"></div>
        </div>
<?php
    }

    /**
     * Load wc action for quick view product template
     *
     * @access public
     * @since  1.0.0
     * @author REDQ 
     * @return void
     */
    public function redq_quick_view_action_template()
    {

        // Image.
        add_action('redq_wcqv_product_image', 'woocommerce_show_product_sale_flash', 10);
        add_action('redq_wcqv_product_image', 'woocommerce_show_product_images', 20);

        // Summary.
        add_action('redq_wcqv_product_summary', 'woocommerce_template_single_title', 5);
        add_action('redq_wcqv_product_summary', 'woocommerce_template_single_rating', 10);
        add_action('redq_wcqv_product_summary', 'woocommerce_template_single_price', 15);
        add_action('redq_wcqv_product_summary', 'woocommerce_template_single_excerpt', 20);
        add_action('redq_wcqv_product_summary', 'woocommerce_template_single_add_to_cart', 25);
        add_action('redq_wcqv_product_summary', 'woocommerce_template_single_meta', 30);

        // after summery

        add_action('redq_wcqv_after_product_summary', 'woocommerce_upsell_display', 35);
        add_action('redq_wcqv_after_product_summary', 'woocommerce_output_related_products', 40);
    }
}

new RedQWoocommerceQuickViewHooks();
