jQuery(document).ready(function ($) {
  ('use strict');

  if (typeof wc_add_to_cart_params === 'undefined') {
    return false;
  }

  var rqv_modal = $(document).find('#redq-quick-view-modal'),
    rqv_content = rqv_modal.find('#redq-quick-view-content');

  rqv_modal.addClass('product-loading');

  $('body').on('click', '.button-redq-woocommerce-quick-view', function (e) {
    e.preventDefault();

    setTimeout(function () {
      $('.jquery-modal').addClass('redq-quick-view-modal-blocker');
    }, 10);

    $('#fade').modal({
      fadeDuration: 100,
    });

    var product_id = $(this).data('product_id');

    $.ajax({
      url: redq_woocommerce_quick_view.ajax_url,
      data: {
        action: 'redq_woocommerce_quick_view_show',
        product_id: product_id,
      },
      dataType: 'html',
      type: 'POST',
      success: function (data) {
        rqv_content.html(data);

        // Variation Form
        var form_variation = rqv_content.find('.variations_form');

        form_variation.each(function () {
          $(this).wc_variation_form();
        });

        form_variation.trigger('check_variations');
        form_variation.trigger('reset_image');

        if (typeof $.fn.wc_product_gallery !== 'undefined') {
          rqv_content.find('.woocommerce-product-gallery').each(function () {
            $(this).wc_product_gallery();
          });
        }
        rqv_modal.removeClass('product-loading').addClass('product-loaded');
      },
    });
  });

  $('#redq-quick-view-modal').on($.modal.CLOSE, function (event, modal) {
    rqv_modal.removeClass('product-loaded').addClass('product-loading');
    $('body #redq-quick-view-content').html('');
  });

  // Add to Cart Old Code

  $('#redq-quick-view-content').on(
    'click',
    '.single_add_to_cart_button',
    function (e) {
      e.preventDefault();

      var $thisbutton = $(this);
      var $form = $thisbutton.closest('form.cart');
      var id = $thisbutton.val();
      var product_qty = $form.find('input[name=quantity]').val();
      var product_id = $form.find('input[name=product_id]').val();
      var variation_id = $form.find('input[name=variation_id]').val() || 0;
      var data;
      var allZero = true;

      if (undefined == product_id) {
        product_id = $form.find('button[name=add-to-cart]').val();
      }

      if ($form.hasClass('grouped_form')) {
        data = {
          action: 'woocommerce_ajax_add_to_cart',
          product_id: product_id,
          product_sku: '',
          forms: $form.serialize(),
          quantity: product_qty,
          variation_id: variation_id,
        };
      } else {
        data = {
          action: 'woocommerce_ajax_add_to_cart',
          product_id: product_id,
          product_sku: '',
          quantity: product_qty,
          variation_id: variation_id,
        };
      }

      if ($form.hasClass('grouped_form')) {
        // iterate group product and check quantity
        var form_data = data ? data.forms.split('&') : '';
        form_data.pop();
        var qtyArray = [];
        for (var index = 0; index < form_data.length; index++) {
          var element = form_data[index];
          var temp = element.split('=');
          var id = temp[0].replace('%5D', '');
          var qty = id.replace('quantity%5B', '');
          qtyArray.push(parseInt(temp[1]));
        }

        for (var index = 0; index < qtyArray.length; index++) {
          if (qtyArray[index] !== 0) {
            allZero = false;
          }
        }
        if (allZero) {
          return;
        }
      }

      if (
        $form.hasClass('variations_form') &&
        (variation_id == undefined || variation_id == 0)
      ) {
        return;
      }

      $(document.body).trigger('adding_to_cart', [$thisbutton, data]);
      $.ajax({
        type: 'post',
        url: wc_add_to_cart_params.ajax_url,
        data: data,
        beforeSend: function (response) {
          $thisbutton.removeClass('added').addClass('loading');
        },
        complete: function (response) {
          $thisbutton.addClass('added').removeClass('loading');
        },
        success: function (response) {
          var responseData = data;

          $(document.body).trigger('wc_fragment_refresh');
          $(document.body).trigger('wc_fragments_loaded');
          $(`body .cartsy-cart-product-${responseData.product_id}`).html(
            responseData.quantity
          );

          if (responseData.quantity) {
            $(`body .cartsy-qty-button-${responseData.product_id}`).show();
            $(`body .added-to-cart-${responseData.product_id}`).show();
          } else {
            $(`body .cartsy-qty-button-${responseData.product_id}`).hide();
            $(`body .added-to-cart-${responseData.product_id}`).hide();
          }

          if (response.error && response.product_url) {
            window.location = response.product_url;
            return;
          } else {
            $(document.body).trigger('added_to_cart', [
              response.fragments,
              response.cart_hash,
              $thisbutton,
            ]);
          }
        },
      });

      return false;
    }
  );
});
