<?php

/**
 * Plugin Name: RedQ WooCommerce Quick View
 * Plugin URI: http://redq.io
 * Description: This is a handy plugin for using in Cartsy theme. Main purpose of this plugin is to provide a quick view of any product and carting them.
 * Version: 1.0.2
 * Author: RedQ,Inc
 * Author URI: http://redq.io
 * Requires at least: 4.7
 * Tested up to: 4.9.5
 * 
 *
 *
 * Text Domain: redq-woocommerce-quick-view
 * Domain Path: /languages/
 *
 * Copyright: © 2020 redqteam.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class RedQWooCommerceQuickView
{
    /**
     * @var null
     *
     * @since 1.0.0
     */
    protected static $_instance = null;

    /**
     * instance.
     *
     * @return void
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->Bootstrap();
        $this->Load_Classes();
    }

    /**
     * Bootstrap.
     *
     * @return void
     */
    public function Bootstrap()
    {
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_DIR', untrailingslashit(plugin_dir_path(__FILE__)));
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_URL', untrailingslashit(plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__))));
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_FILE', dirname(__FILE__));
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_CSS', REDQ_WOOCOMMERCE_QUICK_VIEW_URL.'/assets/css/');
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_JS', REDQ_WOOCOMMERCE_QUICK_VIEW_URL.'/assets/js/');
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_JS_VENDOR', REDQ_WOOCOMMERCE_QUICK_VIEW_URL.'/assets/ven/');
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_IMG', REDQ_WOOCOMMERCE_QUICK_VIEW_URL.'/assets/img/');
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_INCLUDE', REDQ_WOOCOMMERCE_QUICK_VIEW_DIR.'/includes/');
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_TEMPLATE_PATH', plugin_dir_path(__FILE__).'templates/');
        define('REDQ_WOOCOMMERCE_QUICK_VIEW_SHORTCODE_PATH', plugin_dir_path(__FILE__).'shortcodes/');
    }

    /**
     * Load_Classes.
     *
     * @return void
     */
    public function Load_Classes()
    {
        require_once REDQ_WOOCOMMERCE_QUICK_VIEW_INCLUDE.DIRECTORY_SEPARATOR.'class-hooks.php';
        require_once REDQ_WOOCOMMERCE_QUICK_VIEW_INCLUDE.DIRECTORY_SEPARATOR.'class-scripts.php';
        require_once REDQ_WOOCOMMERCE_QUICK_VIEW_INCLUDE.DIRECTORY_SEPARATOR.'class-admin.php';
        require_once REDQ_WOOCOMMERCE_QUICK_VIEW_INCLUDE.DIRECTORY_SEPARATOR.'class-ajax.php';

        add_action('plugins_loaded', [$this, 'load_redq_wcqv_plugin']);
    }

    /**
     * load_redq_wcqv_plugin.
     *
     * @return void
     */
    public function load_redq_wcqv_plugin()
    {
        $this->load_textdomain();
        if (!$this->has_full_fill_dependencies()) {
            add_action('admin_init', [$this, 'self_deactivation']);
            add_action('admin_notices', [$this, 'render_notice']);

            return;
        }
        add_action( 'before_woocommerce_init', function() {
            if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
            }
        } );
    }

    /**
     * has_full_fill_dependencies.
     *
     * @return void
     */
    public function has_full_fill_dependencies()
    {
        $dependency_errors = $this->get_installation_requirement_errors();

        return 0 === count($dependency_errors);
    }

    /**
     * get_installation_requirement_errors.
     *
     * @return array
     */
    protected function get_installation_requirement_errors()
    {
        $errors = [];
        $wordpress_version = get_bloginfo('version');
        $minimum_wordpress_version = '5.3';
        $minimum_woocommerce_version = '3.6';
        $wordpress_minimum_met = version_compare($wordpress_version, $minimum_wordpress_version, '>=');
        $woocommerce_minimum_met = class_exists('WooCommerce') && defined('WC_VERSION') && version_compare(WC_VERSION, $minimum_woocommerce_version, '>=');

        if (!$woocommerce_minimum_met) {
            $errors[] = sprintf(
        /* translators: 1: URL of WooCommerce plugin, 2: The minimum WooCommerce version number */
        __('The RedQ WooCommerce Quick View plugin requires <a href="%1$s">WooCommerce</a> %2$s or greater to be installed and active.', 'redq-woocommerce-quick-view'),
        'https://wordpress.org/plugins/woocommerce/',
        $minimum_woocommerce_version
      );
        }

        if (!$wordpress_minimum_met) {
            $errors[] = sprintf(
        /* translators: 1: URL of WordPress.org, 2: The minimum WordPress version number */
        __('The RedQ WooCommerce Quick View plugin requires <a href="%1$s">WordPress</a> %2$s or greater to be installed and active.', 'redq-woocommerce-quick-view'),
        'https://wordpress.org/',
        $minimum_wordpress_version
      );
        }

        return $errors;
    }

    /**
     * render_notice.
     *
     * @return void
     */
    public function render_notice()
    {
        $message = $this->get_installation_requirement_errors();
        printf('<div class="error"><p>%s</p></div>', implode(' ', $message)); /* phpcs:ignore xss ok. */
    }

    /**
     * self_deactivation.
     *
     * @return void
     */
    public function self_deactivation()
    {
        deactivate_plugins(plugin_basename(plugin_basename(__FILE__)));
        if (isset($_GET['activate'])) {
            unset($_GET['activate']);
        }
        // phpcs:ignore CSRF ok.
    }

    /**
     * load_textdomain.
     *
     * @return void
     */
    public function load_textdomain()
    {
        load_plugin_textdomain('redq-woocommerce-quick-view', false, basename(dirname(__FILE__)).'/languages');
    }
}

function RedQWooCommerceQuickView()
{
    return RedQWooCommerceQuickView::instance();
}

$GLOBALS['redq-woocommerce-quick-view'] = RedQWooCommerceQuickView();
