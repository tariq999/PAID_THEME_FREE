<?php

// if uninstall.php is not called by WordPress, die
if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

// delete options data if plugin uninstalled

$option_name = 'gridster_settings';
delete_option($option_name);
