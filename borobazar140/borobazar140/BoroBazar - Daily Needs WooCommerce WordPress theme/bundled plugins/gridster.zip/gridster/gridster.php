<?php

/**
 * Plugin Name: GridSter
 * Plugin URI: http://codecanyon.com/user/redqteam
 * Description: GridSter — is a Gutenberg plugin created via create-guten-block.
 * Author: redqteam
 * Author URI: https://redq.io
 * Version: 1.2.3
 * Requires at least: 6.0
 * Tested up to: 6.2
 * Requires PHP: 7.4
 * Text Domain: gridster
 * Domain Path: /languages
 *
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

if (!defined('GS_PLUGIN_FILE')) {
    define('GS_PLUGIN_FILE', __FILE__);
}

use GridSter\Classes;

/**
 * Main GridSter Class for the plugin.
 *
 * @class GridSter
 */
final class GridSter
{
    /**
     * version.
     *
     * @var string
     */
    public $version = '1.2.3';

    /**
     * init a singleton instance.
     *
     * @return \GridSter
     */
    public static function init()
    {
        static $instance = false;

        if (!$instance) {
            $instance = new self();
        }

        return $instance;
    }

    /**
     * class constructor.
     *
     * @return void
     */
    private function __construct()
    {
        $this->declareConstants();
        $this->classLoader();
        $this->initHooks();
    }

    /**
     * declareConstants.
     */
    public function declareConstants()
    {
        define('GS_ABSPATH', dirname(GS_PLUGIN_FILE) . '/');
        define('GS_VERSION', $this->version);
        define('GS_DIR', untrailingslashit(plugin_dir_path(__FILE__)));
        define('GS_URL', untrailingslashit(plugins_url(basename(plugin_dir_path(__FILE__)), basename(__FILE__))));
        define('GS_REQUIRED_PHP_VERSION', 5.6);
        define('GS_REQUIRED_WP_VERSION', 5.5);
        define('GS_ADMIN_VIEWS', GS_DIR . '/admin-templates/');
        define('GS_ASSETS', GS_URL . '/assets/');
        define('GS_DIST', GS_URL . '/dist/');
        define('GS_ADMIN_TEMPLATE_PATH', GS_DIR . '/admin-templates/');
        define('GS_TEMPLATE_PATH', GS_DIR . '/templates/');
        define('GS_SHORTCODE_PATH', GS_DIR . '/includes/shortcodes/');
    }

    /**
     * classLoader.
     */
    public function classLoader()
    {
        require_once 'vendor' . DIRECTORY_SEPARATOR . 'autoload.php';
        require_once GS_DIR . DIRECTORY_SEPARATOR . 'includes/woo-quick-cart/functions.php';
        new Classes();
    }

    /**
     * initHooks.
     */
    public function initHooks()
    {
        add_action('admin_init', [$this, 'checkPHPVersion']);
        add_action('init', [$this, 'gsIncludeTemplateFunctions']);
        add_filter('body_class', [$this, 'gsBodyClasses']);

        add_action( 'before_woocommerce_init', function() {
            if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
            }
        } );

        if (!self::compatibleVersion()) {
            return;
        }
    }

    /**
     * gsBodyClasses.
     *
     * @param array $classes
     *
     * @return array
     */
    public function gsBodyClasses($classes)
    {
        // predefine class
        $classes[] = 'gridster';

        // custom class
        $customBodyClass = '';
        $gridster_settings = get_option('gridster_settings');
        $customBodyClass = !empty($gridster_settings) ? $gridster_settings['gs_custom_body_class'] : '';

        if (!empty($customBodyClass) && $customBodyClass !== '') {
            $classes[] = $customBodyClass;
        }

        return $classes;
    }

    /**
     * gsIncludeTemplateFunctions.
     */
    public function gsIncludeTemplateFunctions()
    {
        include_once GS_ABSPATH . 'includes/TemplateHooks.php';
        include_once GS_ABSPATH . 'includes/TemplateFunctions.php';
    }

    /**
     * checkPHPVersion.
     */
    public function checkPHPVersion()
    {
        if (!self::compatibleVersion() || !class_exists('WooCommerce')) {
            if (is_plugin_active(plugin_basename(__FILE__))) {
                deactivate_plugins(plugin_basename(__FILE__));
                add_action('admin_notices', [$this, 'disableNotice']);
                if (isset($_GET['activate'])) {
                    unset($_GET['activate']);
                }
            }
        }
    }

    /**
     * compatibleVersion.
     *
     * @return bool
     */
    public static function compatibleVersion()
    {
        if (phpversion() < GS_REQUIRED_PHP_VERSION || $GLOBALS['wp_version'] < GS_REQUIRED_WP_VERSION) {
            return false;
        }

        return true;
    }

    /**
     * disableNotice.
     */
    public function disableNotice()
    {
        if (phpversion() < GS_REQUIRED_PHP_VERSION) { ?>
            <div class="notice notice-error is-dismissible">
                <p>
                    <?php esc_html_e('Can not activate GridSter! GridSter requires PHP ' . GS_REQUIRED_PHP_VERSION . ' or higher!', 'gridster'); ?>
                </p>
            </div>
        <?php
        }
        if ($GLOBALS['wp_version'] < GS_REQUIRED_WP_VERSION) { ?>
            <div class="notice notice-error is-dismissible">
                <p>
                    <?php esc_html_e('Can not activate GridSter! GridSter requires Wordpress ' . GS_REQUIRED_WP_VERSION . ' or higher!', 'gridster'); ?>
                </p>
            </div>
        <?php
        }

        if (!class_exists('WooCommerce')) { ?>
            <div class="notice notice-error is-dismissible">
                <p><?php esc_html_e('Can not activate GridSter! Please activate WooCommerce first.', 'gridster'); ?></p>
            </div>
<?php
        }
    }

    /**
     * templatePath.
     */
    public function templatePath()
    {
        return apply_filters('GS_TEMPLATE_PATH', 'gridster/');
    }

    /**
     * pluginPath.
     */
    public function pluginPath()
    {
        return untrailingslashit(plugin_dir_path(__FILE__));
    }
}

/**
 * initialize the plugin works.
 *
 * @return \GridSter
 */
function gridster()
{
    return GridSter::init();
}

// fire up the plugin
$GLOBALS['gridster'] = gridster();
