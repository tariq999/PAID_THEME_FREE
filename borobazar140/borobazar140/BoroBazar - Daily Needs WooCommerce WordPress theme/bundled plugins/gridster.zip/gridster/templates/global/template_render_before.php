<?php

/**
 * The template for displaying content before product loop
 *
 * This template can be overridden by copying it to yourtheme/gridster/global/loop_start_wrap.php.
 */

defined('ABSPATH') || exit;

?>

<div class="gs-products-block gs-block-spacing-wrapper <?php echo esc_attr($customClass) ?>" style="<?php echo esc_attr($padding) ?>">