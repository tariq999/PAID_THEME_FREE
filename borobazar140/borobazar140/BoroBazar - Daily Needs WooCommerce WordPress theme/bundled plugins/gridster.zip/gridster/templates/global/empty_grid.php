<?php

/**
 * Grid Name : Empty Grid
 * 
 * The template for displaying product content within loops
 * 
 * This template can be overridden by copying it to yourtheme/gridster/global/empty_grid.php.
 */

defined('ABSPATH') || exit;

$alt         = !empty($alt_image) ? $alt_image        : 'nothing-found';
$message     = !empty($empty_message) ? $empty_message : esc_html__('Nothing Found: (', 'gridster');
$allowedHTML = wp_kses_allowed_html('post');
?>

<div class="<?php echo esc_attr(apply_filters(' gs_item_loop_empty_wrap_classes', 'no-result-found')) ?>">
    <img src="<?php echo esc_url($empty_image); ?>" alt="<?php echo esc_attr__($alt, 'gridster'); ?>">
    <h2><?php echo wp_kses($message, $allowedHTML); ?></h2>
</div>