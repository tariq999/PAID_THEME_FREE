<?php
$allowedHTML = wp_kses_allowed_html('post');
?>
<?php if (!empty($seeAll['see_all']['display_link'])) { ?>
    <div class="swiper-slide">
        <a href="<?php echo esc_url($seeAll['see_all']['pageSlug']); ?>" class="view-all-slide w-full h-full flex flex-col items-center justify-center no-underline">
            <svg width="50" height="50" viewBox="0 0 50 50" fill="none" class="text-brand">
                <circle cx="25" cy="25" r="24" fill="white" stroke="currentColor" stroke-width="2" />
                <path d="M13.477 23.9716H34.3765L26.3737 16.4878C25.9547 16.096 25.9385 15.4449 26.3376 15.0335C26.7362 14.6226 27.3994 14.6061 27.8189 14.998L36.9584 23.5453C37.3538 23.9341 37.5723 24.4504 37.5723 25.0002C37.5723 25.5494 37.3538 26.0663 36.94 26.4721L27.8184 35.0019C27.6157 35.1917 27.3559 35.2858 27.0961 35.2858C26.8195 35.2858 26.5429 35.1788 26.3371 34.9664C25.9379 34.555 25.9542 33.9044 26.3732 33.5125L34.4095 26.0288H13.477C12.8987 26.0288 12.4294 25.568 12.4294 25.0002C12.4294 24.4324 12.8987 23.9716 13.477 23.9716Z" fill="currentColor" stroke="currentColor" stroke-width="0.5" />
            </svg>
            <span class="text-brand"><?php echo wp_kses($seeAll['see_all']['linkText'], $allowedHTML); ?></span>
        </a>
    </div>
<?php } ?>