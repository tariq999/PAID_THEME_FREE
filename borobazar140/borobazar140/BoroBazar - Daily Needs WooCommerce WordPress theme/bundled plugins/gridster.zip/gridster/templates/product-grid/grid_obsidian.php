<?php

/**
 * Grid Name : Obsidian.
 *
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/gridster/product-grid/grid_obsidian.php.
 */
defined('ABSPATH') || exit;

use GridSter\Front\Shortcodes;

?>

<?php
/**
 * Hook: gs_grid_loop_items_before_wrap.
 */
do_action('gs_grid_loop_items_before_wrap');

$parentClass  = $superDealParentClass = $superDealChildClass = $childClass = '';
$isSuperDeal = false;
$childClass   = 'gs-obsidian-product-card-item';
$uniqueId     = uniqid();
$gridName     = !empty($blockName) ? $blockName : '';
$showQuickView = get_theme_mod('woo_preview_pop_switch', 'on');
if ($gridName === 'gridster/super-deals') {
    $isSuperDeal = true;
    $superDealParentClass = "gs-super-deal-slider-{$templateSlug} swiper";
    $superDealChildClass = "gs-super-deal-slider-item-{$templateSlug}";
} else {
    $superDealParentClass  = "gs-grid-item-wrap gs-obsidian-grid-wrap {$gridClass}";
}
?>

<?php if (!empty($posts)) { ?>

    <?php echo $isSuperDeal ? "<div class='w-full overflow-hidden md:max-w-[50%] lg:max-w-none'>"  : ""; ?>
    <div class="gs-product-grid-main-wrap !grid-cols-[repeat(auto-fit,_minmax(400px,_1fr))] <?php echo esc_attr($superDealParentClass); ?>">
        <?php echo $isSuperDeal ? "<div class='swiper-wrapper'>"  : ""; ?>

        <!-- Grid Loop start -->
        <?php foreach ($posts as $key => $post) { ?>

            <?php
            $cartItems   = [];
            $_product    = !empty($post['ID']) ? wc_get_product($post['ID']) : null;
            $_product_id = !empty($_product) ? $_product->get_id() : "";

            if (function_exists('gsWooCheckProductInCart')) {
                $qty = gsWooCheckProductInCart($_product_id);
            } else {
                $qty = [];
            }

            $display = $qty ? "flex" : "hidden";
            $cartButton = $qty ? 'hidden' : 'flex';
            $qty_class = 'gs-qty-button gs-qty-button-' . $_product_id;
            $postTitle = !empty($post['post_title']) ? $post['post_title'] : "";
            $isOnSale =  !empty($_product) ? $_product->is_on_sale() : "";
            $isInStock = !empty($_product) ? $_product->is_in_stock() : "";
            $priceHTML = !empty($_product) ? $_product->get_price_html() : "";
            $stock_qty = !empty($post['stock']) ? $post['stock'] : -1;
            $unit = !empty($post['unit']) ? $post['unit'] : '';
            $label = !empty($post['unit_label']) ? $post['unit_label'] : '';
            $thumbnail_url = !empty($post['thumbnail']['url']) ? $post['thumbnail']['url'] : $placeholder_image;
            $gallery = !empty($post['gallery']) ? $post['gallery'] : [];
            $productType = get_the_terms($_product_id, 'product_type') ? current(get_the_terms($_product_id, 'product_type'))->slug : '';
            $productURL = get_the_permalink($_product_id);
            if ($productType === 'simple') {
                $regularPrice = $_product->get_regular_price();
                $salePrice = $_product->get_sale_price();
                $priceDiff = (float)$regularPrice - (float)$salePrice;
                $priceDiscount = round(($priceDiff / $regularPrice) * 100);
            }

            if (function_exists('gsWooCheckProductInCart')) {
                $itemOnCart = gsWooCheckProductInCart($_product_id);
            } else {
                $itemOnCart = [];
            }

            $cartItems = Shortcodes::checkGSIfProductInCart();

            ?>
            <?php echo $isSuperDeal ? "<div class='swiper-slide h-auto'>"  : ""; ?>
            <div class="gs-product-<?php echo esc_attr($_product_id); ?> <?php echo esc_attr($superDealChildClass); ?> gs-obsidian-product-card h-full grid grid-cols-[170px,1fr] gap-5 border border-[#EAEEF2] rounded-lg bg-white overflow-hidden transition-all hover:shadow-product-hover">
                <div class="borobazar-obsidian-product-card-thumb relative h-full min-h-[150px] border-r border-[#EAEEF2]">
                    <a href="<?php echo esc_url($productURL); ?>" class="borobazar-image-fade-in" aria-label="<?php echo esc_attr($postTitle); ?>">
                        <?php
                        /**
                         * Hook: gs_grid_loop_item_thumbnails.
                         *
                         * @hooked gsGridLoopItemThumbnailsFunc - 10
                         */
                        do_action('gs_grid_loop_item_thumbnails', $_product_id, $thumbnail_url, $gallery, $placeholder_image, 'on');
                        ?>
                        <?php if (!$isInStock) { ?>
                            <span class="py-[2px] px-2 bg-error text-white text-[12px] uppercase rounded-full absolute top-[10px] right-[10px] z-1"><?php esc_html_e('OUT OF STOCK', 'gridster') ?></span>
                        <?php } ?>
                        <?php if ($isInStock && $isOnSale && $productType === 'simple') { ?>
                            <span class="py-[2px] px-2 bg-brand text-white text-[12px] uppercase rounded-full absolute top-[10px] right-[10px] z-1">
                            <?php
                                echo sprintf(
                                    /* translators: %s: Discount.*/
                                    __('Save %s %%','gridster'),$priceDiscount
                                    );
                            ?>
                            </span>
                        <?php } ?>
                        <?php if ($isInStock && $isOnSale && $productType === 'variable') { ?>
                            <span class="py-[2px] px-2 bg-brand text-white text-[12px] uppercase rounded-full absolute top-[10px] right-[10px] z-1"><?php esc_html_e('ON SALE', 'gridster') ?></span>
                        <?php } ?>
                        <?php if ($_product->backorders_allowed()) { ?>
                            <span class="py-[2px] px-2 bg-brand text-white text-[12px] uppercase rounded-full absolute top-[10px] right-[10px] z-1">
                                <?php echo esc_html__('Pre Order', 'borobazar'); ?>
                            </span>
                        <?php } ?>

                    </a>
                    <?php if (($showQuickView === 'on' && class_exists('RedQWooCommerceQuickView')) && $productType !== 'redq_rental') { ?>
                        <a href="#redq-quick-view-modal" class="button-redq-woocommerce-quick-view m-auto !absolute inset-0 w-full h-full opacity-0 transition-all hover:opacity-100 hover:bg-[rgba(0,0,0,0.3)]" data-product_id="<?php echo esc_attr($_product_id); ?>" aria-label="<?php echo esc_attr__('View Products', 'borobazar'); ?>" rel="modal:open">
                            <span class="flex items-center justify-center w-full h-full text-white">
                                <svg stroke="currentColor" fill="none" stroke-width="2.1" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="1.5em" width="1.5em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                    <circle cx="12" cy="12" r="3" />
                                </svg>
                            </span>
                        </a>
                    <?php } else { ?>
                        <a href="<?php echo esc_url($productURL); ?>" class="grid grid-cols-[1fr,max-content] items-center bg-[#F4F6F8] rounded-[4px] mt-auto no-underline transition-all text-gray-600 hover:text-black font-medium" data-product_id="<?php echo esc_attr($_product_id); ?>" aria-label="<?php echo esc_attr__('View Products', 'borobazar'); ?>">
                            <span class="flex items-center justify-center w-full h-full text-main">
                                <svg stroke="currentColor" fill="none" stroke-width="2.1" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="1.5em" width="1.5em" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                    <circle cx="12" cy="12" r="3" />
                                </svg>
                            </span>
                        </a>
                    <?php } ?>
                </div> <!-- end .borobazar-obsidian-product-card-thumb -->

                <div class="borobazar-obsidian-product-card-meta flex justify-between gap-3">
                    <div class="pt-[18px]">

                        <a href="<?php echo esc_url($productURL); ?>" class="borobazar-obsidian-product-card-title block text-sm sm:text-md leading-6 overflow-hidden text-ellipsis no-underline">
                            <?php echo apply_filters('gs_grid_item_title', $postTitle); ?>
                        </a>

                        <div class="borobazar-obsidian-product-card-price text-sm sm:text-lg  font-bold text-main mt-0.5 sm:mt-1.5">
                            <?php echo apply_filters('gs_grid_loop_item_price', $priceHTML); ?>
                        </div>

                        <div class="<?php echo esc_attr($display); ?> flex-col justify-between border-l border-[#EAEAEA] z-1 borobazar-qty-button borobazar-qty-button-<?php echo esc_attr($_product_id); ?>">
                            <span class="text-sm sm:text-base text-[#02b290] font-semibold quantity borobazar-cart-qty borobazar-cart-product-<?php echo esc_attr($_product_id); ?>">
                                <?php echo wp_kses('x' . $qty, $allowedHTML); ?>
                            </span>
                        </div>

                    </div>

                    <?php if (!empty($unit)) : ?>
                        <span class="block unit text-sm text-dark mb-[10px]">
                            <?php echo wp_kses($unit, $allowedHTML); ?>
                            <?php echo wp_kses($label, $allowedHTML); ?>
                        </span>
                    <?php endif; ?>

                    <?php if ($isInStock) { ?>
                        <?php if ($productType === 'simple') { ?>

                            <?php
                            $product_link = '';
                            if (class_exists('BoroBazarHelper')) {
                                $product_link = '#';
                            } else {
                                $product_link = $productURL;
                            }
                            ?>


                            <!-- Add to cart button -->
                            <a href="<?php echo esc_url($product_link); ?>" class="<?php echo esc_attr($cartButton); ?> flex-col items-center border-l border-[#EAEAEA] no-underline transition-all text-gray-600 hover:text-black font-medium product_type_simple borobazar-update-qty borobazar-add-to-cart-<?php echo esc_attr($_product_id); ?>" data-product_id="<?php echo esc_attr($_product_id); ?>" aria-label="<?php echo esc_attr__('Add to Cart', 'borobazar'); ?>">
                                <span class="w-[70px] h-1/2 flex items-center justify-center ml-auto">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.2999 7.29998H8.70002V1.69996C8.70002 1.31364 8.38638 1 7.99994 1C7.61362 1 7.29998 1.31364 7.29998 1.69996V7.29998H1.69996C1.31364 7.29998 1 7.61362 1 7.99994C1 8.38638 1.31364 8.70002 1.69996 8.70002H7.29998V14.2999C7.29998 14.6864 7.61362 15 7.99994 15C8.38638 15 8.70002 14.6864 8.70002 14.2999V8.70002H14.2999C14.6864 8.70002 15 8.38638 15 7.99994C15 7.61362 14.6864 7.29998 14.2999 7.29998Z" fill="#000000" stroke="#000000" stroke-width="0.5" />
                                    </svg>
                                </span>
                                <span class="flex items-center justify-center w-[70px] h-1/2 cursor-pointer transition-all border-t border-[#EAEAEA] decrement borobazar-update-qty" title="<?php echo esc_attr__('Decrement', 'borobazar-helper'); ?>"">
                                    <svg width=" 16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <g clip-path="url(#clip0_3845_18)">
                                        <path d="M8.80005 7.19922H15.2C15.6416 7.19922 16 7.55767 16 7.99917C16 8.44082 15.6416 8.79927 15.2 8.79927H8.80005H7.2H0.799951C0.358447 8.79927 0 8.44082 0 7.99917C0 7.55767 0.358447 7.19922 0.799951 7.19922H7.2H8.80005Z" fill="#ACACAC" stroke="#ACACAC" stroke-width="0.5" />
                                    </g>
                                    <defs>
                                        <clipPath>
                                            <rect width="16" height="16" fill="#ACACAC" />
                                        </clipPath>
                                    </defs>
                                    </svg>
                                </span>
                            </a>
                            <!-- End -->

                            <!-- Counter -->
                            <div class="<?php echo esc_attr($display); ?> flex-col justify-between border-l border-[#EAEAEA] z-1 borobazar-qty-button borobazar-qty-button-<?php echo esc_attr($_product_id); ?>">
                                <span class="flex items-center justify-center w-[70px] h-1/2 border-b border-[#EAEAEA] bg-[#F8F8F9] cursor-pointer transition-all decrement borobazar-update-qty" data-product_id="<?php echo esc_attr($_product_id); ?>" data-type="plus" data-stock_qty="<?php echo esc_attr($stock_qty); ?>" title="<?php echo esc_attr__('Increment', 'borobazar'); ?>">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.2999 7.29998H8.70002V1.69996C8.70002 1.31364 8.38638 1 7.99994 1C7.61362 1 7.29998 1.31364 7.29998 1.69996V7.29998H1.69996C1.31364 7.29998 1 7.61362 1 7.99994C1 8.38638 1.31364 8.70002 1.69996 8.70002H7.29998V14.2999C7.29998 14.6864 7.61362 15 7.99994 15C8.38638 15 8.70002 14.6864 8.70002 14.2999V8.70002H14.2999C14.6864 8.70002 15 8.38638 15 7.99994C15 7.61362 14.6864 7.29998 14.2999 7.29998Z" fill="black" stroke="black" stroke-width="0.5" />
                                    </svg>
                                </span>
                                <span class="flex items-center justify-center w-[70px] h-1/2 cursor-pointer transition-all increment borobazar-update-qty" data-product_id="<?php echo esc_attr($_product_id); ?>" data-type="minus" data-stock_qty="<?php echo esc_attr($stock_qty); ?>" title="<?php echo esc_attr__('Decrement', 'borobazar'); ?>">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_3845_18)">
                                            <path d="M8.80005 7.19922H15.2C15.6416 7.19922 16 7.55767 16 7.99917C16 8.44082 15.6416 8.79927 15.2 8.79927H8.80005H7.2H0.799951C0.358447 8.79927 0 8.44082 0 7.99917C0 7.55767 0.358447 7.19922 0.799951 7.19922H7.2H8.80005Z" fill="black" stroke="black" stroke-width="0.5" />
                                        </g>
                                        <defs>
                                            <clipPath>
                                                <rect width="16" height="16" fill="black" />
                                            </clipPath>
                                        </defs>
                                    </svg>

                                </span>
                            </div>
                            <!-- End Counter -->

                        <?php } ?>
                    <?php } ?>
                </div> <!-- end .borobazar-obsidian-product-card-meta -->
            </div> <!-- end .borobazar-obsidian-product-card -->
            <?php echo $isSuperDeal ? "</div>"  : ""; ?>

        <?php } ?>
        <!-- Grid Loop End -->
        <?php echo $isSuperDeal ? "</div>" : ""; ?>


        <?php if ($isSuperDeal) : ?>
            <!-- .swiper-scrollbar -->
            <div class="swiper-scrollbar slider-mobile-scrollbar"></div>
            <!-- end .swiper-scrollbar -->

            <!-- .swiper navigation -->
            <div class="gs-super-deal-prev-button absolute top-1/2 left-1.5 md:left-9 bg-white w-9 md:w-11 4xl:w-13 h-9 md:h-11 4xl:h-13 rounded-full z-1 flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white gs-slider-prev-nav-button">
                <svg class="w-2 4xl:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M106.218,12.005,115.2,3.026a1.316,1.316,0,0,0,0-1.856l-.787-.786a1.315,1.315,0,0,0-1.857,0l-10.69,10.69a1.325,1.325,0,0,0,0,1.863l10.68,10.68a1.315,1.315,0,0,0,1.857,0l.787-.786a1.314,1.314,0,0,0,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>
            <div class="gs-super-deal-next-button absolute top-1/2 right-1.5 md:right-9 bg-white w-9 md:w-11 4xl:w-13 h-9 md:h-11 4xl:h-13 rounded-full z-1 flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white  gs-slider-next-nav-button gs-grid-next-nav-<?php echo esc_attr($uniqueId); ?>" data-class="gs-grid-next-nav-<?php echo esc_attr($uniqueId); ?>">
                <svg class="w-2 4xl:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M110.841,12.005l-8.978-8.979a1.316,1.316,0,0,1,0-1.856l.787-.786a1.315,1.315,0,0,1,1.857,0l10.69,10.69a1.325,1.325,0,0,1,0,1.863l-10.68,10.68a1.315,1.315,0,0,1-1.857,0l-.787-.786a1.314,1.314,0,0,1,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>
            <!-- end .swiper navigation -->
        <?php endif; ?>

    </div> <!-- end .gs-product-grid-main-wrap -->
    <?php echo $isSuperDeal ? "</div>" : ""; ?>
<?php } else { ?>
    <?php
    /**
     * Hook: gs_grid_loop_empty.
     *
     * @hooked gsGridLoopItemsEmptyFunc - 10
     */
    do_action('gs_grid_loop_empty');
    ?>
<?php } ?>

<?php
/**
 * Hook: gs_grid_loop_items_after_wrap.
 */
do_action('gs_grid_loop_items_after_wrap');
?>