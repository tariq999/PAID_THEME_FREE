<?php

/**
 * Grid Name : Maple.
 *
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/gridster/product-grid/grid_alpine.php.
 */
defined('ABSPATH') || exit;

use GridSter\Front\Shortcodes;

?>

<?php
/**
 * Hook: gs_grid_loop_items_before_wrap.
 */
do_action('gs_grid_loop_items_before_wrap');

$parentClass  = $superDealParentClass = $superDealChildClass = $childClass = '';
$isSuperDeal = false;
$childClass   = 'gs-maple-product-card-item';
$uniqueId     = uniqid();
$gridName     = !empty($blockName) ? $blockName : '';
$showQuickView = get_theme_mod('woo_preview_pop_switch', 'on');
if ($gridName === 'gridster/super-deals') {
    $isSuperDeal = true;
    $superDealParentClass = "gs-super-deal-slider-{$templateSlug} swiper";
    $superDealChildClass = "gs-super-deal-slider-item-{$templateSlug}";
} else {
    $superDealParentClass  = "gs-grid-item-wrap gs-maple-grid-wrap {$gridClass}";
}
?>

<?php if (!empty($posts)) { ?>

    <?php echo $isSuperDeal ? "<div class='w-full overflow-hidden md:max-w-[50%] lg:max-w-none'>"  : ""; ?>
    <div class="gs-product-grid-main-wrap !grid-cols-[repeat(auto-fit,_minmax(370px,_1fr))] <?php echo esc_attr($superDealParentClass); ?>">
        <?php echo $isSuperDeal ? "<div class='swiper-wrapper'>"  : ""; ?>

        <!-- Grid Loop start -->
        <?php foreach ($posts as $key => $post) { ?>

            <?php
            $cartItems   = [];
            $_product    = !empty($post['ID']) ? wc_get_product($post['ID']) : null;
            $_product_id = !empty($_product) ? $_product->get_id() : "";

            if (function_exists('gsWooCheckProductInCart')) {
                $qty = gsWooCheckProductInCart($_product_id);
            } else {
                $qty = [];
            }

            $display = $qty ? "flex" : "hidden";
            $cartButton = $qty ? 'hidden' : 'flex';
            $qty_class = 'gs-qty-button gs-qty-button-' . $_product_id;
            $postTitle = !empty($post['post_title']) ? $post['post_title'] : "";
            $isOnSale =  !empty($_product) ? $_product->is_on_sale() : "";
            $isInStock = !empty($_product) ? $_product->is_in_stock() : "";
            $priceHTML = !empty($_product) ? $_product->get_price_html() : "";
            $stock_qty = !empty($post['stock']) ? $post['stock'] : -1;
            $unit = !empty($post['unit']) ? $post['unit'] : '';
            $label = !empty($post['unit_label']) ? $post['unit_label'] : '';
            $thumbnail_url = !empty($post['thumbnail']['url']) ? $post['thumbnail']['url'] : $placeholder_image;
            $gallery = !empty($post['gallery']) ? $post['gallery'] : [];
            $productType = get_the_terms($_product_id, 'product_type') ? current(get_the_terms($_product_id, 'product_type'))->slug : '';
            $productURL = get_the_permalink($_product_id);
            if ($productType === 'simple') {
                $regularPrice = $_product->get_regular_price();
                $salePrice = $_product->get_sale_price();
                $priceDiff = (float)$regularPrice - (float)$salePrice;
                $priceDiscount = round(($priceDiff / $regularPrice) * 100);
            }

            if (function_exists('gsWooCheckProductInCart')) {
                $itemOnCart = gsWooCheckProductInCart($_product_id);
            } else {
                $itemOnCart = [];
            }

            $cartItems = Shortcodes::checkGSIfProductInCart();

            ?>
            <?php echo $isSuperDeal ? "<div class='swiper-slide h-auto'>"  : ""; ?>
            <div class="gs-product-<?php echo esc_attr($_product_id); ?> <?php echo esc_attr($superDealChildClass); ?> gs-maple-product-card h-full p-[10px] grid grid-cols-[130px,1fr] lg:grid-cols-[130px,1fr]  2xl:grid-cols-[180px,1fr] gap-5 border border-[#EAEEF2] rounded bg-white overflow-hidden transition-all hover:shadow-product-hover">
                <div class="borobazar-maple-product-card-thumb relative h-44 md:h-36 lg:h-48 xl:h-40 2xl:h-48 overflow-hidden">
                    <a href="<?php echo esc_url($productURL); ?>" class="borobazar-image-fade-in" aria-label="<?php echo esc_attr($postTitle); ?>">
                        <?php
                        /**
                         * Hook: gs_grid_loop_item_thumbnails.
                         *
                         * @hooked gsGridLoopItemThumbnailsFunc - 10
                         */
                        do_action('gs_grid_loop_item_thumbnails', $_product_id, $thumbnail_url, $gallery, $placeholder_image, 'on');
                        ?>
                        <?php if (!$isInStock) { ?>
                            <span class="product-badge text-xs text-white font-bold bg-error rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                                <?php echo esc_html__('OUT OF STOCK', 'gridster'); ?>
                            </span>
                        <?php } ?>

                        <?php if ($isInStock && $isOnSale && $productType === 'simple') { ?>
                            <span class="product-badge text-xs text-white font-bold bg-brand rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                                <?php
                                echo sprintf(
                                    /* translators: %s: Discount.*/
                                    __('Save %s %%', 'gridster'),
                                    $priceDiscount
                                );
                                ?>
                            </span>
                        <?php } ?>
                        <?php if ($isInStock && $isOnSale && $productType === 'variable') { ?>
                            <span class="product-badge text-xs text-white font-bold bg-brand rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                                <?php esc_html_e('On Sale', 'gridster') ?>
                            </span>
                        <?php } ?>
                        <?php if ($_product->backorders_allowed()) { ?>
                            <span class="product-badge text-xs text-white font-bold bg-brand rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                                <?php echo esc_html__('Pre Order', 'borobazar'); ?>
                            </span>
                        <?php } ?>
                    </a>
                </div> <!-- end .borobazar-maple-product-card-thumb -->

                <div class="borobazar-maple-product-card-meta flex flex-col py-[18px] md:py-3 pr-[5px]">
                    <div class="borobazar-maple-product-card-price text-sm sm:text-base text-main font-semibold mb-0.5 sm:mb-1.5">
                        <?php echo apply_filters('gs_grid_loop_item_price', $priceHTML); ?>
                    </div>

                    <a href="<?php echo esc_url($productURL); ?>" class="borobazar-maple-product-card-title block text-sm sm:text-md leading-6 overflow-hidden text-ellipsis no-underline mb-3">
                        <?php echo apply_filters('gs_grid_item_title', $postTitle); ?>
                    </a>

                    <?php if (!empty($unit)) : ?>
                        <span class="block unit text-sm text-dark mb-[10px]">
                            <?php echo wp_kses($unit, $allowedHTML); ?>
                            <?php echo wp_kses($label, $allowedHTML); ?>
                        </span>
                    <?php endif; ?>

                    <?php if ($isInStock) { ?>
                        <?php if ($productType === 'simple') { ?>

                            <?php
                            $product_link = '';
                            if (class_exists('BoroBazarHelper')) {
                                $product_link = '#';
                            } else {
                                $product_link = $productURL;
                            }
                            ?>


                            <!-- Add to cart button -->
                            <a href="<?php echo esc_url($product_link); ?>" class="<?php echo esc_attr($cartButton); ?> grid grid-cols-[1fr,max-content] items-center bg-[#F4F6F8] rounded-[4px] mt-auto no-underline transition-all text-gray-600 hover:text-black font-medium product_type_simple borobazar-update-qty borobazar-add-to-cart-<?php echo esc_attr($_product_id); ?>" data-product_id="<?php echo esc_attr($_product_id); ?>" aria-label="<?php echo esc_attr__('Add to Cart', 'borobazar'); ?>">
                                <span class="flex items-center justify-center"><?php esc_html__('Add', 'gridster'); ?> </span>
                                <span class="w-10 h-10 bg-[#E5E8EC] rounded-tr-[4px] rounded-br-[4px] flex items-center justify-center ml-auto">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.2999 7.29998H8.70002V1.69996C8.70002 1.31364 8.38638 1 7.99994 1C7.61362 1 7.29998 1.31364 7.29998 1.69996V7.29998H1.69996C1.31364 7.29998 1 7.61362 1 7.99994C1 8.38638 1.31364 8.70002 1.69996 8.70002H7.29998V14.2999C7.29998 14.6864 7.61362 15 7.99994 15C8.38638 15 8.70002 14.6864 8.70002 14.2999V8.70002H14.2999C14.6864 8.70002 15 8.38638 15 7.99994C15 7.61362 14.6864 7.29998 14.2999 7.29998Z" fill="#ACACAC" stroke="#ACACAC" stroke-width="0.5" />
                                    </svg>
                                </span>
                            </a>
                            <!-- End -->

                            <!-- Counter -->
                            <div class="<?php echo esc_attr($display); ?> justify-between bg-brand rounded-[4px] z-1 mt-auto borobazar-qty-button borobazar-qty-button-<?php echo esc_attr($_product_id); ?>">

                                <span class="flex items-center justify-center w-10 h-10 cursor-pointer rounded-tl-[4px] rounded-bl-[4px] transition-all bg-black/10 decrement borobazar-update-qty" data-product_id="<?php echo esc_attr($_product_id); ?>" data-type="minus" data-stock_qty="<?php echo esc_attr($stock_qty); ?>" title="<?php echo esc_attr__('Decrement', 'borobazar'); ?>">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_3845_18)">
                                            <path d="M8.80005 7.19922H15.2C15.6416 7.19922 16 7.55767 16 7.99917C16 8.44082 15.6416 8.79927 15.2 8.79927H8.80005H7.2H0.799951C0.358447 8.79927 0 8.44082 0 7.99917C0 7.55767 0.358447 7.19922 0.799951 7.19922H7.2H8.80005Z" fill="white" stroke="white" stroke-width="0.5" />
                                        </g>
                                        <defs>
                                            <clipPath>
                                                <rect width="16" height="16" fill="white" />
                                            </clipPath>
                                        </defs>
                                    </svg>

                                </span>

                                <span class="self-center text-sm sm:text-base text-white font-semibold quantity borobazar-cart-qty borobazar-cart-product-<?php echo esc_attr($_product_id); ?>">
                                    <?php echo wp_kses('x' . $qty, $allowedHTML); ?>
                                </span>

                                <span class="flex items-center justify-center w-10 h-10 cursor-pointer rounded-tr-[4px] rounded-br-[4px] transition-all bg-black/10 increment borobazar-update-qty" data-product_id="<?php echo esc_attr($_product_id); ?>" data-type="plus" data-stock_qty="<?php echo esc_attr($stock_qty); ?>" title="<?php echo esc_attr__('Increment', 'borobazar'); ?>">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14.2999 7.29998H8.70002V1.69996C8.70002 1.31364 8.38638 1 7.99994 1C7.61362 1 7.29998 1.31364 7.29998 1.69996V7.29998H1.69996C1.31364 7.29998 1 7.61362 1 7.99994C1 8.38638 1.31364 8.70002 1.69996 8.70002H7.29998V14.2999C7.29998 14.6864 7.61362 15 7.99994 15C8.38638 15 8.70002 14.6864 8.70002 14.2999V8.70002H14.2999C14.6864 8.70002 15 8.38638 15 7.99994C15 7.61362 14.6864 7.29998 14.2999 7.29998Z" fill="white" stroke="white" stroke-width="0.5" />
                                    </svg>
                                </span>
                            </div>
                            <!-- End Counter -->

                        <?php } else { ?>

                            <!-- View Products button -->
                            <?php if (($showQuickView === 'on' && class_exists('RedQWooCommerceQuickView')) && $productType !== 'redq_rental') { ?>
                                <a href="#redq-quick-view-modal" class="button-redq-woocommerce-quick-view grid grid-cols-[1fr,max-content] items-center bg-[#F4F6F8] rounded-[4px] mt-auto no-underline transition-all text-gray-600 hover:text-black font-medium" data-product_id="<?php echo esc_attr($_product_id); ?>" aria-label="<?php echo esc_attr__('View Products', 'borobazar'); ?>" rel="modal:open">
                                    <span class="flex items-center justify-center"><?php echo esc_attr__('View Products', 'borobazar'); ?></span>
                                    <span class="w-10 h-10 bg-[#E5E8EC] rounded-tr-[4px] rounded-br-[4px] flex items-center justify-center ml-auto">
                                        <svg stroke="currentColor" fill="none" stroke-width="2.1" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="1.25em" width="1.25em" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                            <circle cx="12" cy="12" r="3" />
                                        </svg>
                                    </span>
                                </a>
                            <?php } else { ?>
                                <a href="<?php echo esc_url($productURL); ?>" class="grid grid-cols-[1fr,max-content] items-center bg-[#F4F6F8] rounded-[4px] mt-auto no-underline transition-all text-gray-600 hover:text-black font-medium" data-product_id="<?php echo esc_attr($_product_id); ?>" aria-label="<?php echo esc_attr__('View Products', 'borobazar'); ?>">
                                    <span class="flex items-center justify-center"><?php echo esc_attr__('View Products', 'borobazar'); ?></span>
                                    <span class="w-10 h-10 bg-[#E5E8EC] rounded-tr-[4px] rounded-br-[4px] flex items-center justify-center ml-auto">
                                        <svg width="11" height="17" viewBox="0 0 11 17" fill="none" xmlns="http://www.w3.org/2000/svg" class="inline-flex borobazar-rtl-rotate">
                                            <path d="M9.41065 9.03532L2.66522 15.7785C2.36923 16.0737 1.88969 16.0737 1.59296 15.7785C1.29697 15.4833 1.29697 15.0037 1.59296 14.7085L7.80335 8.50034L1.59371 2.29219C1.29772 1.99696 1.29772 1.51741 1.59371 1.22143C1.88969 0.926191 2.36998 0.926191 2.66597 1.22143L9.4114 7.96455C9.70284 8.25674 9.70284 8.74382 9.41065 9.03532Z" fill="#737D90" stroke="#737D90" />
                                        </svg>
                                    </span>
                                </a>
                            <?php } ?>
                            <!-- End View Products button -->
                        <?php } ?>
                    <?php } ?>
                </div> <!-- end .borobazar-maple-product-card-meta -->
            </div> <!-- end .borobazar-maple-product-card -->
            <?php echo $isSuperDeal ? "</div>"  : ""; ?>

        <?php } ?>
        <!-- Grid Loop End -->
        <?php echo $isSuperDeal ? "</div>" : ""; ?>


        <?php if ($isSuperDeal) : ?>
            <!-- .swiper-scrollbar -->
            <div class="swiper-scrollbar slider-mobile-scrollbar"></div>
            <!-- end .swiper-scrollbar -->

            <!-- .swiper navigation -->
            <div class="gs-super-deal-prev-button absolute top-1/2 left-1.5 md:left-9 bg-white w-9 md:w-11 4xl:w-13 h-9 md:h-11 4xl:h-13 rounded-full z-1 flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white gs-slider-prev-nav-button">
                <svg class="w-2 4xl:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M106.218,12.005,115.2,3.026a1.316,1.316,0,0,0,0-1.856l-.787-.786a1.315,1.315,0,0,0-1.857,0l-10.69,10.69a1.325,1.325,0,0,0,0,1.863l10.68,10.68a1.315,1.315,0,0,0,1.857,0l.787-.786a1.314,1.314,0,0,0,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>
            <div class="gs-super-deal-next-button absolute top-1/2 right-1.5 md:right-9 bg-white w-9 md:w-11 4xl:w-13 h-9 md:h-11 4xl:h-13 rounded-full z-1 flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white  gs-slider-next-nav-button gs-grid-next-nav-<?php echo esc_attr($uniqueId); ?>" data-class="gs-grid-next-nav-<?php echo esc_attr($uniqueId); ?>">
                <svg class="w-2 4xl:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M110.841,12.005l-8.978-8.979a1.316,1.316,0,0,1,0-1.856l.787-.786a1.315,1.315,0,0,1,1.857,0l10.69,10.69a1.325,1.325,0,0,1,0,1.863l-10.68,10.68a1.315,1.315,0,0,1-1.857,0l-.787-.786a1.314,1.314,0,0,1,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>
            <!-- end .swiper navigation -->
        <?php endif; ?>

    </div> <!-- end .gs-product-grid-main-wrap -->
    <?php echo $isSuperDeal ? "</div>" : ""; ?>
<?php } else { ?>
    <?php
    /**
     * Hook: gs_grid_loop_empty.
     *
     * @hooked gsGridLoopItemsEmptyFunc - 10
     */
    do_action('gs_grid_loop_empty');
    ?>
<?php } ?>

<?php
/**
 * Hook: gs_grid_loop_items_after_wrap.
 */
do_action('gs_grid_loop_items_after_wrap');
?>