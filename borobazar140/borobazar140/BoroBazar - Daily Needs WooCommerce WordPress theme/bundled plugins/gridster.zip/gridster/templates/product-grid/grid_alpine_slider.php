<?php

/**
 * Grid Name : Helium.
 *
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/gridster/product-grid/grid_alpine.php.
 */
defined('ABSPATH') || exit;

use GridSter\Front\Shortcodes;

?>

<?php
/**
 * Hook: gs_grid_loop_items_before_wrap.
 */
do_action('gs_grid_loop_items_before_wrap');

$parent_class = $child_class = '';

$parent_class  = 'swiper gs_grid_product_slider';
$child_class   = 'swiper-slide gs-helium-product-card-item';
$unique_id     = uniqid();
$showQuickView = get_theme_mod('woo_preview_pop_switch', 'on');
?>

<?php if (!empty($posts)) { ?>
    <div class="gs-product-grid-main-wrap">
        <div class="<?php echo esc_attr($parent_class); ?>" id="gs-grid-slider-id-<?php echo esc_attr($unique_id); ?>" data-id="gs-grid-slider-id-<?php echo esc_attr($unique_id); ?>">
            <div class="swiper-wrapper">
                <!-- Grid Loop start -->
                <?php foreach ($posts as $key => $post) { ?>
                    <?php if ($key === 'see_all' && $featured_product_view === 'slider') { ?>
                        <?php
                        /**
                         * Hook: gs_grid_slider_see_all.
                         *
                         * @hooked gsGridSliderSeeAll - 10
                         */
                        do_action('gs_grid_slider_see_all', $seeAll);
                        ?>
                    <?php } else { ?>
                        <?php
                        $cartItems   = [];
                        $_product    = !empty($post['ID']) ? wc_get_product($post['ID']) : null;
                        $_product_id = !empty($_product) ? $_product->get_id() : "";

                        if (function_exists('gsWooCheckProductInCart')) {
                            $qty = gsWooCheckProductInCart($_product_id);
                        } else {
                            $qty = [];
                        }

                        $display = $qty ? "flex" : "hidden";
                        $cartButton = $qty ? 'hidden' : 'flex';
                        $qty_class = 'gs-qty-button gs-qty-button-' . $_product_id;
                        $postTitle = !empty($post['post_title']) ? $post['post_title'] : "";
                        $isOnSale =  !empty($_product) ? $_product->is_on_sale() : "";
                        $isInStock = !empty($_product) ? $_product->is_in_stock() : "";
                        $priceHTML = !empty($_product) ? $_product->get_price_html() : "";
                        $stock_qty = !empty($post['stock']) ? $post['stock'] : -1;
                        $unit = !empty($post['unit']) ? $post['unit'] : '';
                        $label = !empty($post['unit_label']) ? $post['unit_label'] : '';
                        $thumbnail_url = !empty($post['thumbnail']['url']) ? $post['thumbnail']['url'] : $placeholder_image;
                        $gallery = !empty($post['gallery']) ? $post['gallery'] : [];
                        $productType = get_the_terms($_product_id, 'product_type') ? current(get_the_terms($_product_id, 'product_type'))->slug : '';
                        $productURL = get_the_permalink($_product_id);
                        if ($productType === 'simple') {
                            $regularPrice = $_product->get_regular_price();
                            $salePrice = $_product->get_sale_price();
                            $priceDiff = (float)$regularPrice - (float)$salePrice;
                            $priceDiscount = round(($priceDiff / $regularPrice) * 100);
                        }

                        if (function_exists('gsWooCheckProductInCart')) {
                            $itemOnCart = gsWooCheckProductInCart($_product_id);
                        } else {
                            $itemOnCart = [];
                        }

                        $cartItems = Shortcodes::checkGSIfProductInCart();
                        ?>

                        <div class="<?php echo esc_attr($child_class . ' ' . "gs-product-$_product_id"); ?>">
                            <div class="borobazar-alpine-product-card gs-product-<?php echo esc_attr($_product_id); ?> shadow-product rounded bg-white overflow-hidden transition-all hover:shadow-product-hover">
                                <div class="borobazar-alpine-product-card-thumb relative h-40 sm:h-48">
                                    <a class="borobazar-image-fade-in" href="<?php echo esc_url($productURL); ?>" aria-label="<?php echo esc_attr($postTitle); ?>">
                                        <?php
                                        /**
                                         * Hook: gs_grid_loop_item_thumbnails.
                                         *
                                         * @hooked gsGridLoopItemThumbnailsFunc - 10
                                         */
                                        do_action('gs_grid_loop_item_thumbnails', $_product_id, $thumbnail_url, $gallery, $placeholder_image, 'on');
                                        ?>

                                        <?php if (!$isInStock) { ?>
                                            <span class="product-badge text-xs text-white font-bold bg-error rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                                                <?php echo esc_html__('OUT OF STOCK', 'gridster'); ?>
                                            </span>
                                        <?php } ?>

                                        <?php if ($isInStock && $isOnSale && $productType === 'simple') { ?>
                                            <span class="product-badge text-xs text-white font-bold bg-brand rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                                                <?php
                                                    echo sprintf(
                                                        /* translators: %s: Discount.*/
                                                        __('Save %s %%','gridster'),$priceDiscount
                                                    );
                                                ?>
                                            </span>
                                        <?php } ?>
                                        <?php if ($isInStock && $isOnSale && $productType === 'variable') { ?>
                                            <span class="product-badge text-xs text-white font-bold bg-brand rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                                                <?php esc_html_e('On Sale', 'gridster') ?>
                                            </span>
                                        <?php } ?>

                                        <?php if ($_product->backorders_allowed()) { ?>
                                            <span class="product-badge text-xs text-white font-bold bg-brand rounded-3xl py-0.5 px-1.5 absolute top-3 sm:top-3.5 left-3 sm:left-3.5 z-1">
                                                <?php echo esc_html__('PRE ORDER', 'borobazar'); ?>
                                            </span>
                                        <?php } ?>

                                    </a>

                                    <?php if ($isInStock) { ?>
                                        <?php if ($productType === 'simple') { ?>
                                            <?php
                                            $product_link = '';
                                            if (class_exists('BoroBazarHelper')) {
                                                $product_link = '#';
                                            } else {
                                                $product_link = $productURL;
                                            }
                                            ?>
                                            <!-- Add to cart button -->
                                            <a href="<?php echo esc_url($product_link); ?>" class="<?php echo esc_attr($cartButton); ?> add-to-cart absolute items-center justify-center w-9 h-9 rounded-full bottom-3 right-3.5 bg-brand z-1 text-white no-underline transition-all hover:text-white hover:bg-brand-hover focus:text-white product_type_simple  gs-update-qty gs-add-to-cart-<?php echo esc_attr($_product_id); ?>" data-product_id="<?php echo esc_attr($_product_id); ?>" aria-label="<?php echo esc_attr__('Add to Cart', 'gridster'); ?>">
                                                <svg width="15" height="15" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M15.2 7.2H8.80005V0.799951C8.80005 0.358447 8.4416 0 7.99995 0C7.55845 0 7.2 0.358447 7.2 0.799951V7.2H0.799951C0.358447 7.2 0 7.55845 0 7.99995C0 8.4416 0.358447 8.80005 0.799951 8.80005H7.2V15.2C7.2 15.6416 7.55845 16 7.99995 16C8.4416 16 8.80005 15.6416 8.80005 15.2V8.80005H15.2C15.6416 8.80005 16 8.4416 16 7.99995C16 7.55845 15.6416 7.2 15.2 7.2Z" fill="currentColor" stroke="white" stroke-width="0.5" />
                                                </svg>
                                            </a>
                                            <!-- End -->

                                            <!-- Counter -->
                                            <div class="<?php echo esc_attr($display); ?> justify-between p-0.75 absolute left-1/2 bottom-3 -translate-x-1/2 w-32 sm:w-36 4xl:w-40 h-9 sm:h-9.5 bg-white rounded-3xl z-1 shadow-counter gs-qty-button gs-qty-button-<?php echo esc_attr($_product_id); ?>">

                                                <span class="flex items-center justify-center w-11 sm:w-12 text-lightest cursor-pointer rounded-3xl transition-all hover:bg-base decrement gs-update-qty" data-product_id="<?php echo esc_attr($_product_id); ?>" data-type="minus" data-stock_qty="<?php echo esc_attr($stock_qty); ?>" title="<?php echo esc_attr__('Decrement', 'gridster'); ?>">
                                                    <svg width="16" height="4" viewBox="0 0 16 4" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M8.80005 1.20001H15.2C15.6416 1.20001 16 1.55846 16 1.99996C16 2.44161 15.6416 2.80006 15.2 2.80006H8.80005H7.2H0.799951C0.358447 2.80006 0 2.44161 0 1.99996C0 1.55846 0.358447 1.20001 0.799951 1.20001H7.2H8.80005Z" fill="currentColor" stroke="currentColor" stroke-width="0.5" />
                                                    </svg>
                                                </span>

                                                <span class="self-center text-sm sm:text-base text-main font-semibold quantity gs-cart-qty gs-cart-product-<?php echo esc_attr($_product_id); ?>">
                                                    <?php echo esc_html__($qty, 'gridster'); ?>
                                                </span>

                                                <span class="flex items-center justify-center w-11 sm:w-12 text-lightest cursor-pointer rounded-3xl transition-all hover:bg-base increment gs-update-qty" data-product_id="<?php echo esc_attr($_product_id); ?>" data-type="plus" data-stock_qty="<?php echo esc_attr($stock_qty); ?>" title="<?php echo esc_attr__('Increment', 'gridster'); ?>">
                                                    <svg width="15" height="15" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M15.2 7.2H8.80005V0.799951C8.80005 0.358447 8.4416 0 7.99995 0C7.55845 0 7.2 0.358447 7.2 0.799951V7.2H0.799951C0.358447 7.2 0 7.55845 0 7.99995C0 8.4416 0.358447 8.80005 0.799951 8.80005H7.2V15.2C7.2 15.6416 7.55845 16 7.99995 16C8.4416 16 8.80005 15.6416 8.80005 15.2V8.80005H15.2C15.6416 8.80005 16 8.4416 16 7.99995C16 7.55845 15.6416 7.2 15.2 7.2Z" fill="currentColor" stroke="#8C969F" stroke-width="0.5" />
                                                    </svg>
                                                </span>
                                            </div>
                                            <!-- End -->

                                        <?php } else { ?>

                                            <?php if (($showQuickView === 'on' && class_exists('RedQWooCommerceQuickView')) && $productType !== 'redq_rental') { ?>

                                                <a href="#redq-quick-view-modal" class="button-redq-woocommerce-quick-view  absolute flex items-center justify-center w-9 h-9 rounded-full bottom-3 right-3.5 bg-brand z-1 text-white no-underline transition-all hover:text-white hover:bg-brand-hover focus:text-white" data-product_id="<?php echo $_product_id; ?>" aria-label="<?php echo esc_attr__('Quick View', 'gridster'); ?>" rel="modal:open">
                                                    <svg stroke="currentColor" fill="none" stroke-width="2.1" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="1.25em" width="1.25em" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                                        <circle cx="12" cy="12" r="3" />
                                                    </svg>
                                                </a>

                                            <?php } else { ?>

                                                <a href="<?php echo esc_url($productURL); ?>" class="add-to-cart absolute flex items-center justify-center w-9 h-9 rounded-full bottom-3 right-3.5 bg-brand z-1 text-white no-underline transition-all hover:text-white hover:bg-brand-hover focus:text-white" aria-label="<?php echo esc_attr__('View Details', 'gridster'); ?>">
                                                    <svg stroke="currentColor" fill="none" stroke-width="2.2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" height="1.35em" width="1.35em" xmlns="http://www.w3.org/2000/svg">
                                                        <line x1="5" y1="12" x2="19" y2="12" />
                                                        <polyline points="12 5 19 12 12 19" />
                                                    </svg>
                                                </a>

                                            <?php } ?>
                                        <?php } ?>
                                    <?php } ?>
                                </div>
                                <div class="px-3 sm:px-4 pb-3 sm:pb-6 pt-2.5 sm:pt-3">
                                    <div class="borobazar-alpine-product-card-price text-sm sm:text-base text-main font-semibold mb-0.5 sm:mb-1.5">
                                        <?php echo apply_filters('gs_grid_loop_item_price', $priceHTML); ?>
                                        <?php if (!empty($unit)) { ?>
                                            <span class="unit text-sm sm:text-base text-main font-semibold">
                                                <?php
                                                echo esc_html__($label, 'gridster');
                                                echo esc_html__($unit, 'gridster');
                                                ?>
                                            </span>
                                        <?php } ?>
                                    </div>
                                    <a href="<?php echo esc_url($productURL); ?>" class="borobazar-alpine-product-card-title block text-sm sm:text-md leading-6 overflow-hidden text-ellipsis no-underline">
                                        <?php echo apply_filters('gs_grid_item_title', $postTitle); ?>
                                    </a>
                                </div>

                            </div>
                        </div>
                    <?php } ?>
                <?php } ?>
                <!-- Grid loop end -->
            </div>
            <!-- / end swiper wrapper -->

            <div class="swiper-scrollbar slider-mobile-scrollbar"></div>
            <input type="hidden" class="gs_slider_controls" data-template-name="<?php echo esc_attr($attributes['gridTemplate']); ?>" data-slides-per-view-desktop="<?php echo esc_attr($sliderControls['slidesPerView']['desktop']); ?>" data-slides-per-view-laptop="<?php echo esc_attr($sliderControls['slidesPerView']['laptop']); ?>" data-slides-per-view-tab="<?php echo esc_attr($sliderControls['slidesPerView']['tab']); ?>" data-slides-per-view-mobile="<?php echo esc_attr($sliderControls['slidesPerView']['mobile']); ?>" data-space-between-desktop="<?php echo esc_attr($sliderControls['spaceBetween']['desktop']); ?>" data-space-between-laptop="<?php echo esc_attr($sliderControls['spaceBetween']['laptop']); ?>" data-space-between-tab="<?php echo esc_attr($sliderControls['spaceBetween']['tab']); ?>" data-space-between-mobile="<?php echo esc_attr($sliderControls['spaceBetween']['mobile']); ?>" data-loop="<?php echo esc_attr($sliderControls['loop']); ?>" data-navigation="<?php echo esc_attr($sliderControls['navigation']); ?>" data-pagination="<?php echo esc_attr($sliderControls['pagination']); ?>" data-autoplay="<?php echo esc_attr($sliderControls['autoplay']); ?>" data-speed="<?php echo esc_attr($sliderControls['speed']); ?>">
        </div>

        <?php if (isset($featured_product_view) && $featured_product_view === 'slider' && $sliderControls['pagination']) { ?>
            <div class="gs-swiper-pagination gs-swiper-pagination-<?php echo esc_attr($unique_id); ?>" data-class="gs-swiper-pagination-<?php echo esc_attr($unique_id); ?>">
            </div>
            <!-- /end pagination -->
        <?php } ?>

        <?php if (isset($featured_product_view) && $featured_product_view === 'slider' && $sliderControls['navigation']) { ?>
            <div class="absolute top-1/2 left-1.5 md:left-9 bg-white w-9 md:w-11 4xl:w-13 h-9 md:h-11 4xl:h-13 rounded-full z-1 flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white gs-slider-prev-nav-button gs-grid-prev-nav-<?php echo esc_attr($unique_id); ?>" data-class="gs-grid-prev-nav-<?php echo esc_attr($unique_id); ?>">
                <svg class="w-2 4xl:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M106.218,12.005,115.2,3.026a1.316,1.316,0,0,0,0-1.856l-.787-.786a1.315,1.315,0,0,0-1.857,0l-10.69,10.69a1.325,1.325,0,0,0,0,1.863l10.68,10.68a1.315,1.315,0,0,0,1.857,0l.787-.786a1.314,1.314,0,0,0,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>
            <div class="absolute top-1/2 right-1.5 md:right-9 bg-white w-9 md:w-11 4xl:w-13 h-9 md:h-11 4xl:h-13 rounded-full z-1 flex items-center justify-center shadow-fab cursor-pointer -translate-y-1/2 transition-all hover:bg-brand hover:text-white  gs-slider-next-nav-button gs-grid-next-nav-<?php echo esc_attr($unique_id); ?>" data-class="gs-grid-next-nav-<?php echo esc_attr($unique_id); ?>">
                <svg class="w-2 4xl:w-2.5" xmlns="http://www.w3.org/2000/svg" width="14.1" height="24" viewBox="0 0 14.1 24">
                    <path d="M110.841,12.005l-8.978-8.979a1.316,1.316,0,0,1,0-1.856l.787-.786a1.315,1.315,0,0,1,1.857,0l10.69,10.69a1.325,1.325,0,0,1,0,1.863l-10.68,10.68a1.315,1.315,0,0,1-1.857,0l-.787-.786a1.314,1.314,0,0,1,0-1.857Z" transform="translate(-101.48)" fill="currentColor" />
                </svg>
            </div>
            <!-- / end navigation -->
        <?php } ?>

    </div>
<?php } else { ?>
    <?php
    /**
     * Hook: gs_grid_loop_empty.
     *
     * @hooked gsGridLoopItemsEmptyFunc - 10
     */
    do_action('gs_grid_loop_empty');
    ?>
<?php } ?>

<?php
/**
 * Hook: gs_grid_loop_items_after_wrap.
 */
do_action('gs_grid_loop_items_after_wrap');
?>