<?php
/* eslint no-use-before-define: 0 */

/**
 * Template Name : alpine.
 *
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/gridster/product-deals/coral.php.
 */
defined('ABSPATH') || exit;

use GridSter\Front\Shortcodes;

$parent_class  = $child_class = '';
$parent_class  = "gs-grid-item-wrap gs-coral-wrap $gridClass";
$child_class   = 'borobazar-coral-product-card-item';
$unique_id     = uniqid();
?>

<?php if (!empty($posts)) { ?>

    <!-- Post Loop start -->
    <?php foreach ($posts as $key => $post) { ?>

        <?php
        $_product    = !empty($post['ID']) ? wc_get_product($post['ID']) : null;
        $_product_id = !empty($_product) ? $_product->get_id() : "";
        $postTitle = !empty($post['post_title']) ? $post['post_title'] : "";
        $isOnSale =  !empty($_product) ? $_product->is_on_sale() : "";
        $isInStock = !empty($_product) ? $_product->is_in_stock() : "";
        $priceHTML = !empty($_product) ? $_product->get_price_html() : "";
        $thumbnail_url = !empty($post['thumbnail']['url']) ? $post['thumbnail']['url'] : $placeholder_image;
        $gallery = !empty($post['gallery']) ? $post['gallery'] : [];
        $productType = get_the_terms($_product_id, 'product_type') ? current(get_the_terms($_product_id, 'product_type'))->slug : '';
        $productURL = get_the_permalink($_product_id);
        $productLabel = !empty($attributes['label']) ? $attributes['label'] : '';
        $labelColor = !empty($attributes['labelColor']) ? $attributes['labelColor'] : '';
        $labelBgColor = !empty($attributes['labelBgColor']) ? $attributes['labelBgColor'] : '';
        $backgroundColor = !empty($attributes['backgroundColor']) ? $attributes['backgroundColor'] : '';
        $progressFgColor = !empty($attributes['progressFgColor']) ? $attributes['progressFgColor'] : '';
        $progressBgColor = !empty($attributes['progressBgColor']) ? $attributes['progressBgColor'] : '';

        $salePriceDateFrom = get_post_meta($_product_id, '_sale_price_dates_from', true);
        $salePriceDateTo = get_post_meta($_product_id, '_sale_price_dates_to', true);
        $salePriceDateFromFormatted   = date("M j, Y H:i:s", (int) $salePriceDateFrom);
        $salePriceDateToFormatted   = date("M j, Y H:i:s", (int) $salePriceDateTo);

        $stockStatus = !empty($_product) ? $_product->get_stock_status() : '';
        $stockCount = !empty($_product) ? $_product->get_stock_quantity() : '';
        $saleCount = get_post_meta($_product_id, 'total_sales', true);

        ?>

        <div class="gs-product-<?php echo esc_attr($_product_id); ?> flex flex-col borobazar-product-deal-coral relative w-full mx-auto max-w-md xl:max-w-sm 3xl:max-w-[22rem] 4xl:max-w-md rounded-[4px] pt-16 pb-10" style="background-color: <?php echo esc_html($backgroundColor); ?>;">
            <span class="absolute left-6 top-6 text-xs font-bold uppercase px-2 py-1 rounded-3xl" style="color: <?php echo esc_html($labelColor); ?>; background-color: <?php echo esc_html($labelBgColor); ?>;">
                <?php echo esc_html($productLabel); ?>
            </span>
            <figure class="borobazar-product-deal-coral-thumbnail m-0 flex flex-grow items-center justify-center h-48 w-full px-16 mx-auto relative">
                <?php
                /**
                 * Hook: gs_grid_loop_item_thumbnails.
                 *
                 * @hooked gsGridLoopItemThumbnailsFunc - 10
                 */
                do_action('gs_grid_loop_item_thumbnails', $_product_id, $thumbnail_url, $gallery, $placeholder_image, 'off');
                ?>
            </figure>

            <div class="borobazar-product-deal-coral-information mt-8 mx-7">
                <div class="borobazar-product-deal-coral-price text-center">
                    <?php echo apply_filters('gs_grid_loop_item_price', $priceHTML); ?>
                </div>
                <h6 class="m-0 text-center">
                    <a href="<?php echo esc_url($productURL); ?>" class="borobazar-coral-product-title font-normal no-underline text-black text-base font-body">
                        <?php echo apply_filters('gs_grid_item_title', $postTitle); ?>
                    </a>
                </h6>

                <div id="borobazar-coral-countdown" class="flex items-center justify-center mt-7 min-h-[67px]" data-date-from="<?php echo esc_attr($salePriceDateFromFormatted) ?>" data-date-to="<?php echo esc_attr($salePriceDateToFormatted) ?>"></div>

                <div class="rounded-[50px] h-[10px] mt-8" style="background-color: <?php echo esc_html($progressBgColor); ?>;">
                    <div id="borobazar-coral-progress-bar" class="rounded-[50px] h-full">
                        <div class="rounded-[50px] h-full" style="background-color: <?php echo esc_html($progressFgColor); ?>;"></div>
                    </div>
                </div>

                <div class="borobazar-coral-stock-manager flex items-center justify-between mt-4">
                    <span class="flex items-center">
                        <span>
                            <?php echo esc_attr__('Sold:', 'gridster'); ?>
                        </span>
                        <span class="text-main text-[15px] font-medium ml-1.5">
                            <?php echo esc_attr($saleCount); ?>
                            <?php echo esc_attr__('Items', 'gridster'); ?>
                        </span>
                    </span>
                    <span class="flex items-center">
                        <span>
                            <?php echo esc_attr__('Available:', 'gridster'); ?>
                        </span>
                        <span class="text-main text-[15px] font-medium ml-1.5">
                            <?php echo esc_attr($stockStatus); ?>
                        </span>
                    </span>
                </div>

            </div>

        </div>


    <?php } ?>

<?php } else { ?>
    <?php
    /**
     * Hook: gs_grid_loop_empty.
     *
     * @hooked gsGridLoopItemsEmptyFunc - 10
     */
    do_action('gs_grid_loop_empty');
    ?>
<?php } ?>