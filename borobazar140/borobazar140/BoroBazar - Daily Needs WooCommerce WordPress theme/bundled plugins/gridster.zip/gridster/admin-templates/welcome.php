<div class="gs-theme-setup-main-wrapper">
  <div class="gs-theme-description gs-theme-setup-content-wrapper">
    <!-- LOGO -->
    <div class="gs-getting-started-logo-wrapper">
      <div class="gs-logo">
        <img src="<?php echo esc_url(GS_ASSETS.'global/images/gridster.svg'); ?>" alt="GridSter">
      </div>
      <div class="gs-getting-started-version">
        <span>
          <?php
                    echo esc_html__('v.', 'gridster');
                    echo esc_attr(GS_VERSION);
                    ?>
        </span>
      </div>
    </div>

    <!-- DESCRIPTION -->
    <div class="gs-getting-started-description-wrapper">
      <h1 class="gs-theme-setup-content-title"><?php esc_html_e('Welcome', 'gridster'); ?></h1>
      <p class="description-text">
        <?php echo esc_html__('GridSter is a WordPress plugin, which has multiple Gutenberg blocks with different functionalities. It has multiple grid support with different views.', 'gridster'); ?>
      </p>
    </div>


    <!-- faq wrapper -->
    <div class="gs-getting-started-faq-section">
      <h3><?php echo esc_html__('F.A.Q', 'gridster'); ?></h3>

      <div class="gs-getting-started-faq-wrapper">
        <div id="gs_getting_started_faq">
          <!-- Accordion Item -->
          <h3 class="gs-getting-started-faq-header">
            <span class="faq-header-icon-expand">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-expand.svg'); ?>"
                alt="<?php esc_attr_e('Expand', 'gridster'); ?>">
            </span>
            <span class="faq-header-icon-collapse">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-collapse.svg'); ?>"
                alt="<?php esc_attr_e('Collapse', 'gridster'); ?>">
            </span>
            <?php esc_html_e('What is Gridster plugin?', 'gridster'); ?>
          </h3>
          <div class="gs-getting-started-faq-content">
            <p>
              <?php esc_html_e('Gridster is an gutenberg block grid plugin which contains a numerous amount of blocks with different functionalities.', 'gridster'); ?>
            </p>
          </div>

          <!-- Accordion Item -->
          <h3 class="gs-getting-started-faq-header">
            <span class="faq-header-icon-expand">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-expand.svg'); ?>"
                alt="<?php esc_attr_e('Expand', 'gridster'); ?>">
            </span>
            <span class="faq-header-icon-collapse">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-collapse.svg'); ?>"
                alt="<?php esc_attr_e('Collapse', 'gridster'); ?>">
            </span>
            <?php esc_html_e('What is must required for Gridster plugin?', 'gridster'); ?>
          </h3>
          <div class="gs-getting-started-faq-content">
            <p><?php esc_html_e('WooCommerce plugin is must required for using the GridSter plugin', 'gridster'); ?></p>
          </div>

          <!-- Accordion Item -->
          <h3 class="gs-getting-started-faq-header">
            <span class="faq-header-icon-expand">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-expand.svg'); ?>"
                alt="<?php esc_attr_e('Expand', 'gridster'); ?>">
            </span>
            <span class="faq-header-icon-collapse">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-collapse.svg'); ?>"
                alt="<?php esc_attr_e('Collapse', 'gridster'); ?>">
            </span>
            <?php esc_html_e('How can I use this plugin?', 'gridster'); ?>
          </h3>
          <div class="gs-getting-started-faq-content">
            <p>
              <?php esc_html_e('After installing & activating the plugin, you can use the gutenberg blocks in page editor. There is a category section named "GridSter", where all the listed blocks are located.', 'gridster'); ?>
            </p>
          </div>

          <!-- Accordion Item -->
          <h3 class="gs-getting-started-faq-header">
            <span class="faq-header-icon-expand">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-expand.svg'); ?>"
                alt="<?php esc_attr_e('Expand', 'gridster'); ?>">
            </span>
            <span class="faq-header-icon-collapse">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-collapse.svg'); ?>"
                alt="<?php esc_attr_e('Collapse', 'gridster'); ?>">
            </span>
            <?php esc_html_e('Can I override the grid template file?', 'gridster'); ?>
          </h3>
          <div class="gs-getting-started-faq-content">
            <p>
              <?php esc_html_e('Yes, you can override the grid templates. Create a folder named "gridster > product-grid". There you can copy & paste the files from plugins template folder to override.', 'gridster'); ?>
            </p>
          </div>

          <!-- Accordion Item -->
          <h3 class="gs-getting-started-faq-header">
            <span class="faq-header-icon-expand">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-expand.svg'); ?>"
                alt="<?php esc_attr_e('Expand', 'gridster'); ?>">
            </span>
            <span class="faq-header-icon-collapse">
              <img src="<?php echo esc_url(GS_ASSETS.'admin/images/accordion-collapse.svg'); ?>"
                alt="<?php esc_attr_e('Collapse', 'gridster'); ?>">
            </span>
            <?php esc_html_e('Do I need to use Gutenberg plugin or the default Gutenberg facilities provided by the WordPress is enough?', 'gridster'); ?>
          </h3>
          <div class="gs-getting-started-faq-content">
            <p>
              <?php esc_html_e('There is no conflict whether to use default Gutenberg facilities or the Gutenberg plugin.', 'gridster'); ?>
            </p>
          </div>
        </div>
      </div>
    </div>
    <!-- /faq wrapper -->
  </div>
</div>