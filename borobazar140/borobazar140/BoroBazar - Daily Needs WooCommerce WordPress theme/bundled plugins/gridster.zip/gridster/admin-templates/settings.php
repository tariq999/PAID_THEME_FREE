<?php
if (!empty($_POST) && check_admin_referer('nonce_gridster_settings', 'gridster_settings')) {
	$posted = $_POST;

	unset($posted['submit']);
	unset($posted['gridster_settings']);
	unset($posted['_wp_http_referer']);
	if ($_POST['submit'] == 'Save Changes') {
		update_option('gridster_settings', $posted);
	}

	if ($_POST['submit'] == 'Delete Transient') {
		if (false !== get_transient('transient_gs_product_details')) {
			delete_transient('transient_gs_product_details');
		}
		if (false !== get_transient('transient_gs_products')) {
			delete_transient('transient_gs_products');
		}
		if (false !== get_transient('transient_gs_all_attachment_by_products')) {
			delete_transient('transient_gs_all_attachment_by_products');
		}
		if (false !== get_transient('transient_gs_categories_by_products')) {
			delete_transient('transient_gs_categories_by_products');
		}
	}
}
$gridster_settings = [
	'gs_custom_body_class'         => '',
	'gs_lazyload_images'           => 'false',
	'gs_add_to_cart_notification'  => 'false',
	'gs_transient_switch'          => 'false',
	'gs_transient_expiration_time' => 'MINUTE_IN_SECONDS',
	'gs_set_search_page'           => '',
];

$gridster_settings = get_option('gridster_settings', true) !== true ? get_option('gridster_settings', true) : [];
$pages = get_pages();
?>

<div class="gs-theme-setup-main-wrapper">
	<div class="gs-theme-description gs-theme-setup-content-wrapper">
		<!-- LOGO -->
		<div class="gs-getting-started-logo-wrapper">
			<div class="gs-logo">
				<img src="<?php echo esc_url(GS_ASSETS . 'global/images/gridster.svg'); ?>" alt="GridSter">
			</div>
			<div class="gs-getting-started-version">
				<span>
					<?php
					echo esc_html__('v.', 'gridster');
					echo esc_attr(GS_VERSION);
					?>
				</span>
			</div>
		</div>

		<!-- DESCRIPTION -->
		<div class="gs-getting-started-description-wrapper">
			<h1 class="gs-theme-setup-content-title"><?php esc_html_e('Basic Settings', 'gridster'); ?></h1>
			<p class="description-text">
				<?php echo esc_html__('GridSter basic settings is located here.', 'gridster'); ?>
			</p>
		</div>

		<!-- Settings Start -->
		<form method="post">
			<div class="form-table gs-admin-settings-from">
				<div class="gs-input-group">
					<div class="gs-input-wrapper">
						<span class="gs-input-title"><?php esc_html_e('Custom Body Class', 'gridster'); ?></span>
						<div class="gs-input-field">
							<input type="text" class="widefat rq-rub-input-field" name="gs_custom_body_class" value="<?php echo (isset($gridster_settings['gs_custom_body_class']) && !empty($gridster_settings['gs_custom_body_class'])) ? $gridster_settings['gs_custom_body_class'] : ''; ?>">
						</div>
					</div>
				</div>
			</div>

			<div class="gs-input-group">
				<div class="gs-input-wrapper">
					<span class="gs-input-title">
						<?php esc_html_e('Enable Transient on ShortCodes', 'gridster'); ?>
					</span>
					<div class="gs-input-field">
						<select class="transient-allowed" name="gs_transient_switch">
							<option value="false" <?php if (isset($gridster_settings['gs_transient_switch'])) {
														echo $gridster_settings['gs_transient_switch'] == 'false' ? 'selected="selected"' : '';
													} ?>>
								<?php echo esc_html__('Disable', 'gridster'); ?>
							</option>
							<option value="true" <?php if (isset($gridster_settings['gs_transient_switch'])) {
														echo $gridster_settings['gs_transient_switch'] == 'true' ? 'selected="selected"' : '';
													} ?>>
								<?php echo esc_html__('Enable', 'gridster'); ?>
							</option>
						</select>
					</div>
				</div>
			</div>

			<div class="gs-input-group">
				<div class="gs-input-wrapper">
					<span class="gs-input-title">
						<?php esc_html_e('Transient expiration time', 'gridster'); ?>
					</span>
					<div class="gs-input-field">
						<p class="help_text"><?php echo esc_html__('This will work if transient is kept enable', 'gridster'); ?></p>
						<select class="transient-time-allowed" name="gs_transient_expiration_time">
							<option value="MINUTE_IN_SECONDS" <?php if (isset($gridster_settings['gs_transient_expiration_time'])) {
																	echo $gridster_settings['gs_transient_expiration_time'] == 'MINUTE_IN_SECONDS' ? 'selected="selected"' : '';
																} ?>>
								<?php echo esc_html__('Per minute', 'gridster'); ?>
							</option>
							<option value="HOUR_IN_SECONDS" <?php if (isset($gridster_settings['gs_transient_expiration_time'])) {
																echo $gridster_settings['gs_transient_expiration_time'] == 'HOUR_IN_SECONDS' ? 'selected="selected"' : '';
															} ?>>
								<?php echo esc_html__('Per hour', 'gridster'); ?>
							</option>

							<option value="DAY_IN_SECONDS" <?php if (isset($gridster_settings['gs_transient_expiration_time'])) {
																echo $gridster_settings['gs_transient_expiration_time'] == 'DAY_IN_SECONDS' ? 'selected="selected"' : '';
															} ?>>
								<?php echo esc_html__('Per day', 'gridster'); ?>
							</option>

							<option value="WEEK_IN_SECONDS" <?php if (isset($gridster_settings['gs_transient_expiration_time'])) {
																echo $gridster_settings['gs_transient_expiration_time'] == 'WEEK_IN_SECONDS' ? 'selected="selected"' : '';
															} ?>>
								<?php echo esc_html__('Per week', 'gridster'); ?>
							</option>

							<option value="MONTH_IN_SECONDS" <?php if (isset($gridster_settings['gs_transient_expiration_time'])) {
																	echo $gridster_settings['gs_transient_expiration_time'] == 'MONTH_IN_SECONDS' ? 'selected="selected"' : '';
																} ?>>
								<?php echo esc_html__('Per month', 'gridster'); ?>
							</option>

							<option value="YEAR_IN_SECONDS" <?php if (isset($gridster_settings['gs_transient_expiration_time'])) {
																echo $gridster_settings['gs_transient_expiration_time'] == 'YEAR_IN_SECONDS' ? 'selected="selected"' : '';
															} ?>>
								<?php echo esc_html__('Per year', 'gridster'); ?>
							</option>
						</select>
					</div>
				</div>
			</div>


			<div class="gs-input-group">
				<div class="gs-input-wrapper">
					<span class="gs-input-title">
						<?php esc_html_e('Set "See all products" page', 'gridster'); ?>
					</span>
					<div class="gs-input-field">
						<p class="help_text">
							<?php echo esc_html__('This will work properly if Product Search or Shop page is set completely.', 'gridster'); ?>
						</p>
						<select class="search-page-allowed" name="gs_set_search_page">

							<?php if (!empty($pages)) { ?>
								<option value="#">
									<?php echo esc_html__('Select an option', "gridster"); ?>
								</option>
								<?php foreach ($pages as $key => $page) { ?>
									<?php
									if (!empty($gridster_settings['gs_set_search_page']) && (int) $page->ID === (int) $gridster_settings['gs_set_search_page']) {
										$selected = ' selected="selected" ';
									} else {
										$selected = '';
									}
									?>
									<option value="<?php echo esc_attr($page->ID); ?>" <?php echo esc_attr($selected); ?>>
										<?php echo esc_html__($page->post_title, "gridster"); ?>
									</option>
								<?php } ?>
							<?php } else { ?>
								<option>
									<?php echo esc_html__('There are no pages', 'gridster'); ?>
								</option>
							<?php } ?>

						</select>
					</div>
				</div>
			</div>


			<?php wp_nonce_field('nonce_gridster_settings', 'gridster_settings'); ?>
			<div class="settings__page--btn--wrap">
				<p class="submit">
					<input type="submit" name="submit" id="submit" class="button gs-settings-submit button-primary" value="<?php esc_html_e('Save Changes', 'gridster'); ?>">
				</p>

				<p class="submit">
					<input type="submit" name="submit" id="submit" class="button gs-settings-submit button-primary" value="<?php esc_html_e('Delete Transient', 'gridster'); ?>">
				</p>
			</div>
		</form>
		<!-- Settings End -->
	</div>
</div>