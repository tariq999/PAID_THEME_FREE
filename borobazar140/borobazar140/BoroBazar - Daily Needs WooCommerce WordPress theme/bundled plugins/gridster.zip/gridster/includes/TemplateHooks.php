<?php

/**
 * GridSter Template Hooks.
 */
defined('ABSPATH') || exit;

/*
 * Grid Loop No Items.
 *
 * @see gsGridLoopItemsEmptyFunc()
 */
add_action('gs_grid_loop_empty', 'gsGridLoopItemsEmptyFunc', 10);

/*
 * Render before grid template.
 *
 * @see gsTemplateRenderBeforeWrap()
 */
add_action('gs_grid_template_render_before', 'gsTemplateRenderBeforeWrap', 10, 2);

/*
 * Render after grid template.
 *
 * @see gsTemplateRenderAfterWrap()
 */
add_action('gs_grid_template_render_after', 'gsTemplateRenderAfterWrap', 10);

/*
 * Grid Loop Thumbnails or Gallery or Lazyloading.
 *
 * @see gsGridLoopItemThumbnailsFunc()
 */
add_action('gs_grid_loop_item_thumbnails', 'gsGridLoopItemThumbnailsFunc', 10, 5);

/*
 * Gutenberg Blocks Heading area.
 *
 * @see gsShortCodeHeading()
 */
add_action('gs_grid_block_heading', 'gsShortCodeHeading', 10, 1);

/*
 * Gutenberg Blocks Heading area.
 *
 * @see gsGridSliderSeeAll()
 */
add_action('gs_grid_slider_see_all', 'gsGridSliderSeeAll', 10, 1);

// add_action('gs_grid_loop_items_before_wrap', 'gsGridSliderStart', 10, 1);
// add_action('gs_grid_loop_items_after_wrap', 'gsGridSliderEnd', 10, 1);