<?php

use GridSter\Classes;

defined('ABSPATH') || exit;

if (!function_exists('gsGridLoopItemsEmptyFunc')) {
    /**
     * gsGridLoopItemsEmptyFunc.
     *
     * @return void
     */
    function gsGridLoopItemsEmptyFunc()
    {
        $empty_image = GS_ASSETS . 'global/images/not-found.svg';
        $template = new Classes();

        return $template->gsGetTemplate(
            'global/empty_grid.php',
            [
                'empty_image'   => $empty_image,
                'alt_image'     => esc_html__('Nothing Found', 'gridster'),
                'empty_message' => esc_html__('Nothing Found :(', 'gridster'),
            ]
        );
    }
}

if (!function_exists('gsShortCodeHeading')) {
    /**
     * gsShortCodeHeading.
     *
     * @return void
     */
    function gsShortCodeHeading($attributes)
    {
        $html = $headerTitle = '';
        $showHeading = $showSeeAllButton = false;
        $allowedHTML      = wp_kses_allowed_html('post');
        $headerTitle      = isset($attributes) && !empty($attributes['headerTitle']) ? $attributes['headerTitle'] : esc_html__('On sale', 'gridster');
        $buttonTtitle     = isset($attributes) && !empty($attributes['buttonTtitle']) ? $attributes['buttonTtitle'] : esc_html__('See All Product', 'gridster');
        $showHeading      = isset($attributes) && !empty($attributes['showHeading']) ? $attributes['showHeading'] : false;
        $showSeeAllButton = isset($attributes) && !empty($attributes['showSeeAllButton']) ? $attributes['showSeeAllButton'] : false;

        if (!empty($attributes['seeAllType']) && $attributes['seeAllType'] === 'predefined') {
            $gridster_settings = get_option('gridster_settings', true) !== true ? get_option('gridster_settings', true) : [];
            $seeAllPageID   = !empty($gridster_settings) ? $gridster_settings['gs_set_search_page'] : "";
            $seeAllPageLink = !empty($gridster_settings) && $gridster_settings['gs_set_search_page'] != '#' ? get_page_link($seeAllPageID) : wc_get_page_permalink('shop');
        } else {
            $seeAllPageID   = !empty($attributes['seeAllPageLink']) && $attributes['seeAllPageLink'] !== '#' ? $attributes['seeAllPageLink'] : '';
            $seeAllPageLink = get_page_link((int) $seeAllPageID);
        }

        if ($showHeading && (!empty($headerTitle) || !empty($buttonTtitle))) {
            $html .= '<div class="gs-grid-section-heading">';
            if (!empty($headerTitle)) {
                $html .= '<h2 class="gs-grid-heading-title">';
                $html .= wp_kses($headerTitle, $allowedHTML);
                $html .= '</h2>';
            }
            if ($showSeeAllButton) {
                if (!empty($buttonTtitle)) {
                    $html .= '<a href="' . esc_url($seeAllPageLink) . '" class="gs-grid-button">';
                    $html .= wp_kses($buttonTtitle, $allowedHTML);
                    $html .= '</a>';
                }
            }
            $html .= '</div>';
        }
        echo apply_filters('gs_grid_block_heading_html', $html);
    }
}

if (!function_exists('gsGridSliderStart')) {
    /**
     * gsGridSliderStart.
     *
     * @return void
     */
    function gsGridSliderStart()
    {
        $html = '';
        $html .= '<div class="swiper product-category-slider">';
        $html .= '<div class="swiper-wrapper">';
        echo apply_filters('gs_product_slider_start', $html);
    }
}

if (!function_exists('gsGridSliderEnd')) {
    /**
     * gsGridSliderEnd.
     *
     * @return void
     */
    function gsGridSliderEnd()
    {
        $html = '';
        $html .= '</div>';
        $html .= '</div>';

        echo apply_filters('gs_product_slider_end', $html);
    }
}

if (!function_exists('gsGridSliderSeeAll')) {

    /**
     * gsGridSliderSeeAll
     *
     * @param  array $seeAll
     * @return void
     */
    function gsGridSliderSeeAll($seeAll)
    {
        $transfer_data = new Classes();
        $transfer_data->gsGetTemplate(
            'global/see_all.php',
            ['seeAll' => $seeAll]
        );
    }
}


if (!function_exists('gsTemplateRenderBeforeWrap')) {
    /**
     * gsTemplateRenderBeforeWrap.
     *
     * @param string $customClass
     * @param string $padding
     *
     * @return void
     */
    function gsTemplateRenderBeforeWrap($customClass, $padding)
    {
        $template = new Classes();

        return $template->gsGetTemplate(
            'global/template_render_before.php',
            [
                'customClass' => $customClass,
                'padding'     => $padding,
            ]
        );
    }
}

if (!function_exists('gsTemplateRenderAfterWrap')) {
    /**
     * gsTemplateRenderAfterWrap.
     *
     * @return void
     */
    function gsTemplateRenderAfterWrap()
    {
        $template = new Classes();

        return $template->gsGetTemplate(
            'global/template_render_after.php',
            []
        );
    }
}

if (!function_exists('gsGridLoopItemThumbnailsFunc')) {
    /**
     * gsGridLoopItemThumbnailsFunc.
     *
     * @return void
     */
    function gsGridLoopItemThumbnailsFunc($post_ID, $thumbnail_url, $gallery = null, $fallback_img = null, $slider = null)
    {
        $html = $imageSize = $width = $height = '';
        $imageRatio = [];

        $imageSize = apply_filters('single_product_archive_thumbnail_size', 'woocommerce_thumbnail');
        $imageRatio = wp_get_attachment_image_src(get_post_thumbnail_id($post_ID), $imageSize);
        $width = !empty($imageRatio) ? $imageRatio[1] : 300;
        $height = !empty($imageRatio) ? $imageRatio[2] : 300;

        $html .= '<img class="opacity-0 duration-200 transition-opacity gs-lazy-image" width="' . $width . '" height="' . $height . '" src="' . esc_url($thumbnail_url) . '" alt="item-image-' . $post_ID . '">';

        if (!empty($gallery) && $slider === 'on') {
            gsGridLoopItemThumbnailGalleryFunc($gallery, $fallback_img);
        }

        echo apply_filters('gs_grid_loop_item_image', $html);
    }
}

if (!function_exists('gsGridLoopItemThumbnailGalleryFunc')) {
    /**
     * gsGridLoopItemThumbnailGalleryFunc
     *
     * @param  array $gallery
     * @param  string $fallback_img
     * @return void
     */
    function gsGridLoopItemThumbnailGalleryFunc($gallery, $fallback_img)
    {
        $html = $width = $height = '';
        if (!empty($gallery) && isset($gallery)) {
            $splice_gallery_images = array_slice($gallery, 0, 1);
            $url = !empty($splice_gallery_images) ? $splice_gallery_images[0] : $fallback_img;

            if (!empty($url)) {
                if (attachment_url_to_postid($url) === 0) {
                    $width = 300;
                    $height = 300;
                } else {
                    $image_id = attachment_url_to_postid($url);
                    $image_attributes = wp_get_attachment_image_src($image_id, "woocommerce_thumbnail");
                    $width = !empty($image_attributes) ? $image_attributes['1'] : 300;
                    $height = !empty($image_attributes) ? $image_attributes['2'] : 300;
                }
            }

            $html .= ' <img class="thumb-1 opacity-0 transition-opacity duration-200" width="' . $width . '" height="' . $height . '" src="' . esc_url($url) . '" alt="product-grid-gallery-item">';
        }
        echo apply_filters('gs_grid_loop_item_image_gallery', $html);
    }
}

if (!function_exists('gsGridGetSavingsPercentange')) {
    /**
     * gsGridGetSavingsPercentange.
     *
     * @param mixed $_product_id
     *
     * @return void
     */
    function gsGridGetSavingsPercentange($_product_id)
    {
        $_product = wc_get_product($_product_id);
        if ($_product->is_type('variable')) {
            $var_regular_price = [];
            $var_sale_price = [];
            $var_diff_price = [];

            $available_variations = $_product->get_available_variations();
            foreach ($available_variations as $key => $available_variation) {
                $variation_id = $available_variation['variation_id']; // Getting the variable id of just the 1st product. You can loop $available_variations to get info about each variation.
                $variable_product = new WC_Product_Variation($variation_id);

                $variable_product_regular_price = $variable_product->get_regular_price();
                $variable_product_sale_price = $variable_product->get_sale_price();

                if (!empty($variable_product_regular_price)) {
                    $var_regular_price[] = $variable_product_regular_price;
                } else {
                    $var_regular_price[] = 0;
                }
                if (!empty($variable_product_sale_price)) {
                    $var_sale_price[] = $variable_product_sale_price;
                } else {
                    $var_sale_price[] = 0;
                }
            }

            foreach ($var_regular_price as $key => $reg_price) {
                if (isset($var_sale_price[$key]) && $var_sale_price[$key] !== 0) {
                    $var_diff_price[] = $reg_price - $var_sale_price[$key];
                } else {
                    $var_diff_price[] = 0;
                }
            }

            $best_key = array_search(max($var_diff_price), $var_diff_price);

            $regular_price = $var_regular_price[$best_key];
            $sale_price = $var_sale_price[$best_key];
        } else {
            $regular_price = $_product->get_regular_price();
            $sale_price = $_product->get_sale_price();
        }

        $regular_price = wc_get_price_to_display($_product, ['qty' => 1, 'price' => $regular_price]);
        $sale_price = wc_get_price_to_display($_product, ['qty' => 1, 'price' => $sale_price]);

        $savings = ceil((($regular_price - $sale_price) / $regular_price) * 100) . '%';

        return $savings;
    }
}
