<?php

namespace GridSter\Front;

defined('ABSPATH') || exit;

use GridSter\Traits\BlockPostData;
use GridSter\Traits\StyleScriptLoader;

/**
 * Scripts.
 */
class Scripts
{
    use StyleScriptLoader;
    use BlockPostData;

    /**
     * __construct.
     */
    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'loadScripts']);
    }

    /**
     * loadScripts.
     */
    public function loadScripts()
    {
        self::registerScripts();
        self::enqueueScript('swiper');
        self::enqueueScript('jquery.toast.min');
        self::enqueueScript('woo-quick-cart');
        self::enqueueScript('gs-global-main');
        self::enqueueScript('gs-client-main');

        self::localizeScripts('woo-quick-cart', 'gs_woocommerce', [
            'ajax_url'       => admin_url('admin-ajax.php'),
            'message'        => esc_html__('Message from ', 'gridster'),
            'cartItems'      => self::checkGSIfProductInCart(),
            'addToCartTimer' => get_theme_mod('woo_mini_cart_timer', 3500),
            'nonce'          => wp_create_nonce('gs_helper_ajax_nonce'),
        ]);
    }

    /**
     * registerScripts.
     */
    private static function registerScripts()
    {
        $register_scripts = apply_filters('gs_frontend_scripts_array', [
            'swiper' => [
                'src'     => GS_ASSETS . 'global/swiper-bundle.min.js',
                'deps'    => ['jquery', 'underscore'],
                'version' => '7.0.5',
            ],
            'jquery.toast.min' => [
                'src'     => GS_ASSETS . 'client/js/jquery.toast.min.js',
                'deps'    => [],
                'version' => GS_VERSION,
            ],
            'woo-quick-cart' => [
                'src'     => GS_ASSETS . 'client/js/woo-quick-cart.js',
                'deps'    => [],
                'version' => GS_VERSION,
            ],
            'gs-global-main' => [
                'src'     => GS_ASSETS . 'global/global-main.js',
                'deps'    => [],
                'version' => GS_VERSION,
            ],
            'gs-client-main' => [
                'src'     => GS_ASSETS . 'client/js/gs-main.js',
                'deps'    => [],
                'version' => GS_VERSION,
            ],
        ]);

        foreach ($register_scripts as $name => $key) {
            self::registerScript($name, $key['src'], $key['deps'], $key['version']);
        }
    }
}
