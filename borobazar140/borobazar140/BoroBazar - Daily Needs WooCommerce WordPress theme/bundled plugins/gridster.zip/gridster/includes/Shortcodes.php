<?php

namespace GridSter\Front;

// Exit if accessed directly.
defined('ABSPATH') || exit;

use GridSter\Traits\BlockHelper;
use GridSter\Traits\BlockPostData;

/**
 * Shortcodes.
 */
class Shortcodes
{
    use BlockHelper;
    use BlockPostData;

    public function __construct()
    {
        $this->prepareShortCodeTemplates();
        add_action('save_post', [$this, 'gsClearTransient']);
    }

    public function gsClearTransient()
    {
        if (false !== get_transient('transient_gs_product_details')) {
            delete_transient('transient_gs_product_details');
        }
        if (false !== get_transient('transient_gs_products')) {
            delete_transient('transient_gs_products');
        }
        if (false !== get_transient('transient_gs_all_attachment_by_products')) {
            delete_transient('transient_gs_all_attachment_by_products');
        }
        if (false !== get_transient('transient_gs_categories_by_products')) {
            delete_transient('transient_gs_categories_by_products');
        }
    }

    public function prepareShortCodeTemplates()
    {
        $templates_array = apply_filters('gs_shortcode_lists', [
            'bestSelling',
            'blockTitle',
            'cherryPickedOne',
            'featuredProducts',
            'handpickedCategory',
            'handpickedTag',
            'onSale',
            'recentProductGrid',
            'specialDeals',
            'superDeals',
            'topRated',
        ]);

        foreach ($templates_array as $template) {
            $this->requireShortCodeFiles($template);
        }
    }

    public function requireShortCodeFiles($template)
    {
        require_once GS_SHORTCODE_PATH . $template . '.php';
    }
}
