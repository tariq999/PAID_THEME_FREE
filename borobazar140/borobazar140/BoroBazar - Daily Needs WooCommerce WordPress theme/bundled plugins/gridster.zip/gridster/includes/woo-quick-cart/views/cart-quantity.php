<?php

global $product;

$qty = gsWooCheckProductInCart($product_id);

$display = $qty ? 'display:block;' : 'display:none;';
$qty_class = 'gs-qty-button gs-qty-button-' . $product_id;
$stock_qty = $product->get_manage_stock() ? $product->get_stock_quantity() : -1;

?>
<div class="<?php echo esc_attr($qty_class); ?>" style="<?php echo esc_attr($display); ?> margin-bottom: 10px;">
    <span data-product_id="<?php echo esc_attr($product_id); ?>" data-type="minus" data-stock_qty="<?php echo esc_attr($stock_qty); ?>" style="padding: 2px 5px; border: 1px solid red" class="gs-update-qty">-</span>
    <span class="gs-cart-qty gs-cart-product-<?php echo esc_attr($product_id); ?>"> <?php echo esc_attr($qty); ?> </span>
    <span data-product_id="<?php echo esc_attr($product_id); ?>" data-type="plus" data-stock_qty="<?php echo esc_attr($stock_qty); ?>" style="padding: 2px 5px; border: 1px solid red" class="gs-update-qty">+</span>
</div>