<?php
if (!function_exists('gsIsSimpleProduct')) {
    /**
     * gsIsSimpleProduct
     *
     * @param  mixed $product_id
     * @return void
     */
    function gsIsSimpleProduct($product_id)
    {
        return wc_get_product($product_id)->is_type('simple');
    }
}


/**
 * getGSCustomFields
 *
 * @param  integer $product_id
 * @return array
 */
function getGSCustomFields($product_id)
{
    $step  = get_post_meta($product_id, '_borobazar_woocommerce_step_down', true);
    $unit  = get_post_meta($product_id, '_borobazar_woocommerce_product_unit', true);
    $label = get_post_meta($product_id, '_borobazar_woocommerce_product_unit_label', true);

    return [
        'step'  => $step,
        'unit'  => $unit,
        'label' => $label
    ];
}


/**
 * gsProductAddToCartValidity
 *
 * @param  integer $product_id
 * @return bool
 */
function gsProductAddToCartValidity($product_id)
{
    $product_qty_in_cart      = WC()->cart->get_cart_item_quantities();
    $current_session_order_id = isset(WC()->session->order_awaiting_payment) ? absint(WC()->session->order_awaiting_payment) : 0;
    $product = wc_get_product($product_id);

    // Check stock based on stock-status.
    if (!$product->is_in_stock()) {
        return false;
    }

    // We only need to check products managing stock, with a limited stock qty.
    if (!$product->managing_stock() || $product->backorders_allowed()) {
        return true;
    }

    // Check stock based on all items in the cart and consider any held stock within pending orders.
    $held_stock     = wc_get_held_stock_quantity($product, $current_session_order_id);
    $required_stock = $product_qty_in_cart[$product->get_stock_managed_by_id()];
    $required_stock = 1 + $required_stock;

    if ($product->get_stock_quantity() < ($held_stock + $required_stock)) {
        return false;
    }

    return true;
}


/**
 * gsWooCheckProductInCart
 *
 * @param  integer $product_id
 * @return void
 */
function gsWooCheckProductInCart($product_id)
{
    if (!is_null(WC()->cart) && !WC()->cart->is_empty()) {
        $cart_items = WC()->cart->get_cart();

        if (!count($cart_items)) {
            return false;
        }

        foreach ($cart_items as $cart_item_key => $cart_item) {
            if ($cart_item['product_id'] === $product_id) {
                return $cart_item['quantity'];
            }
        }
    }

    return false;
}
