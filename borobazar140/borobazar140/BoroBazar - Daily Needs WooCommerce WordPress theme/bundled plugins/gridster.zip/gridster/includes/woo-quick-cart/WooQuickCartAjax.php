<?php

namespace GridSter\WooQuickCart;

/**
 * Woo_Quick_Cart_Ajax
 */
class WooQuickCartAjax
{
    /**
     * Action argument used by the nonce validating the AJAX request.
     *
     * @var string
     */
    const NONCE = 'gs_helper_ajax_nonce';

    /**
     * Initialize ajax class
     */
    public function __construct()
    {
        add_action('wp_ajax_gs_woocommerce_update_qty', [$this, 'gsWooCommerceUpdateQty']);
        add_action('wp_ajax_nopriv_gs_woocommerce_update_qty', [$this, 'gsWooCommerceUpdateQty']);
        add_action('wp_ajax_gs_woocommerce_clean_mini_cart', [$this, 'gsWooCommerceCleanMiniCart']);
        add_action('wp_ajax_nopriv_gs_woocommerce_clean_mini_cart', [$this, 'gsWooCommerceCleanMiniCart']);
    }

    /**
     * gsWooCommerceUpdateQty
     *
     * @return void
     */
    public function gsWooCommerceUpdateQty()
    {
        $deleted_items = [];
        $quantity      = 0;
        $product_id    = isset($_REQUEST['product_id']) ? (int) $_REQUEST['product_id'] : 0;
        $type          = isset($_REQUEST['type']) ? $_REQUEST['type'] : 'plus';

        //Check for product validity
        if ($type === 'plus' && !gsProductAddToCartValidity($product_id)) {
            wp_send_json_error([
                'message' => esc_html__('Sorry! Requested quantity is not available', 'gridster'),
            ]);
        }

        $cart_items = WC()->cart->get_cart();

        foreach ($cart_items as $cart_item_key => $cart_item) {
            $in_cart = gsWooCheckProductInCart($product_id);

            if (!$in_cart && !in_array($product_id, $deleted_items)) {
                WC()->cart->add_to_cart($product_id, 1);
            }

            if ($cart_item['product_id'] === $product_id) {
                $quantity = (int) $cart_item['quantity'];
                $updated_quantity = $type === 'plus' ?  $quantity + 1 :  $quantity - 1;

                WC()->cart->set_quantity($cart_item_key, $updated_quantity, true);

                if (!$updated_quantity) {
                    $deleted_items[] = $product_id;
                }
            }
        }

        if (empty($cart_items)) {
            WC()->cart->add_to_cart($product_id, 1);
        }

        wp_send_json_success([
            'quantity' => $type === 'plus' ?  $quantity + 1 : $quantity - 1,
            'message'  => esc_html__('Successfully added on cart', 'gridster'),
            'details'  => $this->gs_woocommerce_product_details($product_id, $type)
        ]);
    }

    /**
     * gsWooCommerceCleanMiniCart
     *
     * @return void
     */
    public function gsWooCommerceCleanMiniCart()
    {
        $deleted_items = [];
        $product_id    = isset($_REQUEST['product_id']) ? (int) $_REQUEST['product_id'] : 0;
        $type          = isset($_REQUEST['type']) ? $_REQUEST['type'] : 'clean_cart_item';

        $cart_items = WC()->cart->get_cart();

        foreach ($cart_items as $cart_item_key => $cart_item) {
            $in_cart = gsWooCheckProductInCart($product_id);
            if (!$in_cart && !in_array($product_id, $deleted_items)) {
                wp_send_json_success([
                    'message'  => esc_html__('Product not in cart', 'gridster'),
                    'details'  => $this->gs_woocommerce_product_details($product_id, $type)
                ]);
            }
            if ($cart_item['product_id'] === $product_id) {
                WC()->cart->remove_cart_item($product_id);
            }
            wp_send_json_success([
                'message'  => esc_html__('Successfully removed on cart', 'gridster'),
                'details'  => $this->gs_woocommerce_product_details($product_id, $type)
            ]);
            wp_die();
        }
    }

    /**
     * Product details
     *
     * @param int $product_id
     * @return array
     */
    public function gs_woocommerce_product_details($product_id, $type)
    {
        $message_type = $thumbnail_src = $title = '';
        $thumbnail_src = get_the_post_thumbnail_url($product_id);
        $title         = get_the_title($product_id);
        switch ($type) {
            case 'plus':
                $message_type = esc_html__('added to cart', 'gridster');
                break;

            case 'minus':
                $message_type = esc_html__('substracted from cart', 'gridster');
                break;

            case 'clean_cart_item':
                $message_type = esc_html__('removed from cart', 'gridster');
                break;

            default:
                $message_type = esc_html__('updated', 'gridster');
                break;
        }

        $markup =
            '<div class="if-toast">
                <img src="' . $thumbnail_src . '"/>
                <span class="if-toast-title">' . $title . '</span> 
                <span class="if-toast-message">' . $message_type . '</span>
            </div>';

        return [
            'id'        => $product_id,
            'title'     => $title,
            'thumbnail' => $thumbnail_src,
            'markup'    => $markup
        ];
    }
}
