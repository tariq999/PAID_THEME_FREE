<?php

namespace GridSter\WooQuickCart;

/**
 * Woo_Quick_Cart_Front
 */
class WooQuickCartFront
{
    public function __construct()
    {
        // add_action('woocommerce_after_shop_loop_item', [$this, 'woo_quickWooCommerceQuantityButton'], 9);
        add_filter('woocommerce_post_class', [$this, 'gs_product_css_class'], 10, 2);
        add_filter('woocommerce_loop_add_to_cart_args', [$this, 'gs_loop_add_to_cart_args'], 10, 2);
        add_filter('woocommerce_loop_add_to_cart_link', [$this, 'gs_loop_add_to_cart_link'], 10, 3);
    }

    /**
     * Add extra class on wooCommerce product listing
     *
     * @param array $classes
     * @param class $product
     * @return array
     */
    public function gs_product_css_class($classes, $product)
    {
        $classes[] = 'gs-product-' . $product->get_id();
        return $classes;
    }

    /**
     * Modify add to cart args
     *
     * @param array $args
     * @param object $product
     * @return array
     */
    public function gs_loop_add_to_cart_args($args, $product)
    {
        if (isset($args['class']) && empty($args['class'])) {
            return $args;
        }

        $classes = isset($args['class']) ? explode(' ', $args['class']) : false;

        if (($key = array_search('ajax_add_to_cart', $classes)) !== false) {
            unset($classes[$key]);
        }

        $classes[] = 'gs_ajax_add_to_cart';
        $classes[] = 'gs-update-qty';
        $classes[] = 'gs-add-to-cart-' . $product->get_id();

        $args['class'] = implode(' ', $classes);

        return $args;
    }

    /**
     * Modify add to cart link in shop page
     *
     * @param [type] $link
     * @param [type] $product
     * @param [type] $args
     * @return void
     */
    public function gs_loop_add_to_cart_link($link, $product, $args)
    {
        $product_id =  $product->get_id();
        $in_cart = gsWooCheckProductInCart($product_id);

        if ($in_cart) {
            return false;
        }

        return $link;
    }
}
