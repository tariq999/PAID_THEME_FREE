<?php

namespace GridSter\Traits;

defined('ABSPATH') || exit;
trait TemplateLoader
{

    /**
     * gsGetTemplate
     *
     * @param  string $template_name
     * @param  array $args
     * @param  string $template_path
     * @param  string $default_path
     * 
     */
    public function gsGetTemplate($template_name, $args = [], $template_path = '', $default_path = '')
    {
        if ($args && is_array($args)) {
            extract($args);
        }
        $located = $this->gsLocateTemplate($template_name, $template_path, $default_path);
        if (!file_exists($located)) {
            _doing_it_wrong(__FUNCTION__, sprintf('<code>%s</code> does not exist.', $located), '2.1');
            return;
        }
        $located = apply_filters('gs_get_template', $located, $template_name, $args, $template_path, $default_path);
        do_action('gs_before_template_part', $template_name, $template_path, $located, $args);
        include($located);
        do_action('gs_after_template_part', $template_name, $template_path, $located, $args);
    }


    /**
     * gsLocateTemplate
     *
     * @param  string $template_name
     * @param  string $template_path
     * @param  string $default_path
     * 
     */
    public function gsLocateTemplate($template_name, $template_path = '', $default_path = '')
    {
        if (!$template_path) {
            $template_path = GridSter()->templatePath();
        }
        if (!$default_path) {
            $default_path = GridSter()->pluginPath() . '/templates/';
        }

        $template = locate_template(
            [
                trailingslashit($template_path) . $template_name,
                $template_name
            ]
        );

        if (!$template) {
            $template = $default_path . $template_name;
        }

        return apply_filters('gs_locate_template', $template, $template_name, $template_path);
    }
}
