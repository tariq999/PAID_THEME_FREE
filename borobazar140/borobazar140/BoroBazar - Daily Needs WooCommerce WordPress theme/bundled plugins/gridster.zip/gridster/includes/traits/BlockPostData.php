<?php

namespace GridSter\Traits;

defined('ABSPATH') || exit;

use WP_Query;

trait BlockPostData
{
    use QueryTrait;
    use ImageResizer;

    /**
     * getGSRecentPosts.
     *
     * @param mixed $postsPerPage
     * @param mixed $orderBy
     * @param mixed $order
     *
     * @return void
     */
    public static function getGSRecentPosts($postsPerPage = null, $orderBy = null, $order = null)
    {
        $data = [];
        //  ********************** WPML Code **********************

        // $query = "
        //             SELECT * FROM $wpdb->posts
        //             LEFT JOIN $wpdb->term_relationships ON
        //             ($wpdb->posts.ID = $wpdb->term_relationships.object_id)
        //             LEFT JOIN $wpdb->term_taxonomy ON
        //             ($wpdb->term_relationships.term_taxonomy_id = $wpdb->term_taxonomy.term_taxonomy_id)
        //             LEFT JOIN {$wpdb->prefix}icl_translations ON
        //             ($wpdb->posts.ID = {$wpdb->prefix}icl_translations.element_id)
        //             WHERE $wpdb->posts.post_status = 'publish'
        //             AND $wpdb->term_taxonomy.taxonomy = 'category'
        //             AND {$wpdb->prefix}icl_translations.language_code = '".ICL_LANGUAGE_CODE."'
        //             GROUP BY ID ORDER BY post_date DESC
        //         ";

        $args = [
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => $postsPerPage,
            'orderby'        => $orderBy,
            'order'          => $order,
            'fields'         => 'ids',
        ];

        $products = new WP_Query($args);
        $results = QueryTrait::prepareProductGridData();

        foreach ($products->posts  as $key => $productId) {
            $data[] = $results[$productId];
        }

        return $data;
    }

    /**
     * getGSPostsByIDs.
     *
     * @param mixed $ids
     *
     * @return void
     */
    public static function getGSPostsByIDs($ids)
    {
        if (empty($ids)) {
            return [];
        }

        $data = $postIds = [];

        if (!is_array($ids)) {
            $postIds = explode(' ', $ids);
        } else {
            $postIds = $ids;
        }

        $results = QueryTrait::prepareProductGridData($ids);
        foreach ($postIds  as $key => $productId) {
            $product = $results[$productId];
            $data[] = $product;
        }

        return $data;
    }

    /**
     * getGSProductsSortBy.
     *
     * @param mixed $post_per_page
     * @param mixed $orderby
     * @param mixed $order
     * @param mixed $taxonomy
     * @param mixed $term
     * @param mixed $field
     * @param mixed $metaKey
     * @param mixed $metaValue
     *
     * @return void
     */
    public static function getGSProductsSortBy($post_per_page = 5, $orderby = null, $order = null, $taxonomy = null, $term = null, $field = null, $metaKey = null, $metaValue = null, $post__not_in = [])
    {
        $data = [];
        $args = [
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => $post_per_page,
            'meta_key'       => $metaKey,
            'orderby'        => $orderby,
            'order'          => $order,
            'fields'         => 'ids',
            'post__not_in'   => [$post__not_in]
        ];

        if (!empty($taxonomy) && !empty($term)) {
            $args['tax_query'] = [
                [
                    'taxonomy' => $taxonomy,
                    'field' => $field,
                    'terms' => $term,
                ],
            ];
        }

        if (!empty($metaKey) && !empty($metaValue)) {
            $args['meta_query'] = [
                [
                    'key' => $metaKey,
                    'value' => $metaValue,
                    'compare' => 'IN',
                ],
            ];
        }

        $products = new WP_Query($args);
        $results = QueryTrait::prepareProductGridData($products->posts);

        foreach ($products->posts  as $key => $productId) {
            $product = $results[$productId];
            $data[] = $product;
        }

        return $data;
    }

    /**
     * checkGSIfProductInCart.
     *
     * @return void
     */
    public static function checkGSIfProductInCart()
    {
        $result = [];

        if (class_exists('WooCommerce') && !empty(WC()->cart)) {
            $cart_items = WC()->cart->get_cart();
            if (!count($cart_items)) {
                return $result;
            }
            foreach ($cart_items as $cart_item_key => $cart_item) {
                $result[$cart_item['product_id']] = $cart_item['quantity'];
            }
        }

        return $result;
    }

    /**
     * getGSPostsByComplexMetaQuery.
     *
     * @param mixed $post_type
     * @param mixed $taxonomy
     * @param mixed $term
     * @param mixed $postsPerPage
     * @param mixed $orderBy
     * @param mixed $order
     * @param mixed $post__in
     * @param mixed $meta_query
     *
     * @return void
     */
    public static function getGSPostsByComplexMetaQuery($post_type = '', $taxonomy = null, $term = null, $postsPerPage = null, $orderBy = null, $order = null, $post__in = null, $meta_query = null)
    {
        $data = [];
        $args = [
            'fields'           => 'ids',
            'posts_per_page'   => $postsPerPage,
            'category'         => 0,
            'orderby'          => $orderBy,
            'order'            => $order,
            'include'          => [],
            'exclude'          => [],
            'meta_key'         => '',
            'meta_value'       => '',
            'post_type'        => $post_type,
            'post__in'         => $post__in,
            'suppress_filters' => true,
            'meta_query'       => $meta_query,
        ];
        $products = new WP_Query($args);
        $results = QueryTrait::prepareProductGridData($products->posts);

        foreach ($products->posts  as $key => $productId) {
            $product = $results[$productId];
            $data[] = $product;
        }

        return $data;
    }
}
