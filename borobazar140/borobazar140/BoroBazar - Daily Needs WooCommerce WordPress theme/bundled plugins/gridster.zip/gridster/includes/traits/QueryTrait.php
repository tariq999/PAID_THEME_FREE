<?php

namespace GridSter\Traits;

defined('ABSPATH') || exit;
trait QueryTrait
{
    /**
     * gsTransientTime.
     *
     * @return void
     */
    public static function gsTransientTime()
    {
        $setTransientTime = 60;
        $gridsterSettings = get_option('gridster_settings', true);
        $transientSwitch = isset($gridsterSettings['gs_transient_switch']) ? $gridsterSettings['gs_transient_switch'] : 'false';
        if ($transientSwitch === 'true') {
            $transientTime = isset($gridsterSettings['gs_transient_expiration_time']) ? $gridsterSettings['gs_transient_expiration_time'] : '';
            if ($transientTime === 'MINUTE_IN_SECONDS') {
                $setTransientTime = 60;
            } elseif ($transientTime === 'HOUR_IN_SECONDS') {
                $setTransientTime = 3600;
            } elseif ($transientTime === 'DAY_IN_SECONDS') {
                $setTransientTime = 86400;
            } elseif ($transientTime === 'WEEK_IN_SECONDS') {
                $setTransientTime = 604800;
            } elseif ($transientTime === 'MONTH_IN_SECONDS') {
                $setTransientTime = 2592000;
            } elseif ($transientTime === 'YEAR_IN_SECONDS') {
                $setTransientTime = 31536000;
            } else {
                $setTransientTime = 60;
            }
        }

        return [
            'transientSwitch' => $transientSwitch,
            'transientTime' => $setTransientTime,
        ];
    }

    /**
     * orderByClause.
     *
     * @param string $tableName
     * @param string $orderBy
     *
     * @return void
     */
    public static function orderByClause($tableName = null, $orderBy = null)
    {
        $orderby_clause = '';
        switch ($orderBy) {
            case 'post_name':
            case 'post_author':
            case 'post_date':
            case 'post_title':
            case 'post_modified':
            case 'post_parent':
            case 'post_type':
            case 'ID':
            case 'menu_order':
            case 'comment_count':
                $orderby_clause = "{$tableName}.{$orderBy}";
                break;
            case 'rand':
                $orderby_clause = 'RAND()';
                break;
            default:
                $orderby_clause = "{$tableName}.ID";
                break;
        }

        return $orderby_clause;
    }

    /**
     * getCategoriesByProducts.
     *
     * @return void
     */
    public static function getCategoriesByProducts()
    {
        $transientData = QueryTrait::gsTransientTime();

        $results = get_transient('transient_gs_categories_by_products');

        if (false === $results) {
            global $wpdb;

            $results = [];

            $termsByProducts = $wpdb->get_results(
                "
                    SELECT DISTINCT * from {$wpdb->prefix}term_relationships as tr 
                    INNER JOIN {$wpdb->prefix}term_taxonomy as tt 
                    ON tr.term_taxonomy_id=tt.term_taxonomy_id AND tt.taxonomy='product_cat' 
                    LEFT JOIN {$wpdb->prefix}terms as t on t.term_id=tt.term_id
                    ORDER BY tr.object_id ASC
                "
            );

            if (empty($termsByProducts)) {
                return $results;
            }

            foreach ($termsByProducts as $key => $term) {
                $results[$term->object_id][] = $term;
            }

            set_transient('transient_gs_categories_by_products', $results, MONTH_IN_SECONDS);
        }

        return $results;
    }

    /**
     * getAllAttachmentsByProducts.
     *
     * @return void
     */
    public static function getAllAttachmentsByProducts()
    {
        $transientData = QueryTrait::gsTransientTime();
        $results = get_transient('transient_gs_all_attachment_by_products');
        if (false === ($results)) {
            global $wpdb;
            $post_type = 'product';
            $query_str = $wpdb->prepare(
                "
                    SELECT DISTINCT p.ID, p.guid, p.post_status, pm.meta_value as attached_file  
                    FROM {$wpdb->prefix}posts as p
                    LEFT JOIN {$wpdb->prefix}postmeta as pm 
                    ON p.ID=pm.post_id
                    WHERE ID IN (
                                SELECT DISTINCT meta.meta_value 
                                FROM {$wpdb->prefix}postmeta as meta 
                                WHERE meta.post_id IN (SELECT DISTINCT ID FROM {$wpdb->prefix}posts 
                                WHERE post_type = %s 
                            ) 
                            AND meta.meta_key='_thumbnail_id')
                    AND pm.meta_key = '_wp_attached_file'
                ",
                $post_type
            );

            if ($transientData['transientSwitch'] === 'true') {
                $results = $wpdb->get_results($query_str, OBJECT);
                set_transient('transient_gs_all_attachment_by_products', $results, $transientData['transientTime']);
            } else {
                if (false !== get_transient('transient_gs_all_attachment_by_products')) {
                    delete_transient('transient_gs_all_attachment_by_products');
                }
                $results = $wpdb->get_results($query_str, OBJECT);
            }
        }

        return $results;
    }

    /**
     * productDetails.
     *
     * @return object
     */
    public static function productDetails()
    {
        $transientData = QueryTrait::gsTransientTime();
        $results = get_transient('transient_gs_product_details');
        if (false === ($results)) {
            global $wpdb;
            $postType = 'product';

            $query = $wpdb->prepare(
                "
                    SELECT DISTINCT
                        p.*,
                        MAX( CASE WHEN pm.meta_key = '_price' THEN pm.meta_value ELSE NULL END) AS price,
                        MAX( CASE WHEN pm.meta_key = '_regular_price' THEN pm.meta_value ELSE NULL END) AS regular_price,
                        MAX( CASE WHEN pm.meta_key = '_sale_price' THEN pm.meta_value ELSE NULL END) AS sale_price,
                        MAX( CASE WHEN pm.meta_key = '_sku' THEN pm.meta_value ELSE NULL END) AS sku,
                        MAX( CASE WHEN pm.meta_key = 'total_sales' THEN pm.meta_value ELSE NULL END) AS total_sales,
                        MAX( CASE WHEN pm.meta_key = '_stock_status' THEN pm.meta_value ELSE NULL END) AS stock_status,
                        MAX( CASE WHEN pm.meta_key = '_stock' THEN pm.meta_value ELSE NULL END) AS stock,
                        MAX( CASE WHEN pm.meta_key = '_thumbnail_id' THEN pm.meta_value ELSE NULL END) AS thumbnail_id,
                        MAX( CASE WHEN pm.meta_key = '_product_image_gallery' THEN pm.meta_value ELSE NULL END) AS product_gallery,
                        MAX( CASE WHEN pm.meta_key = '_wp_attached_file' THEN pm.meta_value ELSE NULL END) AS wp_attached_file,
                        MAX( CASE WHEN pm.meta_key = '_borobazar_woocommerce_product_unit' THEN pm.meta_value ELSE NULL END) AS unit,
                        MAX( CASE WHEN pm.meta_key = '_borobazar_woocommerce_product_unit_label' THEN pm.meta_value ELSE NULL END) AS unit_label,
                        MAX( CASE WHEN pm.meta_key = '_wc_average_rating' THEN pm.meta_value ELSE NULL END) AS average_rating,
                        MAX( CASE WHEN pm.meta_key = '_wc_review_count' THEN pm.meta_value ELSE NULL END) AS review_count
                    FROM
                        {$wpdb->prefix}posts as p
                        LEFT JOIN {$wpdb->prefix}postmeta as pm ON (pm.post_id = p.ID)
                    WHERE
                        p.post_type = '%s'
                    AND p.post_status = 'publish'
                    GROUP BY p.ID
                ",
                $postType
            );

            if ($transientData['transientSwitch'] === 'true') {
                $results = $wpdb->get_results($query, OBJECT);
                set_transient('transient_gs_product_details', $results, $transientData['transientTime']);
            } else {
                if (false !== get_transient('transient_gs_product_details')) {
                    delete_transient('transient_gs_product_details');
                }
                $results = $wpdb->get_results($query, OBJECT);
            }
        }

        return $results;
    }

    /**
     * prepareProductGridData.
     *
     * @return void
     */
    public static function prepareProductGridData()
    {

        $transientData = QueryTrait::gsTransientTime();
        $products = get_transient('transient_gs_products');

        if (false === ($products)) {
            $products = $productDetails = $attachments = $data = [];


            $allAttachmentDetails = !empty(QueryTrait::getAllAttachmentsByProducts()) ? QueryTrait::getAllAttachmentsByProducts() : [];

            for ($i = 0; $i < count($allAttachmentDetails); ++$i) {
                $attachments[$i]['ID'] = $allAttachmentDetails[$i]->ID;
                $attachments[$i]['thumbnail'] = ImageResizer::gsResizeImage($allAttachmentDetails[$i]->ID, $allAttachmentDetails[$i]->guid, 300, 300, true);
                $attachments[$i]['guid'] = $allAttachmentDetails[$i]->post_status;
                $attachments[$i]['post_status'] = $allAttachmentDetails[$i]->post_status;
                $attachments[$i]['attached_file'] = $allAttachmentDetails[$i]->attached_file;
            }
            $attachmentIDs = array_column($attachments, 'ID');

            $productDetails = QueryTrait::productDetails();
            foreach ($productDetails as $key => $product) {
                $products[$product->ID]['ID']                  = $product->ID;
                $products[$product->ID]['post_title']          = $product->post_title;
                $products[$product->ID]['post_type']           = $product->post_type;
                $products[$product->ID]['price']               = $product->price;
                $products[$product->ID]['price_html']          = wc_price($product->price);
                $products[$product->ID]['formattedPrice']      = wc_price($product->price);
                $products[$product->ID]['regular_price']       = $product->regular_price;
                $products[$product->ID]['sale_price']          = $product->sale_price;
                $products[$product->ID]['sku']                 = $product->sku;
                $products[$product->ID]['total_sales']         = $product->total_sales;
                $products[$product->ID]['stock_status']        = $product->stock_status;
                $products[$product->ID]['stock']               = $product->stock;
                $products[$product->ID]['unit']                = $product->unit;
                $products[$product->ID]['unit_label']          = $product->unit_label;
                $products[$product->ID]['average_rating']      = $product->average_rating;
                $products[$product->ID]['review_count']        = $product->review_count;
                $products[$product->ID]['thumbnail_id']        = $product->thumbnail_id;
                $products[$product->ID]['product_gallery_ids'] = $product->product_gallery;

                if (!empty($product->thumbnail_id)) {
                    $index                                                   = array_search($product->thumbnail_id, $attachmentIDs);
                    $attachment                                              = isset($attachments[$index]) ? $attachments[$index] : '';
                    $products[$product->ID]['thumbnail']['guid']             = $attachment['guid'];
                    $products[$product->ID]['thumbnail']['attachmentStatus'] = $attachment['post_status'];
                    $products[$product->ID]['thumbnail']['attachedFile']     = $attachment['attached_file'];
                    $products[$product->ID]['thumbnail']                     = $attachment['thumbnail'];
                }

                if (!empty($product->product_gallery)) {
                    $idPlaceholders = explode(',', $product->product_gallery);
                    if (!empty($idPlaceholders)) {
                        foreach ($idPlaceholders as $key => $id) {
                            $products[$product->ID]['gallery'][$key] = !empty(wp_get_attachment_image_src($id, 'woocommerce_thumbnail')[0]) ? wp_get_attachment_image_src($id, 'woocommerce_thumbnail')[0] : '';
                        }
                    }
                }
            }

            if ($transientData['transientSwitch'] === 'true') {
                set_transient('transient_gs_products', $products, $transientData['transientTime']);
            } else {
                if (false !== get_transient('transient_gs_products')) {
                    delete_transient('transient_gs_products');
                }

                return $products;
            }
        }

        return $products;
    }
}
