<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

use GridSter\Classes;
use GridSter\Front\Shortcodes;

add_action('init', 'gsFeaturedProductsGrid');

function gsFeaturedProductsGrid()
{
    if (function_exists('register_block_type')) {
        register_block_type('gridster/featured-products', [
            'editor_script'                => 'gs-gutenberg-block-scripts',
            'render_callback'              => 'gsFeaturedProductsGridCallback',
            'attributes'                   => [
                'postType'                 => [
                    'type'                 => 'string',
                    'default'              => 'product',
                ],
                'taxonomy'                 => [
                    'type'                 => 'string',
                    'default'              => '',
                ],
                'term'                     => [
                    'type'                 => 'string',
                    'default'              => '',
                ],
                'postsPerPage'             => [
                    'type'                 => 'number',
                    'default'              => 5,
                ],
                'orderBy'                  => [
                    'type'                 => 'string',
                    'default'              => 'ID',
                ],
                'order'                    => [
                    'type'                 => 'string',
                    'default'              => 'DESC',
                ],
                'gridTemplate'             => [
                    'type'                 => 'string',
                    'default'              => 'grid_alpine',
                ],
                'sidebar'                  => [
                    'type'                 => 'boolean',
                    'default'              => false,
                ],
                'paddingTop'               => [
                    'type'                 => 'object',
                    'default'              => [
                        'desktop'          => 0,
                        'laptop'           => 0,
                        'tab'              => 0,
                        'mobile'           => 0,
                    ],
                ],
                'paddingRight'             => [
                    'type'                 => 'object',
                    'default'              => [
                        'desktop'          => 0,
                        'laptop'           => 0,
                        'tab'              => 0,
                        'mobile'           => 0,
                    ],
                ],
                'paddingBottom'            => [
                    'type'                 => 'object',
                    'default'              => [
                        'desktop'          => 0,
                        'laptop'           => 0,
                        'tab'              => 0,
                        'mobile'           => 0,
                    ],
                ],
                'paddingLeft'              => [
                    'type'                 => 'object',
                    'default'              => [
                        'desktop'          => 0,
                        'laptop'           => 0,
                        'tab'              => 0,
                        'mobile'           => 0,
                    ],
                ],
                'gridType'                 => [
                    'type'                 => 'string',
                    'default'              => 'quick_cart',
                ],
                'quickView'                => [
                    'type'                 => 'string',
                    'default'              => 'disable',
                ],
                'featured_product_ids'     => [
                    'type'                 => 'array',
                    'default'              => [],
                ],
                'featured_product_postion' => [
                    'type'                 => 'string',
                    'default'              => 'left',
                ],
                'featured_product_view'    => [
                    'type'                 => 'string',
                    'default'              => 'conventional',
                ],
                'showHeading'              => [
                    'type'                 => 'boolean',
                    'default'              => false,
                ],
                'headerTitle'              => [
                    'type'                 => 'string',
                    'default'              => 'Featured Products',
                ],
                'buttonTtitle'             => [
                    'type'                 => 'string',
                    'default'              => 'See All Product',
                ],
                'slidesPerView'            => [
                    'type'                 => 'object',
                    'default'              => [
                        'desktop'          => 4,
                        'laptop'           => 3,
                        'tab'              => 2,
                        'mobile'           => 1,
                    ],
                ],
                'spaceBetween'             => [
                    'type'                 => 'object',
                    'default'              => [
                        'desktop'          => 30,
                        'laptop'           => 30,
                        'tab'              => 15,
                        'mobile'           => 0,
                    ],
                ],
                'speed'                    => [
                    'type'                 => 'number',
                    'default'              => 300,
                ],
                'loop'                     => [
                    'type'                 => 'boolean',
                    'default'              => false,
                ],
                'navigation'               => [
                    'type'                 => 'boolean',
                    'default'              => true,
                ],
                'pagination'               => [
                    'type'                 => 'boolean',
                    'default'              => false,
                ],
                'autoplay'                 => [
                    'type'                 => 'boolean',
                    'default'              => false,
                ],
                'modernPlateBg'            => [
                    'type'                 => 'string',
                    'default'              => '#F7F7F7',
                ],
                'showSeeAllButton' => [
                    'type'         => 'boolean',
                    'default'      => false,
                ],
                'seeAllType'       => [
                    'type'         => 'string',
                    'default'      => 'predefined',
                ],
                'seeAllPageLink'   => [
                    'type'         => 'string',
                    'default'      => '',
                ],
            ],
        ]);
    }
}

function gsFeaturedProductsGridCallback($attributes, $content)
{
    ob_start();

    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = $padding = $gridClass = $product_view = $modernPlateBg = '';

    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    $padding       = Shortcodes::getGSPaddingStyles($attributes);
    $postsPerPage  = isset($attributes) ? $attributes['postsPerPage']         : 5;
    $orderBy       = isset($attributes) ? $attributes['orderBy']              : 'ID';
    $order         = isset($attributes) ? $attributes['order']                : 'DESC';
    $product_view  = isset($attributes) ? $attributes['featured_product_view'] : 'conventional';
    $modernPlateBg = isset($attributes) ? $attributes['modernPlateBg']        : '#F7F7F7';
    $templateSlug  = isset($attributes) ? $attributes['gridTemplate']         : 'grid_alpine';

    if ($product_view === 'conventional') {
        $templateName = $templateSlug . '.php';
    } else {
        $templateName = $templateSlug . '_slider.php';
    }

    $featured_product_id = '';
    if (!empty($attributes['featured_product_ids']) && is_array($attributes['featured_product_ids'])) {
        foreach ($attributes['featured_product_ids'] as $key => $value) {
            $featured_product_id .= $value['id'];
        }
    }

    $posts         = Shortcodes::getGSProductsSortBy($postsPerPage, $orderBy, $order, 'product_visibility', 'featured', 'name', null, null, []);
    $transfer_data = new Classes();
    $gridClass     = Shortcodes::gsGridLoopItemClasses($templateSlug, []);

    $template_args = [
        'posts'                    => $product_view === 'conventional' ? $posts : array_merge($posts, Shortcodes::blockSeeAllProducts($attributes)),
        'seeAll'                   => Shortcodes::blockSeeAllProducts($attributes),
        'postsPerPage'             => $postsPerPage,
        'allowedHTML'              => $allowedHTML,
        'attributes'               => $attributes,
        'gridClass'                => $gridClass,
        'placeholder_image'        => GS_ASSETS . 'global/images/placeholder-icon.svg',
        'featured_product_id'      => $featured_product_id,
        'featured_product_postion' => $attributes['featured_product_postion'],
        'featured_product_view'    => $product_view,
        'modernPlateBg'            => $modernPlateBg,
        'sliderControls'           => [
            'slidesPerView'        => $attributes['slidesPerView'],
            'spaceBetween'         => $attributes['spaceBetween'],
            'speed'                => $attributes['speed'],
            'loop'                 => $attributes['loop'],
            'navigation'           => $attributes['navigation'],
            'pagination'           => $attributes['pagination'],
            'autoplay'             => $attributes['autoplay'],
        ],
    ];

    /*
     * Hook: gs_grid_template_render_before.
     *
     * @hooked gsTemplateRenderBeforeWrap - 10
     */
    do_action('gs_grid_template_render_before', $customClass, $padding);

    /*
     * Hook: gs_grid_block_heading.
     *
     * @hooked gsShortCodeHeading - 10
     */
    do_action('gs_grid_block_heading', $attributes);

    $transfer_data->gsGetTemplate(
        'product-grid/' . $templateName,
        $template_args
    );
    /*
     * Hook: gs_grid_template_render_after.
     *
     * @hooked gsTemplateRenderAfterWrap - 10
     */
    do_action('gs_grid_template_render_after');

    return apply_filters('gs_featured_products', ob_get_clean(), $attributes, $content);
}
