<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

use GridSter\Classes;
use GridSter\Front\Shortcodes;

add_action('init', 'gsCherryPickedOne');

function gsCherryPickedOne()
{
    if (function_exists('register_block_type')) {
        register_block_type('gridster/cherry-picked-one', [
            'editor_script'   => 'gs-gutenberg-block-scripts',
            'render_callback' => 'gsCherryPickedOneCallback',
            'attributes'      => [
                'postType'        => [
                    'type'    => 'string',
                    'default' => 'product',
                ],
                'editMode'        => [
                    'type'    => 'string',
                    'default' => 'true',
                ],
                'label'           => [
                    'type'    => 'string',
                    'default' => __('Most Popular', 'gridster'),
                ],
                'backgroundColor' => [
                    'type'    => 'string',
                    'default' => '#F2F1EF',
                ],
                'labelColor'      => [
                    'type'    => 'string',
                    'default' => '#fff',
                ],
                'labelBgColor'    => [
                    'type'    => 'string',
                    'default' => '#FD5473',
                ],
                'progressFgColor' => [
                    'type'    => 'string',
                    'default' => '#FFC33C',
                ],
                'progressBgColor' => [
                    'type'    => 'string',
                    'default' => '#E4E9EC',
                ],
                'post'            => [
                    'type'    => 'array',
                    'default' => [],
                ],
                'gridTemplate'    => [
                    'type'    => 'string',
                    'default' => 'coral',
                ],
                'sidebar'         => [
                    'type'    => 'boolean',
                    'default' => false,
                ],
                'paddingTop'      => [
                    'type'    => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0,
                    ],
                ],
                'paddingRight'    => [
                    'type'    => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0,
                    ],
                ],
                'paddingBottom'   => [
                    'type'    => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0,
                    ],
                ],
                'paddingLeft'     => [
                    'type'    => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop'  => 0,
                        'tab'     => 0,
                        'mobile'  => 0,
                    ],
                ],
            ],
        ]);
    }
}

function gsCherryPickedOneCallback($attributes, $content)
{
    ob_start();

    // remove_action('gs_grid_template_render_before', 'gsTemplateRenderBeforeWrap', 10, 2);
    // remove_action('gs_grid_template_render_after', 'gsTemplateRenderAfterWrap', 10);
    // remove_action('gs_grid_block_heading', 'gsShortCodeHeading', 10, 1);

    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = $padding = $gridClass = '';
    $postID = [];

    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    $padding = Shortcodes::getGSPaddingStyles($attributes);

    if (!empty($attributes['post'])) {
        foreach ($attributes['post'] as $key => $post) {
            array_push($postID, $post['value']);
        }
    }

    $transfer_data = new Classes();
    $templateSlug = isset($attributes) ? $attributes['gridTemplate'] : 'grid_alpine';
    $templateName = $templateSlug . '.php';

    if (!empty($postID)) {
        $posts = Shortcodes::getGSPostsByIDs($postID);
    } else {
        $posts = [];
    }

    $gridClass = Shortcodes::gsGridLoopItemClasses($templateSlug, []);

    $template_args = [
        'posts'             => $posts,
        'allowedHTML'       => $allowedHTML,
        'attributes'        => $attributes,
        'gridClass'         => $gridClass,
        'placeholder_image' => GS_ASSETS . 'global/images/placeholder-icon.svg',
    ];

    /*
     * Hook: gs_grid_template_render_before.
     *
     * @hooked gsTemplateRenderBeforeWrap - 10
     */
    // do_action('gs_grid_template_render_before', $customClass, $padding);

    /*
     * Hook: gs_grid_block_heading.
     *
     * @hooked gsShortCodeHeading - 10
     */
    do_action('gs_grid_block_heading', $attributes);

    $transfer_data->gsGetTemplate(
        'product-deals/' . $templateName,
        $template_args
    );
    /*
     * Hook: gs_grid_template_render_after.
     *
     * @hooked gsTemplateRenderAfterWrap - 10
     */
    // do_action('gs_grid_template_render_after');

    return apply_filters('gs_cherry_picked_product', ob_get_clean(), $attributes, $content);
}
