<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

use GridSter\Classes;
use GridSter\Front\Shortcodes;

add_action('init', 'gsBlockTitle');

function gsBlockTitle()
{
    if (function_exists('register_block_type')) {
        register_block_type('gridster/block-title', [
            'editor_script' => 'gs-gutenberg-block-scripts',
            'render_callback' => 'gsBlockTitleCallback',
            'attributes' => [
                'paddingTop' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingRight' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingBottom' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingLeft' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'title' => [
                    'type' => 'string',
                    'default' => '',
                ],
                'subTitle' => [
                    'type' => 'string',
                    'default' => '',
                ],
                'alignment' => [
                    'type' => 'string',
                    'default' => 'left',
                ],
                'titleFontColor' => [
                    'type' => 'string',
                    'default' => '#000000',
                ],
                'subTitleFontColor' => [
                    'type' => 'string',
                    'default' => '#666666',
                ],
                'titleFontSize' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 22,
                        'laptop' => 20,
                        'tab' => 20,
                        'mobile' => 16,
                    ],
                ],
                'subTitleFontSize' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 16,
                        'laptop' => 15,
                        'tab' => 15,
                        'mobile' => 14,
                    ],
                ],
            ],
        ]);
    }
}

function gsBlockTitleCallback($attributes, $content)
{
    ob_start();
    extract($attributes);

    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = $padding = '';

    if (isset($className)) {
        $customClass = $className;
    }

    $padding = Shortcodes::getGSPaddingStyles($attributes);

    $titleStyles = '';
    $titleStyles .= 'color:' . $titleFontColor . ';';
    $titleStyles .= '--desktop-title-font-size:' . $titleFontSize['desktop'] . 'px;';
    $titleStyles .= '--laptop-title-font-size:' . $titleFontSize['laptop'] . 'px;';
    $titleStyles .= '--tab-title-font-size:' . $titleFontSize['tab'] . 'px;';
    $titleStyles .= '--mobile-title-font-size:' . $titleFontSize['mobile'] . 'px;';

    $subTitleStyles = '';
    $subTitleStyles .= 'color:' . $subTitleFontColor . ';';
    $subTitleStyles .= '--desktop-subtitle-font-size:' . $subTitleFontSize['desktop'] . 'px;';
    $subTitleStyles .= '--laptop-subtitle-font-size:' . $subTitleFontSize['laptop'] . 'px;';
    $subTitleStyles .= '--tab-subtitle-font-size:' . $subTitleFontSize['tab'] . 'px;';
    $subTitleStyles .= '--mobile-subtitle-font-size:' . $subTitleFontSize['mobile'] . 'px;';
?>

    <div class="gs-block-spacing-wrapper gridster-fluid-block <?php echo esc_attr($customClass) ?>" style="<?php echo esc_attr($padding) ?>">
        <div class="gridster-section-header" style="text-align: <?php echo esc_attr($alignment) ?>">
            <h2 class="gridster-section-header-title" style="<?php echo esc_attr($titleStyles) ?>">
                <?php echo wp_kses($title, $allowedHTML); ?>
            </h2>
            <?php if ($subTitle) { ?>
                <div class="gridster-section-header-subtitle" style="<?php echo esc_attr($subTitleStyles) ?>">
                    <?php echo wp_kses($subTitle, $allowedHTML); ?>
                </div>
            <?php } ?>
        </div>
    </div>

<?php
    return apply_filters('gs_block_title', ob_get_clean(), $attributes, $content);
}
?>