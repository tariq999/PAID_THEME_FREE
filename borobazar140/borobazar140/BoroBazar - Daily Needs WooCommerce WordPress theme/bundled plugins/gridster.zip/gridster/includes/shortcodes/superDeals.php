<?php

// Exit if accessed directly.
defined('ABSPATH') || exit;

use GridSter\Classes;
use GridSter\Front\Shortcodes;

add_action('init', 'gsSuperDeals');

function gsSuperDeals()
{
    if (function_exists('register_block_type')) {
        register_block_type('gridster/super-deals', [
            'editor_script' => 'gs-gutenberg-block-scripts',
            'render_callback' => 'gsSuperDealsCallback',
            'attributes' => [
                'productTypeInGrid' => [
                    'type'        => 'string',
                    'default'     => 'recent_product',
                ],
                'postType' => [
                    'type' => 'string',
                    'default' => 'product',
                ],
                'taxonomy' => [
                    'type' => 'string',
                    'default' => '',
                ],
                'term' => [
                    'type' => 'string',
                    'default' => '',
                ],
                'postsPerPage' => [
                    'type' => 'number',
                    'default' => 5,
                ],
                'orderBy' => [
                    'type' => 'string',
                    'default' => 'ID',
                ],
                'order' => [
                    'type' => 'string',
                    'default' => 'DESC',
                ],
                'gridType' => [
                    'type' => 'string',
                    'default' => 'quick_cart',
                ],
                'gridTemplate' => [
                    'type' => 'string',
                    'default' => 'grid_alpine',
                ],
                'paddingTop' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingRight' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingBottom' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'paddingLeft' => [
                    'type' => 'object',
                    'default' => [
                        'desktop' => 0,
                        'laptop' => 0,
                        'tab' => 0,
                        'mobile' => 0,
                    ],
                ],
                'width'    => [
                    'type'      => 'number',
                    'default'   =>  75.25
                ],
                'textAreaPosition'    => [
                    'type'      => 'string',
                    'default'   =>  'left'
                ],
                'placeAt' => [
                    'type' => 'string',
                    'default' => 'right'
                ]
            ],
        ]);
    }
}

function gsSuperDealsCallback($attributes, $content)
{
    ob_start();

    $allowedHTML = wp_kses_allowed_html('post');
    $customClass = $padding = $gridClass = $textAreaPadding = $counterAreaPadding = $alignItems = '';

    if (isset($attributes['className'])) {
        $customClass = $attributes['className'];
    }

    $padding      = Shortcodes::getGSPaddingStyles($attributes);
    $postsPerPage = isset($attributes) ? $attributes['postsPerPage'] : 5;
    $orderBy      = isset($attributes) ? $attributes['orderBy'] : 'ID';
    $order        = isset($attributes) ? $attributes['order'] : 'DESC';
    $templateSlug = isset($attributes) ? $attributes['gridTemplate'] : 'grid_alpine';
    $templateName = $templateSlug . '.php';

    switch ($attributes['productTypeInGrid']) {
        case 'on_sale':
            // Meta query to retrieve the product which have sale price
            $meta_query = [
                'relation'    => 'OR',
                // Simple products type
                [
                    'key'     => '_sale_price',
                    'value'   => 0,
                    'compare' => '>',
                    'type'    => 'numeric',
                ],
                // Variable products type
                [
                    'key'     => '_min_variation_sale_price',
                    'value'   => 0,
                    'compare' => '>',
                    'type'    => 'numeric',
                ],
            ];

            $posts = Shortcodes::getGSPostsByComplexMetaQuery('product', '', '', $postsPerPage, $orderBy, $order, [], $meta_query);
            break;
        case 'best_selling':
            $posts = Shortcodes::getGSProductsSortBy($postsPerPage, 'meta_value_num', 'DESC', null, null, 'id', 'total_sales', null);
            break;
        case 'recent_product':
            $posts = Shortcodes::getGSRecentPosts($postsPerPage, $orderBy, $order);
            break;
        case 'top_rated':
            $posts = Shortcodes::getGSRecentPosts($postsPerPage, $orderBy, $order);
            break;
        case 'featured':
            $posts = Shortcodes::getGSProductsSortBy($postsPerPage, $orderBy, $order, 'product_visibility', 'featured', 'name', null, null, []);
            break;

        default:
            $posts = Shortcodes::getGSRecentPosts($postsPerPage, $orderBy, $order);
            break;
    }

    $transfer_data = new Classes();
    $gridClass = Shortcodes::gsGridLoopItemClasses($templateSlug, [
        'blockName' => 'gridster/super-deals',
    ]);

    $template_args = [
        'posts'             => $posts,
        'allowedHTML'       => $allowedHTML,
        'attributes'        => $attributes,
        'gridClass'         => $gridClass,
        'templateSlug'      => $templateSlug,
        'blockName'         => 'gridster/super-deals',
        'placeholder_image' => GS_ASSETS . 'global/images/placeholder-icon.svg',
    ];

    /*
     * Hook: gs_grid_template_render_before.
     *
     * @hooked gsTemplateRenderBeforeWrap - 10
     */
    do_action('gs_grid_template_render_before', $customClass, $padding);

    /*
     * Hook: gs_grid_block_heading.
     *
     * @hooked gsShortCodeHeading - 10
     */
    do_action('gs_grid_block_heading', $attributes);


?>

    <div id="borobazar-product-super-deals" class="grid grid-cols-1 md:flex md:grid-cols-none gap-5" style="flex-direction: <?php echo esc_attr($attributes['textAreaPosition'] === 'left' ? 'row' : 'row-reverse') ?>;">

        <?php

        if ($attributes["placeAt"] == "left") {
            echo $content;
        }

        $transfer_data->gsGetTemplate(
            'product-grid/' . $templateName,
            $template_args
        );

        if ($attributes["placeAt"] == "right") {
            echo $content;
        }
        ?>



    </div> <!-- end .grid -->

<?php

    /*
     * Hook: gs_grid_template_render_after.
     *
     * @hooked gsTemplateRenderAfterWrap - 10
     */
    do_action('gs_grid_template_render_after');

    return apply_filters('gs_recent_products', ob_get_clean(), $attributes, $content);
}
