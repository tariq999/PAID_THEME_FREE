<?php

namespace GridSter;

// Exit if accessed directly.
defined('ABSPATH') || exit;
// Admin Classes
use GridSter\Admin\AdminMenu;
use GridSter\Admin\AdminScripts;
use GridSter\Admin\AdminStyles;
// Front Classes
use GridSter\Front\Internationalization;
use GridSter\Front\Scripts;
use GridSter\Front\Shortcodes;
use GridSter\Front\Styles;
// Traits
use GridSter\Traits\TemplateLoader;
// Quick Carting Classes
use GridSter\WooQuickCart\WooQuickCartAjax;
use GridSter\WooQuickCart\WooQuickCartFront;

/**
 * Classes.
 */
class Classes
{
    use TemplateLoader;

    /**
     * __construct.
     */
    public function __construct()
    {
        $this->classes();
    }

    /**
     * classes.
     */
    public function classes()
    {
        if (is_admin()) {
            new AdminMenu();
            new AdminStyles();
            new AdminScripts();
        }

        new Internationalization();
        new Scripts();
        new Styles();
        new Shortcodes();

        new WooQuickCartAjax();
        new WooQuickCartFront();
    }
}