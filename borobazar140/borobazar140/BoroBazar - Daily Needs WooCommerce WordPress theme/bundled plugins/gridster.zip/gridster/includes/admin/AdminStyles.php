<?php

namespace GridSter\Admin;

// Exit if accessed directly.
defined('ABSPATH') || exit;

use GridSter\Traits\StyleScriptLoader;

/**
 * AdminStyles
 */
class AdminStyles
{
    use StyleScriptLoader;

    private static $styles = [];

    /**
     * __construct
     *
     */
    public function __construct()
    {
        add_action('admin_enqueue_scripts', [$this, 'loadStyles']);
    }

    /**
     * registerStyles
     *
     */
    private static function registerStyles()
    {
        $register_styles = apply_filters('gs_admin_styles_array', [
            'gs-getting-started-css' => [
                'src'     => GS_ASSETS . 'admin/css/getting-started.css',
                'deps'    => [],
                'version' => GS_VERSION,
                'has_rtl' => false,
            ],
            'gs-gutenberg-editor-css' => [
                'src'     => GS_DIST . 'blocks.editor.build.css',
                'deps'    => [],
                'version' => GS_VERSION,
                'has_rtl' => false,
            ],
        ]);

        foreach ($register_styles as $name => $props) {
            self::registerStyle($name, $props['src'], $props['deps'], $props['version'], 'all', $props['has_rtl']);
        }
    }


    /**
     * loadStyles
     *
     */
    public function loadStyles()
    {
        self::registerStyles();
        self::enqueueStyle('gs-getting-started-css');
        self::enqueueStyle('gs-gutenberg-editor-css');
    }
}
