<?php

namespace GridSter\Admin;

// Exit if accessed directly.
defined('ABSPATH') || exit;

/**
 * AdminMenu.
 */
class AdminMenu
{
    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        add_action('admin_menu', [$this, 'adminMenu'], 9);
    }

    /**
     * adminMenu.
     *
     * @return void
     */
    public function adminMenu()
    {
        $page_title = esc_html__('GridSter', 'gridster');
        $menu_title = esc_html__('GridSter', 'gridster');
        $capability = 'manage_options';
        $menu_slug  = 'gridster';
        $function   = [$this, 'welcome'];
        $icon_url   = 'dashicons-building';
        $position   = 80;

        add_menu_page(
            $page_title,
            $menu_title,
            $capability,
            $menu_slug,
            $function,
            $icon_url,
            $position
        );

        $sub_menu_args = apply_filters('gs_admin_submenu_args', [
            'settings' => [
                'parent_slug' => 'gridster',
                'page_title'  => esc_html__('GridSter', 'gridster'),
                'menu_title'  => esc_html__('Settings', 'gridster'),
                'capability'  => 'manage_options',
                'menu_slug'   => 'settings',
                'function'    => 'settings',
                'position'    => 85,
            ],
        ]);

        foreach ($sub_menu_args as $key => $value) {
            $this->subMenuCreation($value);
        }
    }

    /**
     * subMenuCreation.
     *
     * @param array $args
     *
     * @return void
     */
    private function subMenuCreation($args)
    {
        return add_submenu_page(
            $parent_slug = $args['parent_slug'],
            $page_title  = $args['page_title'],
            $menu_title  = $args['menu_title'],
            $capability  = $args['capability'],
            $menu_slug   = $args['menu_slug'],
            $function    = [$this, $args['function']],
            $position    = $args['position']
        );
    }

    /**
     * settings.
     *
     * @return void
     */
    public function settings()
    {
        if (!current_user_can('manage_options')) {
            wp_die(
                __('You do not have sufficient permissions to access this page.', 'gridster')
            );
        }
        include_once GS_ADMIN_VIEWS . 'settings.php';
    }

    /**
     * welcome.
     *
     * @return void
     */
    public function welcome()
    {
        if (!current_user_can('manage_options')) {
            wp_die(
                __('You do not have sufficient permissions to access this page.', 'gridster')
            );
        }
        include_once GS_ADMIN_VIEWS . 'welcome.php';
    }
}
