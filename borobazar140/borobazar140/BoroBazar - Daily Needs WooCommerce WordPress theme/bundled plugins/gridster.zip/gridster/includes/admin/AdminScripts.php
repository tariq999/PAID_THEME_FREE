<?php

namespace GridSter\Admin;

// Exit if accessed directly.
defined('ABSPATH') || exit;

use GridSter\Traits\StyleScriptLoader;

/**
 * Scripts
 */
class AdminScripts
{
    use StyleScriptLoader;

    /**
     * __construct
     *
     */
    public function __construct()
    {
        add_action('admin_enqueue_scripts', [$this, 'loadScripts']);
    }

    /**
     * registerScripts
     *
     */
    private static function registerScripts()
    {
        $register_scripts = apply_filters('gs_admin_scripts_array', [
            'swiper' => [
                'src'     => GS_ASSETS . 'global/swiper-bundle.min.js',
                'deps'    => ['jquery', 'underscore'],
                'version' => '7.0.5',
            ],
            'lazyload'  => [
                'src'     => GS_ASSETS . 'global/lazysizes.min.js',
                'deps'    => [],
                'version' => '5.2.2',
            ],
            'lottie-player'  => [
                'src'     => GS_ASSETS . 'global/lottie-player.js',
                'deps'    => [],
                'version' => '0.5.1',
            ],
            'gs-admin'  => [
                'src'     => GS_ASSETS . 'admin/js/gs-admin.js',
                'deps'    => [],
                'version' => GS_VERSION,
            ],
            'gs-global-main'  => [
                'src'     => GS_ASSETS . 'global/global-main.js',
                'deps'    => [],
                'version' => GS_VERSION,
            ],
            'gs-gutenberg-block-scripts'  => [
                'src'     => GS_DIST . 'blocks.build.js',
                'deps'    => ['wp-api', 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor'],
                'version' => GS_VERSION,
            ],
        ]);
        foreach ($register_scripts as $name => $key) {
            self::registerScript($name, $key['src'], $key['deps'], $key['version']);
        }
    }

    /**
     * loadScripts
     *
     */
    public function loadScripts()
    {
        self::registerScripts();
        wp_enqueue_script('jquery-ui-accordion');
        self::enqueueScript('swiper');
        self::enqueueScript('gs-admin');
        self::enqueueScript('lazyload');
        self::enqueueScript('lottie-player');
        self::enqueueScript('gs-global-main');
        self::enqueueScript('gs-gutenberg-block-scripts');

        self::localizeScripts(
            'gs-gutenberg-block-scripts',
            'GS_ADMIN_LOCALIZE',
            [
                'pluginDirPath' => plugin_dir_path(__DIR__),
                'pluginDirUrl'  => plugin_dir_url(__DIR__),
                'imagePath'     => GS_ASSETS . '/admin/images/',
            ]
        );
    }
}
