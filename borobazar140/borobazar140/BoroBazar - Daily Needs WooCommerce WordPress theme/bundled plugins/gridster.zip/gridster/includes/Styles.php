<?php

namespace GridSter\Front;

defined('ABSPATH') || exit;

use GridSter\Traits\StyleScriptLoader;

/**
 * Styles.
 */
class Styles
{
    use StyleScriptLoader;

    /**
     * __construct.
     */
    public function __construct()
    {
        add_action('wp_enqueue_scripts', [$this, 'loadStyles']);
    }

    /**
     * registerStyles.
     */
    private static function registerStyles()
    {
        $register_styles = apply_filters('gs_frontend_styles_array', [
            'swiper_css' => [
                'src'     => GS_ASSETS . 'client/css/swiper-bundle.min.css',
                'deps'    => [],
                'version' => '6.0.0',
                'has_rtl' => false,
            ],
            'jquery.toast.min' => [
                'src'     => GS_ASSETS . 'client/css/jquery.toast.min.css',
                'deps'    => [],
                'version' => GS_VERSION,
                'has_rtl' => false,
            ],
            'gs-gutenberg-style-css' => [
                'src'     => GS_DIST . 'blocks.style.build.css',
                'deps'    => [],
                'version' => GS_VERSION,
                'has_rtl' => false,
            ],
        ]);

        foreach ($register_styles as $name => $props) {
            self::registerStyle($name, $props['src'], $props['deps'], $props['version'], 'all', $props['has_rtl']);
        }
    }

    /**
     * loadStyles.
     */
    public function loadStyles()
    {
        self::registerStyles();
        self::enqueueStyle('swiper_css');
        self::enqueueStyle('jquery.toast.min');
        self::enqueueStyle('gs-gutenberg-style-css');
    }
}
