<?php

namespace GridSter\Front;

// Exit if accessed directly.
defined('ABSPATH') || exit;
/**
 * Internationalization.
 */
class Internationalization
{
    /**
     * __construct.
     */
    public function __construct()
    {
        add_action('plugins_loaded', [$this, 'loadTextDomain']);
    }

    /**
     * loadTextDomain.
     */
    public function loadTextDomain()
    {
        load_plugin_textdomain(
            'gridster',
            false,
            basename(dirname(__FILE__)).'/languages'
        );
    }
}