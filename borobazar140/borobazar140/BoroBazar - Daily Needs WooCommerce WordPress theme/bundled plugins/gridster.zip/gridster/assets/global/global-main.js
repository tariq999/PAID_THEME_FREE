(function ($) {
	"use strict";

	ImageLazy();
	//Image Lazyload with broken image detector
	function ImageLazy() {
		$(document).on("lazyloaded", function () {
			var lazyImage = $(".gs-lazy-image");
			lazyImage.on("error", function () {
				$(this).addClass("image-is-broken");
				$(this).parent().addClass("broken-image-icon");
			});
			lazyImage.each(function () {
				if ($(this).hasClass("lazyloaded")) {
					$(this).parent().removeClass("gs-content-loading");
					$(this).siblings(".gs-image-loader").remove();
				}
			});
		});
	}
})(jQuery);
