/* eslint-disable wrap-iife */
/* eslint-disable prefer-const */
/* eslint-disable no-undef */
(function ($) {
	'use strict';

	// ImageLazy();
	// //Image Lazyload with broken image detector
	// function ImageLazy() {
	// 	var lazyImage = $(".gs-lazy-image");
	// 	$(document).on("lazyloaded", function () {
	// 		lazyImage.on("error", function () {
	// 			$(this).addClass("image-is-broken");
	// 			$(this).parent().addClass("broken-image-icon");
	// 		});
	// 		lazyImage.each(function () {
	// 			if ($(this).hasClass("lazyloaded")) {
	// 				$(this).parent().removeClass("gs-content-loading");
	// 				$(this).siblings(".gs-image-loader").remove();
	// 			}
	// 		});
	// 	});
	// }

	//Mutation Observer
	function onElementInserted(containerSelector, elementSelector, callback) {
		const onMutationsObserved = function (mutations) {
			mutations.forEach(function (mutation) {
				if (mutation.addedNodes.length) {
					const elements = $(mutation.addedNodes).find(elementSelector);
					for (let i = 0, len = elements.length; i < len; i++) {
						callback(elements[i]);
					}
				}
			});
		};

		const target = $(containerSelector)[0];
		const config = { childList: true, subtree: true };
		const MutationObserver =
			window.MutationObserver || window.WebKitMutationObserver;
		const observer = new MutationObserver(onMutationsObserved);
		observer.observe(target, config);
	}

	$(document).ready(function () {
		$('#gs_getting_started_faq').accordion({
			collapsible: true,
			header: '.gs-getting-started-faq-header',
			heightStyle: 'content',
			create: function () {
				$('.gs-getting-started-faq-header').find('.ui-icon').remove();
			},
		});

		$('.gs-getting-started-faq-header').each(function () {
			if ($(this).hasClass('ui-accordion-header-active')) {
				$(this)
					.children('.faq-header-icon-expand')
					.removeClass('show')
					.addClass('hide');
				$(this)
					.children('.faq-header-icon-collapse')
					.removeClass('hide')
					.addClass('show');
			} else {
				$(this)
					.children('.faq-header-icon-expand')
					.removeClass('hide')
					.addClass('show');
				$(this)
					.children('.faq-header-icon-collapse')
					.removeClass('show')
					.addClass('hide');
			}
		});

		$(document).on('click', '.gs-getting-started-faq-header', function () {
			$(this)
				.parents('#gs_getting_started_faq')
				.find('.faq-header-icon-expand')
				.removeClass('hide')
				.addClass('show');

			$(this)
				.parents('#gs_getting_started_faq')
				.find('.faq-header-icon-collapse')
				.removeClass('show')
				.addClass('hide');

			if ($(this).hasClass('ui-accordion-header-active')) {
				$(this)
					.find('.faq-header-icon-expand')
					.removeClass('show')
					.addClass('hide');

				$(this)
					.find('.faq-header-icon-collapse')
					.removeClass('hide')
					.addClass('show');
			} else {
				$(this)
					.find('.faq-header-icon-expand')
					.removeClass('hide')
					.addClass('show');

				$(this)
					.find('.faq-header-icon-collapse')
					.removeClass('show')
					.addClass('hide');
			}
		});
		jQuery(document).ready(function () {
			createSlider();
		});

		onElementInserted('body', '.gs_grid_product_slider', function () {
			createSlider();
		});
		onElementInserted('body', '#borobazar-product-super-deals', function () {
			coralDealCountdown();
			superDealSliderMaple();
			superDealSliderOak();
			superDealSliderAlpine();
			superDealSliderSweetgum();
			superDealSliderBroomstick();
			superDealSliderObsidian();
		});

		const createSlider = function () {
			if ($('.gs_grid_product_slider').length) {
				const gridSelector = $('.gs-product-grid-main-wrap');
				$(gridSelector).each(function () {
					const settings = $(this).find('.gs_slider_controls');
					let target = $(this).find('.swiper').attr('data-id'),
						gridName = settings.attr('data-template-name'),
						pagination = settings.attr('data-pagination'),
						navigation = settings.attr('data-navigation'),
						// autoplay = settings.attr("data-autoplay"),
						autoplay = false,
						nextNav = $(this)
							.find('.gs-slider-next-nav-button')
							.attr('data-class'),
						prevNav = $(this)
							.find('.gs-slider-prev-nav-button')
							.attr('data-class'),
						paginationNav = $(this)
							.find('.gs-swiper-pagination')
							.attr('data-class');

					let breakpoints = {};

					switch (gridName) {
						case 'grid_alpine':
							breakpoints = {
								0: {
									slidesPerView: 1.5,
									spaceBetween: 12,
								},
								640: {
									slidesPerView: 2.7,
									spaceBetween: 12,
								},
								768: {
									slidesPerView: 2.7,
									spaceBetween: 16,
								},
								1024: {
									slidesPerView: 3.7,
									spaceBetween: 16,
								},
								1280: {
									slidesPerView: 4.7,
									spaceBetween: 16,
								},
								1500: {
									slidesPerView: 5.5,
									spaceBetween: 16,
								},
								1700: {
									slidesPerView: 7,
									spaceBetween: 20,
								},
							};
							break;

						case 'grid_oak':
							breakpoints = {
								0: {
									slidesPerView: 1.3,
									spaceBetween: 12,
								},
								640: {
									slidesPerView: 2,
									spaceBetween: 12,
								},
								768: {
									slidesPerView: 2.4,
									spaceBetween: 16,
								},
								1024: {
									slidesPerView: 3.2,
									spaceBetween: 16,
								},
								1280: {
									slidesPerView: 4,
									spaceBetween: 16,
								},
								1440: {
									slidesPerView: 4.5,
									spaceBetween: 16,
								},
								1500: {
									slidesPerView: 5,
									spaceBetween: 16,
								},
								1700: {
									slidesPerView: 6,
									spaceBetween: 20,
								},
							};
							break;

						case 'grid_sweetgum':
							breakpoints = {
								0: {
									slidesPerView: 1.3,
									spaceBetween: 12,
								},
								640: {
									slidesPerView: 2,
									spaceBetween: 12,
								},
								768: {
									slidesPerView: 2.4,
									spaceBetween: 16,
								},
								1024: {
									slidesPerView: 3.2,
									spaceBetween: 16,
								},
								1280: {
									slidesPerView: 4,
									spaceBetween: 16,
								},
								1440: {
									slidesPerView: 4.5,
									spaceBetween: 16,
								},
								1500: {
									slidesPerView: 5,
									spaceBetween: 16,
								},
								1700: {
									slidesPerView: 6,
									spaceBetween: 20,
								},
							};
							break;

						case 'grid_maple':
							breakpoints = {
								0: {
									slidesPerView: 1,
									spaceBetween: 12,
								},
								640: {
									slidesPerView: 1.5,
									spaceBetween: 12,
								},
								768: {
									slidesPerView: 1.6,
									spaceBetween: 16,
								},
								1024: {
									slidesPerView: 2.1,
									spaceBetween: 16,
								},
								1280: {
									slidesPerView: 2.7,
									spaceBetween: 16,
								},
								1440: {
									slidesPerView: 3,
									spaceBetween: 16,
								},
								1500: {
									slidesPerView: 3,
									spaceBetween: 16,
								},
								1700: {
									slidesPerView: 3,
									spaceBetween: 20,
								},
							};
							break;
						case 'grid_broomstick':
							breakpoints = {
							0: {
								slidesPerView: 1,
								spaceBetween: 12,
							},
							640: {
								slidesPerView: 1.5,
								spaceBetween: 12,
							},
							768: {
								slidesPerView: 1.6,
								spaceBetween: 16,
							},
							1024: {
								slidesPerView: 2.1,
								spaceBetween: 16,
							},
							1280: {
								slidesPerView: 2.7,
								spaceBetween: 16,
							},
							1440: {
								slidesPerView: 3,
								spaceBetween: 16,
							},
							1500: {
								slidesPerView: 3,
								spaceBetween: 16,
							},
							1700: {
								slidesPerView: 3,
								spaceBetween: 20,
							},
							};
							break;
						case 'grid_obsidian':
							breakpoints = {
							0: {
								slidesPerView: 1,
								spaceBetween: 12,
							},
							640: {
								slidesPerView: 1.5,
								spaceBetween: 12,
							},
							768: {
								slidesPerView: 1.6,
								spaceBetween: 16,
							},
							1024: {
								slidesPerView: 2.1,
								spaceBetween: 16,
							},
							1280: {
								slidesPerView: 3,
								spaceBetween: 16,
							},
							1440: {
								slidesPerView: 3,
								spaceBetween: 16,
							},
							1500: {
								slidesPerView: 3,
								spaceBetween: 16,
							},
							1700: {
								slidesPerView: 3,
								spaceBetween: 20,
							},
							};
							break;
						
						default:
							breakpoints = {
								420: {
									slidesPerView: 2.4,
									spaceBetween: 12,
								},
								640: {
									slidesPerView: 2.7,
									spaceBetween: 12,
								},
								768: {
									slidesPerView: 3.5,
									spaceBetween: 16,
								},
								1024: {
									slidesPerView: 4.5,
									spaceBetween: 16,
								},
								1280: {
									slidesPerView: 5.5,
									spaceBetween: 16,
								},
								1500: {
									slidesPerView: 6.5,
									spaceBetween: 16,
								},
								1700: {
									slidesPerView: 7.5,
									spaceBetween: 20,
								},
							};
							break;
					}
					// eslint-disable-next-line no-undef
					new Swiper('#' + target, {
						navigation: {
							nextEl: Boolean(navigation) ? '.' + nextNav : '',
							prevEl: Boolean(navigation) ? '.' + prevNav : '',
						},
						pagination: {
							el: Boolean(pagination) ? '.' + paginationNav : '',
							clickable: true,
						},
						scrollbar: {
							el: '#' + target + ' .swiper-scrollbar',
							draggable: true,
						},
						autoplay: false,
						loop: false,
						speed: 400,
						allowTouchMove: false,
						slidesPerView: 1.7,
						spaceBetween: 12,
						watchSlidesProgress: true,
						breakpoints,
						on: {
							init: function () {
								//last visible item opacity
								if ($(window).width() > 767) {
									const lastVisibleItem = this.visibleSlides.pop();
									lastVisibleItem.style.opacity = 0.4;
								}
							},
							resize: function () {
								$('#' + target)
									.find('.swiper-slide')
									.css('opacity', '');
								//last visible item opacity
								if ($(window).width() > 767) {
									const lastVisibleItem = this.visibleSlides.pop();
									lastVisibleItem.style.opacity = 0.4;
								}
							},
							slideChange: function () {
								//last visible item opacity on slide change
								if ($(window).width() > 767) {
									const lastVisibleItem = this.visibleSlides.pop();
									const prevItem =
										this.visibleSlides[this.visibleSlides.length - 1];

									prevItem.style.opacity = 1;
									if (this.progress !== 1) {
										lastVisibleItem.style.opacity = 0.4;
									} else {
										lastVisibleItem.style.opacity = 1;
									}
								}
							},
						},
					});
					if (autoplay) {
						$(this)
							.find('.swiper-container')
							.hover(
								function () {
									this.swiper.autoplay.stop();
								},
								function () {
									this.swiper.autoplay.start();
								}
							);
					}
				});
			}
		};

		function coralDealCountdown() {
			// date holder selector
			const dateHolder = $('#borobazar-coral-countdown');

			// Get the date from data attribute we're counting down to
			const dateFrom = new Date(dateHolder.attr('data-date-from'));
			const dateTo = new Date(dateHolder.attr('data-date-to'));
			// const dateTo = new Date('Mar 5, 2022 21:06:55');

			//get the time
			const countDownDate = new Date(dateTo).getTime();

			// Update the count down every 1 second
			const countDownClock = setInterval(function () {
				// Get today's date and time
				const now = new Date().getTime();
				// Find the distance between now and the count down date
				const distance = countDownDate - now;
				// Time calculations for days, hours, minutes and seconds
				const days = Math.floor(distance / (1000 * 60 * 60 * 24));
				const hours = Math.floor(
					(distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
				);
				const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
				const seconds = Math.floor((distance % (1000 * 60)) / 1000);

				const countdownMarkup = `
      <span class="flex items-start">
        <span class="flex flex-col">
          <span class="inline-flex min-w-[2.75rem] justify-center py-1.5 px-2 bg-[#DFDDD9] text-main text-lg font-medium rounded-[3px]">${days}</span>
          <span class="text-center font-medium text-[15px] text-[rgba(0,0,0,0.3)]">DD</span>
        </span>
        <span class="inline-flex mt-1.5 mx-1.5">:</span>
        <span class="flex flex-col">
          <span class="inline-flex min-w-[2.75rem] justify-center py-1.5 px-2 bg-[#DFDDD9] text-main text-lg font-medium rounded-[3px]">${hours}</span>
          <span class="text-center font-medium text-[15px] text-[rgba(0,0,0,0.3)]">HH</span>
        </span>
        <span class="inline-flex mt-1.5 mx-1.5">:</span>
        <span class="flex flex-col">
          <span class="inline-flex min-w-[2.75rem] justify-center py-1.5 px-2 bg-[#DFDDD9] text-main text-lg font-medium rounded-[3px]">${minutes}</span>
          <span class="text-center font-medium text-[15px] text-[rgba(0,0,0,0.3)]">MM</span>
        </span>
        <span class="inline-flex mt-1.5 mx-1.5">:</span>
        <span class="flex flex-col">
          <span class="inline-flex min-w-[2.75rem] justify-center py-1.5 px-2 bg-[#DFDDD9] text-main text-lg font-medium rounded-[3px]">${seconds}</span>
          <span class="text-center font-medium text-[15px] text-[rgba(0,0,0,0.3)]">SS</span>
        </span>
      </span>
      `;

				// set and display countdown markup
				dateHolder.html(countdownMarkup);
				// If the count down is finished, write some text
				if (distance < 0) {
					clearInterval(countDownClock);
					dateHolder.html(
						'<span class="inline-flex justify-center px-3 py-1.5 bg-[#DFDDD9] text-main text-lg font-medium rounded-[3px]">Expired!</span>'
					);
				}
			}, 1000);

			// Get today's date and time
			const now = new Date().getTime();

			// Find the distance between now and the count down date
			const distance = countDownDate - now;
			let percentComplete = getPercentage(dateFrom, dateTo);

			function getPercentage(saleStart = dateFrom, saleEnd = dateTo) {
				const startDate = Date.parse(saleStart);
				const endDate = Date.parse(saleEnd);

				const diff = Math.max(0, endDate - new Date());
				const range = endDate - startDate;
				return (100 * diff) / range;
			}

			$('#borobazar-coral-progress-bar').attr(
				'style',
				`width: ${percentComplete}%`
			);

			if (distance < 0) {
				$('#borobazar-coral-progress-bar').attr('style', 'width: 0%');
			}
		}

		function superDealSliderMaple() {
			const target = 'gs-super-deal-slider-grid_maple';
			// eslint-disable-next-line no-undef
			new Swiper(`.${target}`, {
				slidesPerView: 1,
				spaceBetween: 15,
				allowTouchMove: false,
				grid: {
					rows: 2,
					fill: 'row',
				},
				breakpoints: {
					420: {
						slidesPerView: 2.5,
						spaceBetween: 20,
						grid: {
							rows: 3,
						},
					},
					768: {
						slidesPerView: 1,
						grid: {
							rows: 3,
						},
					},
					1280: {
						slidesPerView: 2,
						grid: {
							rows: 3,
						},
					},
					1400: {
						slidesPerView: 2,
						grid: {
							rows: 3,
						},
					},
					1536: {
						slidesPerView: 3,
						grid: {
							rows: 3,
						},
					},
					1700: {
						slidesPerView: 3,
						spaceBetween: 20,
						grid: {
							rows: 3,
							fill: 'row',
						},
					},
				},
				navigation: {
					prevEl: '.gs-super-deal-prev-button',
					nextEl: '.gs-super-deal-next-button',
				},
				scrollbar: {
					el: '.' + target + ' .swiper-scrollbar',
					draggable: true,
				},
			});
		}
		function superDealSliderBroomstick() {
			const target = 'gs-super-deal-slider-grid_broomstick';
			// eslint-disable-next-line no-undef
			new Swiper(`.${target}`, {
				slidesPerView: 1,
				spaceBetween: 15,
				allowTouchMove: false,
				grid: {
					rows: 2,
					fill: 'row',
				},
				breakpoints: {
					420: {
						slidesPerView: 2.5,
						spaceBetween: 20,
						grid: {
							rows: 3,
						},
					},
					768: {
						slidesPerView: 1,
						grid: {
							rows: 3,
						},
					},
					1280: {
						slidesPerView: 2,
						grid: {
							rows: 3,
						},
					},
					1400: {
						slidesPerView: 2,
						grid: {
							rows: 3,
						},
					},
					1536: {
						slidesPerView: 3,
						grid: {
							rows: 3,
						},
					},
					1700: {
						slidesPerView: 3,
						spaceBetween: 20,
						grid: {
							rows: 3,
							fill: 'row',
						},
					},
				},
				navigation: {
					prevEl: '.gs-super-deal-prev-button',
					nextEl: '.gs-super-deal-next-button',
				},
				scrollbar: {
					el: '.' + target + ' .swiper-scrollbar',
					draggable: true,
				},
			});
		}
		function superDealSliderObsidian() {
			const target = 'gs-super-deal-slider-grid_obsidian';
			// eslint-disable-next-line no-undef
			new Swiper(`.${target}`, {
				slidesPerView: 1,
				spaceBetween: 15,
				allowTouchMove: false,
				grid: {
					rows: 2,
					fill: 'row',
				},
				breakpoints: {
					420: {
						slidesPerView: 2.5,
						spaceBetween: 20,
						grid: {
							rows: 3,
						},
					},
					768: {
						slidesPerView: 1,
						grid: {
							rows: 3,
						},
					},
					1280: {
						slidesPerView: 2,
						grid: {
							rows: 3,
						},
					},
					1400: {
						slidesPerView: 2,
						grid: {
							rows: 3,
						},
					},
					1536: {
						slidesPerView: 3,
						grid: {
							rows: 3,
						},
					},
					1700: {
						slidesPerView: 3,
						spaceBetween: 20,
						grid: {
							rows: 3,
							fill: 'row',
						},
					},
				},
				navigation: {
					prevEl: '.gs-super-deal-prev-button',
					nextEl: '.gs-super-deal-next-button',
				},
				scrollbar: {
					el: '.' + target + ' .swiper-scrollbar',
					draggable: true,
				},
			});
		}
		function superDealSliderOak() {
			const target = 'gs-super-deal-slider-grid_oak';
			// eslint-disable-next-line no-undef
			new Swiper(`.${target}`, {
				slidesPerView: 1.3,
				spaceBetween: 15,
				allowTouchMove: false,
				breakpoints: {
					768: {
						slidesPerView: 1,
						spaceBetween: 15,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1024: {
						slidesPerView: 2,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1280: {
						slidesPerView: 3,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1536: {
						slidesPerView: 4,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1700: {
						slidesPerView: 5,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
				},
				navigation: {
					prevEl: '.gs-super-deal-prev-button',
					nextEl: '.gs-super-deal-next-button',
				},
				scrollbar: {
					el: '.' + target + ' .swiper-scrollbar',
					draggable: true,
				},
			});
		}
		function superDealSliderSweetgum() {
			const target = 'gs-super-deal-slider-grid_sweetgum';
			// eslint-disable-next-line no-undef
			new Swiper(`.${target}`, {
				slidesPerView: 1.3,
				spaceBetween: 15,
				allowTouchMove: false,
				breakpoints: {
					768: {
						slidesPerView: 1,
						spaceBetween: 15,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1024: {
						slidesPerView: 2,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1280: {
						slidesPerView: 3,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1536: {
						slidesPerView: 4,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1700: {
						slidesPerView: 5,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
				},
				navigation: {
					prevEl: '.gs-super-deal-prev-button',
					nextEl: '.gs-super-deal-next-button',
				},
				scrollbar: {
					el: '.' + target + ' .swiper-scrollbar',
					draggable: true,
				},
			});
		}
		function superDealSliderAlpine() {
			const target = 'gs-super-deal-slider-grid_alpine';
			// eslint-disable-next-line no-undef
			new Swiper(`.${target}`, {
				slidesPerView: 2,
				spaceBetween: 15,
				allowTouchMove: false,
				grid: {
					rows: 1,
					fill: 'row',
				},
				breakpoints: {
					768: {
						slidesPerView: 1,
						spaceBetween: 15,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1024: {
						slidesPerView: 2,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1280: {
						slidesPerView: 3,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1440: {
						slidesPerView: 4,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
					1700: {
						slidesPerView: 6,
						spaceBetween: 15,
						grid: {
							rows: 2,
							fill: 'row',
						},
					},
				},
				navigation: {
					prevEl: '.gs-super-deal-prev-button',
					nextEl: '.gs-super-deal-next-button',
				},
				scrollbar: {
					el: '.' + target + ' .swiper-scrollbar',
					draggable: true,
				},
			});
		}
	});
})(jQuery);
