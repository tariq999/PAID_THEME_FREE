(function ($) {
	const cartItems = gs_woocommerce ? gs_woocommerce.cartItems : [];

	// const addToCartTimer = gs_woocommerce
	// ? parseInt(gs_woocommerce.addToCartTimer)
	// 	: 3500;

	const loading = (selector) => {
		$(selector).block({
			message: null,
			overlayCSS: {
				background: '#fff',
				opacity: 0.6,
				zIndex: 1,
			},
		});
	};

	const unLoading = (selector) => {
		$(selector).unblock();
	};

	$('body').on('click', '.gs-update-qty', function (e) {
		e.preventDefault();

		const product_id = $(this).data('product_id');
		const type = $(this).data('type');
		const source = $(this).data('source');
		const loaderSelector = `.gs-product-${product_id}`;

		const data = {
			action: 'gs_woocommerce_update_qty',
			product_id,
			type,
		};

		loading(loaderSelector);

		$.post(gs_woocommerce.ajax_url, data, function (response) {
			const responseData = response.data;
			const header = $('#masthead>div');

			if (response.success === false) {
				$.toast({
					text: responseData.message,
					showHideTransition: 'fade',
					// hideAfter: addToCartTimer,
					position: {
						right: 10,
						top: 10 + header[0].getBoundingClientRect().bottom,
					},
					stack: false,
					bgColor: '#fff',
				});
			}

			if (response.success) {
				$(document.body).trigger('wc_fragment_refresh');
				$(document.body).trigger('wc_fragments_loaded');
				$(`.gs-cart-product-${product_id}`).html(responseData.quantity);
				if (responseData.quantity) {
					// hide + btn
					$(`.gs-add-to-cart-${product_id}`).removeClass('flex');
					$(`.gs-add-to-cart-${product_id}`).addClass('hidden');
					// show quantity
					$(`.gs-qty-button-${product_id}`).removeClass('hidden');
					$(`.gs-qty-button-${product_id}`).addClass('flex');
				} else {
					// show + btn
					$(`.gs-add-to-cart-${product_id}`).removeClass('hidden');
					$(`.gs-add-to-cart-${product_id}`).addClass('flex');
					// hide quantity
					$(`.gs-qty-button-${product_id}`).removeClass('flex');
					$(`.gs-qty-button-${product_id}`).addClass('hidden');
				}

				//Toast message
				if (source !== 'mini_cart') {
					$.toast({
						text: responseData.details.markup,
						showHideTransition: 'fade',
						// hideAfter: addToCartTimer,
						position: {
							right: 10,
							top: 10 + header[0].getBoundingClientRect().bottom,
						},
						stack: false,
						bgColor: '#fff',
					});
				}
			}
			unLoading(loaderSelector);
		}).fail(function () {
			console.log(gs_woocommerce.message);
		});
	});

	// start mini cart remove ajax

	$('body').on('click', '.remove_from_cart_button', function (e) {
		e.preventDefault();

		const product_id = $(this).data('product_id');
		const type = $(this).data('type');
		const source = $(this).data('source');

		const data = {
			action: 'gs_woocommerce_clean_mini_cart',
			product_id,
			type,
		};

		const loaderSelector = `.gs-product-${product_id}`;
		loading(loaderSelector);

		$.post(gs_woocommerce.ajax_url, data, function (response) {
			if (response.success) {
				const responseData = response.data;

				$(document.body).trigger('wc_fragment_refresh');
				$(document.body).trigger('wc_fragments_loaded');
				$(`.gs-cart-product-${product_id}`).html(responseData.quantity);

				$(`.gs-add-to-cart-${product_id}`).removeClass('hidden');
				$(`.gs-add-to-cart-${product_id}`).addClass('flex');

				$(`.gs-qty-button-${product_id}`).removeClass('flex');
				$(`.gs-qty-button-${product_id}`).addClass('hidden');

				$(`.added-to-cart-${product_id}`).removeClass('flex');
				$(`.added-to-cart-${product_id}`).addClass('hidden');

				const header = $('#masthead>div');
				// Toast message
				if (responseData.source !== 'mini_cart_remove') {
					$.toast({
						text: responseData.details.markup,
						showHideTransition: 'fade',
						// hideAfter: addToCartTimer,
						position: {
							right: 10,
							top: 10 + header[0].getBoundingClientRect().bottom,
						},
						stack: false,
						bgColor: '#fff',
					});
				}
			}
			unLoading(loaderSelector);
		}).fail(function () {
			console.log(gs_woocommerce.message);
		});
		// end mini cart remove ajax
	});
})(jQuery);
