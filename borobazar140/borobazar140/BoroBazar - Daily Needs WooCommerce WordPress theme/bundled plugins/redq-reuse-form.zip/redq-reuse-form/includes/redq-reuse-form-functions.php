<?php

function enqueue_reuse_form_script()
{
	wp_enqueue_style('icomoon-css');
	wp_enqueue_style('flaticon-css');
	wp_enqueue_style('ionicons-css');
	wp_enqueue_style('font-awesome');
	wp_enqueue_script('reuse-form-variable');
	wp_enqueue_script('react');
	wp_enqueue_script('react-dom');
	wp_enqueue_style('reuse-form-two');
	wp_enqueue_style('reuse-form');
	wp_enqueue_script('reuse_vendor');
	wp_enqueue_script('reusejs');
}
