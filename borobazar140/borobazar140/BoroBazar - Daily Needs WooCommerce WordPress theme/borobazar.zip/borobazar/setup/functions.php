<?php
// Silence is gloden


// function turbo_get_post($page_title, $post_type = 'page')
// {
//     global $wpdb;

//     $sql = $wpdb->prepare(
//         "
//         SELECT ID
//         FROM $wpdb->posts
//         WHERE post_title = %s
//         AND post_type = %s
//     ",
//         $page_title,
//         $post_type
//     );

//     $page_id = $wpdb->get_var($sql);

//     return $page_id;
// }
