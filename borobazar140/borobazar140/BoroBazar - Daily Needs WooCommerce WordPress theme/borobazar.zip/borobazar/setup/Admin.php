<?php

namespace  Turbo\Setup;

class Admin
{
    /**
     * Class initialize
     */
    function __construct()
    {
        new Admin\Menu();
    }
}
