<?php
// berlin global search
get_template_part('template-parts/header/shared/global-search');
