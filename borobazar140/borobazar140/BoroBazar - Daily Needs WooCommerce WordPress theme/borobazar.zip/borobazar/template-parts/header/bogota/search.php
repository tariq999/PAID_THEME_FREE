<?php
// default search
get_template_part('template-parts/header/shared/search');
