<?php
// default site branding
get_template_part('template-parts/header/shared/site-branding');
